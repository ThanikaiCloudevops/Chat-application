export const MODULE = { NAME: 'User Auth Module', PORT: 5000 };
export const DB = {
  URL: 'mongodb+srv://super-league_user01:RiBA5Y8HUiDFUpEo@cluster-1.fehzk.mongodb.net/superleague?retryWrites=true&w=majority&appName=Cluster-1',
};

export const MSG91APIKEY = {
  MSG91_AUTH_KEY: '',
  MSG91_TEMPLATE_ID_SIGNUP: '',
  MSG91_TEMPLATE_ID_LOGIN: '',
};
export const TRPC = {
  // TRANSACTION: 'http:/{devip}:5005/trpc/wallet',
  // USERMODULE: 'http://{devip}:5004/trpc/userprofile',
  TRANSACTION: 'http://localhost:5005/trpc/wallet',
  USERMODULE: 'http://localhost:5004/trpc/userprofile',
};

export const GOOGLE = {
  CLIENT_ID: '',
  CLIENT_SECRET: '',
};

export const FACEBOOK = {
  APP_ID: '',
  APP_SECRET: '',
  verifyURL: 'https://graph.facebook.com/me?fields=id,name,email&access_token',
};

export const APPLE = {
  clientId: '',
};

export const AWS = {
  AWS_ACCESSKEY: '',
  AWS_SECRET: '',
  S3_REGION: '',
  S3_BUCKET: '',
  SES: {
    SES_REGION: 'us-east-1',
    AWS_ACCESSKEY: 'AKIA4CDUU23WS6NHWFVJ',
    AWS_SECRET: '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',
    MAIL: 'dev2@sciflare.com',
    IAM_USER_NAME: '',
    SMTP_USER_NAME: '',
    SMTP_PASSWORD: '',
  },
};
