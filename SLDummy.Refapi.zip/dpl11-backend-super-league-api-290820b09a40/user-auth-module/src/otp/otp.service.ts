// msg91.service.ts
import { MSG91APIKEY } from 'config/envirnment';
import { Injectable } from '@nestjs/common';

@Injectable()
export class Msg91OtpService {
  private readonly apiKey: string;
  private readonly baseUrl: string;
  private readonly verifyUrl: string;
  constructor() {
    this.apiKey = MSG91APIKEY.MSG91_AUTH_KEY;
    this.baseUrl = 'https://control.msg91.com/api/v5/otp';
    this.verifyUrl = 'https://control.msg91.com/api/v5/otp/verify';
  }

  async sendOTP(phoneNumber: string, template: string): Promise<void> {
    const headers = {
      'Content-Type': 'application/json',
      authkey: this.apiKey,
    };
    const data = {
      template_id:
        template === 'login'
          ? MSG91APIKEY.MSG91_TEMPLATE_ID_LOGIN
          : MSG91APIKEY.MSG91_TEMPLATE_ID_SIGNUP,
      mobile: '91' + phoneNumber,
      otp_length: 6,
      otp_expiry: 1,
    };
    const otpRequest = await fetch(this.baseUrl, {
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        authkey: this.apiKey,
      },
      method: 'POST',
      body: JSON.stringify(data),
    });
    return otpRequest.json();
  }

  async verifyOTP(phoneNumber: string, otp: string): Promise<void> {
    const mobile = '91' + phoneNumber;
    const otpRequest = await fetch(
      `${this.verifyUrl}?mobile=${mobile}&otp=${otp}&otp_expiry=1`,
      {
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          authkey: this.apiKey,
        },
        method: 'GET',
      },
    );
    return otpRequest.json();
  }
}
