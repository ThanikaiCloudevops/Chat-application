import { Controller, Get, Post, Body, HttpCode } from '@nestjs/common';
import { InviteService } from './invite.service';

@Controller('invite')
export class InviteController {
  constructor(private readonly inviteService: InviteService) {}

  @Post()
  @HttpCode(200)
  create(@Body() body: any) {
    return this.inviteService.sendAppLink(body.email);
  }

  @Get('points')
  @HttpCode(200)
  getPoints() {
    return this.inviteService.getPoints();
  }
}
