import { Module } from '@nestjs/common';
import { InviteService } from './invite.service';
import { InviteController } from './invite.controller';
import { mailSender } from 'src/helpers/ses.mail.helper';
import { MongooseModule } from '@nestjs/mongoose';
import { Point, PointsSchema } from 'src/user/entities/point.entity';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: Point.name, schema: PointsSchema }]),
  ],
  controllers: [InviteController],
  providers: [InviteService, mailSender],
})
export class InviteModule {}
