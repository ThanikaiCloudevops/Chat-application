import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import graphqlTypeJson from 'graphql-type-json';

@ObjectType()
export class message {
  @Field({ nullable: true, defaultValue: '' })
  message: string;
  @Field({ nullable: true, defaultValue: '' })
  location: string;
}

@ObjectType()
class dataFields {
  @Field({ nullable: true, defaultValue: '' })
  token: string;
  @Field({ nullable: true, defaultValue: '' })
  user_id: string;
  @Field({ nullable: true, defaultValue: '' })
  email: string;
  @Field({ nullable: true })
  profileStatus: boolean;
  @Field({ nullable: true })
  registered: boolean;
  @Field({ nullable: true })
  emailSet: boolean;
  @Field({ nullable: true, defaultValue: '' })
  deviceToken: string;
}

@ObjectType()
export class defaultFields {
  @Field()
  status: boolean;

  @Field({ nullable: true })
  error: message;

  @Field({ nullable: true })
  success: message;
}

@ObjectType()
export class defaultFields2 {
  @Field()
  status: boolean;

  @Field({ nullable: true })
  error: message;

  @Field({ nullable: true })
  success: message;
}

@ObjectType()
export class JsonResponse extends PartialType(defaultFields) {
  @Field({ nullable: true })
  data?: dataFields;
}

@ObjectType()
export class pointsResponse extends PartialType(defaultFields) {
  @Field(() => graphqlTypeJson, { defaultValue: [] })
  data: any;
}

@ObjectType()
export class referralsList {
  @Field({ nullable: true, defaultValue: '' })
  userName: string;
  @Field({ nullable: true, defaultValue: '' })
  amount: number;
}
@ObjectType()
export class referralFields {
  @Field({ defaultValue: '' })
  userName: string;
  @Field({ defaultValue: '' })
  amount: number;
  @Field({ defaultValue: '' })
  referralCode: string;
  @Field(() => [referralsList], { nullable: true })
  referrals: referralsList[];
}

@ObjectType()
export class ReferralResponse extends PartialType(defaultFields2) {
  @Field({ nullable: true })
  data?: referralFields;
}

// an optional type //data?: Prettify<dataFields>;
export type Prettify<T> = {
  [K in keyof T]: T[K];
} & object;
