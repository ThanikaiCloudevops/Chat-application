const successMsg = {
  proceed: 'Email/Phone not registered yet',
  AlreadyExist: 'Email/Phone already exist',
  registered: 'User registered successfully',
  loggedin: 'Login successful',
  passwordChanged: 'Password changed successfully',
  userUpdated: 'User Updated successfully',
  retrieved: 'User retrieved successfully',
  otpgeneration: 'OTP has been sent to your phone',
  otpsent: 'OTP has been sent',
  update: 'User updated successfully',
  password: 'Password updated successfully',
  email: 'Email verified successfully',
  app: 'App link sent successfully',
  fcm: 'FCM token upated successfully',
  logout: 'User logout successfully',
  ForgotPassword: 'Mail sent successfully',
  otpVerify: 'OTP verified successfully',
  referral: 'Referal list retrieved successfully',
  found: 'Data found',
  userName: 'Username is valid',
  meta: 'Meta-data successful',
  auth: 'Token valid',
};
export function successResponse(msg: string, data: any = null) {
  return { status: true, success: { message: successMsg[msg] }, data };
}
