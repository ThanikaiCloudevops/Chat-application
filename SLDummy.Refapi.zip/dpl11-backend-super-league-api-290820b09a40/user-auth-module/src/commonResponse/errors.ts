import { GraphQLError } from 'graphql';

const errorMsg = {
  unAuth: 'User UnAuthendicated',
  proceed: 'Email not registered yet',
  EmailAlreadyExist: 'Email already registered',
  IncorrectEmail: 'Email not registered',
  IncorrectPhone: 'Incorrect Phone',
  Incorrect: 'Incorrect Phone/Email',
  IncorrectPassword: 'Incorrect Email/Password',
  InvalidOTP: 'Invalid OTP',
  PasswordMandatory: 'Password is required',
  invalidUser: 'Email/Mobile not registered yet',
  phoneExist: 'Mobile number already registered',
  emailExist: 'Email already registered',
  retrieved: 'No users found',
  NotaNumber: 'Not a Valid number',
  required: 'Fill the required fields',
  OTPExp: 'OTP expired',
  password: 'Cannot set password',
  emailerror: 'Error updating email',
  invalidReferral: 'Invalid invite code',
  fcm: 'Unable to set FCM token',
  logout: 'Unable to logout',
  forgotEmail: 'not registered yet',
  state: 'Data not found',
  InvalidEmail: 'Invalid Email',
  username: 'Username Already Exists',
  block: 'Your account is blocked contact support',
  auth: 'Invalid auth token',
};
export function commonErrors(errorType: string, data: any = null) {
  return { status: false, error: { message: errorMsg[errorType] }, data };
}
export function handleException(error) {
  throw new GraphQLError(error, {
    extensions: {
      code: 'FORBIDDEN',
    },
  });
}
