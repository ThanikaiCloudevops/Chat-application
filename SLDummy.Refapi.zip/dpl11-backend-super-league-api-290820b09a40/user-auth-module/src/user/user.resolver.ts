import { Resolver, Query, Mutation, Args, Context } from '@nestjs/graphql';
import { UserService } from './user.service';
import { UserRes } from './entities/user.entity';
import {
  JsonResponse,
  defaultFields,
  referralFields,
  ReferralResponse,
  defaultFields2,
  pointsResponse,
} from 'src/commonResponse/response.entity';

import {
  checkEmail,
  loginViaEmail,
  loginViaMobile,
  registerViaEmail,
  verifyEmail,
  verify_OTP,
  ForgotPassword,
  ForgotPasswordVerify,
} from './dto/login-user.input';
import { AuthGuard } from 'src/auth/auth.guard';
import { UseGuards } from '@nestjs/common';
import { updatePhoneEmail } from './dto/update-user.input';

@Resolver(() => UserRes)
export class UserResolver {
  constructor(private readonly userService: UserService) {}

  // check Email is exist
  @Query(() => JsonResponse, { name: 'isPhoneExist' })
  isPhoneExist(@Args('input') input: checkEmail) {
    return this.userService.isPhoneExist(input);
  }

  @Mutation(() => JsonResponse, { name: 'forgotPassword' })
  forgotPassword(@Args('input') input: ForgotPassword) {
    return this.userService.forgotPassword(input);
  }

  @Query(() => JsonResponse, { name: 'emailVerify' })
  @UseGuards(AuthGuard)
  emailVerify(@Args('otp') otp: number, @Context('user') user: any) {
    return this.userService.emailVerify(user._id, otp);
  }

  @Query(() => JsonResponse, { name: 'forgotPasswordVerify' })
  forgotPasswordVerify(@Args('input') input: ForgotPasswordVerify) {
    return this.userService.forgotPasswordVerify(input);
  }

  @Query(() => JsonResponse, { name: 'linkEmail' })
  @UseGuards(AuthGuard)
  linkEmail(@Args('email') email: string, @Context('user') user: any) {
    return this.userService.linkEmail(user._id, email);
  }

  // login With Mobile
  @Mutation(() => JsonResponse, { name: 'loginWithMobile' })
  loginWithMobile(@Args('input') loginInput: loginViaMobile) {
    return this.userService.loginWithMobile(loginInput);
  }

  // login With Email
  @Mutation(() => JsonResponse, { name: 'loginWithEmail' })
  loginWithEmail(
    @Args('input')
    loginInput: loginViaEmail,
  ) {
    return this.userService.loginWithEmail(loginInput);
  }

  // register with mobile
  @Mutation(() => JsonResponse, { name: 'registerWithMobile' })
  registerWithMobile(@Args('input') registerInput: loginViaMobile) {
    return this.userService.regsiterWithMobile(registerInput);
  }

  // register with Email
  @Mutation(() => JsonResponse, { name: 'registerWithEmail' })
  registerWithEmail(@Args('input') registerInput: registerViaEmail) {
    return this.userService.regsiterWithEmail(registerInput);
  }

  // verifyOTP
  @Mutation(() => JsonResponse, {
    name: 'verifyOTP',
    description: 'To verify the OTP',
  })
  verifyOTP(@Args('input') verifyOTP: verify_OTP) {
    return this.userService.OTPverify(verifyOTP);
  }

  @Mutation(() => JsonResponse, {
    name: 'verifyEmail',
    description: 'To verify the email ',
  })
  verifyEmail(@Args('input') verifyEmail: verifyEmail) {
    return this.userService.verifyEmail(verifyEmail);
  }

  @Query(() => JsonResponse, {
    name: 'setPassword',
    description: 'Setting password for the first time',
  })
  setPassword(
    @Args('deviceToken') deviceToken: string,
    @Args('password') password: string,
    @Args('referral') referral: string,
    @Args('userName') userName: string,
  ) {
    return this.userService.setUserPassword(
      deviceToken,
      password,
      referral,
      userName,
    );
  }

  // @Query(() => JsonResponse, {
  //   name: 'tes',
  //   description: 'Setting password for the first time',
  // })
  // testing(@Context('user') user: any) {
  //   return this.userService.testing(user);
  // }

  @Query(() => JsonResponse, {
    name: 'passwordSet',
  })
  passwordSet(
    @Args('token') token: string,
    @Args('password') password: string,
  ) {
    return this.userService.passwordSet(token, password);
  }

  @Query(() => JsonResponse, {
    name: 'addReferral',
    description: 'Adding referral for user',
  })
  @UseGuards(AuthGuard)
  addReferral(
    @Context('user') user: any,
    @Args('referral') referral: string,
    @Args('userName') userName: string,
  ) {
    return this.userService.referralAdd(user._id, referral, userName);
  }

  // social login
  @Mutation(() => JsonResponse, { name: 'socialAuth' })
  async socialAuth(@Args('token') token: string, @Args('type') type: number) {
    return this.userService.socialLogin(token, type);
  }

  @Query(() => JsonResponse, {
    name: 'updatePassword',
    description: 'To change user password',
  })
  @UseGuards(AuthGuard)
  updatePassword(
    @Context('user') user: any,
    @Args('password') password: string,
  ) {
    return this.userService.updatePassword(user['_id'], password);
  }

  @Mutation(() => JsonResponse, {
    name: 'updatePhoneEmail',
    description: 'To update user phone or email',
  })
  @UseGuards(AuthGuard)
  updatePhoneEmail(
    @Context('user') user: any,
    @Args('input') { phone, email }: updatePhoneEmail,
  ) {
    return this.userService.updatePhoneEmail(user['_id'], phone, email);
  }

  @Query(() => JsonResponse, {
    name: 'verifyUpdateOTP',
    description: 'To confirm validation in update user phone or email',
  })
  @UseGuards(AuthGuard)
  verifyUpdateOTP(
    @Context('user') user: any,
    @Args('phone') phone: boolean,
    @Args('otp') otp: string,
  ) {
    return this.userService.verifyUpdate(user['_id'], phone, otp);
  }

  // Get single User
  @Query(() => UserRes, {
    name: 'getOneUser',
    description: 'To get one user',
  })
  @UseGuards(AuthGuard)
  findOne(@Context('user') user: any) {
    return this.userService.findOne(user['_id']);
  }

  @Query(() => defaultFields)
  sendAppEmail(@Args('email') email: string) {
    return this.userService.sendAppLink(email);
  }

  @Query(() => pointsResponse)
  getPoints() {
    return this.userService.points();
  }

  @Query(() => String)
  testMail() {
    return this.userService.testMail();
  }

  @Query(() => UserRes)
  tokenVerify(@Args('token') token: string) {
    return this.userService.verifyMiddleware(token);
  }

  @Query(() => defaultFields, {
    name: 'setFCM',
    description: 'To set user FCM tokes',
  })
  @UseGuards(AuthGuard)
  setFCMToken(
    @Context('user') user: any,
    @Args('deviceType') deviceType: string,
    @Args('deviceToken') deviceToken: string,
  ) {
    return this.userService.setFCM(user['_id'], deviceType, deviceToken);
  }

  @Query(() => defaultFields, {
    name: 'logout',
    description: 'To logout user',
  })
  @UseGuards(AuthGuard)
  logout(@Context('user') user: any) {
    return this.userService.Logout(user._id);
  }

  @UseGuards(AuthGuard)
  @Query(() => ReferralResponse, { name: 'referralList' })
  referralList(@Context('user') user: any) {
    return this.userService.referralList(user);
  }

  @UseGuards(AuthGuard)
  @Query(() => defaultFields, { name: 'helpEmail' })
  helpEmail(
    @Context('user') user: any,
    @Args('email') email: string,
    @Args('description') description: string,
  ) {
    return this.userService.helpEmail(user, email, description);
  }

  @UseGuards(AuthGuard)
  @Mutation(() => JsonResponse, { name: 'metaDataDumping' })
  async metaDataDump(@Context('user') user: any) {
    // return this.userService.metaDataDump(user, userData);
  }

  @UseGuards(AuthGuard)
  @Query(() => defaultFields, { name: 'usernameUniqueCheck' })
  usernameUniqueCheck(
    @Context('user') user: any,
    @Args('userName') userName: string,
  ) {
    return this.userService.usernameUniqueCheck(user, userName);
  }
}
