import { InputType, Field, PartialType, OmitType } from '@nestjs/graphql';
import { IsEmail, Length, Matches } from 'class-validator';
// const mobileNumberRegex = /^(\+[0-9]{1,3}[- ]?)?[0-9]{9,10}$/;
@InputType()
export class loginUser {
  @Field()
  @Length(8, 12)
  phone: string;
  @Field({ nullable: true })
  @IsEmail()
  email?: string;
  @Field({ nullable: true })
  password?: string;
}

@InputType()
export class loginViaMobile {
  @Field()
  @Length(8, 12)
  phone: string;
}
@InputType()
export class loginViaEmail {
  @Field()
  // @IsEmail()
  email: string;

  @Field()
  deviceType: string;

  @Field()
  deviceToken: string;

  @Field({ nullable: false })
  // @Matches(/((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/)
  password: string;
}

@InputType()
export class registerViaEmail {
  @Field()
  // @IsEmail()
  email: string;
}

@InputType()
export class checkEmail extends PartialType(
  OmitType(loginViaEmail, [
    'password',
    'deviceToken',
    'deviceType',
    'email',
  ] as const),
) {
  @Field()
  @Length(8, 12)
  phone: string;
}
@InputType()
export class ForgotPassword
{
  @Field()
  @IsEmail()
  email: string;
}

@InputType()
export class ForgotPasswordVerify
{
  @Field()
  otp: string;
  @Field({ nullable: true })
  token?: string;
}


@InputType()
export class changePassword {
  @Field()
  @Matches(/((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/)
  newPassword: string;

  @Field()
  @Matches(/((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/)
  oldPassword: string;
}

@InputType()
export class verify_OTP {
  @Field()
  @Length(8, 12)
  phone: string;
  @Field()
  otp: string;
  @Field()
  isNew: boolean;
  @Field({ nullable: true })
  token?: string;
  @Field()
  deviceType: string;
  @Field()
  deviceToken: string;
}

@InputType()
export class verifyEmail {
  @Field()
  email: string;

  @Field()
  otp: string;

  @Field()
  token: string;

  @Field()
  deviceType: string;
  @Field()
  deviceToken: string;
}
