import { ObjectType, Field, PartialType, OmitType, Int } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { defaultFields } from 'src/commonResponse/response.entity';

export type userDocument = User & Document;

@ObjectType()
@Schema()
export class User {
  @Field()
  @Prop()
  email: string;
  @Field()
  @Prop()
  userName: string;
  @Field()
  @Prop()
  countryCode: string;
  @Field()
  @Prop()
  phone: string;
  @Field({ nullable: true })
  @Prop()
  OTP?: string;
  @Field({ nullable: true })
  @Prop()
  updateToken?: string;
  @Field()
  @Prop()
  deviceType: string;
  @Field()
  @Prop()
  authToken: string;
  @Field()
  @Prop()
  deviceToken: string;
  @Field()
  @Prop({ default: new Date() })
  createdat: Date;
  @Field()
  @Prop()
  deletedat: Date;
  @Field()
  @Prop()
  updatedat: Date;
  @Field()
  @Prop({ default: true })
  isactive: boolean;
  @Field()
  @Prop({ default: false })
  profileStatus: boolean;
  @Field()
  @Prop({ default: false })
  kycStatus: boolean;
  @Field({ defaultValue: false })
  @Prop({ default: false })
  panStatus: boolean;

  @Field()
  @Prop()
  password: string;
  @Field()
  @Prop()
  referral: string;
  @Field({ nullable: true })
  @Prop()
  ref_from?: string;
  @Field({ nullable: true })
  @Prop()
  is_ref?: string;
  @Field()
  @Prop()
  lastLoginTime: Date;

  @Prop()
  name?: string;
}

@ObjectType()
class userResponse extends PartialType(
  OmitType(User, [
    'deviceType',
    'authToken',
    'deviceToken',
    'createdat',
    'deletedat',
    'updatedat',
    'isactive',
    'password',
    'deviceType',
    'authToken',
    'OTP',
    'updateToken',
  ] as const),
) {
  @Field()
  _id: string;
}

@ObjectType()
export class UserRes extends PartialType(defaultFields) {
  @Field({ nullable: true })
  data: userResponse;
}
@ObjectType()
class paginatedPayload {
  @Field(() => Int)
  totalPage: number;
  @Field(() => Int)
  currentPage: number;
  @Field(() => [userResponse], { nullable: true })
  list: userResponse[];
}
@ObjectType()
export class usersCollectionFormat extends PartialType(defaultFields) {
  @Field({ nullable: true })
  data: paginatedPayload;
}

export const UserSchema = SchemaFactory.createForClass(User);
