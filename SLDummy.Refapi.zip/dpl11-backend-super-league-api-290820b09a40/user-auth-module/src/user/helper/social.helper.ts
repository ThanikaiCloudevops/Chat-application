import { Injectable } from '@nestjs/common';
import { OAuth2Client } from 'google-auth-library';
import verifyAppleToken from 'verify-apple-id-token';
import { GOOGLE, FACEBOOK, APPLE } from 'config/envirnment';

const client = new OAuth2Client(GOOGLE.CLIENT_ID, GOOGLE.CLIENT_SECRET);

@Injectable()
export class socialLoginHelper {
  constructor() {}

  async googleLogin(token: string) {
    try {
      const ticket = await client.verifyIdToken({
        idToken: token,
        audience: GOOGLE.CLIENT_ID,
      });
      return ticket.getPayload();
    } catch (err) {
      return {};
    }
  }

  async facebookLogin(token: string) {
    try {
      const verifyToken = await fetch(`${FACEBOOK.verifyURL}=${token}`);
      return await verifyToken.json();
    } catch (err) {
      return {};
    }
  }

  async appleLogin(token: string) {
    try {
      const jwtClaims = await verifyAppleToken({
        idToken: token,
        clientId: APPLE.clientId, // or ["app1ClientId", "app2ClientId"]
        // nonce: "nonce", // optional
      });

      return jwtClaims;
    } catch (err) {
      console.log(err);
      return {};
    }
  }
}
