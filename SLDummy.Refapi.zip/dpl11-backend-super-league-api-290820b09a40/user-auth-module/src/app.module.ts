import { Module } from '@nestjs/common';
import { GraphQLModule } from '@nestjs/graphql';
import { MongooseModule } from '@nestjs/mongoose';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import {
  ApolloFederationDriverConfig,
  ApolloFederationDriver,
} from '@nestjs/apollo';
import { UserModule } from './user/user.module';
import { TrpcModule } from './trpc/server/trpc.module';
import { DB } from 'config/envirnment';
import { InviteModule } from './invite/invite.module';
import { UserMetaModule } from './user-meta/user-meta.module';

@Module({
  imports: [
    MongooseModule.forRoot(DB.URL, {
      maxConnecting: 5,
      maxPoolSize: 5,
      connectTimeoutMS: 3000,
      socketTimeoutMS: 8000,
      maxIdleTimeMS: 10000,
    }),
    // GraphQLModule.forRoot<ApolloDriverConfig>({
    //   driver: ApolloDriver,
    //   autoSchemaFile: join(process.cwd(), 'schema.gql'),
    //   include: [UserModule],
    //   includeStacktraceInErrorResponses: false,
    //   sortSchema: true,
    // }),
    GraphQLModule.forRoot<ApolloFederationDriverConfig>({
      driver: ApolloFederationDriver,
      autoSchemaFile: {
        federation: 2,
      },
      includeStacktraceInErrorResponses: false,
    }),

    UserModule,
    TrpcModule,
    InviteModule,
    UserMetaModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
