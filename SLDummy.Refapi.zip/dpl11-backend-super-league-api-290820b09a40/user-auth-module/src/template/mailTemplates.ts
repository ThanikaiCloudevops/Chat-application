export const TEMPLATE = {
  INVITE: (name: string) => {
    return `<table width="600" align="center">
    <tr>
        <td align="center" style="background-color: #ededed">
            <img height="45" src="https://{superleaguedomain}.in/images/logo_main.png" alt="Logo">
        </td>
    </tr>
    <tr>
        <td align="center">
            <h5 style="margin-top: 1rem; margin-bottom: 1rem">Hello ${name}</h5>
            <table
                align="center"
                width="545"
                border="0"
                cellspacing="0"
                cellpadding="0"
            >
                <tbody>
                    <tr>
                        <td style="text-align: center">
                            Thank you for your interest in
                            <span style="color: #ed1b24">Super League</span>
                            , the
                            ultimate
                            <span style="color: #ed1b24">Fantasy Sports</span>
                            Experience!
                            We're excited to share that the download link for the Super League application is now ready for you.
                        </td>
                    </tr>
                    <tr>
                        <td cellspacing="3" style="text-align: center">
                            <p style="margin-top: 1rem; margin-bottom: 1rem">
                                To access the download, simply click on the link below:
                            </p>
                        </td>
                    </tr>
                    <table cellpadding="6" align="center">
                        <tbody>
                            <tr style="text-align: center">
                                <td width="5"></td>
                                <td style="
                      font-size: 1.3rem !important;
                      border-radius: 0.5rem;
                      background-color: #ed1b24 !important;
                      border-color: #ed1b24 !important;
                      transition: none !important;
                      box-shadow: none !important;
                      font-weight: 700;
                      line-height: 1.5;
                    ">
                                    <a style="text-decoration: none; color: #fff" href="#" target="_blank">
                                        Download
                                    </a>
                                </td>
                                <td width="5"></td>
                            </tr>
                        </tbody>
                    </table>
                    <table
                        align="center"
                        width="545"
                        border="0"
                        cellspacing="0"
                        cellpadding="0"
                        style="border-bottom: 1.5px solid #929292"
                    >
                        <tbody>
                            <tr>
                                <td align="center">
                                    <p style="
                        margin-top: 1rem;
                        margin-bottom: 1rem;
                        color: #545454;
                      ">
                                        Please Follow the on-screen instructions for a seamless
                                        installation & Enjoy the thrill of fantasy sports with
                                        Super League!
                                    </p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table
                        align="center"
                        width="335"
                        border="0"
                        cellspacing="0"
                        cellpadding="0"
                    >
                        <tbody>
                            <tr>
                                <td align="center">
                                    <img
                                        height="85"
                                        style="margin-top: 1rem;"
                                        src="https://{superleaguedomain}.us/mail-images/select-contest.png"
                                        alt="image"
                                    >
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: center">
                                    <p style="margin-top: 1rem; margin-bottom: 1rem">
                                        <strong>Select the contest</strong>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: center">
                                    <p style="margin-bottom: 1rem">
                                        Choose the specific contest you wish to join within that
                                        match.
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <img
                                        height="85"
                                        style="margin-top: 1rem;"
                                        src="https://{superleaguedomain}.us/mail-images/build-your-team%20(1).png"
                                        alt="image"
                                    >
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: center">
                                    <p style="margin-top: 1rem; margin-bottom: 1rem">
                                        <strong>Build Your Team</strong>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: center">
                                    <p style="margin-bottom: 1rem">
                                        Create your team by selecting players based on their
                                        performance and positions.
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <img
                                        height="85"
                                        style="margin-top: 1rem;"
                                        src="https://{superleaguedomain}.us/mail-images/enter-real-money.png"
                                        alt="image"
                                    >
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: center">
                                    <p style="margin-top: 1rem; margin-bottom: 1rem">
                                        <strong>Enter with Real Money</strong>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: center">
                                    <p style="margin-bottom: 1rem">
                                        Join the contest by entering with real money to compete
                                        against others.
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <img
                                        height="85"
                                        style="margin-top: 1rem;"
                                        src="https://{superleaguedomain}.us/mail-images/compete-prizes.png"
                                        alt="image"
                                    >
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: center">
                                    <p style="margin-top: 1rem; margin-bottom: 1rem">
                                        <strong>Compete for Prizes</strong>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: center">
                                    <p style="margin-bottom: 1rem">
                                        Get a chance to win exciting prizes based on your team's
                                        performance in the contest.
                                    </p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table align="center">
                        <tbody>
                            <tr>
                                <td cellspacing="3" style="text-align: center">
                                    <p style="margin-top: 1rem; margin-bottom: 1rem">
                                        <strong>
                                            If the download button doesn't work, copy and paste the below link in browser
                                        </strong>
                                        <br>
                                        <a href="https://{superleaguedomain}.us/appLinkRedirect.html" target="_blank">
                                            https://{superleaguedomain}.us/appLinkRedirect.html
                                        </a>
                                    </p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <!-- <table cellpadding="6" align="center">
                        <tbody>
                            <tr style="text-align: center">
                                <td style="
                      font-size: 1.3rem !important;
                      border-radius: 0.5rem;
                      background-color: #ed1b24 !important;
                      border-color: #ed1b24 !important;
                      transition: none !important;
                      box-shadow: none !important;
                      font-weight: 700;
                      line-height: 1.5;
                    ">
                                    <a style="text-decoration: none; color: #fff" href="https://{superleaguedomain}.us/appLinkRedirect.html">
                                        Download
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table> -->
                    <table
                        align="center"
                        width="545"
                        border="0"
                        cellspacing="0"
                        cellpadding="0"
                    >
                        <tbody>
                            <tr>
                                <td align="center">
                                    <p style="
                        margin-top: 1rem;
                        margin-bottom: 1rem;
                        color: #545454;
                      ">
                                        Please Follow the on-screen instructions for a seamless
                                        installation & Enjoy the thrill of fantasy sports with
                                        Super League!
                                    </p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </tbody>
            </table>
            <table align="center" style="background-color:  #e6e5e5" width="600">
                <tbody>
                    <tr>
                        <td align="center">
                            <p style="margin-top: 0.5rem; margin-bottom: 0.5rem; font-size: 0.8rem">
                                You are receiving this email as you have requested service from Super League
                            </p>
                        </td>
                    </tr>
                </tbody>
            </table>
            <table align="center" style="background-color:  #939393" width="600">
                <tbody>
                    <tr>
                        <td>
                            <table align="center" width="558">
                                <tfoot>
                                    <tr valign="top">
                                        <td>
                                            <img height="30" src="https://{superleaguedomain}.in/images/logo_main.png" alt="logo">
                                        </td>
                                        <td align="right">
                                            <p style="color: #fff">
                                                <small>
                                                    Super League Fantasy Sports
                                                    <br>
                                                    New York, USA
                                                    <br>
                                                    <a style="text-decoration: none; color: #fff" href="https://{superleaguedomain}.in/privacyPolicy.html">
                                                        Privacy Policy
                                                    </a>
                                                    /
                                                    <a style="text-decoration: none; color: #fff" href="https://{superleaguedomain}.in/terms-and-conditions.html">
                                                        Terms & Conditions
                                                    </a>
                                                    / Copyright 2024
                                                </small>
                                            </p>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
            <!-- <table align="center" style="background-color: #d9d9d9" width="600">
                <tbody>
                    <tr>
                        <td>
                            <table align="center" width="558">
                                <tfoot>
                                    <tr align="right">
                                        <td>
                                            <img height="23.7" src="https://{superleaguedomain}.in/images/icons/linkedin.svg" alt="linkedin">
                                            <img
                                                height="23.7"
                                                style="margin-left: 10px; margin-right: 10px"
                                                src="https://{superleaguedomain}.in/images/icons/instagram.svg"
                                                alt="insta"
                                            >
                                            <img height="23.7" src="https://{superleaguedomain}.in/images/icons/facebook.svg" alt="facebook">
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table> -->
        </td>
    </tr>
</table>
`;
  },
  OTP: (OTP: number) => {
    return `<table width="600" align="center">
    <tr>
        <td align="center" style="background-color: #ededed">
            <img height="45" src="https://{superleaguedomain}.in/images/logo_main.png" alt="Logo">
        </td>
    </tr>
    <tr>
        <td align="center">
            <big style="margin-top: 1rem; margin-bottom: 1rem">Hello</big>
            <table
                align="center"
                width="559"
                border="0"
                cellspacing="10"
                cellpadding="0"
            >
                <tbody>
                    <tr>
                        <td style="text-align: center">
                            Thank you for choosing
                            <span style="color: #ed1b24">Super League</span>
                        </td>
                    </tr>
                    <tr>
                        <td cellspacing="3" style="text-align: center">
                            To ensure the security of your Super League account, we
              need to verify your identity using a one-time password (OTP).
                        </td>
                    </tr>
                    <table cellpadding="6">
                        <tbody>
                            <tr style="text-align: center">
                                <td style="color: #929292">
                                    Please use the following OTP code to complete the
                  verification process:
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table
                        align="center"
                        width="250"
                        border="0"
                        cellspacing="10"
                        cellpadding="5"
                    >
                        <tbody>
                            <tr>
                            ${OTP}
                                <td align="center" style="background-color: #fac6c8; border-radius: 6px" width="25">
                                    <!-- 6
                                </td>
                                <td align="center" style="background-color: #fac6c8; border-radius: 6px" width="25">
                                    6
                                </td>
                                <td align="center" style="background-color: #fac6c8; border-radius: 6px" width="25">
                                    6
                                </td>
                                <td align="center" style="background-color: #fac6c8; border-radius: 6px" width="25">
                                    6
                                </td>
                                <td align="center" style="background-color: #fac6c8; border-radius: 6px" width="25">
                                    6
                                </td>
                                <td align="center" style="background-color: #fac6c8; border-radius: 6px" width="25">
                                    6 --></td>
                            </tr>
                        </tbody>
                    </table>
                    <table align="center" width="559">
                        <tbody>
                            <tr>
                                <td cellspacing="3" style="text-align: center">
                                    <p style="margin-top: 1rem; margin-bottom: 1rem">
                                        Kindly enter this OTP code within the specified time
                    limit to confirm your account.
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <small style="color: #545454">
                                        If you haven't requested this OTP or have any concerns
                    regarding your account's security, please reach out to
                    our support team immediately.
                                    </small
                  >
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </tbody>
            </table>
            <table align="center" style="background-color: #939393" width="600">
                <tbody>
                    <tr>
                        <td>
                            <table align="center" width="558">
                                <tfoot>
                                    <tr valign="top">
                                        <td>
                                            <img height="30" src="https://{superleaguedomain}.in/images/logo_main.png" alt="logo">
                                        </td>
                                        <td align="right">
                                            <p style="color: #fff">
                                                <small>
                                                    Super League Fantasy Sports
                                             
                                                    <a style="text-decoration: none; color: #fff" href="https://{superleaguedomain}.in/privacyPolicy.html">
                                                        Privacy Policy
                                                    </a
                          >
                                                    /
                                                    <a style="text-decoration: none; color: #fff" href="https://{superleaguedomain}.in/terms-and-conditions.html">
                                                        Terms & Conditions
                                                    </a
                          >
                                                    / Copyright 2024
                                                </small>
                                            </p>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
            <table align="center" style="background-color: #d9d9d9" width="600">
                <tbody>
                    <tr>
                        <td>
                            <table align="center" width="558">
                                <tfoot>
                                    <tr align="right">
                                        <td>
                                            <img height="23.7" src="https://{superleaguedomain}.in/images/icons/linkedin.svg" alt="twitter">
                                            <img
                                                height="23.7"
                                                style="margin-left: 10px; margin-right: 10px"
                                                src="https://{superleaguedomain}.in/images/icons/instagram.svg"
                                                alt="insta"
                                            >
                                            <img height="23.7" src="https://{superleaguedomain}.in/images/icons/facebook.svg" alt="fb">
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </td>
                    </tr>
                </tbody>
            </table>
        </td>
    </tr>
</table>
`;
  },
  HELPEMAIL: (email: string, username: string, description: string) => {
    return `Hi Super League Team, this mail is from user: ${username} and email id: ${email}
    Subject is ${description}`;
  },
};
