import { SES } from 'aws-sdk';
import { AWS } from '../../config/envirnment';
import { Injectable } from '@nestjs/common';
import { SendEmailRequest } from 'aws-sdk/clients/ses';

const SES_CONFIG = {
  accessKeyId: AWS.SES.AWS_ACCESSKEY,
  secretAccessKey: AWS.SES.AWS_SECRET,
  region: AWS.SES.SES_REGION,
};
const AWS_SES = new SES(SES_CONFIG);

@Injectable()
export class mailSender {
  constructor() {}

  async sendEmail(toMail: string[], subject: string, bodyHtml: string) {
    try {
      const emailParams: SendEmailRequest = {
        Source: AWS.SES.MAIL,
        Destination: {
          ToAddresses: toMail,
        },
        Message: {
          Body: {
            Html: {
              Data: bodyHtml,
            },
          },
          Subject: { Data: subject },
        },
      };

      const res = await AWS_SES.sendEmail(emailParams).promise();
      console.log(res);
      return res;
    } catch (err) {
      console.log(err);
      return err;
    }
  }

  async readMail() {
    try {
      await AWS_SES.getTemplate().promise();

      return 'Success';
    } catch (err) {
      console.log(err);
      return 'Failed';
    }
  }
}
