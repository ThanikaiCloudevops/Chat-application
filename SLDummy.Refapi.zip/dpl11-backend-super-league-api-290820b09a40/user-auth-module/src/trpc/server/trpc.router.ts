import { INestApplication, Injectable } from '@nestjs/common';
import { z } from 'zod';
import { TrpcService } from './trpc.service';
import * as trpcExpress from '@trpc/server/adapters/express';
import { AuthService } from 'src/auth/auth.service';
import { UserService } from 'src/user/user.service';

@Injectable()
export class TrpcRouter {
  constructor(
    private readonly trpc: TrpcService,
    private auth: AuthService,
    private userService: UserService,
  ) {}

  appRouter = this.trpc.router({
    verify: this.trpc.procedure
      .input(
        z.object({
          token: z.string(),
        }),
      )
      .query(async ({ input }) => {
        try {
          // const isVerified = this.auth.verifyToken(input.token);
          const isVerified = await this.userService.verifyMiddleware(
            input.token,
          );
          return isVerified && isVerified;
        } catch (error) {
          return false;
        }
      }),

    profilestatus: this.trpc.procedure
      .input(
        z.object({
          request: z.any(),
        }),
      )
      .query(({ input }) => {
        return this.userService.updateUserProfile(input?.request);
      }),

    getuserbyphone: this.trpc.procedure
      .input(
        z.object({
          request: z.any(),
        }),
      )
      .query(({ input }) => {
        return this.userService.getUserbyPhone(input?.request?.phone);
      }),
  });

  async applyMiddleware(app: INestApplication) {
    app.use(
      `/trpc/userauth`,
      trpcExpress.createExpressMiddleware({
        router: this.appRouter,
      }),
    );
  }
}

export type AppRouter = TrpcRouter[`appRouter`];
