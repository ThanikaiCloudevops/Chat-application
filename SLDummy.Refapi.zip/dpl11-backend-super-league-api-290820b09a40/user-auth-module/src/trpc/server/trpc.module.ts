import { Module } from '@nestjs/common';
import { TrpcService } from './trpc.service';
import { TrpcRouter } from './trpc.router';
import { AuthService } from 'src/auth/auth.service';
import { MongooseModule } from '@nestjs/mongoose';
import { User, UserSchema } from 'src/user/entities/user.entity';
import { UserService } from 'src/user/user.service';
import { trpcServices } from '../client/trpc';
import { socialLoginHelper } from 'src/user/helper/social.helper';
import { mailSender } from 'src/helpers/ses.mail.helper';
import { Msg91OtpService } from 'src/otp/otp.service';
import { Point, PointsSchema } from 'src/user/entities/point.entity';
import { InviteService } from 'src/invite/invite.service';
@Module({
  imports: [
    MongooseModule.forFeature([{ name: User.name, schema: UserSchema }]),
    MongooseModule.forFeature([{ name: Point.name, schema: PointsSchema }]),
  ],
  controllers: [],
  providers: [
    TrpcService,
    TrpcRouter,
    AuthService,
    UserService,
    trpcServices,
    socialLoginHelper,
    mailSender,
    Msg91OtpService,
    InviteService,
  ],
})
export class TrpcModule {}
