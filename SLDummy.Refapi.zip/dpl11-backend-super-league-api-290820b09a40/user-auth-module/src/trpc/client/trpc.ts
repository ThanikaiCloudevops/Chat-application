import { Injectable } from '@nestjs/common';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import { initTRPC, TRPCError } from '@trpc/server';
import { TRPC } from 'config/envirnment';
import fetch from 'node-fetch';

const globalAny = global as any;
globalAny.AbortController = AbortController;
globalAny.fetch = fetch;

export const transaction = createTRPCProxyClient({
  links: [httpBatchLink({ url: TRPC.TRANSACTION })],
});
export const userProfile = createTRPCProxyClient({
  links: [httpBatchLink({ url: TRPC.USERMODULE })],
});
@Injectable()
export class trpcServices {
  async walletCreation(urlKey: string, payload: any) {
    try {
      return await transaction[urlKey].query({
        request: payload,
      });
    } catch (err) {
      console.log(err);
    }
  }
  async userProfile(urlKey: string, payload: any) {
    return await userProfile[urlKey].query({
      request: payload,
    });
  }

  async walletUpdation(urlKey: string, payload: any) {
    try {
      return await transaction[urlKey].query({
        request: payload,
      });
    } catch (err) {
      console.log(err);
    }
  }

  async transactionupdate(urlKey: string, payload: any) {
    try {
      return await transaction[urlKey].query({
        request: payload,
      });
    } catch (err) {
      console.log(err);
    }
  }

  async transactions(urlKey: string, payload: any) {
    try {
      return await transaction[urlKey].query({
        request: payload,
      });
    } catch (err) {
      if (err instanceof TRPCError) {
        console.error('tRPC Error:', err);
      } else {
        console.error('Unexpected errorr:', err);
      }
      throw err;
    }
  }

  async getWallet(urlKey: string, payload: any) {
    try {
      return await transaction[urlKey].query({
        request: payload,
      });
    } catch (err) {
      console.log(err);
    }
  }
}
