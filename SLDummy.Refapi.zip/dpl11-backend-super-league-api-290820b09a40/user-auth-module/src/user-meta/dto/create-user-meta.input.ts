import { InputType, Field } from '@nestjs/graphql';
import graphqlTypeJson from 'graphql-type-json';

@InputType()
export class CreateUserMetaInput {
  @Field()
  metaType: string;

  @Field(() => graphqlTypeJson)
  metadata: any;
}
