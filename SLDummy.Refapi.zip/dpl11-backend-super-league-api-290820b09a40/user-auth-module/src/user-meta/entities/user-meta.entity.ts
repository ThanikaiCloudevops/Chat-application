import { ObjectType, Field, Int } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import graphqlTypeJson from 'graphql-type-json';

export type UserMetaDocument = UserMeta & Document;

@ObjectType()
@Schema()
export class UserMeta {
  @Field()
  @Prop()
  userId: string;

  @Field()
  @Prop()
  metaType: string;

  @Field(() => graphqlTypeJson)
  @Prop({ type: Object })
  metadata: any;

  @Prop()
  createdAt: Date;
}

export const UserMetachema = SchemaFactory.createForClass(UserMeta);
