import { Module } from '@nestjs/common';
import { UserMetaService } from './user-meta.service';
import { UserMetaResolver } from './user-meta.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import { UserMeta, UserMetachema } from './entities/user-meta.entity';
import { AuthService } from 'src/auth/auth.service';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: UserMeta.name, schema: UserMetachema }]),
  ],
  providers: [UserMetaResolver, UserMetaService, AuthService],
})
export class UserMetaModule {}
