export const MODULE = { NAME: 'Master', PORT: 3000 };

export const userAuth = {
  // graphUrl: 'http://{devip}:5000/graphql',
  graphUrl: 'http://localhost:5000/graphql',
};

export const SUBGRAPH = [
  {
    name: 'user-auth',
    // url: 'http://{devip}:5000/graphql',
    url: 'http://localhost:5000/graphql',
  },
  {
    name: 'game-module',
    // url: 'http://{devip}:5001/graphql',
    url: 'http://localhost:5001/graphql',
  },
  {
    name: 'contest-module',
    // url: 'http://{devip}:5002/graphql',
    url: 'http://localhost:5002/graphql',
  },
  {
    name: 'user-module',
    // url: 'http://{devip}:5004/graphql',
    url: 'http://localhost:5004/graphql',
  },

  {
    name: 'scorecard-contest',
    // url: 'http://{devip}:4000/graphql',
    url: 'http://localhost:4000/graphql',
  },
  {
    name: 'wallet-module',
    // url: 'http://{devip}:5005/graphql',
    url: 'http://localhost:5005/graphql',
  },
  {
    name: 'masterData-module',
    // url: 'http://{devip}:5080/graphql',
    url: 'http://localhost:5080/graphql',
  },
];
