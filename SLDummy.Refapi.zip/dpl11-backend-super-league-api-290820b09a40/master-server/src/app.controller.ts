import { Controller, Get, Post, Req } from '@nestjs/common';
import { AppService } from './app.service';
import { userAuth } from 'config/envirnment';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @Get('points')
  async pointsSystem() {
    try {
      const res = await fetch(userAuth.graphUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: `{
                getPoints {
                            status
                            error {
                                 message
                                    }
                            success {
                                  message
                                    }
                             data
                        }
                    }`,
        }),
      });
      const data = await res.json();
      return data;
    } catch (err) {
      return {
        data: {
          getPoints: {
            status: true,
            error: null,
            success: {
              message: 'Data found',
            },
            data: [],
          },
        },
      };
    }
  }
}
