export const MODULE = { NAME: 'Score Card Module', PORT: 4000 };
export const DB = {
  URL: 'mongodb+srv://super-league_user01:RiBA5Y8HUiDFUpEo@cluster-1.fehzk.mongodb.net/superleague?retryWrites=true&w=majority&appName=Cluster-1',
};

export const TRPC = {
  //dev
  /* USERAUTH: 'http://{devip}:5000/trpc/userauth',
  CRICKETGAME: 'http://{devip}:5001/trpc/game', */

  // Local
  USERAUTH: 'http://localhost:5000/trpc/userauth',
  CRICKETGAME: 'http://localhost:5001/trpc/game',
};
