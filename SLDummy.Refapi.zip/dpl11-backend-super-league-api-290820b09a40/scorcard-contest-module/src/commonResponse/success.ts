const successMsg = {
  getallcontets: 'Get all Contests',
  teamCreated: 'Team created successfully',
  retrived: 'Data retrived successfully',
};
export function successResponse(msg: string, data: any = null) {
  return { status: true, success: { message: successMsg[msg] }, data };
}
