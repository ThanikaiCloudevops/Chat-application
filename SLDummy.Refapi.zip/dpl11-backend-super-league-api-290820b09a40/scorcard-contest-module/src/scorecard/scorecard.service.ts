import { Inject, Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { scorecardDocument, scorecards } from './entities/scorecard.entity';
import { successResponse } from 'src/commonResponse/success';
import { CommentryDocument } from './entities/commentary.entity';
import { commonErrors } from 'src/commonResponse/errors';
import {
  playerPerformanceDocument,
  playerPoint,
  playerPointStats,
} from './entities/playerPerformance.entity';
import { trpcServices } from 'src/trpc/client/trpc';
import { FootballPlayerPointsDocument } from './entities/football-playerperformance.entity';
import { footballScorecardDocument } from './entities/football-scorecard.entity';
import { FootballCommentaryDocument } from './entities/football-commentry.entity';
import {
  KabaddiScorecard,
  kabaddiScorecardDocument,
} from './entities/kabaddi-scorecard.entity';
import { KabaddiPlayerPerformanceDocument } from './entities/kabaddi-playerperformance.entity';
import { CACHE_MANAGER, Cache } from '@nestjs/cache-manager';

@Injectable()
export class ScorecardService {
  constructor(
    @InjectModel('scorecards') private scoreCardModel: Model<scorecardDocument>,
    @InjectModel('commentries')
    private commentaryModel: Model<CommentryDocument>,
    @InjectModel('playerPerformance')
    private playerPerformanceModel: Model<playerPerformanceDocument>,
    @InjectModel('FootballPlayerPerformance')
    private footballPlayerPerformanceModel: Model<FootballPlayerPointsDocument>,
    @InjectModel('FootballScorecard')
    private footballScorecardModel: Model<footballScorecardDocument>,
    @InjectModel('KabaddiPlayerPerformance')
    private kabaddiPlayerPerformanceModel: Model<KabaddiPlayerPerformanceDocument>,
    @InjectModel('KabaddiScorecard')
    private kabaddiScorecardModel: Model<kabaddiScorecardDocument>,
    @InjectModel('FootballCommentary')
    private footballcommentariesModel: Model<FootballCommentaryDocument>,
    private trpcService: trpcServices,
    @Inject(CACHE_MANAGER) private cacheManager: Cache,
  ) {}

  async scoreCardGetData(fixtureAPIId: number) {
    const key = `cricket_scorecard_${fixtureAPIId}`;
    let data;
    const scorecard = await this.cacheManager.get(key);
    if (scorecard) data = scorecard;
    else {
      data = await this.scoreCardModel
        .findOne({
          fixtureAPIId,
        })
        .lean();
      if (data) await this.cacheManager.set(key, data, 60000);
    }

    if (!data) return commonErrors('scorecard');

    return successResponse('retrived', data);
  }

  async kabaddiscoreCardData(fixtureAPIId: number) {
    const key = `kabaddi_scorecard_${fixtureAPIId}`;
    const cacheCheck = await this.cacheManager.get(key);
    if (cacheCheck) return successResponse('retrived', cacheCheck);
    const data: KabaddiScorecard = await this.kabaddiScorecardModel
      .findOne({
        fixtureAPIId,
      })
      .lean();
    if (!data) return commonErrors('scorecard');
    const keyNameMapping = {
      totalpoint: 'Total Points',
      alloutpoint: 'Allout Points',
      extrapoint: 'Extra Points',
      declarepoint: 'Declare Points',
      raidtotalpoint: 'Total Raid Points',
      raidtouchpoint: 'Raid Touch Points',
      raidbonuspoint: 'Raid Bonus Points',
      tackletotalpoint: 'Total Tackle Points',
      tacklecapturepoint: 'Tackle Capture Points',
      tacklecapturebonuspoint: 'Tackle Capture Bonus Points',
      raidtotal: 'Total Raids',
      raidsuccessful: 'Successful Raids',
      raidunsuccessful: 'Unsuccessful Raids',
      raidempty: 'Empty Raid',
      superraid: 'Super Raid',
      tackletotal: 'Total Tackles',
      tacklesuccessful: 'Successful Tackles',
      tackleunsuccessful: 'Unsuccessful Tackles',
      supertackles: 'Super Tackles',
      allouts: 'Allout',
      declare: 'Declare',
    };
    const gameStatsArray = Object.keys(data['gameStats']['home'])?.map(
      (key) => ({
        home: data['gameStats']['home'][key] || 0,
        away: data['gameStats']['away'][key] || 0,
        name: keyNameMapping[key] || '',
      }),
    );

    data['gameStats'] = gameStatsArray;
    const playerPerformaces = await this.kabaddiPlayerPerformanceModel
      .findOne({ fixtureAPIId })
      .lean();
    const groupByplayerStats = playerPerformaces['playerStats'].reduce(
      (group, playerStats) => {
        const { side } = playerStats;
        group[side] = group[side] ?? [];
        group[side].push(playerStats);
        return group;
      },
      {},
    );
    data['playerStats'] = {
      home: groupByplayerStats['home'] || [],
      away: groupByplayerStats['away'] || [],
    };
    await this.cacheManager.set(key, data, 60000);
    return successResponse('retrived', data);
  }

  async footballScorecard(fixtureAPIId: number) {
    const key = `football_scorecard_${fixtureAPIId}`;
    const cacheCheck = await this.cacheManager.get(key);
    if (cacheCheck) return successResponse('retrived', cacheCheck);

    const data = await this.footballScorecardModel
      .findOne({ fixtureAPIId })
      .lean();
    if (!data || !data.gameStats) {
      return commonErrors('scorecard');
    }
    data['ballpossession'] =
      data['gameStats']?.find((res) => res?.name === 'Ball possession') || null;
    data.result['result_str'] =
      (data?.teams[data?.result.winner]?.name
        ? `${data?.teams[data?.result.winner]?.name} Won `
        : `Match Draw`) + ` ${data?.result.away}-${data?.result.home}`;
    if (!data) return commonErrors('scorecard');
    this.cacheManager.set(key, data, 60000);

    return successResponse('retrived', data);
  }

  async getCommentaryData(fixtureAPIId: number, page: number = 1) {
    try {
      const data = await this.commentaryModel.findOne({ fixtureAPIId }).lean();
      if (!data) return commonErrors('retrived');
      data.commentaries = data.commentaries.slice((page - 1) * 30, page * 30);
      return successResponse('retrived', data);
    } catch (error) {
      console.log(error);
      return commonErrors('retrived');
    }
  }

  async getFootballCommentaryData(fixtureAPIId: number, page: number = 1) {
    try {
      const data = await this.footballcommentariesModel
        .findOne({
          fixtureAPIId,
        })
        .lean();

      if (!data) return commonErrors('retrived');
      data.commentary = data.commentary.slice((page - 1) * 30, page * 30);
      return successResponse('retrived', data);
    } catch (error) {
      console.log(error);
      return commonErrors('retrived');
    }
  }

  async playerPerformaces(
    playerAPIId: number,
    teamAPIId: number,
    sereisAPIId: number,
  ) {
    try {
      const response = [];
      let playerTotalPoints: number = 0;
      const previousFixtures = await this.scoreCardModel
        .find({
          $or: [
            { 'teams.teamA.teamAPIId': teamAPIId },
            { 'teams.teamB.teamAPIId': teamAPIId },
          ],
          sereisAPIId,
        })
        .sort({ fixtureAPIId: -1 })
        .limit(5)
        .select(['fixtureAPIId', 'teams', 'toss', '-_id'])
        .lean();
      const fixtureAPIIds = previousFixtures.map((e) => e.fixtureAPIId);
      const playerPerformances = (
        await this.playerPerformanceModel.aggregate([
          { $match: { fixtureAPIId: { $in: fixtureAPIIds } } },
          {
            $project: {
              playerPoint: {
                $filter: {
                  input: '$playerPoint',
                  as: 'playerPoints',
                  cond: { $eq: ['$$playerPoints.player_id', playerAPIId] },
                },
              },
              fixtureAPIId: 1,
            },
          },
        ])
      ).reduce((total, value) => {
        const playerPoint = value?.playerPoint[0];
        playerTotalPoints += playerPoint?.point || 0;
        if (!total[value.fixtureAPIId])
          total[value.fixtureAPIId] = {
            totalPoints: 0,
            batPoints: 0,
            bowlPoints: 0,
            otherPoints: 0,

            playerName: playerPoint?.player_name || '',
          };

        if (playerPoint) {
          total[value.fixtureAPIId].totalPoints += playerPoint?.point || 0;
          total[value.fixtureAPIId].batPoints +=
            (playerPoint?.run || 0) +
            (playerPoint?.four || 0) +
            (playerPoint?.six || 0) +
            (playerPoint?.fifty || 0) +
            (playerPoint?.duck || 0) +
            (playerPoint?.strike_rate || 0) +
            (playerPoint?.thirty || 0);
          total[value.fixtureAPIId].bowlPoints +=
            (playerPoint?.wickets || 0) +
            (playerPoint?.maidenover || 0) +
            (playerPoint?.economic_rate || 0) +
            (playerPoint?.bonus || 0) +
            (playerPoint?.bonus_bowedlbw || 0);
          total[value.fixtureAPIId].otherPoints +=
            (playerPoint?.catch || 0) +
            (playerPoint?.runout_stumping || 0) +
            (playerPoint?.runout_thrower || 0) +
            (playerPoint?.runout_catcher || 0) +
            (playerPoint?.stumping || 0) +
            (playerPoint?.bonus_catch || 0);
        }

        return total;
      }, {});

      for (const fixture of previousFixtures) {
        const responseObj: any = { ...fixture };
        responseObj.playerPoints = playerPerformances[fixture.fixtureAPIId];
        if (playerPerformances[fixture.fixtureAPIId])
          response.push(responseObj);
      }

      const playerTotalMatches = Object.keys(playerPerformances).length;

      return successResponse('retrived', {
        playerTotalPoints,
        playerPointAverage:
          playerTotalPoints / (playerTotalMatches ? playerTotalMatches : 1),
        data: response,
      });
    } catch (err) {
      return successResponse('retrived', []);
    }
  }

  async footballPlayerPerformance(
    playerAPIId: number,
    teamAPIId: number,
    seriesAPIId: number,
  ) {
    try {
      const previousFixtures = await this.footballScorecardModel
        .find({
          $or: [
            { 'teams.home.teamAPIId': teamAPIId.toString() },
            { 'teams.away.teamAPIId': teamAPIId.toString() },
          ],
          seriesAPIId,
        })
        .lean()
        .sort({ fixtureAPIId: -1 })
        .limit(5);

      const fixtureAPI = previousFixtures.map((e) => {
        return {
          fixtureAPIId: e.fixtureAPIId,
          teams: {
            teamA: {
              name: e.teams.away.name,
              shortName: e.teams.away.shortName,
              teamAPIId: e.teams.away.teamAPIId,
              logo: e.teams.away.logo,
            },
            teamB: {
              name: e.teams.home.name,
              shortName: e.teams.home.shortName,
              teamAPIId: e.teams.home.teamAPIId,
              logo: e.teams.home.logo,
            },
          },
        };
      });

      const playerPerformance: any = await this.footballPlayerPerformanceModel
        .find({
          'playerPoints.playerAPIId': playerAPIId,
          fixtureAPIId: { $in: fixtureAPI.map((e) => e.fixtureAPIId) },
        })
        .select(
          'playerPoints.playerAPIId playerPoints.playerPoints playerPoints.playerName fixtureAPIId ',
        );

      const response = [];
      let playerTotalPoints = 0;
      fixtureAPI.forEach((element: any) => {
        const points = playerPerformance
          .find((j) => j.fixtureAPI === element.fixtureAPI)
          ?.playerPoints.find((e: any) => e.playerAPIId === playerAPIId);
        playerTotalPoints += points?.playerPoints;
        (element.fixtureAPIId = !playerPerformance.length
          ? 0
          : element.fixtureAPIId),
          (element.teams = !playerPerformance.length ? '' : element.teams);
        element.playerPoints = {
          totalPoints: points?.playerPoints,
          playerName: points?.playerName,
        };
      });

      return successResponse('retrived', {
        playerTotalPoints,
        playerPointAverage: playerTotalPoints / fixtureAPI.length || 1,
        data: fixtureAPI,
      });
    } catch (err) {
      console.log(err.message);
    }
  }

  async kabaddiPlayerPerformance(
    playerAPIId: number,
    teamAPIId: number,
    seriesAPIId: number,
  ) {
    try {
      const previousFixtures = await this.kabaddiScorecardModel
        .find({
          $or: [
            { 'teams.home.teamAPIId': teamAPIId },
            { 'teams.away.teamAPIId': teamAPIId },
          ],
          seriesAPIId,
        })
        .lean()
        .sort({ fixtureAPIId: -1 })
        .limit(5);

      const fixtureAPI = previousFixtures.map((e) => {
        return {
          fixtureAPIId: e.fixtureAPIId,
          teams: {
            home: {
              teamName: e.teams.home.teamName,
              teamDisplayName: e.teams.home.teamDisplayName,
              teamAPIId: e.teams.home.teamAPIId,
              logo: e.teams.home.logo,
            },
            away: {
              teamName: e.teams.away.teamName,
              teamDisplayName: e.teams.away.teamDisplayName,
              teamAPIId: e.teams.away.teamAPIId,
              logo: e.teams.away.logo,
            },
          },
        };
      });

      const playerPerformance: any = await this.kabaddiPlayerPerformanceModel
        .find({
          'playerPoints.playerAPIId': playerAPIId,
          fixtureAPIId: { $in: fixtureAPI.map((e) => e.fixtureAPIId) },
        })
        .select(
          'playerPoints.playerAPIId playerPoints.playerPoints playerPoints.playerName fixtureAPIId ',
        );
      if (!playerPerformance) return commonErrors('retrived');

      const response = [];
      let playerTotalPoints = 0;
      fixtureAPI.forEach((element: any) => {
        const points = playerPerformance
          .find((j) => j.fixtureAPI === element.fixtureAPI)
          ?.playerPoints.find((e: any) => e.playerAPIId === playerAPIId);
        playerTotalPoints += points?.playerPoints;
        (element.fixtureAPIId = !playerPerformance.length
          ? 0
          : element.fixtureAPIId),
          (element.teams = !playerPerformance.length ? '' : element.teams);
        element.playerPoints = {
          totalPoints: points?.playerPoints,
          playerName: points?.playerName,
        };
      });

      return successResponse('retrived', {
        playerTotalPoints,
        playerPointAverage: playerTotalPoints / fixtureAPI.length || 1,
        data: fixtureAPI,
      });
    } catch (err) {
      console.log(err.message);
    }
  }

  async getMatchStats(
    gameType: string,
    fixtureAPIId: number,
    playerAPIId?: number,
  ) {
    try {
      const lineup = await this.trpcService.getLineup('getlineUp', {
        fixtureAPIId,
        gameType,
      });

      if (playerAPIId) {
        const in11Players: any = [
          ...lineup.teamA.squads,
          ...lineup.teamB.squads,
        ].map((e) => e.playerId);

        if (!in11Players.includes(playerAPIId))
          return successResponse('retrived', {
            innings1: [],
            innings2: [],
            combinedPoints: [],
          });
      }

      if (!lineup?.fixtureAPIId) return successResponse('retrived', []);
      const PlayerPerformance = await this.playerPerformanceModel
        .find({
          fixtureAPIId,
        })
        .lean();

      let formatedResponse: any = this.playerPerformanceFormatting(
        lineup,
        PlayerPerformance[0],
      );

      //Test match
      if (PlayerPerformance[1]) {
        var secondInningsFormating: any = this.playerPerformanceFormatting(
          lineup,
          PlayerPerformance[1],
        );
        if (playerAPIId && playerAPIId != 0) {
          var index = this.arrSearch(
            secondInningsFormating,
            secondInningsFormating.length,
            playerAPIId,
            'playerAPIId',
          );
          if (index == -1) secondInningsFormating = [];
          secondInningsFormating = [secondInningsFormating[index - 1]];
        }
      }

      let combinedPoints = this.combineMatchPoints(
        lineup,
        PlayerPerformance[0]?.playerPoint,
        PlayerPerformance[1]?.playerPoint,
      );

      if (playerAPIId && playerAPIId != 0) {
        const index = this.arrSearch(
          formatedResponse,
          formatedResponse.length,
          playerAPIId,
          'playerAPIId',
        );
        if (index == -1) formatedResponse = [];
        else formatedResponse = [formatedResponse[index - 1]];

        const ind = this.arrSearch(
          combinedPoints,
          combinedPoints.length,
          playerAPIId,
          'player_id',
        );
        if (ind == -1) combinedPoints = [];
        else combinedPoints = [combinedPoints[ind - 1]];
      }

      return successResponse('retrived', {
        innings1: formatedResponse || [],
        innings2: secondInningsFormating || [],
        combinedPoints: combinedPoints || [],
      });
    } catch (err) {
      console.log(err);
      return commonErrors('retrived');
    }
  }

  private combineMatchPoints(
    lineup: any,
    innings1: playerPoint[],
    innings2?: playerPoint[],
  ) {
    try {
      const playing11Players = [
        ...lineup?.teamA?.squads.map((e) => {
          return {
            ...e,
            teamId: lineup.teamA.teamId,
            teamName: lineup.teamA.teamName,
          };
        }),
        ...lineup.teamB.squads.map((e) => {
          return {
            ...e,
            teamId: lineup.teamB.teamId,
            teamName: lineup.teamB.teamName,
          };
        }),
      ].reduce((total, value) => {
        total[value.playerId] = value;
        return total;
      }, {});

      const in11Players: any = [
        ...lineup.teamA.squads,
        ...lineup.teamB.squads,
      ].map((e) => e.playerId);

      const playerSelby = lineup?.selby?.players.reduce(
        (total: any, value: any) => {
          total[value?.playerAPIId] = value;
          return total;
        },
        {},
      );

      const playerPointsInnings1 = innings1.reduce((total, value) => {
        total[value.player_id] = value;
        return total;
      }, {});
      const playerPointsInnings2 = innings2?.reduce((total, value) => {
        total[value.player_id] = value;
        return total;
      }, {});

      const response = [];

      for (const playerId of in11Players) {
        const playerInnings1 = playerPointsInnings1[playerId];
        const playerInnings2 = playerPointsInnings2?.[playerId];

        const playerPointObj: playerPoint = {
          player_id: playing11Players[playerId].playerId,
          player_name: playing11Players[playerId].name,
          player_role: playing11Players[playerId].role,
          teamAPIId: playing11Players[playerId].teamId,
          selectedby: +(
            ((playerSelby?.[playerId]?.selectedbyCount || 0) /
              (lineup?.selby?.totalSelection || 1)) *
            100
          ).toFixed(2),
          bonus: (playerInnings1?.bonus || 0) + (playerInnings2?.bonus || 0),
          bonus_bowedlbw:
            (playerInnings1?.bonus_bowedlbw || 0) +
            (playerInnings2?.bonus_bowedlbw || 0),
          bonus_catch:
            (playerInnings1?.bonus_catch || 0) +
            (playerInnings2?.bonus_catch || 0),
          catch: (playerInnings1?.catch || 0) + (playerInnings2?.catch || 0),
          direct_runout:
            (playerInnings1?.direct_runout || 0) +
            (playerInnings2?.direct_runout || 0),
          duck: (playerInnings1?.duck || 0) + (playerInnings2?.duck || 0),
          economic_rate:
            (playerInnings1?.economic_rate || 0) +
            (playerInnings2?.economic_rate || 0),
          fifty: (playerInnings1?.fifty || 0) + (playerInnings2?.fifty || 0),
          four: (playerInnings1?.four || 0) + (playerInnings2?.four || 0),
          maidenover:
            (playerInnings1?.maidenover || 0) +
            (playerInnings2?.maidenover || 0),
          point: (playerInnings1?.point || 0) + (playerInnings2?.point || 0),
          rating: (playerInnings1?.rating || 0) + (playerInnings2?.rating || 0),
          run: (playerInnings1?.run || 0) + (playerInnings2?.run || 0),
          runout_catcher:
            (playerInnings1?.runout_catcher || 0) +
            (playerInnings2?.runout_catcher || 0),
          runout_stumping:
            (playerInnings1?.runout_stumping || 0) +
            (playerInnings2?.runout_stumping || 0),
          runout_thrower:
            (playerInnings1?.runout_thrower || 0) +
            (playerInnings2?.runout_thrower || 0),
          six: (playerInnings1?.six || 0) + (playerInnings2?.six || 0),
          strike_rate:
            (playerInnings1?.strike_rate || 0) +
            (playerInnings2?.strike_rate || 0),
          stumping:
            (playerInnings1?.stumping || 0) + (playerInnings2?.stumping || 0),
          thirty: (playerInnings1?.thirty || 0) + (playerInnings2?.thirty || 0),
          wickets:
            (playerInnings1?.wickets || 0) + (playerInnings2?.wickets || 0),
        };
        if (playerPointObj.player_id) response.push(playerPointObj);
      }
      return response;
    } catch (err) {
      console.log(err);
      return [];
    }
  }

  private playerPerformanceFormatting(lineup: any, PlayerPerformance: any) {
    try {
      const playing11Players = [
        ...lineup.teamA.squads.map((e) => {
          return {
            ...e,
            teamId: lineup.teamA.teamId,
            teamName: lineup.teamA.teamName,
          };
        }),
        ...lineup.teamB.squads.map((e) => {
          return {
            ...e,
            teamId: lineup.teamB.teamId,
            teamName: lineup.teamB.teamName,
          };
        }),
      ].reduce((total, value) => {
        total[value.playerId] = value;
        return total;
      }, {});

      const in11Players: any = [
        ...lineup.teamA.squads,
        ...lineup.teamB.squads,
      ].map((e) => e.playerId);

      const playerSelby = lineup?.selby?.players.reduce(
        (total: any, value: any) => {
          total[value?.playerAPIId] = value;
          return total;
        },
        {},
      );

      const teamA = JSON.stringify(lineup.teamA.squads);
      // const teamB = JSON.stringify(lineup.teamB.squads);

      const combinedStats = {
        playerPoint: PlayerPerformance.playerPoint.reduce(
          (value: any, item: any) => {
            value[item['player_id']] = item;
            return value;
          },
          {},
        ),
        playerStat: PlayerPerformance.playerStat.reduce(
          (value: any, item: any) => {
            value[item['playerAPIId'] || item['fielder_id']] = item;
            return value;
          },
          {},
        ),
      };

      const formatedResponse: [any] = in11Players
        .map((e: any) => {
          return {
            ...combinedStats.playerPoint[e],
            ...combinedStats.playerStat[e],
            playerData: playing11Players[e],
          };
        })
        .map((e: any) => {
          const playerAPIId = e.playerData.playerId;
          return {
            playerAPIId: playerAPIId,
            playerName: e.playerData.name,
            playerTeam: e.playerData.teamName,
            playerRole: e.playerData.role,
            selectedby: (
              ((playerSelby?.[playerAPIId]?.selectedbyCount || 0) /
                (lineup?.selby?.totalSelection || 1)) *
              100
            ).toFixed(2),
            in11: e?.playing11 || 4,
            runPoints: e.run,
            runs: e.runsScored,
            fours: e.foursHit,
            fourPoints: e.four,
            six: e.sixesHit,
            sixPoints: e.six,
            strikeRate: e.strikeRate,
            strikeRatePoints: e.strike_rate || 0,
            ballsFaced: e.ballsFaced,
            fiftysPoints: e.fifty,
            thirtyPoints: e.thirty,
            duckPoints: e.duck,
            oversBowled: e.oversBowled,
            wickets: e.wicketsTaken,
            wicketsPoints: e.wickets,
            lbw: e.lbwMade,
            bowled: e.bowledMade,
            lbwBowledPoints: e.bonus_bowedlbw,
            maiden: e.maidensBowled,
            maidenPoints: e.maidenover,
            ecconomy: e.economy,
            ecconomyPoints: e.economic_rate,
            catches: e?.catches || 0, //Check
            catchPoints: e.catch,
            bonusCatch: e.bonus_catch || 0,
            runouts: e?.runout_thrower || 0 + e?.runout_catcher || 0, //Check
            stumpings: e?.stumping || 0, //Check
            runoutStumpingPoints:
              combinedStats?.playerPoint?.[playerAPIId]?.stumping || 0,
            runout_catcher:
              combinedStats?.playerPoint?.[playerAPIId]?.runout_catcher || 0,
            runout_thrower:
              combinedStats?.playerPoint?.[playerAPIId]?.runout_thrower || 0,
            direct_runout:
              combinedStats?.playerPoint?.[playerAPIId]?.direct_runout || 0,
            totalPoints: e.point,
            bonusPoints: e.bonus,
          };
        });

      return formatedResponse.filter((e) => e.playerAPIId);
    } catch (err) {
      return null;
    }
  }

  private groupFn(arr: any[], field: string) {
    return arr.reduce(function (value, item) {
      let keys = item[field];
      if (!value[keys]) {
        value[keys] = [];
      }

      value[keys].push(item);
      return value;
    }, {});
  }

  private findAndGroupStatPoints(
    playerStatsGroup: object,
    fixtureAPIId: number,
    playerAPIId: number,
  ) {
    const playerPointIndex = this.arrSearch(
      playerStatsGroup[fixtureAPIId][0]['playerPoint'],
      playerStatsGroup[fixtureAPIId][0]['playerPoint'].length,
      playerAPIId,
      'player_id',
    );
    let playerStatsIndex = this.arrSearch(
      playerStatsGroup[fixtureAPIId][0]['playerStat'],
      playerStatsGroup[fixtureAPIId][0]['playerStat'].length,
      playerAPIId,
      'player_id',
    );
    if (playerStatsIndex == -1)
      playerStatsIndex = this.arrSearch(
        playerStatsGroup[fixtureAPIId][0]['playerStat'],
        playerStatsGroup[fixtureAPIId][0]['playerStat'].length,
        playerAPIId,
        'fielder_id',
      );

    const playerStats =
      playerStatsGroup[fixtureAPIId][0]['playerStat'][playerStatsIndex];
    const playerPoints =
      playerStatsGroup[fixtureAPIId][0]['playerPoint'][playerPointIndex];
    return { ...playerPoints, ...playerStats };
  }

  private arrSearch(arr: any, n: number, x: any, key: string): number {
    let front = 0;
    let back = n - 1;

    while (front <= back) {
      if (arr[front][key] == x) return front + 1;
      if (arr[back][key] == x) return back + 1;
      front++;
      back--;
    }

    return -1;
  }

  async footballMatchStats(
    gameType: string,
    fixtureAPIId: number,
    playerAPIId?: number,
  ) {
    try {
      const lineup = await this.trpcService.getLineup('getlineUp', {
        fixtureAPIId,
        gameType,
      });

      const playerPerformaces = await this.footballPlayerPerformanceModel
        .findOne({ fixtureAPIId })
        .lean();
      if (!playerPerformaces) throw new Error();

      const playerSelby = lineup?.selby?.players.reduce(
        (total: any, value: any) => {
          total[value?.playerAPIId] = value;
          return total;
        },
        {},
      );

      const groupedByPlayerAPIId = lineup.teamplayers.reduce((acc, player) => {
        const { playerAPIId } = player.squads;
        if (!acc[playerAPIId]) {
          acc[playerAPIId] = {
            _id: player._id,
            teamAPIId: player.teamAPIId,
          };
        }

        return acc;
      }, {});
      const playerStats = playerPerformaces.playerStats.reduce(
        (total, value) => {
          total[value.playerAPIId] = value;
          return total;
        },
        {},
      );
      const playerPointsStats = playerPerformaces?.playerPoints?.reduce(
        (total, value) => {
          total.push({
            ...value,
            ...playerStats[value.playerAPIId],
            selectedbyCount:
              +playerSelby[value.playerAPIId]?.selectedbyCount || 0,
            selectedbyCountVC:
              +playerSelby[value.playerAPIId]?.selectedbyCountVC || 0,
            selectedbyCountCAP:
              +playerSelby[value.playerAPIId]?.selectedbyCountCAP || 0,
            teamAPIId: +groupedByPlayerAPIId[value.playerAPIId]?.teamAPIId || 0,
          });
          return total;
        },
        [],
      );

      return successResponse(
        'retrived',
        playerAPIId
          ? playerPointsStats.filter((e) => e.playerAPIId == playerAPIId)
          : playerPointsStats,
      );
    } catch (err) {
      console.log(err);
      return commonErrors('retrived');
    }
  }

  async kabaddiMatchStats(
    gameType: string,
    fixtureAPIId: number,
    playerAPIId?: number,
  ) {
    try {
      const lineup = await this.trpcService.getLineup('getlineUp', {
        fixtureAPIId,
        gameType,
      });
      const playerPerformaces = await this.kabaddiPlayerPerformanceModel
        .findOne({ fixtureAPIId })
        .lean();

      if (!playerPerformaces) throw new Error();

      const playerSelby = lineup?.selby?.players.reduce(
        (total: any, value: any) => {
          total[value?.playerAPIId] = value;
          return total;
        },
        {},
      );

      const groupedByPlayerAPIId = lineup.teamplayers.reduce((acc, player) => {
        const { playerAPIId } = player.squads;
        if (!acc[playerAPIId]) {
          acc[playerAPIId] = {
            _id: player._id,
            teamAPIId: player.teamAPIId,
            positionType: player?.squads?.positionType,
          };
        }

        return acc;
      }, {});
      console.log(groupedByPlayerAPIId);
      const playerStats = playerPerformaces.playerStats.reduce(
        (total, value) => {
          total[value.playerAPIId] = value;
          return total;
        },
        {},
      );
      const playerPointsStats = playerPerformaces?.playerPoints?.reduce(
        (total, value) => {
          total.push({
            ...value,
            ...playerStats[value.playerAPIId],
            selectedbyCount:
              +playerSelby[value.playerAPIId]?.selectedbyCount || 0,
            selectedbyCountVC:
              +playerSelby[value.playerAPIId]?.selectedbyCountVC || 0,
            selectedbyCountCAP:
              +playerSelby[value.playerAPIId]?.selectedbyCountCAP || 0,
            teamAPIId: +groupedByPlayerAPIId[value.playerAPIId]?.teamAPIId || 0,
            playerRole:
              groupedByPlayerAPIId[value.playerAPIId]?.positionType || '',
          });
          return total;
        },
        [],
      );
      return successResponse(
        'retrived',
        playerAPIId
          ? playerPointsStats.filter((e) => e.playerAPIId == playerAPIId)
          : playerPointsStats,
      );
    } catch (err) {
      console.log(err);
      return commonErrors('retrived');
    }
  }
}
