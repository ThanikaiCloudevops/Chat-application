import { CreateScorecardInput } from './create-scorecard.input';
import { InputType, Field, Int, PartialType } from '@nestjs/graphql';

@InputType()
export class UpdateScorecardInput extends PartialType(CreateScorecardInput) {
  @Field(() => Int)
  id: number;
}
