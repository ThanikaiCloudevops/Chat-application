import { Query, Args, Resolver } from '@nestjs/graphql';
import { ScorecardService } from './scorecard.service';
import { scoreCardData } from './entities/scorecard.entity';
import { UseGuards } from '@nestjs/common';
import { AuthGuard } from 'src/auth/auth.guard';
import { commentary_data } from './entities/commentary.entity';
import {
  player_data,
  previousPerformances,
} from './entities/playerPerformance.entity';
import { footballcommentary_data } from './entities/football-commentry.entity';
import {
  FinalFootballPlayerPerformanceStats,
  FootballPlayerPerformance,
  FootballPlayerPerformanceStats,
} from './entities/football-playerperformance.entity';
import { FootballScoreCardData } from './entities/football-scorecard.entity';
import { KabaddiScoreCardData } from './entities/kabaddi-scorecard.entity';
import {
  FinalKabaddiPlayerPerformanceStats,
  KabaddiPlayerPerformanceStats,
} from './entities/kabaddi-playerperformance.entity';

@Resolver()
@UseGuards(AuthGuard)
export class ScorecardResolver {
  constructor(private readonly scorecardService: ScorecardService) {}

  @Query(() => scoreCardData, { name: 'scorecard' })
  scoreCardData(@Args('fixtureAPIId') fixtureAPIId: number) {
    return this.scorecardService.scoreCardGetData(fixtureAPIId);
  }
  @Query(() => KabaddiScoreCardData, { name: 'kabaddiscorecard' })
  kabaddiscoreCardData(@Args('fixtureAPIId') fixtureAPIId: number) {
    return this.scorecardService.kabaddiscoreCardData(fixtureAPIId);
  }

  @Query(() => FootballScoreCardData, { name: 'footballScorecard' })
  footballScorecard(@Args('fixtureAPIId') fixtureAPIId: number) {
    return this.scorecardService.footballScorecard(fixtureAPIId);
  }

  @Query(() => commentary_data, { name: 'getCommentray' })
  commentary(
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('page', { nullable: true }) page?: number,
  ) {
    return this.scorecardService.getCommentaryData(fixtureAPIId, page);
  }

  @Query(() => footballcommentary_data, { name: 'getFootballCommentray' })
  footballcommentary(
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('page', { nullable: true }) page?: number,
  ) {
    return this.scorecardService.getFootballCommentaryData(fixtureAPIId, page);
  }

  @Query(() => player_data, { name: 'getPlayerStats' })
  playerStats(
    @Args('gameType') gameType: string,
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('playerAPIId', { nullable: true }) playerAPIId?: number,
  ) {
    return this.scorecardService.getMatchStats(
      gameType,
      fixtureAPIId,
      playerAPIId,
    );
  }

  @Query(() => FootballPlayerPerformanceStats, { name: 'footballPlayerStats' })
  footballPlayerStats(
    @Args('gameType') gameType: string,
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('playerAPIId', { nullable: true }) playerAPIId?: number,
  ) {
    return this.scorecardService.footballMatchStats(
      gameType,
      fixtureAPIId,
      playerAPIId,
    );
  }

  @Query(() => KabaddiPlayerPerformanceStats, { name: 'kabaddiPlayerStats' })
  kabaddiPlayerStats(
    @Args('gameType') gameType: string,
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('playerAPIId', { nullable: true }) playerAPIId?: number,
  ) {
    return this.scorecardService.kabaddiMatchStats(
      gameType,
      fixtureAPIId,
      playerAPIId,
    );
  }

  @Query(() => previousPerformances, { name: 'playerPreviousPerformance' })
  async playerPreviousPerformance(
    @Args('playerAPIId') playerAPIId: number,
    @Args('teamAPIId') teamAPIId: number,
    @Args('sereisAPIId') sereisAPIId: number,
  ) {
    return await this.scorecardService.playerPerformaces(
      playerAPIId,
      teamAPIId,
      sereisAPIId,
    );
  }

  @Query(() => FinalFootballPlayerPerformanceStats, {
    name: 'footballPlayerPreviousPerformance',
  })
  async footballPlayerPreviousPerformance(
    @Args('playerAPIId') playerAPIId: number,
    @Args('teamAPIId') teamAPIId: number,
    @Args('sereisAPIId') sereisAPIId: number,
  ) {
    return await this.scorecardService.footballPlayerPerformance(
      playerAPIId,
      teamAPIId,
      sereisAPIId,
    );
  }

  @Query(() => FinalKabaddiPlayerPerformanceStats, {
    name: 'kabaddiPlayerPreviousPerformance',
  })
  async kabaddiPlayerPreviousPerformance(
    @Args('playerAPIId') playerAPIId: number,
    @Args('teamAPIId') teamAPIId: number,
    @Args('sereisAPIId') sereisAPIId: number,
  ) {
    return await this.scorecardService.kabaddiPlayerPerformance(
      playerAPIId,
      teamAPIId,
      sereisAPIId,
    );
  }
}
