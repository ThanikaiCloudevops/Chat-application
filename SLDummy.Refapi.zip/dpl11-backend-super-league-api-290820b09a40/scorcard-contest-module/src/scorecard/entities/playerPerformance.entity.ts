import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { BatTeam, BowlTeam, TeamDetails, Toss } from './scorecard.entity';
import { Field, ObjectType, PartialType } from '@nestjs/graphql';
import { score_defaultFields } from 'src/commonResponse/response.entity';
export type playerPerformanceDocument = playerPerformance & Document;

@ObjectType()
export class playerStat extends BatTeam {
  @Field({ nullable: true })
  playerName: string;
  @Field({ nullable: true })
  playerAPIId: number;
  @Field({ nullable: true })
  player_type: string;
  @Field({ nullable: true })
  bowlingPosition: string;
  @Field({ nullable: true })
  oversBowled: number;
  @Field({ nullable: true })
  runsGiven: number;
  @Field({ nullable: true })
  maidensBowled: number;
  @Field({ nullable: true })
  noBallsBowled: number;
  @Field({ nullable: true })
  widesBowled: number;
  @Field({ nullable: true })
  wicketsTaken: number;
  @Field({ nullable: true })
  bowledMade: number;
  @Field({ nullable: true })
  lbwMade: number;
  @Field({ nullable: true })
  economy: number;
  @Field({ nullable: true })
  bowlingStrikerate: number;
}

@ObjectType()
export class playerPoint {
  @Field()
  player_id: number;
  @Field()
  teamAPIId: number;
  @Field()
  player_name: string;
  @Field()
  player_role: string;
  @Field()
  rating: number;
  @Field()
  point: number;
  @Field()
  run: number;
  @Field()
  four: number;
  @Field()
  six: number;
  @Field()
  strike_rate: number;
  @Field()
  fifty: number;
  @Field()
  duck: number;
  @Field()
  wickets: number;
  @Field()
  maidenover: number;
  @Field()
  economic_rate: number;
  @Field()
  catch: number;
  @Field()
  runout_stumping: number;
  @Field()
  runout_thrower: number;
  @Field()
  runout_catcher: number;
  @Field()
  direct_runout: number;
  @Field()
  stumping: number;
  @Field()
  thirty: number;
  @Field()
  bonus: number;
  @Field()
  bonus_catch: number;
  @Field()
  bonus_bowedlbw: number;
  @Field({ nullable: true })
  selectedby: number;
}

@ObjectType()
@Schema()
export class playerPerformance {
  @Field()
  @Prop({ type: Number })
  fixtureAPIId: number;

  @Field()
  @Prop({ type: String })
  fixtureStatus: string;

  @Field({ defaultValue: 1 })
  @Prop({ type: Number, default: 1 })
  innings: number;

  @Field(() => [playerStat])
  @Prop({ type: Array })
  playerStat?: playerStat[];

  @Field(() => [playerPoint])
  @Prop({ type: Array })
  playerPoint?: playerPoint[];
}

@ObjectType()
export class playerPointStats {
  @Field()
  playerAPIId: number;
  @Field()
  playerName: string;
  @Field({ defaultValue: '' })
  playerTeam: string;
  @Field({ nullable: true })
  playerRole: string;
  @Field({ defaultValue: 0 })
  in11: number;
  @Field({ defaultValue: 0 })
  selectedby: number;
  @Field({ defaultValue: 0 })
  runPoints: number;
  @Field({ defaultValue: 0 })
  runs: number;
  @Field({ defaultValue: 0 })
  fours: number;
  @Field({ defaultValue: 0 })
  fourPoints: number;
  @Field({ defaultValue: 0 })
  six: number;
  @Field({ defaultValue: 0 })
  sixPoints: number;
  @Field({ defaultValue: 0 })
  strikeRate: number;
  @Field({ defaultValue: 0 })
  strikeRatePoints: number;
  @Field({ defaultValue: 0 })
  ballsFaced: number;
  @Field({ defaultValue: 0 })
  fiftysPoints: number;
  @Field({ defaultValue: 0 })
  thirtyPoints: number;
  @Field({ defaultValue: 0 })
  duckPoints: number;
  @Field({ defaultValue: 0 })
  oversBowled: number;
  @Field({ defaultValue: 0 })
  wickets: number;
  @Field({ defaultValue: 0 })
  wicketsPoints: number;
  @Field({ defaultValue: 0 })
  lbw: number;
  @Field({ defaultValue: 0 })
  bowled: number;
  @Field({ defaultValue: 0 })
  lbwBowledPoints: number;
  @Field({ defaultValue: 0 })
  maiden: number;
  @Field({ defaultValue: 0 })
  maidenPoints: number;
  @Field({ defaultValue: 0 })
  ecconomy: number;
  @Field({ defaultValue: 0 })
  ecconomyPoints: number;
  @Field({ defaultValue: 0 })
  catches: number;
  @Field({ defaultValue: 0 })
  catchPoints: number;
  @Field({ defaultValue: 0 })
  bonusCatch: number;
  @Field({ defaultValue: 0 })
  runouts: number;
  @Field({ defaultValue: 0 })
  stumpings: number;
  @Field({ defaultValue: 0 })
  runoutStumpingPoints: number;
  @Field({ defaultValue: 0 })
  runout_catcher: number;
  @Field({ defaultValue: 0 })
  runout_thrower: number;
  @Field({ defaultValue: 0 })
  direct_runout: number;
  @Field({ defaultValue: 0 })
  totalPoints: number;
  @Field({ defaultValue: 0 })
  bonusPoints: number;
}

@ObjectType()
class Innings {
  @Field(() => [playerPointStats], { nullable: 'items' })
  innings1: playerPointStats[];
  @Field(() => [playerPointStats], { nullable: 'items' })
  innings2: playerPointStats[];
  @Field(() => [playerPoint], { nullable: 'itemsAndList' })
  combinedPoints: playerPoint[];
}

@ObjectType()
export class player_data extends PartialType(score_defaultFields) {
  @Field(() => Innings, { nullable: true })
  data: Innings;
}

@ObjectType()
class PlayerPointsDatas {
  @Field({ defaultValue: 0 })
  totalPoints: number;
  @Field({ defaultValue: 0 })
  batPoints: number;
  @Field({ defaultValue: 0 })
  bowlPoints: number;
  @Field({ defaultValue: 0 })
  otherPoints: number;
  @Field({ defaultValue: '' })
  playerName: string;
}

@ObjectType()
class previousPerformance {
  @Field()
  fixtureAPIId: number;

  @Field(() => TeamDetails)
  teams: TeamDetails;

  @Field(() => Toss)
  toss?: Toss;

  @Field(() => PlayerPointsDatas)
  playerPoints: PlayerPointsDatas;
}

@ObjectType()
export class previousPerformancesData {
  @Field(() => [previousPerformance])
  data: previousPerformance[];

  @Field({ defaultValue: 0 })
  playerTotalPoints: number;

  @Field({ defaultValue: 0 })
  playerPointAverage: number;
}

@ObjectType()
export class previousPerformances extends PartialType(score_defaultFields) {
  @Field(() => previousPerformancesData)
  data: previousPerformancesData;
}

export const playerPerformanceSchema =
  SchemaFactory.createForClass(playerPerformance);
