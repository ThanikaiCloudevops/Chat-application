import { Field, ObjectType, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { score_defaultFields } from 'src/commonResponse/response.entity';

export type footballScorecardDocument = FootballScorecard & Document;

@ObjectType()
export class scorecardTeam {
  @Field()
  teamAPIId: number;
  @Field()
  shortName: string;
  @Field()
  logo: string;
  @Field()
  name: string;
  @Field()
  fullName: string;
}

@ObjectType()
export class scorecardTeams {
  @Field(() => scorecardTeam)
  away: scorecardTeam;
  @Field(() => scorecardTeam)
  home: scorecardTeam;
}

@ObjectType()
export class HomeAway {
  @Field({ defaultValue: 0, nullable: true })
  away: number;
  @Field({ defaultValue: 0, nullable: true })
  home: number;
}

@ObjectType()
export class Periods {
  @Field(() => HomeAway)
  ft: HomeAway;
  @Field(() => HomeAway)
  p1: HomeAway;
  @Field(() => HomeAway)
  p2: HomeAway;
}

@ObjectType()
export class GameStats extends HomeAway {
  @Field()
  name: string;
}

@ObjectType()
export class PlayerStats {
  @Field()
  playerAPIId: number;
  @Field()
  playerName: string;
  @Field()
  role: string;
  @Field()
  teamType: string;
  @Field()
  fouls: number;
  @Field()
  goals: number;
  @Field()
  saves: number;
  @Field()
  assist: number;
  @Field()
  keypass: number;
  @Field()
  punches: number;
  @Field()
  redcard: number;
  @Field()
  duelswon: number;
  @Field()
  owngoals: number;
  @Field()
  totalpass: number;
  @Field()
  wasfouled: number;
  @Field()
  cleansheet: number;
  @Field()
  crossesacc: number;
  @Field()
  duelstotal: number;
  @Field()
  penaltywon: number;
  @Field()
  totalcross: number;
  @Field()
  yellowcard: number;
  @Field()
  hitwoodwork: number;
  @Field()
  penaltymiss: number;
  @Field()
  penaltysave: number;
  @Field({ defaultValue: 0, nullable: true })
  accuratepass: number;
  @Field()
  dispossessed: number;
  @Field()
  goalconceded: number;
  @Field()
  longballsacc: number;
  @Field()
  shotsblocked: number;
  @Field()
  totalrunsout: number;
  @Field()
  challengelost: number;
  @Field()
  goodhighclaim: number;
  @Field()
  lastmantackle: number;
  @Field()
  minutesplayed: number;
  @Field()
  runsoutsucess: number;
  @Field()
  shotsontarget: number;
  @Field()
  tacklesuccess: number;
  @Field()
  dribblesuccess: number;
  @Field()
  errorledtogoal: number;
  @Field()
  errorledtoshot: number;
  @Field()
  shotsofftarget: number;
  @Field()
  totalclearance: number;
  @Field()
  totallongballs: number;
  @Field()
  bigchancemissed: number;
  @Field()
  dribbleattempts: number;
  @Field()
  interceptionwon: number;
  @Field()
  outfielderblock: number;
  @Field()
  passingaccuracy: number;
  @Field()
  tacklecommitted: number;
  @Field()
  bigchancecreated: number;
  @Field()
  clearanceoffline: number;
  @Field()
  penaltycommitted: number;
  @Field()
  savesfrominsidebox: number;
}

@ObjectType()
export class Result extends HomeAway {
  @Field()
  winner: string;
  @Field()
  result_str: string;
}
@ObjectType()
export class Ballpossession {
  @Field({ defaultValue: 0, nullable: true })
  away: number;
  @Field({ defaultValue: 0, nullable: true })
  home: number;
  @Field({ defaultValue: '', nullable: true })
  name: string;
}
@ObjectType()
@Schema()
export class FootballScorecard {
  @Field()
  @Prop({ type: Number })
  fixtureAPIId: number;

  @Field()
  @Prop({ type: Number })
  seriesAPIId: number;

  @Field()
  @Prop()
  status: string;

  @Field(() => Result, { nullable: true })
  @Prop()
  result: Result;

  @Field(() => Ballpossession, { nullable: true })
  @Prop()
  ballpossession?: Ballpossession;

  @Field(() => scorecardTeams)
  @Prop()
  teams: scorecardTeams;

  @Field(() => Periods)
  @Prop()
  periods: Periods;

  @Field(() => [GameStats], { nullable: true })
  @Prop()
  gameStats?: GameStats[];

  @Field(() => [PlayerStats])
  @Prop()
  playerStats: PlayerStats[];
}

@ObjectType()
export class FootballScoreCardData extends PartialType(score_defaultFields) {
  @Field(() => FootballScorecard, { nullable: true })
  data: FootballScorecard;
}

export const FootballScorecardSchema =
  SchemaFactory.createForClass(FootballScorecard);
