import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { score_defaultFields } from 'src/commonResponse/response.entity';

export type CommentryDocument = commentries & Document;
@ObjectType()
class LiveScore {
  @Field()
  runs: number;
  @Field()
  overs: number;
  @Field()
  wickets: number;
  @Field()
  target: number;
  @Field()
  runrate: number;
  @Field()
  requiredRunrate: string;
}

@ObjectType()
class commentary_Team {
  @Field()
  team_id: number;
  @Field()
  title: string;
  @Field()
  team_sh: string;
  @Field()
  alt_name: string;
  @Field()
  type: string;
  @Field()
  thumb_url: string;
  @Field()
  logo_url: string;
  @Field()
  country_sh: string;
  @Field()
  sex: string;
  @Field()
  scores_full: string;
  @Field()
  scores: string;
  @Field()
  overs: string;
}

@ObjectType()
class commentary_Teams {
  @Field(() => commentary_Team)
  teamA: commentary_Team;
  @Field(() => commentary_Team)
  teamB: commentary_Team;
}

@ObjectType()
class Batsmen {
  @Field()
  name: string;
  @Field()
  batsman_id: number;
  @Field()
  runs: number;
  @Field()
  ballsFaced: number;
  @Field()
  foursHit: number;
  @Field()
  sixesHit: number;
  @Field()
  strikeRate: number;
}

@ObjectType()
class Bowlers {
  @Field()
  name: string;
  @Field()
  bowler_id: number;
  @Field()
  oversBowled: number;
  @Field()
  runsConceded: number;
  @Field()
  wickets: number;
  @Field()
  maidens: number;
  @Field()
  econ: number;
}

@ObjectType()
class didNotBat {
  @Field()
  player_id: number;
  @Field()
  name: string;
}

@ObjectType()
class fielderData {
  @Field()
  fielder_id: number;
  @Field()
  fielder_name: string;
  @Field()
  catches: number;
  @Field()
  runout_thrower: number;
  @Field()
  runout_catcher: number;
  @Field()
  runout_direct_hit: number;
  @Field()
  stumping: number;
  @Field()
  is_substitute: boolean;
}

@ObjectType()
class batsmenData {
  @Field()
  name: string;
  @Field()
  batsman_id: number;
  @Field()
  runs: number;
  @Field()
  balls: number;
}
@ObjectType()
class current_partnership {
  @Field()
  runs: number;
  @Field()
  balls: number;
  @Field()
  overs: number;
  @Field(() => [batsmenData])
  batsmen: batsmenData[];
}

@ObjectType()
class lastWicket {
  @Field()
  name: string;
  @Field()
  batsman_id: number;
  @Field()
  runs: number;
  @Field()
  balls: number;
  @Field()
  how_out: string;
  @Field()
  score_at_dismissal: number;
  @Field()
  overs_at_dismissal: number;
  @Field()
  bowler_id: number;
  @Field()
  dismissal: string;
  @Field()
  number: number;
}
@ObjectType()
class extraRuns {
  @Field()
  byes: number;
  @Field()
  legbyes: number;
  @Field()
  wides: number;
  @Field()
  noballs: number;
  @Field()
  penalty: number;
  @Field()
  total: number;
}

@ObjectType()
class equationData {
  @Field()
  runs: number;
  @Field()
  wickets: number;
  @Field()
  overs: number;
  @Field()
  bowlers_used: number;
  @Field()
  runrate: number;
}

@ObjectType()
class bat_and_bowl {
  @Field()
  total_review: number;
  @Field()
  review_success: number;
  @Field()
  review_failed: number;
  @Field()
  review_available: number;
}

@ObjectType()
class reviewData {
  @Field(() => bat_and_bowl)
  batting: bat_and_bowl;
  @Field(() => bat_and_bowl)
  bowling: bat_and_bowl;
}

@ObjectType()
class PP {
  @Field()
  startover: string;
  @Field()
  endover: string;
}

@ObjectType()
class Powerplay {
  @Field(() => PP, {
    defaultValue: {
      startover: '',
      endover: '',
    },
  })
  p1?: PP;

  @Field(() => PP, {
    defaultValue: {
      startover: '',
      endover: '',
    },
  })
  p2?: PP;

  @Field(() => PP, {
    defaultValue: {
      startover: '',
      endover: '',
    },
  })
  p3?: PP;

  @Field(() => PP, {
    defaultValue: {
      startover: '',
      endover: '',
    },
  })
  p4?: PP;
}

@ObjectType()
class live_Innings_Data {
  @Field()
  innings_id: number;
  @Field()
  innings_number: number;
  @Field()
  name: string;
  @Field()
  short_name: string;
  @Field()
  status: number;
  @Field()
  issuperover: boolean;
  @Field()
  result: number;
  @Field()
  batting_team_id: number;
  @Field()
  fielding_team_id: number;
  @Field()
  scores: string;
  @Field()
  scores_full: string;
  @Field()
  max_over: string;
  @Field()
  recent_scores: string;
  @Field()
  last_five_overs: string;
  @Field()
  last_ten_overs: string;
  @Field(() => [didNotBat])
  did_not_bat: didNotBat[];
  @Field(() => [fielderData])
  fielder: fielderData[];
  @Field(() => lastWicket)
  last_wicket: lastWicket;
  @Field(() => extraRuns)
  extra_runs: extraRuns;
  @Field(() => equationData)
  equations: equationData;
  @Field(() => reviewData)
  review: reviewData;
  @Field(() => current_partnership)
  current_partnership: current_partnership;
  @Field(() => Powerplay)
  @Prop({ type: Object })
  powerplay: Powerplay;
}

@ObjectType()
class Bats {
  @Field()
  runs: number;
  @Field()
  balls_faced: number;
  @Field()
  fours: number;
  @Field()
  sixes: number;
  @Field()
  batsman_id: number;
}

@ObjectType()
class Bowls {
  @Field()
  runs_conceded: number;
  @Field()
  maidens: number;
  @Field()
  wickets: number;
  @Field()
  bowler_id: number;
  @Field()
  overs: number;
}

@ObjectType()
class Commentry {
  @Field({ nullable: true, defaultValue: 0 })
  event_id?: number;
  @Field({ nullable: true, defaultValue: '' })
  event?: string;
  @Field({ nullable: true, defaultValue: 0 })
  batsman_id?: number;
  @Field({ nullable: true, defaultValue: 0 })
  bowler_id?: number;
  @Field({ nullable: true, defaultValue: 0 })
  over?: number;
  @Field({ nullable: true, defaultValue: 0 })
  ball?: number;
  @Field({ nullable: true, defaultValue: '' })
  score?: string;
  @Field({ nullable: true, defaultValue: '' })
  commentary?: string;
  @Field({ nullable: true, defaultValue: false })
  noball_dismissal?: boolean;
  @Field({ nullable: true, defaultValue: '' })
  text?: string;
  @Field({ nullable: true, defaultValue: 0 })
  timestamp?: number;
  @Field({ nullable: true, defaultValue: 0 })
  run?: number;
  @Field({ nullable: true, defaultValue: 0 })
  noball_run?: number;
  @Field({ nullable: true, defaultValue: 0 })
  wide_run?: number;
  @Field({ nullable: true, defaultValue: 0 })
  bye_run?: number;
  @Field({ nullable: true, defaultValue: 0 })
  legbye_run?: number;
  @Field({ nullable: true, defaultValue: 0 })
  bat_run?: number;
  @Field({ nullable: true, defaultValue: false })
  noball?: boolean;
  @Field({ nullable: true, defaultValue: false })
  wideball?: boolean;
  @Field({ nullable: true, defaultValue: false })
  six?: boolean;
  @Field({ nullable: true, defaultValue: false })
  four?: boolean;
  @Field({ nullable: true, defaultValue: 0 })
  runs?: number;

  @Field(() => [Bats], { nullable: true })
  bats?: [Bats];

  @Field(() => [Bowls], { nullable: true })
  bowls?: [Bowls];
}

@ObjectType()
@Schema()
export class commentries {
  @Field()
  @Prop()
  fixtureAPIId: number;
  @Field()
  @Prop()
  status: number;
  @Field()
  @Prop()
  status_str: string;
  @Field()
  @Prop()
  status_notes: string;
  @Field()
  @Prop()
  remainingOvers: string;
  @Field()
  @Prop()
  battingTeam: string;
  @Field()
  @Prop()
  bowlingTeam: string;
  @Field()
  @Prop()
  inningsNumber: number;
  @Field(() => LiveScore)
  @Prop()
  liveScore: LiveScore;
  @Field(() => commentary_Teams)
  @Prop()
  teams: commentary_Teams;
  @Field(() => [Batsmen])
  @Prop()
  batsmen: Batsmen[];
  @Field(() => [Bowlers])
  @Prop()
  bowlers: Bowlers[];
  @Field(() => live_Innings_Data)
  @Prop()
  liveInnings: live_Innings_Data;

  @Field(() => [Commentry])
  @Prop()
  commentaries: Commentry[];
}

@ObjectType()
export class commentary_data extends PartialType(score_defaultFields) {
  @Field(() => commentries, { nullable: true })
  data: commentries;
}

export const CommentrySchema = SchemaFactory.createForClass(commentries);
