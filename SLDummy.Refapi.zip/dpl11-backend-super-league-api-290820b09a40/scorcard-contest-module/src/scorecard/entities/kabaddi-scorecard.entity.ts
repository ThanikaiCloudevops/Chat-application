import { Field, Int, ObjectType, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { score_defaultFields } from 'src/commonResponse/response.entity';

export type kabaddiScorecardDocument = KabaddiScorecard & Document;

@ObjectType()
export class KabaddiResult {
  @Field()
  home: number;

  @Field()
  away: number;

  @Field()
  winner: number;

  @Field()
  text: string;

  @Field()
  tie: boolean;
}

@ObjectType()
export class KabadiToss {
  @Field()
  winner: number;

  @Field()
  decision: string;
}

@ObjectType()
export class KabadiScorecardTeam {
  @Field()
  teamAPIId: number;

  @Field()
  teamName: string;

  @Field()
  teamDisplayName: string;

  @Field()
  logo: string;
}

@ObjectType()
export class KabaddiScorecardTeams {
  @Field(() => KabadiScorecardTeam, { nullable: true })
  home: KabadiScorecardTeam;

  @Field(() => KabadiScorecardTeam, { nullable: true })
  away: KabadiScorecardTeam;
}

@ObjectType()
export class KabaddiMatchStats {
  @Field()
  totalpoint: number;

  @Field()
  alloutpoint: number;

  @Field()
  extrapoint: number;

  @Field()
  declarepoint: number;

  @Field()
  raidtotalpoint: number;

  @Field()
  raidtouchpoint: number;

  @Field()
  raidbonuspoint: number;

  @Field()
  tackletotalpoint: number;

  @Field()
  tacklecapturepoint: number;

  @Field()
  tacklecapturebonuspoint: number;

  @Field()
  raidtotal: number;

  @Field()
  raidsuccessful: number;

  @Field()
  raidunsuccessful: number;

  @Field()
  raidempty: number;

  @Field()
  superraid: number;

  @Field()
  tackletotal: number;

  @Field()
  tacklesuccessful: number;

  @Field()
  tackleunsuccessful: number;

  @Field()
  supertackles: number;

  @Field()
  allouts: number;

  @Field()
  declare: number;
}

@ObjectType()
export class KabadiTeamStats {
  @Field(() => KabaddiMatchStats)
  home: KabaddiMatchStats;

  @Field(() => KabaddiMatchStats)
  away: KabaddiMatchStats;
}

@ObjectType()
class KabaddiPlayerStatsdata {
  @Field()
  playerAPIId: number;

  @Field()
  playerName: string;

  @Field()
  side: string;

  @Field()
  greencardcount: number;

  @Field()
  yellowcardcount: number;

  @Field()
  redcardcount: number;

  @Field()
  totalpoint: number;

  @Field()
  raidtotalpoint: number;

  @Field()
  raidtouchpoint: number;

  @Field()
  raidbonuspoint: number;

  @Field()
  tackletotalpoint: number;

  @Field()
  tacklecapturepoint: number;

  @Field()
  tacklecapturebonuspoint: number;

  @Field()
  tackletotal: number;

  @Field()
  tacklesuccessful: number;

  @Field()
  tackleunsuccessful: number;

  @Field()
  supertackles: number;

  @Field()
  raidtotal: number;

  @Field()
  raidsuccessful: number;

  @Field()
  raidunsuccessful: number;

  @Field()
  raidempty: number;

  @Field()
  superraid: number;

  @Field()
  superten: number;

  @Field()
  highfive: number;
}

@ObjectType()
export class KabadiplayerStatss {
  @Field(() => [KabaddiPlayerStatsdata], { nullable: true })
  home: KabaddiPlayerStatsdata[];

  @Field(() => [KabaddiPlayerStatsdata], { nullable: true })
  away: KabaddiPlayerStatsdata[];
}

@ObjectType()
export class gameStats {
  @Field({ defaultValue: 0, nullable: true })
  away: number;
  @Field({ defaultValue: 0, nullable: true })
  home: number;
  @Field({ defaultValue: '' })
  name: string;
}

@Schema()
@ObjectType()
export class KabaddiScorecard {
  @Field()
  @Prop({ type: Number })
  fixtureAPIId: number;

  @Field()
  @Prop({ type: Number })
  seriesAPIId: number;

  @Field()
  @Prop()
  status: string;

  @Field(() => KabaddiResult, { nullable: true })
  @Prop()
  result: KabaddiResult;

  @Field(() => KabadiToss, { nullable: true })
  @Prop()
  toss: KabadiToss;

  @Field(() => KabaddiScorecardTeams)
  @Prop()
  teams: KabaddiScorecardTeams;

  @Field(() => [gameStats], { nullable: true })
  @Prop()
  gameStats?: gameStats[];
  @Field(() => KabadiplayerStatss)
  @Prop()
  playerStats: KabadiplayerStatss;
}

@ObjectType()
export class KabaddiScoreCardData extends PartialType(score_defaultFields) {
  @Field(() => KabaddiScorecard, { nullable: true })
  data: KabaddiScorecard;
}

export const KabaddiScorecardSchema =
  SchemaFactory.createForClass(KabaddiScorecard);
