import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TrpcModule } from './trpc/server/trpc.module';
import { MongooseModule } from '@nestjs/mongoose';
import { GraphQLModule } from '@nestjs/graphql';
import {
  ApolloFederationDriver,
  ApolloFederationDriverConfig,
} from '@nestjs/apollo';
import { DB } from 'config/envirnment';
import { ScorecardModule } from './scorecard/scorecard.module';

@Module({
  imports: [
    TrpcModule,
    MongooseModule.forRoot(DB.URL, {
      maxConnecting: 5,
      maxPoolSize: 5,
      connectTimeoutMS: 3000,
      socketTimeoutMS: 8000,
      maxIdleTimeMS: 10000,
    }),
    GraphQLModule.forRoot<ApolloFederationDriverConfig>({
      driver: ApolloFederationDriver,
      autoSchemaFile: {
        federation: 2,
      },
      includeStacktraceInErrorResponses: false,
    }),
    ScorecardModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
