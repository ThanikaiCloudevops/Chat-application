import { ObjectType, Field, PartialType, OmitType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import graphqlTypeJson from 'graphql-type-json';
import { Document } from 'mongoose';
import { contest_defaultFields } from 'src/commonResponse/response.entity';
import { team } from 'src/teams/entities/team.entity';

export type contestDocument = Contest & Document;

@ObjectType()
export class priceSplitUp {
  @Field({ nullable: true })
  rank: string;
  @Field({ nullable: true })
  price: number;
}
@ObjectType()
export class prizeBreakup {
  @Field({ nullable: true })
  rank: string;
  @Field({ nullable: true })
  price: number;
}

@ObjectType()
export class Prize {
  @Field()
  @Prop()
  prizeType: string;

  @Field()
  @Prop()
  totalValue: number;

  @Field()
  @Prop()
  split: boolean;

  @Field(() => graphqlTypeJson, { defaultValue: {} })
  @Prop({ type: Object })
  prizeSplitUp: any;

  @Field(() => graphqlTypeJson, { defaultValue: {} })
  @Prop({ type: Object })
  prizeBreak: any;

  @Field(() => [prizeBreakup], { defaultValue: [] })
  prizeBreakup: prizeBreakup[];

  // for response only
  @Field(() => [priceSplitUp], { nullable: true })
  priceSplitUp: priceSplitUp[];
}

@ObjectType()
@Schema()
export class Contest {
  @Field({ nullable: true })
  _id?: string;

  @Field()
  @Prop({ index: true })
  fixtureAPIId: number;

  @Field()
  @Prop({ index: true })
  seriesAPIId: number;

  @Prop({ default: true })
  isJoin?: boolean;

  @Field({ nullable: true })
  @Prop()
  contestCode?: string;

  @Field()
  @Prop()
  contestName: string;

  @Field()
  @Prop()
  adminCommission?: number;

  @Field()
  @Prop()
  constestCaption: string;

  @Field()
  @Prop()
  contestType: string;

  @Field()
  @Prop()
  poolType: string;

  @Field()
  @Prop()
  maxPrizepool: number;

  @Field()
  @Prop()
  totalPrizePool: number;

  @Field()
  @Prop()
  totalSpots: number;

  @Field()
  @Prop({ min: 0 })
  remainingSpots: number;

  @Field()
  @Prop()
  maxTeamCount: number;

  @Field()
  @Prop()
  currentWinning: number;

  @Field()
  @Prop()
  guaranteed: boolean;

  @Field()
  @Prop()
  enabledStatus: boolean;

  @Field()
  @Prop()
  isactive: boolean;

  @Field(() => Prize, { nullable: 'itemsAndList' })
  @Prop()
  prize: Prize;

  @Field(() => graphqlTypeJson)
  @Prop({ type: Object, default: {} })
  jointUsers: any;

  @Field({ defaultValue: false })
  position: boolean;

  @Field({ defaultValue: 0 })
  @Prop()
  discountEntryFee?: number;

  @Field()
  @Prop()
  winningPercentage: number;

  @Field()
  @Prop()
  entryFee: number;

  @Field({ nullable: true })
  @Prop()
  paid: boolean;

  @Prop()
  previousContest: string;

  @Field({ nullable: true })
  @Prop()
  autoCreate: boolean;

  @Field({ nullable: true })
  @Prop()
  adminCumissionPercentage: number;

  @Field()
  @Prop()
  gameType: string;

  @Field({ nullable: true })
  @Prop()
  startDate: Date;

  @Field({ nullable: true })
  @Prop()
  order?: number;

  @Prop({ default: '' })
  createdBy?: string;
}

@ObjectType()
class JointUsers {
  @Field({ defaultValue: '' })
  teamId: string;
  @Field({ defaultValue: '' })
  teamName: string;
  @Field({ defaultValue: '' })
  userName: string;
  @Field({ defaultValue: 0 })
  points: number;
  @Field({ nullable: true })
  joinedAt: Date;
  @Field({ defaultValue: 0 })
  rank: number;
  @Field({ defaultValue: 0 })
  price: number;
}

@ObjectType()
class copyContest extends PartialType(
  OmitType(Contest, ['fixtureAPIId', 'jointUsers']),
) {
  @Field({ defaultValue: 0 })
  joinedCount: number;

  @Field(() => [JointUsers], { nullable: 'itemsAndList' })
  userTeams: JointUsers[];
}

@ObjectType()
class fixtureTeamCount {
  @Field()
  fixtureAPIId: number;
  @Field({ defaultValue: 0 })
  createdTeamCount: number;
  @Field({ defaultValue: 0 })
  contestJoinedCount: number;
}
@ObjectType()
class contestdetails extends fixtureTeamCount {
  @Field(() => [copyContest], { nullable: 'itemsAndList' })
  contest: copyContest[];
  @Field({ nullable: true })
  page?: number;
}

@ObjectType()
export class contestCollectionFormat extends PartialType(
  contest_defaultFields,
) {
  @Field(() => contestdetails, { nullable: true })
  data: contestdetails;
}

@ObjectType()
class contestdetail extends fixtureTeamCount {
  @Field(() => copyContest, { nullable: true })
  contest: copyContest;
}
@ObjectType()
export class singleContest extends PartialType(contest_defaultFields) {
  @Field(() => contestdetail, { nullable: true })
  data: contestdetail;
}

@ObjectType()
class capandVc {
  @Field({ defaultValue: '' })
  imgUrl: string;
  @Field({ defaultValue: '' })
  jerseyUrl: string;
  @Field({ defaultValue: '' })
  playerImageUrl: string;
  @Field()
  playerName: string;
  @Field()
  playerDisplayName: string;
  @Field()
  teamName: string;
}
@ObjectType()
class userJoinedTeams {
  @Field()
  teamId: string;
  @Field()
  teamName: string;
  @Field(() => capandVc)
  captain: capandVc;
  @Field(() => capandVc)
  viceCaptain: capandVc;
}
@ObjectType()
class contestWithTeamDetails extends PartialType(copyContest) {
  @Field(() => [userJoinedTeams], { nullable: true })
  joinedTeams?: userJoinedTeams[];
}
@ObjectType()
class myContestDetails extends fixtureTeamCount {
  @Field(() => [contestWithTeamDetails], { nullable: 'itemsAndList' })
  contest: contestWithTeamDetails[];
}

@ObjectType()
export class myContestCollection extends PartialType(contest_defaultFields) {
  @Field(() => myContestDetails, { nullable: true })
  data: myContestDetails;
}
export const ContestsSchema = SchemaFactory.createForClass(Contest);

// leaderBoard res

@ObjectType()
export class leaderBoard_team_Detail {
  @Field({ nullable: true })
  teamId: string;
  @Field({ nullable: true })
  teamName: string;
  @Field({ defaultValue: 0 })
  points: number;
  @Field({ nullable: true })
  userName: string;
  @Field({ nullable: true })
  userId: string;
  @Field({ defaultValue: 0 })
  rank: number;
  @Field({ defaultValue: 0 })
  price: number;

  @Field({ defaultValue: false })
  myTeam: boolean;
}
@ObjectType()
export class leaderBoardTeams {
  // @Field(() => [leaderBoard_team_Detail], { nullable: 'itemsAndList' })
  // userTeams: leaderBoard_team_Detail[];

  // @Field(() => [leaderBoard_team_Detail], { nullable: 'items' })
  // AllTeams: leaderBoard_team_Detail[];

  @Field(() => [leaderBoard_team_Detail], { nullable: 'items' })
  combinedTeams: leaderBoard_team_Detail[];

  @Field({ nullable: true })
  page?: number;

  @Field()
  joinedUsers: number;
}

@ObjectType()
export class teamLeaderbord extends PartialType(leaderBoard_team_Detail) {
  @Field(() => [team])
  team: team[];
}

@ObjectType()
export class leaderBoardTeamsCollection extends PartialType(
  contest_defaultFields,
) {
  @Field(() => leaderBoardTeams)
  data: leaderBoardTeams;
}

@ObjectType()
export class leaderBoardDownloadRes extends PartialType(contest_defaultFields) {
  @Field(() => [teamLeaderbord])
  data: teamLeaderbord[];
}
