import { InputType, Field } from '@nestjs/graphql';

@InputType()
export class teamList {
  @Field()
  teamId: string;
  @Field()
  teamName: string;
}
@InputType()
export class JoinContestInput {
  @Field({ nullable: true })
  contestId?: string;

  @Field({ nullable: true })
  contestCode?: string;

  @Field()
  fixtureAPIId: number;

  @Field(() => [teamList])
  teamList: teamList[];

  @Field()
  gameType: string;
}
