import { Module, forwardRef } from '@nestjs/common';
import { ContestService } from './contest.service';
import { ContestResolver } from './contest.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import { Contest, ContestsSchema } from './entities/contest.entity';
import { trpcServices } from 'src/trpc/client/trpc';
import { TeamsModule } from 'src/teams/teams.module';
import { TeamsService } from 'src/teams/teams.service';
import { TimeOut, TimeoutSchema } from './entities/timeout.entity';
import { ContestHelper } from './helpers/contest.helper';

@Module({
  imports: [
    forwardRef(() => TeamsModule),
    MongooseModule.forFeature([{ name: Contest.name, schema: ContestsSchema }]),
    MongooseModule.forFeature([{ name: TimeOut.name, schema: TimeoutSchema }]),
  ],
  providers: [ContestResolver, ContestService, trpcServices, ContestHelper],
  exports: [ContestService],
})
export class ContestModule {}
