import { Inject, Injectable, forwardRef } from '@nestjs/common';
import { JoinContestInput } from './dto/join-contest.input';
import { InjectModel } from '@nestjs/mongoose';
import {
  Contest,
  contestDocument,
  leaderBoardTeams,
  teamLeaderbord,
} from './entities/contest.entity';
import { Model } from 'mongoose';
import { successResponse } from 'src/commonResponse/success';
import { commonErrors } from 'src/commonResponse/errors';
import { trpcServices } from 'src/trpc/client/trpc';
import { contestCreationInput, contestList } from './dto/contest.input';
import { TeamsService } from 'src/teams/teams.service';
import { userTeams } from 'src/teams/entities/team.entity';
import { leaderBoard_team_Detail } from 'src/contest/entities/contest.entity';
import { timeOutDocument } from './entities/timeout.entity';
import { ContestHelper } from './helpers/contest.helper';
import { privateContestData } from 'src/commonResponse/response.entity';

@Injectable()
export class ContestService {
  constructor(
    @InjectModel('Contest') private contestModel: Model<contestDocument>,
    @InjectModel('TimeOut') private timeoutModel: Model<timeOutDocument>,
    private trpcService: trpcServices,
    @Inject(forwardRef(() => TeamsService))
    private teams: TeamsService,
    private contestHelper: ContestHelper,
  ) {}
  private sports = {
    cricket: { contest: this.contestModel },
  };
  async EnableTimeOut(userId: string, days: number) {
    try {
      const currentDate = new Date();
      currentDate.setHours(0, 0, 0, 0);

      const endDate = new Date();
      endDate.setHours(0, 0, 0, 0);
      endDate.setDate(endDate.getDate() + days);

      const timeOutCheck = await this.timeoutModel
        .findOne({
          userId,
          timeOutEndDate: { $lte: currentDate },
        })
        .lean();
      if (timeOutCheck) return commonErrors('timeoutexist');

      const options = { upsert: true, new: true, setDefaultsOnInsert: true };

      await this.timeoutModel.findOneAndUpdate(
        { userId },
        { userId, timeOutStartDate: currentDate, timeOutEndDate: endDate },
        options,
      );

      return successResponse('timeout');
    } catch (err) {
      console.log(err.message);
      return commonErrors('timeout');
    }
  }

  private async validateJoinTeam(
    joinContestInput: JoinContestInput,
    userId: any,
    contest: any,
    fixtureAPIId: number,
  ) {
    const { teamList, gameType } = joinContestInput;

    const team_List = teamList.reduce(
      (list, value) => (list = [...list, ...Object.values(value)]),
      [],
    );
    if (team_List.some((ite) => !ite)) return commonErrors('invalidTeam');

    const isTeamAvailable = await this.teams.getTeamCount(
      fixtureAPIId,
      userId,
      gameType,
      teamList,
    );

    if (isTeamAvailable) return commonErrors('invalidTeam');
    if (!contest) return commonErrors('joincontest');

    const JoinedTeam = contest.jointUsers?.[userId]?.userTeams || {};
    const isAlreadyJoined = teamList.find((ite: any) => JoinedTeam[ite.teamId]);
    // const isAlreadyJoined = JoinedTeam.includes(...joinTeamId);

    if (isAlreadyJoined) return commonErrors('AlreadyJoined');
    //
    if (
      contest.remainingSpots == 0 ||
      Object.values(JoinedTeam).length == contest.maxTeamCount
    )
      return commonErrors('contestfull');
    const userWallet = await this.trpcService.transaction('getwallet', userId);
    if (!userWallet) return commonErrors('balance');
    /*******Bonus Amount Added Ajith***** */
    const bonusData = userWallet?.data?.totalBonus;
    const cal = contest?.entryFee * teamList.length;
    const persentage =
      bonusData >= ((5 / 100) * cal).toFixed(2)
        ? ((5 / 100) * cal).toFixed(2)
        : bonusData;
    const reducedAmt = bonusData > 0 ? +persentage : 0;
    /*******Bonus Amount Added Ajith END reducedAmt only Added Bottom condition ***** */
    if (
      userWallet?.data?.userBalance + reducedAmt <
      contest.entryFee * teamList.length
    )
      return commonErrors('balance');
    return 'success';
  }

  async joinContest(joinContestInput: JoinContestInput, user: any) {
    const { contestId, teamList, contestCode, fixtureAPIId, gameType } =
      joinContestInput;
    const currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);
    const timeOutCheck = await this.timeoutModel
      .findOne({
        timeOutEndDate: { $gte: currentDate },
        userId: user._id,
      })
      .lean();

    if (timeOutCheck) return commonErrors('timeoutactive');
    const userId = user._id;
    const userName = user.userName || 'testUser';
    let contest: any;

    if (!contestId && !contestCode) return commonErrors('getallcontets');

    if (joinContestInput.contestId)
      contest = await this.contestModel
        .findOne({
          _id: contestId,
          isactive: true,
        })
        .lean();
    else
      contest = await this.contestModel
        .findOne({
          contestCode,
          isactive: true,
        })
        .lean();
    if (!contest) return commonErrors('getallcontets');
    // if (contest?.isJoin === false) return commonErrors('privatecontest');
    if (contest.fixtureAPIId != fixtureAPIId)
      return commonErrors('contestmissmatch');

    if (
      contest.remainingSpots < teamList.length ||
      Object.keys(contest?.jointUsers?.[userId]?.['userTeams'] || {}).length +
        teamList.length >
        contest.maxTeamCount
    )
      return commonErrors('spots');
    if (contest.remainingSpots == 0) return commonErrors('contestfull');

    const validation = await this.validateJoinTeam(
      joinContestInput,
      userId,
      contest,
      fixtureAPIId,
    );
    if (validation !== 'success') return validation;
    const team_List_data = teamList.reduce((teams, value) => {
      teams[value['teamId']] = { ...value, points: 0, joinedAt: new Date() };
      return teams;
    }, {});

    if (!contest.jointUsers?.[userId])
      contest.jointUsers[userId] = { userName, userTeams: {} };
    contest.jointUsers[userId].userTeams = {
      ...contest.jointUsers[userId].userTeams,
      ...team_List_data,
    };
    contest.remainingSpots -= teamList.length;

    const fixture = await this.trpcService.game('getfixture', {
      fixtureAPIId,
      gameType,
    });
    if (fixture?.fixtureStatus == 'Live') return commonErrors('live');
    const checkContest = await this.contestModel.findById(contest._id).lean();
    if (
      checkContest.remainingSpots < teamList.length ||
      Object.keys(checkContest?.jointUsers?.[userId]?.['userTeams'] || {})
        .length +
        teamList.length >
        checkContest.maxTeamCount
    )
      return commonErrors('spots');

    await this.joinContestUpdate(contest._id, teamList.length, contest, userId);
    if (contest.paid == true) {
      const transaction = await this.trpcService.transaction(
        'transactionupdate',
        {
          userId,
          transanctionType: 'Debit',
          amount: contest.entryFee * teamList.length,
          transanctionRelatedType: 'EntryFee',
          fixtureId: contest.fixtureAPIId,
          fixtureName: fixture.fixtureDisplayName.toString(),
          contestId: contest._id.toString(),
          contestName: contest.contestName,
        },
      );
      if (!transaction.status) return commonErrors('balance');
    }
    // await this.updateContest(contest._id, contest);
    //Update myfixtures
    await this.trpcService.game('joinfixture', {
      userId,
      fixtureAPIId,
      gameType,
    });
    if (!contest.guaranteed) {
      await this.dynamicSplitupV2(contestId);
    }
    const contestcheck = await this.contestModel
      .findOne({ _id: contestId, isactive: true })
      .lean();
    if (contestcheck.autoCreate === true && contestcheck.remainingSpots === 0) {
      const duplicate = await this.contestDuplication(contestId);
    }
    return successResponse('joinContest');
  }

  async dynamicSplitup(contestid: string) {
    try {
      const contest = await this.contestModel.findOne({
        _id: contestid,
        isactive: true,
      });
      const joincounts = contest.totalSpots - contest.remainingSpots;
      if (joincounts > 1) {
        const currentWinning = Math.round(
          (joincounts / contest.totalSpots) * contest.totalPrizePool,
        );
        const myObject = contest.prize.prizeSplitUp;
        const entries = Object.entries(myObject);
        var win: number = currentWinning;
        var newarray = [];

        for (const [key, value] of entries) {
          let rank = key;
          let strings = (key as string).split('-');
          let prize = value;

          if (strings.length < 2) {
            var newarray2 = [];
            newarray2.push(Number(rank));
            newarray2.push(Number(prize));
            newarray.push(newarray2);
          } else if (strings.length > 1) {
            //const start =  strings[0];
            let start = Number(strings[0]);
            let end = Number(strings[1]);
            let i: Number;

            for (let i = start; i <= end; i++) {
              var newarray3 = [];
              newarray3.push(Number(i));
              newarray3.push(Number(prize));
              newarray.push(newarray3);
            }
          }
        }

        var newRange = [];
        var joined = 1;
        for (let i = 0; i < joined; i++) {
          let newrank = {};
          if (newarray[i][1] > win) {
            (newrank['rank'] = i + 1), (newrank['price'] = win);
          } else if (newarray[i][1] == win) {
            (newrank['rank'] = i + 1), (newrank['price'] = win);
          } else if (newarray[i][1] < win) {
            (newrank['rank'] = newarray[i][0]),
              (newrank['price'] = newarray[i][1]),
              (win = win - newrank['price']);
            joined = joined + 1;
          }
          newRange.push(newrank);
        }
        let range = [];
        let position = 0;
        let prizebreak = {};

        for (let i = 0; i < newRange.length; i++) {
          try {
            let rankrange = {};
            if (newRange.length > 1) {
              if (i + 1 < newRange.length) {
                if (newRange[i]['price'] == newRange[i + 1]['price']) {
                  if (position == 0) {
                    var start = newRange[i]['rank'];
                    position = position + 1;
                  }
                  if (i + 2 < newRange.length) {
                    if (newRange[i + 1]['price'] == newRange[i + 2]['price']) {
                      continue;
                    } else {
                      var end = newRange[i + 1]['rank'];
                      rankrange['rank'] = start + '-' + end;
                      rankrange['price'] = newRange[i]['price'];
                      prizebreak[start + '-' + end] = newRange[i]['price'];
                      position = 0;
                      i = i + 1;
                    }
                  } else {
                    var end = newRange[i + 1]['rank'];
                    rankrange['rank'] = start + '-' + end;
                    rankrange['price'] = newRange[i]['price'];
                    prizebreak[start + '-' + end] = newRange[i]['price'];
                    position = 0;
                    i = i + 1;
                  }
                } else {
                  rankrange['rank'] = String(newRange[i]['rank']);
                  rankrange['price'] = newRange[i]['price'];
                  prizebreak[newRange[i]['rank']] = newRange[i]['price'];
                }
              } else {
                (rankrange['rank'] = String(newRange[i]['rank'])),
                  (rankrange['price'] = newRange[i]['price']);
                prizebreak[newRange[i]['rank']] = newRange[i]['price'];
              }
            } else {
              (rankrange['rank'] = String(newRange[i]['rank'])),
                (rankrange['price'] = newRange[i]['price']);
              prizebreak[newRange[i]['rank']] = newRange[i]['price'];
            }

            range.push(rankrange);
            // range.push(rankrange)
          } catch (err) {
            console.log(err);
          }
        }
        const updatedData = await this.contestModel.findOneAndUpdate(
          { _id: contestid },
          {
            $set: {
              'prize.prizeBreakup': range,
              'prize.prizeBreak': prizebreak,
              currentWinning: currentWinning,
            },
          },
          { new: true }, // Return the updated document
        );
      } else {
        const updated = await this.contestModel.findOneAndUpdate(
          { _id: contestid },
          {
            $set: {
              'prize.prizeBreakup': [],
              'prize.prizeBreak': {},
            },
          },
          { new: true }, // Return the updated document
        );
      }
    } catch {
      //
    }
  }

  async dynamicBreakup(contestid: string) {
    try {
      const contest = await this.contestModel.findOne({
        _id: contestid,
        isactive: true,
      });
      const joincounts = contest.totalSpots - contest.remainingSpots;
      if (joincounts > 1) {
        const winningAmount =
          contest.totalPrizePool -
          (contest.totalPrizePool * contest.adminCumissionPercentage) / 100;
        const currentWinning = Math.round(joincounts * contest.entryFee);
        const NewcurrentWinning =
          currentWinning -
          (currentWinning * contest.adminCumissionPercentage) / 100;
        const totalranks = Math.ceil(
          (contest.winningPercentage / 100) * contest.totalSpots,
        );
        let newRankCount = 0;
        if (joincounts == 2) {
          newRankCount = 1;
        } else if (joincounts == 3) {
          newRankCount = 1;
        } else if (joincounts == 4) {
          newRankCount = 2;
        } else if (joincounts == 5) {
          newRankCount = 3;
        } else if (joincounts > 5 && (40 / 100) * joincounts < totalranks) {
          newRankCount = Math.ceil((40 / 100) * joincounts);
        } else {
          newRankCount = Math.ceil(
            (contest.winningPercentage / 100) * joincounts,
          );
        }
        //let newRankCount = Math.ceil((contest.winningPercentage/100) * joincounts);
        const myObject = contest.prize.prizeSplitUp;
        const entries = Object.entries(myObject);

        let win: number = NewcurrentWinning;
        let newarray = [];
        let newObject: any = {};
        for (const [key, value] of entries) {
          let rank = key;
          let strings = (key as string).split('-');
          let prize = value;

          if (strings.length < 2) {
            let newarray2 = [];
            newarray2.push(Number(rank));
            newarray2.push(Number(prize));
            newarray.push(newarray2);
            newObject.rank = newObject.prize;
          } else if (strings.length > 1) {
            //const start =  strings[0];
            let start = Number(strings[0]);
            let end = Number(strings[1]);
            let i: Number;
            for (let i = start; i <= end; i++) {
              let newarray3 = [];
              newarray3.push(Number(i));
              newObject.i = newObject.prize;
              newarray3.push(Number(prize));
              newarray.push(newarray3);
            }
          }
        }
        let newRankArray: any = [];

        let totalPercent = 0;
        for (let i = 1; i <= newRankCount; i++) {
          let percentArray = [];
          percentArray.push(i);
          const percent = (newarray[i - 1][1] / winningAmount) * 100;

          totalPercent = totalPercent + percent;
          percentArray.push(
            +((NewcurrentWinning * Number(percent)) / 100).toFixed(2),
          );
          newRankArray.push(percentArray);
        }
        const splitPercent = 100 - totalPercent;
        const splitAmountTotal = NewcurrentWinning * (splitPercent / 100);
        const splitAmount = splitAmountTotal / newRankCount;
        let totalCheck = 0;
        if (totalCheck == 0) {
          for (let index = newRankCount - 1; index >= 0; index--) {
            newRankArray[index][1] = newRankArray[index][1] + splitAmount;
          }
        }

        for (let key in newRankArray) {
          //await this.splitRepeat(newRankArray,contest,newRankCount);
        }

        /*
          for(let y=newRankCount-1; y>=0; y--){
          
            if(newRankArray[y][1] < contest.entryFee){
             // newRankArray[y][1] = newRankArray[y][1] + splitAmount;
              if(y > 0){
                for(let z = y; z >= 0; z--){
                  newRankArray[z][1] = newRankArray[z][1] + splitAmount;
                  totalCheck = totalCheck + newRankArray[z][1];
                }
              }
            }
          }

          
          
          const obj={};
          for(const ar of newRankArray){
              if(!obj[ar[1]]) obj[ar[1]]=[]
              obj[ar[1]].push(ar[0])
          }
          const priceSplit={};
          const priceSplitUp=[];
          for(const price in obj){
              let rank;
              const ranks=obj[price]
              
              if(ranks.length>1){
                  const sortRanks=ranks.sort((a,b)=>+a-+b);
                  rank=`${sortRanks[0]}-${sortRanks[sortRanks.length-1]}`
              }
              else
              rank=`${ranks[0]}`
              priceSplit[rank]=+(Number(price).toFixed(2));
              priceSplitUp.push({rank,price:+(Number(price).toFixed(2))});
          }

          const updatedData = await this.contestModel.findOneAndUpdate(
            { _id: contestid },
            {
              $set: {
                'prize.prizeBreakup': priceSplitUp,
                'prize.prizeBreak': priceSplit,
                currentWinning: currentWinning,
              },
            },
            { new: true }, // Return the updated document
          );
          */
      } else {
        const updated = await this.contestModel.findOneAndUpdate(
          { _id: contestid },
          {
            $set: {
              'prize.prizeBreakup': [],
              'prize.prizeBreak': {},
            },
          },
          { new: true }, // Return the updated document
        );
      }
    } catch (err) {}
    return successResponse('found');
  }

  async dynamicSplitupV2(contestid: string) {
    try {
      const contest = await this.contestModel.findOne({
        _id: contestid,
        isactive: true,
      });
      const joincounts = contest.totalSpots - contest.remainingSpots;

      if (joincounts > 1) {
        const currentWinning = contest.entryFee * joincounts;
        const newCurrentWining = +(
          currentWinning -
          currentWinning * (contest.adminCumissionPercentage / 100)
        ).toFixed(2);

        const splitup = contest.prize.prizeSplitUp;
        let newObj: any = {};
        for (let key in splitup) {
          let rank = key;
          let strings = (key as string).split('-');
          let prize = splitup[key];
          if (strings.length < 2) {
            newObj[rank] = prize;
          } else if (strings.length > 1) {
            let start = Number(strings[0]);
            let end = Number(strings[1]);
            let i: Number;
            for (let i = start; i <= end; i++) {
              newObj[i] = prize;
            }
          }
        }

        let breakup: any = {};
        let prices;

        if (joincounts > 2) {
          //for joincount greater than 2
          prices = await this.splitupCalculation(
            newObj,
            contest.totalSpots,
            contest.entryFee,
            contest.adminCommission / 100,
            joincounts,
          );
        } else {
          // For joincount = 2 only

          const winning =
            contest.entryFee * joincounts -
            (contest.entryFee * joincounts * contest.adminCommission) / 100;

          breakup['1'] = +Math.floor(winning);
          prices = breakup;
        }

        const priceSplitUp = [];
        const length = Object.keys(prices).length;
        let priceBreak = {};
        let totalPrice = 0;
        for (let i = 1; i <= length; ) {
          let end = 0;
          if (prices[i] === prices[i + 1]) {
            for (let y = i + 1; y > 0; ) {
              if (prices[y] === prices[y + 1]) {
                y++;
              } else {
                end = y;
                priceBreak[i + '-' + end] = prices[i];
                const addcount = end - i + 1;
                totalPrice = prices[i] * addcount + totalPrice;
                priceSplitUp.push({
                  rank: i + '-' + end,
                  price: +Number(prices[i]).toFixed(2),
                });
                y = 0;
                i = end + 1;
              }
            }
          } else {
            priceBreak[i] = prices[i];
            totalPrice = totalPrice + prices[i];
            priceSplitUp.push({
              rank: `${i}`,
              price: +Number(prices[i]).toFixed(2),
            });
            i++;
          }
        }

        const updatedData = await this.contestModel.findOneAndUpdate(
          { _id: contestid },
          {
            $set: {
              'prize.prizeBreakup': priceSplitUp,
              'prize.prizeBreak': priceBreak,
              currentWinning: totalPrice,
            },
          },
          { new: true }, // Return the updated document
        );
      } else {
        const updated = await this.contestModel.findOneAndUpdate(
          { _id: contestid },
          {
            $set: {
              'prize.prizeBreakup': [],
              'prize.prizeBreak': {},
            },
          },
          { new: true }, // Return the updated document
        );
      }
    } catch (error) {
      console.log('splitup error');
    }
  }

  splitupCalculation(
    initialPrizePool: object,
    maxJointUsers: number,
    entryFee: number,
    adminCommision: number,
    currentJointUsers: number,
  ): object {
    try {
      if (currentJointUsers == 2) return {};
      if (maxJointUsers == currentJointUsers) return initialPrizePool;
      if (maxJointUsers < currentJointUsers) return initialPrizePool;
      const prizePercentagePerRank = {};
      const dynamicPoolPercentage = {};
      const dynamicPriceSplit = {};
      const dynamicSumCoefficient = {};
      let reducibleRanks = [];
      let coefficientRequiredCount = 0;
      let requiredPercentageSum = 0;
      let remainingPrizePercentage = 0;

      const initialWinnersCount = Object.values(initialPrizePool).length;
      const currentUserPrize = Math.floor(
        currentJointUsers * entryFee * (1 - adminCommision),
      );
      const minPrizePercentage = +(
        ((entryFee + 1) / currentUserPrize) *
        100
      ).toFixed(2);
      const maxPrizePool = Math.floor(
        maxJointUsers * entryFee * (1 - adminCommision),
      );
      let winnersPercentage = +(initialWinnersCount / maxJointUsers).toFixed(2);
      let currentWinnersCount = Math.floor(
        winnersPercentage * currentJointUsers,
      );
      if (winnersPercentage < 0.4) {
        if (currentWinnersCount < initialWinnersCount) {
          winnersPercentage = 0.4;
          currentWinnersCount = Math.floor(
            winnersPercentage * currentJointUsers,
          );
        }
        if (currentWinnersCount > initialWinnersCount) {
          currentWinnersCount = initialWinnersCount;
          winnersPercentage = +(
            currentWinnersCount / currentJointUsers
          ).toFixed(2);
        }
      }

      for (const rank in initialPrizePool) {
        const prize = initialPrizePool[rank];
        prizePercentagePerRank[rank] = +Number(
          (prize / maxPrizePool) * 100,
        ).toFixed(2);
      }
      for (let rank = 1; rank < initialWinnersCount + 1; rank++) {
        if (rank <= currentWinnersCount)
          dynamicPoolPercentage[rank] = prizePercentagePerRank[rank];
        else remainingPrizePercentage += prizePercentagePerRank[rank];
      }
      const remainingPrizePercentageDistribution = +(
        remainingPrizePercentage / currentWinnersCount
      ).toFixed(2);
      remainingPrizePercentage = 0;

      for (let rank = 1; rank < currentWinnersCount + 1; rank++) {
        dynamicPoolPercentage[rank] = +(
          dynamicPoolPercentage[rank] + remainingPrizePercentageDistribution
        ).toFixed(2);
      }

      for (const rank in dynamicPoolPercentage) {
        const prizePercentage = dynamicPoolPercentage[rank];
        if (prizePercentage < minPrizePercentage) {
          dynamicSumCoefficient[rank] = +(
            minPrizePercentage - prizePercentage
          ).toFixed(2);
          coefficientRequiredCount++;
        } else dynamicSumCoefficient[rank] = 0;
        requiredPercentageSum += dynamicSumCoefficient[rank];
      }
      const prizeReductionPercentagePerUser = +(
        requiredPercentageSum /
        (currentWinnersCount - coefficientRequiredCount)
      ).toFixed(2);

      for (const rank in dynamicPoolPercentage) {
        if (dynamicSumCoefficient[rank] > 0)
          dynamicPoolPercentage[rank] = +(
            dynamicPoolPercentage[rank] + dynamicSumCoefficient[rank]
          ).toFixed(2);
        else if (
          +(
            dynamicPoolPercentage[rank] - prizeReductionPercentagePerUser
          ).toFixed(2) < minPrizePercentage
        )
          remainingPrizePercentage += prizeReductionPercentagePerUser;
        else {
          dynamicPoolPercentage[rank] = +(
            dynamicPoolPercentage[rank] - prizeReductionPercentagePerUser
          ).toFixed(2);
          reducibleRanks.push(rank);
        }
      }

      let recussion = true;
      while (recussion) {
        recussion = false;
        const perUserReduction = +(
          remainingPrizePercentage / reducibleRanks.length
        ).toFixed(2);
        const arr = [];
        remainingPrizePercentage = 0;
        for (const rank of reducibleRanks) {
          if (
            dynamicPoolPercentage[rank] - perUserReduction >
            minPrizePercentage
          ) {
            dynamicPoolPercentage[rank] = +(
              dynamicPoolPercentage[rank] - perUserReduction
            ).toFixed(2);
          } else
            remainingPrizePercentage = +(
              remainingPrizePercentage + perUserReduction
            ).toFixed(2);
        }
        reducibleRanks = arr;
        if (remainingPrizePercentage > 0) recussion = false;
      }

      let splitSum = 0;

      for (const rank in dynamicPoolPercentage) {
        const pricePercentage = dynamicPoolPercentage[rank];
        dynamicPriceSplit[rank] = +(
          (pricePercentage / 100) *
          currentUserPrize
        ).toFixed(2);

        dynamicPriceSplit[rank] =
          dynamicPriceSplit[rank] < entryFee + 1
            ? +Math.ceil(dynamicPriceSplit[rank])
            : +Math.floor(dynamicPriceSplit[rank]);

        splitSum += dynamicPriceSplit[rank];
      }

      if (splitSum < currentUserPrize) {
        let pendingAmout = currentUserPrize - splitSum;

        let distrubution = true;
        while (distrubution) {
          for (const rank in dynamicPriceSplit) {
            const prize = dynamicPriceSplit[rank];
            if (pendingAmout == 0) {
              distrubution = false;
              break;
            }
            dynamicPriceSplit[rank]++;
            pendingAmout--;
          }
        }
      }
      const sortedPool = {};
      const prizes = Object.values(dynamicPriceSplit).sort(
        (a: number, b: number) => b - a,
      );
      for (let index = 0; index < prizes.length; index++) {
        const prize = prizes[index];
        sortedPool[index + 1] = prize;
      }

      return sortedPool;
    } catch (err) {
      console.log(err);
      return {};
    }
  }

  async getAllContest(userID: string, request: contestList) {
    try {
      const fixtureAPIId = request?.fixtureAPIId;
      const SortBy = request?.SortBy;
      const filterBy = request?.filterBy;
      const contestName = request?.contestName;
      const page = request?.page;
      const gameType = request?.gameType;

      const currentDate = new Date();
      currentDate.setHours(0, 0, 0, 0);

      const timeOutCheck = await this.timeoutModel.findOne({
        timeOutEndDate: { $gte: currentDate },
        userId: userID,
      });

      const query: any = {
        $and: [
          { enabledStatus: true, fixtureAPIId, isactive: true, gameType },
          { remainingSpots: { $ne: 0 } },
        ],
      };

      if (timeOutCheck) query.$and.push({ paid: false });

      if (contestName) query.$and.push({ contestName });

      /* Filter start */
      query.$and.push({ contestType: 'public' });

      if (filterBy?.Entry?.length) {
        query.$and.push(
          this.contestHelper.filterHelper(filterBy.Entry, 'entryFee'),
        );
      }
      if (filterBy?.PrizePool?.length) {
        query.$and.push(
          this.contestHelper.filterHelper(filterBy.PrizePool, 'totalPrizePool'),
        );
      }
      if (filterBy?.Spots?.length) {
        query.$and.push(
          this.contestHelper.filterHelper(filterBy.Spots, 'remainingSpots'),
        );
      }
      if (filterBy?.ContestType?.length) {
        if (filterBy?.ContestType[0] == 'Single Entry')
          query.$and.push({ maxTeamCount: 1 });
        else query.$and.push({ maxTeamCount: { $gt: 1 } });
      }
      /* Filter end */
      var contests = await this.contestModel
        .find(query)
        .sort({ order: 1, totalPrizePool: -1, contestName: 1 })
        .lean();
      let contestsNewArray = contests.filter(function (el) {
        return el.order > 0;
      });
      let contestsBalArray = contests.filter(function (el) {
        return el.order == null;
      });
      const contestArray = [...contestsNewArray, ...contestsBalArray];
      const createdTeamCount = await this.teams.getTeamCount(
        fixtureAPIId,
        userID,
        gameType,
      );

      let contestJoinedCount = 0; // get joined team count of user
      const test = await this.getMyContest(
        userID,
        fixtureAPIId,
        gameType,
        page,
      );
      contestJoinedCount = test.data.contestJoinedCount;

      if (!contestArray.length)
        return successResponse('notfound', {
          fixtureAPIId,
          createdTeamCount,
          contestJoinedCount,
          contest: [],
          page,
        });

      //  group by Contest name
      const groupedKeys = contestArray.reduce((group, item) => {
        if (!group[item.contestName]) {
          group[item.contestName] = [];
        }

        item.prize.priceSplitUp = item?.prize?.prizeSplitUp
          ? this.priceSplitUp(item.prize.prizeSplitUp)
          : [];

        group[item.contestName].push(item);

        // sort desc group with prize
        group[item.contestName].sort(
          (a: { totalPrizePool: number }, b: { totalPrizePool: number }) =>
            b.totalPrizePool - a.totalPrizePool,
        );
        return group;
      }, {});

      // sort overall contest by prize
      const flatList = Object.values(groupedKeys)
        // .sort((a, b) => b[0].totalPrizePool - a[0].totalPrizePool)
        .map((item) => ((item[0].position = true), item)) //aditional field
        .flat()
        .map((e: any) => {
          return {
            ...e,
            joinedCount: e.jointUsers?.[userID]?.userTeams
              ? Object.keys(e.jointUsers?.[userID]?.userTeams)?.length
              : 0,
          };
        });

      const modifiedList = await this.sortFn(flatList, SortBy);

      let contestPaginated = {};
      if (!page) contestPaginated = modifiedList;
      else contestPaginated = modifiedList.slice((page - 1) * 10, page * 10);

      return successResponse('getallcontets', {
        contestJoinedCount,
        createdTeamCount,
        fixtureAPIId,
        contest: contestPaginated,
        page: page || 0,
      });
    } catch (error) {
      console.log(error);
      return commonErrors('getallcontets', null);
    }
  }

  async getContestDetail(userID: string, contestId: string, gameType: string) {
    try {
      const data = await this.contestModel.findById(contestId);
      if (data.prize.prizeSplitUp) {
        data.prize.priceSplitUp = this.priceSplitUp(data.prize.prizeSplitUp);
      }

      data['joinedCount'] = data.jointUsers?.[userID]?.userTeams
        ? Object.keys(data.jointUsers?.[userID]?.userTeams).length
        : 0;

      const fixtureAPIId = data.fixtureAPIId;
      const createdTeamCount = await this.teams.getTeamCount(
        fixtureAPIId,
        userID,
        gameType,
      );

      return successResponse('getallcontets', {
        createdTeamCount,
        fixtureAPIId,
        contest: data,
      });
    } catch (error) {
      return commonErrors('getallcontets');
    }
  }
  async joinContestUpdate(
    contestId: string,
    teamCount: number,
    contest: any,
    userId: string,
  ) {
    const update = await this.contestModel.findByIdAndUpdate(contestId, {
      $inc: { remainingSpots: -teamCount },
      $set: { [`jointUsers.${userId}`]: contest.jointUsers[userId] },
    });
    return update;
  }

  async updateContest(contestId: string, contest: any): Promise<void> {
    await this.contestModel.findByIdAndUpdate(contestId, contest);
  }

  async getMyContest(
    userID: string,
    fixtureAPIId: number,
    gameType: string,
    page: number,
  ) {
    try {
      const contests = await this.contestModel.find({
        enabledStatus: true,
        fixtureAPIId,
        [`jointUsers.${userID}.userName`]: {
          $regex: new RegExp(''.toLowerCase(), 'i'),
        },
        isactive: true,
      });
      const usercontest = contests.map((item) => {
        item.prize.priceSplitUp = item?.prize?.prizeSplitUp
          ? this.priceSplitUp(item.prize.prizeSplitUp)
          : [];
        return item;
      });

      const teamList = usercontest.reduce(
        (teams, ite) => [
          ...teams,
          ...Object.values(ite.jointUsers[userID]?.userTeams),
        ],
        [],
      );

      const getTeams = await this.teams.getUserJoinedTeam(
        fixtureAPIId,
        gameType,
        teamList,
      );

      const user_joined_Teams = getTeams.length ? getTeams[0]?.userTeams : [];
      const groupUserTeams = user_joined_Teams.reduce(
        (group: any, ite: any) => {
          group[ite._id] = {
            teamId: ite._id,
            teamName: ite.teamName,
            captain: this.capVc(ite.team, 'cap'),
            viceCaptain: this.capVc(ite.team, 'vc'),
          };
          return group;
        },
        {},
      );

      const contest = usercontest.reduce((teams, ite) => {
        const item = {
          ...JSON.parse(JSON.stringify(ite)),
          joinedTeams: Object.values(ite['jointUsers']?.[userID]?.['userTeams'])
            .map((team: any) => groupUserTeams[team.teamId])
            .filter((ite) => ite && ite),
        };

        const userName = ite['jointUsers']?.[userID]?.userName;
        const userTeam = [];
        const userTeams = Object?.values(
          item?.jointUsers?.[userID]?.userTeams,
        ).sort((a: any, b: any) => a?.rank - b?.rank);
        for (const index of userTeams) {
          const temp: any = index;
          temp.price = temp.price || 0;
          temp.userName = userName;
          userTeam.push(temp);
        }

        item.userTeams = userTeam || null;

        teams = [...teams, item];
        return teams;
      }, []);

      // get joined team count of user

      let contestJoinedCount = 0;
      contest.forEach((ite) => {
        (ite['joinedCount'] =
          Object.values(ite['jointUsers']?.[userID]?.['userTeams'])?.length ||
          0),
          (contestJoinedCount += ite['joinedCount'] && 1);
      });

      const createdTeamCount = await this.teams.getTeamCount(
        fixtureAPIId,
        userID,
        gameType,
      );

      let contestPaginated = contest.slice((page - 1) * 10, page * 10); // Pagination

      return successResponse('retrived', {
        contestJoinedCount,
        createdTeamCount,
        fixtureAPIId,
        contest: contestPaginated,
      });
    } catch (error) {
      console.log(error);
      return commonErrors('getallcontets');
    }
  }

  // get Leader board
  async getLeaderBoard(userID: string, contestID: string, page: number = 1) {
    try {
      const data = await this.contestModel.findById(contestID);
      const teamList = data?.jointUsers;
      const leaderBoardTeams = [];
      for (const key in teamList) {
        const { userTeams } = teamList[key];
        for (const team in userTeams) {
          userTeams[team]['userId'] = key;
          userTeams[team]['userName'] = teamList[key].userName;
          leaderBoardTeams.push(userTeams[team]);
        }
      }

      const desc_LeaderBoard = leaderBoardTeams.sort(
        (a, b) => b.points - a.points,
      );
      const teamCollection = {
        userTeams: [],
        AllTeams: [],
      };
      const split_userTeams = desc_LeaderBoard.reduce((teams, value, index) => {
        const team = { ...value /*rank: index + 1 */ };
        if (userID === value.userId) teams.userTeams.push(team);
        else teams.AllTeams.push(team);
        return teams;
      }, teamCollection);

      const { userTeams, AllTeams } = split_userTeams;
      if (!userTeams.length && !AllTeams.length) {
        const joinedUsers = 0;
        return successResponse('leaderBoard', {
          combinedTeams: [],
          page,
          joinedUsers,
        });
      }

      split_userTeams.combinedTeams = [
        ...split_userTeams.userTeams.map((e: any) => ({ ...e, myTeam: true })),
        ...split_userTeams.AllTeams.map((e: any) => ({ ...e, myTeam: false })),
      ].slice((page - 1) * 20, page * 20);

      split_userTeams.page = page;
      split_userTeams.joinedUsers = leaderBoardTeams.length;
      return successResponse('leaderBoard', split_userTeams);
    } catch (error) {
      return commonErrors('leaderBoard', {});
    }
  }

  async contestCreation(createContestInput: contestCreationInput, user: any) {
    try {
      const currentDate = new Date();
      currentDate.setHours(0, 0, 0, 0);

      const timeOutCheck = await this.timeoutModel.findOne({
        timeOutEndDate: { $gte: currentDate },
        userId: user._id,
      });

      if (timeOutCheck) return commonErrors('timeoutactive');
      const contest: Contest =
        this.contestHelper.formatContest(createContestInput);
      contest.createdBy = user?.userName || '';
      const contestCreation = await this.contestModel.create(contest);
      await this.contestModel.findByIdAndUpdate(contestCreation._id, {
        jointUsers: {},
      });

      await this.joinContest(
        {
          contestId: contestCreation._id.toString(),
          teamList: createContestInput.joiningTeams,
          fixtureAPIId: contestCreation.fixtureAPIId,
          gameType: createContestInput.gameType,
        },
        user,
      );

      return successResponse('contestcreate', {
        contestCode: contestCreation.contestCode,
      });
    } catch (err) {
      return commonErrors('contestcreate');
    }
  }

  async downloadLeaderboard(userID: string, contestID: string) {
    try {
      const contest = await this.contestModel.findById(contestID);
      const { data } = await this.getLeaderBoard(userID, contestID);
      const allTeams: leaderBoard_team_Detail[] = [
        ...data.userTeams,
        ...data.AllTeams,
      ];
      const fixtureTeams: userTeams = await this.teams.selectUserTeams(
        contest.fixtureAPIId,
      );
      const userTeams = fixtureTeams.userTeams.reduce(
        (value: any, item: any) => {
          value[item['_id']] = item;
          return value;
        },
        {},
      );

      const response: teamLeaderbord[] = allTeams.map(
        (team: leaderBoard_team_Detail) => {
          return {
            teamId: team.teamId,
            points: team.points,
            price: team.price,
            rank: team.rank,
            userName: team.userName,
            teamName: team.teamName,
            team: userTeams[team.teamId].team,
          };
        },
      );

      return successResponse('leaderBoard', response);
    } catch (err) {
      console.log(err);
      return commonErrors('leaderBoard');
    }
  }

  async checkTimeout(userId: string) {
    try {
      const currentDate = new Date();
      const timeout = await this.timeoutModel
        .findOne({
          userId,
          timeOutEndDate: { $gte: currentDate },
        })
        .lean();
      return successResponse('found', timeout);
    } catch (err) {
      return commonErrors('timeoutcheck');
    }
  }

  async privateContestCheck(
    contestCode: string,
    fixtureAPIId: number,
    userId: string,
    gameType: string,
  ) {
    try {
      const contest = await this.contestModel.findOne({ contestCode });
      if (contest.fixtureAPIId != fixtureAPIId)
        return commonErrors('contestmissmatch');
      const fixture = await this.trpcService.game('getfixture', {
        fixtureAPIId: contest.fixtureAPIId,
        gameType,
      });

      if (
        !fixture ||
        fixture?.fixtureStatus !=
          (gameType === 'cricket' ? 'Upcoming' : 'upcoming') ||
        contest.remainingSpots == 0
      )
        throw new Error();

      const userTeams = await this.teams.myTeams({
        fixtureAPIId: contest.fixtureAPIId,
        userId,
        gameType,
      });

      const responseOBj: privateContestData = {
        fixtureAPIId: fixture.fixtureAPIId,
        fixtureDisplayName: fixture.fixtureDisplayName,
        fixtureStartDate: fixture.fixtureStartDate,
        fixtureStatus: fixture.fixtureStatus,
        fixtureType: fixture.fixtureType || '',
        seriesAPIId: fixture.seriesAPIId,
        seriesName: fixture.seriesName,
        seriesShortName: fixture.seriesShortName,
        teamAFullName: fixture?.fixtureTeams?.teamA?.name,
        teamAlogo: fixture?.fixtureTeams?.teamA?.logo,
        teamAShortName: fixture?.fixtureTeams?.teamA?.shortName,
        teamBFullName: fixture?.fixtureTeams?.teamB?.name,
        teamBlogo: fixture?.fixtureTeams?.teamB?.logo,
        teamBShortName: fixture?.fixtureTeams?.teamB?.shortName,
        contestId: contest._id.toString(),
        contestName: contest.contestName,
        maxTeamCount: contest.maxTeamCount,
        createdTeamCount: userTeams?.data?.length || 0,
      };

      return successResponse('privatecontest', responseOBj);
    } catch (err) {
      return commonErrors('privatecontest');
    }
  }

  private priceSplitUp(price: ArrayLike<unknown> | { [s: string]: unknown }) {
    return Object.entries(price).map((item: any) => ({
      rank: item[0],
      price: item[1],
    }));
  }

  async contestDuplication(contestId: string) {
    try {
      const mainContest = await this.contestModel.findById(contestId).lean();
      mainContest.previousContest = mainContest['_id'].toString();
      delete mainContest['_id'];
      if (!mainContest.guaranteed) {
        mainContest.prize.prizeBreak = {};
        mainContest.prize.prizeBreakup = [];
      }
      mainContest.jointUsers = {};
      mainContest.remainingSpots = mainContest.totalSpots;
      mainContest.autoCreate = true;
      mainContest.adminCumissionPercentage =
        mainContest.adminCumissionPercentage;
      mainContest.startDate = mainContest.startDate;
      mainContest.contestCode = await this.contestHelper.contestCode(12); //Auto generate code
      const contestCheck = await this.contestModel
        .find({ previousContest: mainContest.previousContest })
        .lean();
      const options = { upsert: true, new: true, setDefaultsOnInsert: true };
      const duplicateContest = await this.contestModel.findOneAndUpdate(
        { previousContest: mainContest.previousContest },
        mainContest,
        options,
      );
      // const duplicateContest = await this.contestModel.create(mainContest);
      await this.contestModel.findByIdAndUpdate(
        duplicateContest._id.toString(),
        {
          $set: { jointUsers: {}, 'prize.prizeBreak': {} },
        },
      );
      return 'Success';
    } catch (err) {
      return { status: false };
    }
  }
  private capVc(team: any, key: string) {
    return team.reduce((player: any, ite: any) => {
      if (ite[key]) {
        player.imgUrl = ite.imgUrl;
        player.jerseyUrl = ite?.jerseyUrl || '';
        player.playerImageUrl = ite?.playerImageUrl || '';
        player.playerName = ite.playerName;
        player.playerDisplayName = ite.playerDisplayName;
        player.teamName = ite.teamName;
      }
      return player;
    }, {});
  }

  private sortFn(lists: any, code: any): any {
    const sortCode = {
      1: 'entryFee',
      2: 'totalSpots',
      3: 'totalPrizePool',
      4: 'winningPercentage',
    };
    const item = sortCode[Math.abs(code || 3)] || null;

    if (!item) return lists;
    const direction = Math.sign(code);
    const assignpostion = {};

    return lists
      .sort((a: any, b: any) =>
        a[item] < b[item] ? -direction : a[item] > b[item] ? direction : 0,
      )
      .map((item: { contestName: string | number; position: boolean }) => {
        if (!assignpostion[item.contestName]) {
          assignpostion[item.contestName] = 1;
          item.position = true;
        } else {
          assignpostion[item.contestName] += 1;
          item.position = false;
        }
        return item;
      });
  }
}
