import { Field, ObjectType, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { contest_defaultFields } from 'src/commonResponse/response.entity';

export type PredictorAnswersDocument = PredictorAnswers & Document;

@ObjectType()
export class AnswerQuestions {
  @Field()
  questionId: string;
  @Field()
  answerOption: string;
  @Field()
  isAnswered: boolean;
  @Field()
  isCorrect: boolean;
}

@ObjectType()
@Schema()
export class PredictorAnswers {
  @Field()
  @Prop()
  predictorId: string;
  @Field()
  @Prop()
  title: string;
  @Field()
  @Prop()
  description: string;
  @Field()
  @Prop()
  userId: string;
  @Field()
  @Prop()
  fixtureAPIId: number;
  @Field()
  @Prop()
  remainingQuestions: number;
  @Field()
  @Prop()
  isFinished: boolean;
  @Field()
  @Prop()
  isDeclared: boolean;
  @Field()
  @Prop()
  correctAnsCount: number;
  @Field(() => [AnswerQuestions])
  @Prop({ type: Array })
  questions: AnswerQuestions[];
}

@ObjectType()
export class PredictorAnswerRes extends PartialType(contest_defaultFields) {
  @Field(() => PredictorAnswers, { nullable: true })
  data: PredictorAnswers;
}

export const PredictorAnswerschema =
  SchemaFactory.createForClass(PredictorAnswers);
