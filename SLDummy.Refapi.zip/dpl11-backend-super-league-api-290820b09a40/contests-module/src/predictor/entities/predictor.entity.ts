import { Field, ObjectType, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { contest_defaultFields } from 'src/commonResponse/response.entity';

export type PredictorDocument = Predictor & Document;

@ObjectType()
export class PredictorOptionsObj {
  @Field({ defaultValue: '' })
  option?: string;
  @Field()
  checkStr: string;
  @Field()
  optionStr: string;
  @Field()
  selby: number;
  @Field()
  isCorrect: boolean;
}

@ObjectType()
export class PredictorOptions {
  @Field(() => PredictorOptionsObj)
  a: PredictorOptionsObj;
  @Field(() => PredictorOptionsObj)
  b: PredictorOptionsObj;
  @Field(() => PredictorOptionsObj, { nullable: true })
  c: PredictorOptionsObj;
  @Field(() => PredictorOptionsObj, { nullable: true })
  d: PredictorOptionsObj;
}
@ObjectType()
export class PredictorQuestions {
  @Field()
  _id: string;
  @Field()
  qStr: string;
  @Field()
  event: string;
  @Field()
  teamAPIId: number;
  @Field()
  totalAnswers: number;

  @Field(() => [PredictorOptionsObj])
  optionsRes: PredictorOptionsObj[];

  // @Field(() => PredictorOptions)
  options?: PredictorOptions;
}

@ObjectType()
@Schema()
export class Predictor {
  @Field({ nullable: true })
  _id?: string;
  @Field()
  @Prop()
  predictorType: string;
  @Field()
  @Prop()
  title: string;
  @Field()
  @Prop()
  description: string;
  @Field()
  @Prop()
  fixtureAPIId: number;
  @Field()
  @Prop()
  totalQuestions: number;
  @Field()
  @Prop()
  totalAttempts: number;
  @Field()
  @Prop()
  isCompleted: boolean;
  @Field()
  @Prop()
  createdAt: Date;
  @Field()
  @Prop()
  isactive: boolean;
  @Field(() => [PredictorQuestions])
  @Prop({ type: Array })
  questions: PredictorQuestions[];
}

@ObjectType()
export class PredictorQuestionsRes extends PartialType(contest_defaultFields) {
  @Field(() => [Predictor], { nullable: true })
  data: Predictor[];
}

export const PredictorSchema = SchemaFactory.createForClass(Predictor);
