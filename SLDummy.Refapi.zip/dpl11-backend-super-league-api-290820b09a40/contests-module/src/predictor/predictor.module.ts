import { Module } from '@nestjs/common';
import { PredictorService } from './predictor.service';
import { PredictorResolver } from './predictor.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import { Predictor, PredictorSchema } from './entities/predictor.entity';
import {
  PredictorAnswers,
  PredictorAnswerschema,
} from './entities/predictor-ans.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Predictor.name, schema: PredictorSchema },
      { name: PredictorAnswers.name, schema: PredictorAnswerschema },
    ]),
  ],
  providers: [PredictorResolver, PredictorService],
})
export class PredictorModule {}
