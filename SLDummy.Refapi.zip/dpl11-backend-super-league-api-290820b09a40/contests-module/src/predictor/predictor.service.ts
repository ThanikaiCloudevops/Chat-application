import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { PredictorDocument } from './entities/predictor.entity';
import {
  PredictorAnswers,
  PredictorAnswersDocument,
} from './entities/predictor-ans.entity';
import { commonErrors } from 'src/commonResponse/errors';
import { successResponse } from 'src/commonResponse/success';

@Injectable()
export class PredictorService {
  constructor(
    @InjectModel('Predictor') private PredictorModel: Model<PredictorDocument>,
    @InjectModel('PredictorAnswers')
    private PredictorAnswersModel: Model<PredictorAnswersDocument>,
  ) {}

  async viewPredictors(fixtureAPIId: number, predictorId?: string) {
    try {
      if (predictorId) {
        const predictor = await this.PredictorModel.findById(predictorId);
        predictor.questions.forEach((f) => {
          f.optionsRes = [];
          for (const key in f.options) {
            f.optionsRes.push({ option: key, ...f.options[key] });
          }
        });

        return successResponse('found', [predictor]);
      }
      const predictors = await this.PredictorModel.find({ fixtureAPIId });
      predictors.forEach((e) => {
        e.questions.forEach((f) => {
          f.optionsRes = [];
          for (const key in f.options) {
            f.optionsRes.push({ option: key, ...f.options[key] });
          }
        });
      });

      return successResponse('found', predictors);
    } catch (err) {
      return successResponse('found', []);
    }
  }

  async answerPredictor(
    userId: string,
    predictorId: string,
    questionId: string,
    option: string,
  ) {
    try {
      if (!userId) userId = '66c8346abf8c6740825cfe14';
      let answeredQuestions: number = 0;
      const predictorQuestion = await this.PredictorModel.findById(predictorId);
      if (!predictorQuestion) return commonErrors('data');
      if (!JSON.stringify(predictorQuestion.questions).includes(questionId))
        return commonErrors('question');

      const ansCheck = await this.PredictorAnswersModel.findOne({
        userId,
        predictorId,
      });
      if (!ansCheck) {
        const predictorAnsInit: PredictorAnswers = {
          userId,
          predictorId,
          description: predictorQuestion.description,
          title: predictorQuestion.title,
          fixtureAPIId: predictorQuestion.fixtureAPIId,
          remainingQuestions: predictorQuestion.totalQuestions,
          isFinished: false,
          isDeclared: false,
          correctAnsCount: 0,
          questions: [],
        };

        predictorAnsInit.questions.push({
          questionId,
          answerOption: option,
          isAnswered: true,
          isCorrect: false,
        });
        await this.PredictorAnswersModel.create(predictorAnsInit);
        answeredQuestions = 1;
      } else {
        if (JSON.stringify(ansCheck.questions).includes(questionId))
          return commonErrors('ansdone');

        ansCheck.questions.push({
          questionId,
          answerOption: option,
          isAnswered: true,
          isCorrect: false,
        });
        await this.PredictorAnswersModel.findByIdAndUpdate(
          ansCheck._id,
          ansCheck,
        );
        answeredQuestions = ansCheck.questions.length;
      }

      if (predictorQuestion.questions.length == answeredQuestions)
        predictorQuestion.totalAttempts++;

      predictorQuestion.questions.forEach((e) => {
        if (e._id == questionId) {
          e.totalAnswers++;
          e.options[option].selby++;
          return;
        }
      });

      await this.PredictorModel.findByIdAndUpdate(
        predictorQuestion._id,
        predictorQuestion,
      );

      return successResponse('answer');
    } catch (err) {
      return commonErrors('predictor');
    }
  }

  async listPredictorProgress(userId: string, predictorId: string) {
    try {
      if (!userId) userId = '66c8346abf8c6740825cfe14';
      const predictorAnsCheck = await this.PredictorAnswersModel.findOne({
        userId,
        predictorId,
      });
      if (!predictorAnsCheck) throw new Error();

      return successResponse('found', predictorAnsCheck);
    } catch (err) {
      return commonErrors('data');
    }
  }

  async myPredictors(fixtureAPIId: number, userId: string) {
    try {
      if (!userId) userId = '66c8346abf8c6740825cfe14';
      const predictorAnsCheck = await this.PredictorAnswersModel.find({
        userId,
        fixtureAPIId,
      });

      return successResponse('found', predictorAnsCheck);
    } catch (err) {
      return successResponse('found', []);
    }
  }
}
