import { Args, Context, Resolver } from '@nestjs/graphql';
import { PredictorService } from './predictor.service';
import { Query } from '@nestjs/graphql';
import { PredictorQuestionsRes } from './entities/predictor.entity';
import { AuthGuard } from 'src/auth/auth.guard';
import { UseGuards } from '@nestjs/common';
import { PredictorAnswerRes } from './entities/predictor-ans.entity';
import { contest_defaultFields } from 'src/commonResponse/response.entity';

@Resolver()
// @UseGuards(AuthGuard)
export class PredictorResolver {
  constructor(private readonly predictorService: PredictorService) {}

  @Query(() => PredictorQuestionsRes, { name: 'getPredictords' })
  getPredictords(
    @Context('user') user: any,
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('predictorId', { nullable: true }) predictorId?: string,
  ) {
    return this.predictorService.viewPredictors(fixtureAPIId, predictorId);
  }

  @Query(() => PredictorAnswerRes, { name: 'predictorProgress' })
  predictorProgress(
    @Context('user') user: any,
    @Args('predictorId', { nullable: true }) predictorId?: string,
  ) {
    return this.predictorService.listPredictorProgress(user?._id, predictorId);
  }

  @Query(() => PredictorAnswerRes, { name: 'myPredictors' })
  myPredictors(
    @Context('user') user: any,
    @Args('fixtureAPIId') fixtureAPIId: number,
  ) {
    return this.predictorService.myPredictors(fixtureAPIId, user?._id);
  }

  @Query(() => contest_defaultFields, { name: 'predictorAnswer' })
  predictorAnswer(
    @Context('user') user: any,
    @Args('predictorId') predictorId: string,
    @Args('questionId') questionId: string,
    @Args('option') option: string,
  ) {
    return this.predictorService.answerPredictor(
      user?._id,
      predictorId,
      questionId,
      option,
    );
  }
}
