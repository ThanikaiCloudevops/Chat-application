import { Injectable } from '@nestjs/common';
type count = {
  [player: string]: number;
};
// bowl
// ar
// bat
// wk
@Injectable()
export class validateTeamSelection {
  validateTeam(team: any[]): boolean {
    if (team.length < 11) return false;

    // cap/vc
    const count = this.#getPlayerCount(team);

    const isZero: boolean = Object.values(count).some(
      (ite: number) => ite == 0,
    );
    if (count.cap !== 1 || count.vc !== 1 || isZero) return false;

    const wk = count.wk || 1;
    const bat = count.bat > 1 ? count.bat : 1;
    const ar = count.ar || 1;
    const bowl = count.bowl > 1 ? count.bowl : 1;

    // check count
    const check = {
      _wk: count.wk + bat + ar + bowl <= 11,
      _bat: wk + count.bat + ar + bowl <= 11,
      _ar: wk + bat + count.ar + bowl <= 11,
      _bowl: wk + bat + ar + count.bowl <= 11,
    };

    return check._wk && check._bat && check._ar && check._bowl;
  }

  #getPlayerCount(team: any[]) {
    return team.reduce(
      (eachCount: count, player: { [item: string]: string | number }) => {
        eachCount[player['playerType']] += 1;
        eachCount['cap'] += player['cap'] ? 1 : 0;
        eachCount['vc'] += player['vc'] ? 1 : 0;
        return eachCount;
      },
      {
        wk: 0,
        bat: 0,
        ar: 0,
        bowl: 0,
        cap: 0,
        vc: 0,
      },
    );
  }
}

@Injectable()
export class validateFootballTeamSelection {
  validateFootballTeam(team: any[]): boolean {
    if (team.length < 11) return false;
    // cap/vc
    const count = this.#getfootballPlayerCount(team);

    const isZero: boolean = Object.values(count).some(
      (ite: number) => ite == 0,
    );
    if (count.cap !== 1 || count.vc !== 1 || isZero) return false;

    const G = count.G || 1;
    const D = count.D > 1 ? count.D : 1;
    const M = count.M || 1;
    const F = count.F > 1 ? count.F : 1;

    // check count
    const check = {
      _G: count.G + D + M + F <= 11,
      _D: G + count.D + M + F <= 11,
      _M: G + D + count.M + F <= 11,
      _F: G + D + M + count.F <= 11,
    };

    return check._G && check._D && check._M && check._F;
  }

  #getfootballPlayerCount(team: any[]) {
    return team.reduce(
      (eachCount: count, player: { [item: string]: string | number }) => {
        eachCount[player['playerType']] += 1;
        eachCount['cap'] += player['cap'] ? 1 : 0;
        eachCount['vc'] += player['vc'] ? 1 : 0;
        return eachCount;
      },
      {
        G: 0,
        D: 0,
        M: 0,
        F: 0,
        cap: 0,
        vc: 0,
      },
    );
  }
}

@Injectable()
export class validateKabaddiTeamSelection {
  validateKabaddiTeam(team: any[]): boolean {
    if (team.length < 7) return false;
    // cap/vc
    const count = this.#getkabaddiPlayerCount(team);

    const isZero: boolean = Object.values(count).some(
      (ite: number) => ite == 0,
    );
    if (count.cap !== 1 || count.vc !== 1 || isZero) return false;

    const defender = count.defender || 1;
    const raider = count.raider > 1 ? count.raider : 1;
    const allrounder = count.allrounder || 1;

    // check count
    const check = {
      _defender: count.defender + raider + allrounder <= 7,
      _raider: defender + count.raider + allrounder <= 7,
      _allrounder: defender + raider + count.allrounder <= 7,
    };

    return check._defender && check._raider && check._allrounder;
  }

  #getkabaddiPlayerCount(team: any[]) {
    return team.reduce(
      (eachCount: count, player: { [item: string]: string | number }) => {
        eachCount[player['playerType']] += 1;
        eachCount['cap'] += player['cap'] ? 1 : 0;
        eachCount['vc'] += player['vc'] ? 1 : 0;
        return eachCount;
      },
      {
        defender: 0,
        raider: 0,
        allrounder: 0,
        cap: 0,
        vc: 0,
      },
    );
  }
}
