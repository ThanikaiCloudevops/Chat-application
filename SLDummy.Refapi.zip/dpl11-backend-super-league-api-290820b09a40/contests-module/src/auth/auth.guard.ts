import {
  CanActivate,
  ExecutionContext,
  HttpException,
  HttpStatus,
  Injectable,
} from '@nestjs/common';
import { GqlExecutionContext } from '@nestjs/graphql';
import { userAuth } from 'src/trpc/client/trpc';

@Injectable()
export class AuthGuard implements CanActivate {
  async canActivate(context: ExecutionContext): Promise<boolean> {
    try {
      const ctx = GqlExecutionContext.create(context).getContext();
      const token = ctx.req.headers?.authorization.split(' ')[1];
      const user = await userAuth['verify'].query({ token });
      ctx.user = user;
      return user ? true : false;
    } catch (error) {
      throw new HttpException('UnAuthendicated', HttpStatus.UNAUTHORIZED);
    }
  }
}
