import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ContestModule } from './contest/contest.module';
import { MongooseModule } from '@nestjs/mongoose';
import { GraphQLModule } from '@nestjs/graphql';
import {
  ApolloFederationDriver,
  ApolloFederationDriverConfig,
} from '@nestjs/apollo';
import { TrpcModule } from './trpc/server/trpc.module';
import { DB } from 'config/envirnment';
import { TeamsModule } from './teams/teams.module';
import { PredictorModule } from './predictor/predictor.module';

@Module({
  imports: [
    MongooseModule.forRoot(DB.URL, {
      maxConnecting: 5,
      maxPoolSize: 5,
      connectTimeoutMS: 3000,
      socketTimeoutMS: 8000,
      maxIdleTimeMS: 10000,
    }),
    GraphQLModule.forRoot<ApolloFederationDriverConfig>({
      driver: ApolloFederationDriver,
      autoSchemaFile: {
        federation: 2,
      },
      includeStacktraceInErrorResponses: false,
    }),
    ContestModule,
    TrpcModule,
    TeamsModule,
    PredictorModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
