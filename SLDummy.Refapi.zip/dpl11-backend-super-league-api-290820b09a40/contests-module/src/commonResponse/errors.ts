import { GraphQLError } from 'graphql';

const errorMsg = {
  getallcontets: 'No Contests Found',
  joincontest: 'Contest not found for the fixture',
  teamcreation: 'Team creation error',
  contestfull: 'Max amount of teams reached',
  invalidTeam: 'Not a valid team',
  duplicate: 'Team already exist',
  retrived: 'No teams Found',
  AlreadyJoined: 'Already joined this contest with this team',
  balance: 'Insufficient balance',
  leaderBoard: 'No teams available',
  timeout: 'Error setting timeout',
  timeoutexist: 'Time out already active',
  contestcreate: 'Error in contest creation',
  contestjoin: 'Error joining contest',
  spots: 'Contest maximum spots reached',
  timeoutcheck: 'Timeout not found',
  max: 'Maximum team count reached',
  privatecontest: 'Contest not avaliable to join ',
  contestmissmatch: 'Contest not avaliable for given fixture',
  timeoutactive: 'Time out is active unable to join contest',
  data: 'Data not found',
  predictor: 'Predictor answer recorded successfully',
  question: 'Question not found',
  ansdone: 'Question already answered',
  live: 'Match already live',
};

export function commonErrors(errorType: string, data: any = null) {
  return { status: false, error: { message: errorMsg[errorType] }, data };
}
export function handleException(error) {
  throw new GraphQLError(error, {
    extensions: {
      code: 'FORBIDDEN',
    },
  });
}
