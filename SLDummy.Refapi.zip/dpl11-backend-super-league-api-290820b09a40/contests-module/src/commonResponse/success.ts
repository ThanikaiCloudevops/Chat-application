const successMsg = {
  getallcontets: 'Get all Contests',
  joinContest: 'Contest joined successfully',
  teamCreated: 'Team created successfully',
  retrived: 'Team retrived successfully',
  updated: 'Team updated successfully',
  switched: 'Team Switched successfully',
  leaderBoard: 'Leader Board retrived successfully',
  timeout: 'Timeout set successfullu',
  contestcreate: 'Contest created successfully',
  notfound: 'Data not found',
  found: 'Data found',
  privatecontest: 'Private contest avaliable',
  answer: 'Predictor answer recorded successfully',
};
export function successResponse(msg: string, data: any = null) {
  return { status: true, success: { message: successMsg[msg] }, data };
}
