import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { TimeOut } from 'src/contest/entities/timeout.entity';
import { team, userTeam } from 'src/teams/entities/team.entity';

@ObjectType()
export class contest_message {
  @Field({ nullable: true, defaultValue: '' })
  message: string;
  @Field({ nullable: true, defaultValue: '' })
  location: string;
}

@ObjectType()
class selectionTypes {
  @Field(() => [team])
  diffrent: team[];
  @Field(() => [team])
  common: team[];
  @Field(() => [team])
  capvcCommon: team[];
  @Field(() => [team])
  capvcDiffrent: team[];
}

@ObjectType()
class compareTeams {
  @Field(() => selectionTypes)
  teamA: selectionTypes;
  @Field(() => selectionTypes)
  teamB: selectionTypes;
}

@ObjectType()
export class privateContestData {
  @Field()
  fixtureAPIId: number;
  @Field()
  seriesAPIId: number;
  @Field()
  seriesName: string;
  @Field()
  fixtureType: string;
  @Field()
  fixtureDisplayName: string;
  @Field()
  fixtureStatus: string;
  @Field()
  seriesShortName: string;
  @Field()
  fixtureStartDate: Date;
  @Field()
  teamAShortName: string;
  @Field()
  teamBShortName: string;
  @Field()
  teamAlogo: string;
  @Field()
  teamBlogo: string;
  @Field()
  teamAFullName: string;
  @Field()
  teamBFullName: string;
  @Field()
  contestName: string;
  @Field()
  contestId: string;
  @Field()
  maxTeamCount: number;
  @Field({ defaultValue: 0 })
  createdTeamCount: number;
}

@ObjectType()
export class contest_defaultFields {
  @Field()
  status: boolean;

  @Field({ nullable: true })
  error: contest_message;

  @Field({ nullable: true })
  success: contest_message;
}

@ObjectType()
export class privateContestResponse extends PartialType(contest_defaultFields) {
  @Field(() => privateContestData, { nullable: true })
  data: privateContestData;
}

@ObjectType()
export class timeoutRes extends PartialType(contest_defaultFields) {
  @Field(() => TimeOut, { nullable: true })
  data: TimeOut;
}

@ObjectType()
export class singleTeamResponse extends PartialType(contest_defaultFields) {
  @Field(() => userTeam)
  data: userTeam;
}

@ObjectType()
class contestCode {
  @Field()
  contestCode: string;
}

@ObjectType()
export class contestCreationResponse extends PartialType(
  contest_defaultFields,
) {
  @Field(() => contestCode)
  data: contestCode;
}

@ObjectType()
export class compareTeamResponse extends PartialType(contest_defaultFields) {
  @Field(() => compareTeams)
  data: compareTeams;
}

// an optional type //data?: Prettify<dataFields>;
export type Prettify<T> = {
  [K in keyof T]: T[K];
} & object;
