export const MODULE = { NAME: 'Contest Module', PORT: 5002 };
export const DB = {
  URL: 'mongodb+srv://super-league_user01:RiBA5Y8HUiDFUpEo@cluster-1.fehzk.mongodb.net/superleague?retryWrites=true&w=majority&appName=Cluster-1',
};

export const TRPC = {
  //development
  /* USERAUTH: 'http://{devip}:5000/trpc/userauth',
  SCORECARD: 'http://{devip}:4000/trpc/scorecard',
  CRICKETGAME: 'http://{devip}:5001/trpc/game',
  TRANSACTION: 'http://{devip}:5005/trpc/wallet', */

  // local
  USERAUTH: 'http://localhost:5000/trpc/userauth',
  SCORECARD: 'http:/localhost:4000/trpc/scorecard',
  CRICKETGAME: 'http:/localhost:5001/trpc/game',
  TRANSACTION: 'http://localhost:5005/trpc/wallet',
};
