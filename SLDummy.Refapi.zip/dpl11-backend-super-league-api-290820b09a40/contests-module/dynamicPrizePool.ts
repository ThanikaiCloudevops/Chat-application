const initialPrizePool = {
  '1': 100,
  '2': 80,
  '3': 80,
  '4': 30,
  '5': 30,
  '6': 30,
  '7': 30,
  '8': 20,
  '9': 20,
  '10': 20,
  '11': 20,
  '12': 20,
  '13': 10,
  '14': 10,
  '15': 10,
  '16': 10,
  '17': 10,
  '18': 10,
  '19': 10,
  '20': 10,
};
const maxJointUsers = 80;
const entryFee = 10;
const adminCommision = 0.3;
const jointUsers = 80;

function dynamicSplitUp(
  initialPrizePool: object,
  maxJointUsers: number,
  entryFee: number,
  adminCommision: number,
  currentJointUsers: number,
): object {
  try {
    if (currentJointUsers < 2) return {};
    if (maxJointUsers == currentJointUsers) return initialPrizePool;
    if (maxJointUsers < currentJointUsers) return initialPrizePool;
    const prizePercentagePerRank = {};
    const dynamicPoolPercentage = {};
    const dynamicPriceSplit = {};
    const dynamicSumCoefficient = {};
    let reducibleRanks = [];
    let coefficientRequiredCount = 0;
    let requiredPercentageSum = 0;
    let remainingPrizePercentage = 0;

    const initialWinnersCount = Object.values(initialPrizePool).length;
    const currentUserPrize = Math.floor(
      currentJointUsers * entryFee * (1 - adminCommision),
    );
    const minPrizePercentage = +(
      ((entryFee + 1) / currentUserPrize) *
      100
    ).toFixed(2);
    const maxPrizePool = Math.floor(
      maxJointUsers * entryFee * (1 - adminCommision),
    );
    let winnersPercentage = +(initialWinnersCount / maxJointUsers).toFixed(2);
    let currentWinnersCount = Math.floor(winnersPercentage * currentJointUsers);
    if (winnersPercentage < 0.4) {
      if (currentJointUsers <= 5) {
        winnersPercentage = 0.4;
        currentWinnersCount = Math.floor(winnersPercentage * currentJointUsers);
      } else {
        const perUserDecrement =
          (0.4 - winnersPercentage) / (maxJointUsers - 5);
        winnersPercentage = 0.4 - perUserDecrement * currentJointUsers;
        currentWinnersCount = Math.floor(winnersPercentage * currentJointUsers);
      }

      /* if (currentWinnersCount < initialWinnersCount) {
        winnersPercentage = 0.4;
        currentWinnersCount = Math.floor(winnersPercentage * currentJointUsers);
      }
      if (currentWinnersCount > initialWinnersCount) {
        currentWinnersCount = initialWinnersCount;
        winnersPercentage = +(currentWinnersCount / currentJointUsers).toFixed(
          2,
        );
      } */
    }

    for (const rank in initialPrizePool) {
      const prize = initialPrizePool[rank];
      prizePercentagePerRank[rank] = +Number(
        (prize / maxPrizePool) * 100,
      ).toFixed(2);
    }
    for (let rank = 1; rank < initialWinnersCount + 1; rank++) {
      if (rank <= currentWinnersCount)
        dynamicPoolPercentage[rank] = prizePercentagePerRank[rank];
      else remainingPrizePercentage += prizePercentagePerRank[rank];
    }
    const remainingPrizePercentageDistribution = +(
      remainingPrizePercentage / currentWinnersCount
    ).toFixed(2);
    remainingPrizePercentage = 0;

    for (let rank = 1; rank < currentWinnersCount + 1; rank++) {
      dynamicPoolPercentage[rank] = +(
        dynamicPoolPercentage[rank] + remainingPrizePercentageDistribution
      ).toFixed(2);
    }

    for (const rank in dynamicPoolPercentage) {
      const prizePercentage = dynamicPoolPercentage[rank];
      if (prizePercentage < minPrizePercentage) {
        dynamicSumCoefficient[rank] = +(
          minPrizePercentage - prizePercentage
        ).toFixed(2);
        coefficientRequiredCount++;
      } else dynamicSumCoefficient[rank] = 0;
      requiredPercentageSum += dynamicSumCoefficient[rank];
    }
    const prizeReductionPercentagePerUser = +(
      requiredPercentageSum /
      (currentWinnersCount - coefficientRequiredCount)
    ).toFixed(2);

    for (const rank in dynamicPoolPercentage) {
      if (dynamicSumCoefficient[rank] > 0)
        dynamicPoolPercentage[rank] = +(
          dynamicPoolPercentage[rank] + dynamicSumCoefficient[rank]
        ).toFixed(2);
      else if (
        +(
          dynamicPoolPercentage[rank] - prizeReductionPercentagePerUser
        ).toFixed(2) < minPrizePercentage
      )
        remainingPrizePercentage += prizeReductionPercentagePerUser;
      else {
        dynamicPoolPercentage[rank] = +(
          dynamicPoolPercentage[rank] - prizeReductionPercentagePerUser
        ).toFixed(2);
        reducibleRanks.push(rank);
      }
    }

    let recussion = true;
    while (recussion) {
      recussion = false;
      const perUserReduction = +(
        remainingPrizePercentage / reducibleRanks.length
      ).toFixed(2);
      const arr = [];
      remainingPrizePercentage = 0;
      for (const rank of reducibleRanks) {
        if (
          dynamicPoolPercentage[rank] - perUserReduction >
          minPrizePercentage
        ) {
          dynamicPoolPercentage[rank] = +(
            dynamicPoolPercentage[rank] - perUserReduction
          ).toFixed(2);
        } else
          remainingPrizePercentage = +(
            remainingPrizePercentage + perUserReduction
          ).toFixed(2);
      }
      reducibleRanks = arr;
      if (remainingPrizePercentage > 0) recussion = false;
    }

    let splitSum = 0;

    for (const rank in dynamicPoolPercentage) {
      const pricePercentage = dynamicPoolPercentage[rank];
      dynamicPriceSplit[rank] = +(
        (pricePercentage / 100) *
        currentUserPrize
      ).toFixed(2);

      dynamicPriceSplit[rank] =
        dynamicPriceSplit[rank] < entryFee + 1
          ? +Math.ceil(dynamicPriceSplit[rank])
          : +Math.floor(dynamicPriceSplit[rank]);

      splitSum += dynamicPriceSplit[rank];
    }

    if (splitSum < currentUserPrize) {
      let pendingAmout = currentUserPrize - splitSum;

      let distrubution = true;
      while (distrubution) {
        for (const rank in dynamicPriceSplit) {
          const prize = dynamicPriceSplit[rank];
          if (pendingAmout == 0) {
            distrubution = false;
            break;
          }
          dynamicPriceSplit[rank]++;
          pendingAmout--;
        }
      }

      // console.log({ currentUserPrize });
    }

    return dynamicPriceSplit;
  } catch (err) {
    console.log(err);
    return {};
  }
}

const updatedSplitup = dynamicSplitUp(
  initialPrizePool,
  maxJointUsers,
  entryFee,
  adminCommision,
  jointUsers,
);

console.log(updatedSplitup);

/* function dynamicSplitUpV2(
  initialPrizePool: object,
  maxJointUsers: number,
  entryFee: number,
  adminCommision: number,
  currentJointUsers: number,
): object {
  try {
    if (maxJointUsers == currentJointUsers) return initialPrizePool;
    const prizePercentagePerRank = {};
    const dynamicPoolPercentage = {};
    const dynamicPriceSplit = {};
    const dynamicSumCoefficient = {};
    let splitSum = 0;
    let coefficientReductionCount = 0;
    let reducablePercentageTotalPart = 0;
    let requiredPercentageSum = 0;
    let remainingPrizePercentage = 0;

    const initialWinnersCount = Object.values(initialPrizePool).length;
    const currentUserPrize = Math.floor(
      currentJointUsers * entryFee * (1 - adminCommision),
    );

    const minPrizePercentage = +((entryFee / currentUserPrize) * 100).toFixed(
      2,
    );

    const maxPrizePool = Math.floor(
      maxJointUsers * entryFee * (1 - adminCommision),
    );
    let winnersPercentage = +(initialWinnersCount / maxJointUsers).toFixed(2);
    let currentWinnersCount = Math.floor(winnersPercentage * currentJointUsers);

    if (currentWinnersCount < initialWinnersCount) {
      winnersPercentage = 0.4;
      currentWinnersCount = Math.floor(winnersPercentage * currentJointUsers);
    }
    if (currentWinnersCount > initialWinnersCount) {
      currentWinnersCount = initialWinnersCount;
      winnersPercentage = +(currentWinnersCount / currentJointUsers).toFixed(2);
    }

    for (const rank in initialPrizePool) {
      const prize = initialPrizePool[rank];
      prizePercentagePerRank[rank] = +Number(
        (prize / maxPrizePool) * 100,
      ).toFixed(2);
    }
    for (let rank = 1; rank < initialWinnersCount + 1; rank++) {
      if (rank <= currentWinnersCount)
        dynamicPoolPercentage[rank] = prizePercentagePerRank[rank];
      else remainingPrizePercentage += prizePercentagePerRank[rank];
    }

    const remainingPrizePercentageDistribution = +(
      remainingPrizePercentage / currentWinnersCount
    ).toFixed(2);
    remainingPrizePercentage = 0;

    for (let rank = 1; rank < currentWinnersCount + 1; rank++) {
      dynamicPoolPercentage[rank] = +(
        dynamicPoolPercentage[rank] + remainingPrizePercentageDistribution
      ).toFixed(2);
    }

    for (const rank in dynamicPoolPercentage) {
      const pricePercentage = dynamicPoolPercentage[rank];
      dynamicSumCoefficient[rank] = 0;
      if (pricePercentage < minPrizePercentage) {
        dynamicSumCoefficient[rank] = +(
          minPrizePercentage - pricePercentage
        ).toFixed(2);
        requiredPercentageSum += dynamicSumCoefficient[rank];
      } else {
        coefficientReductionCount++;
        reducablePercentageTotalPart = +(
          reducablePercentageTotalPart + pricePercentage
        ).toFixed(2);
      }
    }

    for (const rank in dynamicPoolPercentage) {
      const pricePercentage = dynamicPoolPercentage[rank];
      if (dynamicSumCoefficient[rank] == 0)
        dynamicSumCoefficient[rank] = +(
          (-pricePercentage / reducablePercentageTotalPart) *
          requiredPercentageSum
        ).toFixed(2);
    }

    for (const rank in dynamicPoolPercentage) {
      const pricePercentage = dynamicPoolPercentage[rank];
      dynamicPoolPercentage[rank] = +(
        pricePercentage + dynamicSumCoefficient[rank]
      ).toFixed(2);
    }

    for (const rank in dynamicPoolPercentage) {
      const pricePercentage = dynamicPoolPercentage[rank];
      dynamicPriceSplit[rank] = +(
        (pricePercentage / 100) *
        currentUserPrize
      ).toFixed(2);

      dynamicPriceSplit[rank] =
        dynamicPriceSplit[rank] < entryFee
          ? +Math.ceil(dynamicPriceSplit[rank])
          : +Math.floor(dynamicPriceSplit[rank]);

      splitSum += dynamicPriceSplit[rank];
    }
    console.log({ splitSum, currentUserPrize });

    return dynamicPriceSplit;
  } catch (err) {
    console.log(err);
    return {};
  }
}

const updatedSplitup = dynamicSplitUpV2(
  initialPrizePool,
  maxJointUsers,
  entryFee,
  adminCommision,
  50,
); */
