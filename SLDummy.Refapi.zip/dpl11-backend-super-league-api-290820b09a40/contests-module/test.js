const initialPrizePool = {
  1: 90,
  2: 70,
  3: 15,
  4: 15,
  5: 15,
  6: 15,
  7: 15,
  8: 15,
  9: 15,
  10: 15,
  11: 12,
  12: 12,
  13: 12,
  14: 12,
  15: 12,
  16: 12,
  17: 12,
  18: 12,
  19: 12,
  20: 12,
  21: 10,
  22: 10,
  23: 10,
  24: 10,
  25: 10,
  26: 10,
  27: 10,
  28: 10,
  29: 10,
  30: 10,
  31: 10,
  32: 10,
  33: 10,
  34: 10,
  35: 10,
  36: 10,
  37: 10,
  38: 10,
  39: 10,
  40: 10,
  41: 10,
  42: 10,
  43: 10,
  44: 10,
  45: 10,
  46: 10,
  47: 10,
  48: 10,
  49: 10,
  50: 10,
};
const maxJointUsers = 100;
const entryFee = 10;
const adminCommision = 0.3;
const jointUsers = 100;

function dynamicSplitUpV2(
  initialPrizePool,
  maxJointUsers,
  entryFee,
  adminCommision,
  currentJointUsers,
) {
  try {
    if (currentJointUsers < 2) return {};
    if (maxJointUsers == currentJointUsers) return initialPrizePool;
    if (maxJointUsers < currentJointUsers) return initialPrizePool;
    const prizePercentagePerRank = {};
    const dynamicPoolPercentage = {};
    const dynamicPriceSplit = {};
    const dynamicSumCoefficient = {};
    let splitSum = 0;
    let coefficientReductionCount = 0;
    let reducablePercentageTotalPart = 0;
    let requiredPercentageSum = 0;
    let remainingPrizePercentage = 0;

    const initialWinnersCount = Object.values(initialPrizePool).length;
    const currentUserPrize = Math.floor(
      currentJointUsers * entryFee * (1 - adminCommision),
    );

    const minPrizePercentage = +(
      ((entryFee + 1) / currentUserPrize) *
      100
    ).toFixed(2);

    const maxPrizePool = Math.floor(
      maxJointUsers * entryFee * (1 - adminCommision),
    );
    let winnersPercentage = +(initialWinnersCount / maxJointUsers).toFixed(2);
    let currentWinnersCount = Math.floor(winnersPercentage * currentJointUsers);

    if (winnersPercentage < 0.4) {
      if (currentWinnersCount < initialWinnersCount) {
        winnersPercentage = 0.4;
        currentWinnersCount = Math.floor(winnersPercentage * currentJointUsers);
      }
      if (currentWinnersCount > initialWinnersCount) {
        currentWinnersCount = initialWinnersCount;
        winnersPercentage = +(currentWinnersCount / currentJointUsers).toFixed(
          2,
        );
      }
    }

    for (const rank in initialPrizePool) {
      const prize = initialPrizePool[rank];
      prizePercentagePerRank[rank] = +Number(
        (prize / maxPrizePool) * 100,
      ).toFixed(2);
    }

    for (let rank = 1; rank < initialWinnersCount + 1; rank++) {
      if (rank <= currentWinnersCount)
        dynamicPoolPercentage[rank] = prizePercentagePerRank[rank];
      else remainingPrizePercentage += prizePercentagePerRank[rank];
    }

    const remainingPrizePercentageDistribution = +(
      remainingPrizePercentage / currentWinnersCount
    ).toFixed(2);
    remainingPrizePercentage = 0;

    for (let rank = 1; rank < currentWinnersCount + 1; rank++) {
      dynamicPoolPercentage[rank] = +(
        dynamicPoolPercentage[rank] + remainingPrizePercentageDistribution
      ).toFixed(2);
    }

    for (const rank in dynamicPoolPercentage) {
      const pricePercentage = dynamicPoolPercentage[rank];
      dynamicSumCoefficient[rank] = 0;
      if (pricePercentage < minPrizePercentage) {
        dynamicSumCoefficient[rank] = +(
          minPrizePercentage - pricePercentage
        ).toFixed(2);
        requiredPercentageSum += dynamicSumCoefficient[rank];
      } else {
        coefficientReductionCount++;
        reducablePercentageTotalPart = +(
          reducablePercentageTotalPart + pricePercentage
        ).toFixed(2);
      }
    }

    for (const rank in dynamicPoolPercentage) {
      const pricePercentage = dynamicPoolPercentage[rank];
      if (dynamicSumCoefficient[rank] == 0)
        dynamicSumCoefficient[rank] = +(
          (-pricePercentage / reducablePercentageTotalPart) *
          requiredPercentageSum
        ).toFixed(2);
    }

    for (const rank in dynamicPoolPercentage) {
      const pricePercentage = dynamicPoolPercentage[rank];
      dynamicPoolPercentage[rank] = +(
        pricePercentage + dynamicSumCoefficient[rank]
      ).toFixed(2);
    }

    for (const rank in dynamicPoolPercentage) {
      const pricePercentage = dynamicPoolPercentage[rank];
      dynamicPriceSplit[rank] = +(
        (pricePercentage / 100) *
        currentUserPrize
      ).toFixed(2);

      dynamicPriceSplit[rank] =
        dynamicPriceSplit[rank] < entryFee + 1
          ? +Math.ceil(dynamicPriceSplit[rank])
          : +Math.floor(dynamicPriceSplit[rank]);

      splitSum += dynamicPriceSplit[rank];
    }
    // console.log(splitSum, currentUserPrize, dynamicPoolPercentage);

    if (splitSum < currentUserPrize) {
      let pendingAmout = currentUserPrize - splitSum;

      let distrubution = true;
      while (distrubution) {
        for (const rank in dynamicPriceSplit) {
          const prize = dynamicPriceSplit[rank];
          if (pendingAmout == 0) {
            distrubution = false;
            break;
          }
          dynamicPriceSplit[rank]++;
          pendingAmout--;
        }
      }
    }

    console.log({ currentUserPrize });

    return dynamicPriceSplit;
  } catch (err) {
    console.log(err);
    return {};
  }
}

const updatedSplitup = dynamicSplitUpV2(
  initialPrizePool,
  maxJointUsers,
  entryFee,
  adminCommision,
  jointUsers,
);
console.log(updatedSplitup);
