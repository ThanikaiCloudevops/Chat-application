import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { master_defaultFields } from 'src/commonResponse/response.entity';

@ObjectType()
class winners {
  @Field()
  winnerCount: number;
  @Field()
  firstPrize: number;
}

@ObjectType()
class winnerTable {
  @Field()
  rank: string;
  @Field()
  percentage: number;
  @Field()
  winningPrize: number;
}

@ObjectType()
class winnerListdata {
  @Field()
  key: string;
  @Field()
  value: string;
  @Field(() => [winnerTable])
  winnerTable: winnerTable[];
}

@ObjectType()
class winningListData {
  @Field(() => [winnerListdata])
  winnerList: winnerListdata[];
  @Field()
  maxPrizePool: number;
  @Field(() => winners)
  winners: winners;
}

@ObjectType()
export class winnerList extends PartialType(master_defaultFields) {
  @Field(() => winningListData, { nullable: true })
  data: winningListData;
}
