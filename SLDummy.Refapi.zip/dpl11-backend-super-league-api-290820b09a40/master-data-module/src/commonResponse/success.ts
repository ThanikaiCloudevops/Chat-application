const successMsg = {
  contestmaster: 'Contest master data found',
  joinContest: 'Contest joined successfully',
};
export function successResponse(msg: string, data: any = null) {
  return { status: true, success: { message: successMsg[msg] }, data };
}
