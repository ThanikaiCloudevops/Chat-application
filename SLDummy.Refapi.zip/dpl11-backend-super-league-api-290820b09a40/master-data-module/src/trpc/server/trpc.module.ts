import { Module } from '@nestjs/common';
import { TrpcService } from './trpc.service';
import { TrpcRouter } from './trpc.router';
import { MongooseModule } from '@nestjs/mongoose';
import {
  ContestFilter,
  MasterSchema,
} from 'src/data-modules/entities/data-module.entity';
import { DataModulesService } from 'src/data-modules/data-modules.service';
import { DataModulesModule } from 'src/data-modules/data-modules.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: ContestFilter.name, schema: MasterSchema },
    ]),
  ],
  controllers: [],
  providers: [TrpcService, TrpcRouter, DataModulesService],
})
export class TrpcModule {}
