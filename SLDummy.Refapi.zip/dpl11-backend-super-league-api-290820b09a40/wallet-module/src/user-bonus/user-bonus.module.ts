import { Module } from '@nestjs/common';
import { UserBonusService } from './user-bonus.service';
import { UserBonusResolver } from './user-bonus.resolver';

@Module({
  providers: [UserBonusResolver, UserBonusService],
})
export class UserBonusModule {}
