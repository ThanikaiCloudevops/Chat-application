import { Resolver, Query, Mutation, Args, Int } from '@nestjs/graphql';
import { UserBonusService } from './user-bonus.service';
import { UserBonus } from './entities/user-bonus.entity';
import { CreateUserBonusInput } from './dto/create-user-bonus.input';
import { UpdateUserBonusInput } from './dto/update-user-bonus.input';

@Resolver(() => UserBonus)
export class UserBonusResolver {
  constructor(private readonly userBonusService: UserBonusService) {}

  @Mutation(() => UserBonus)
  createUserBonus(
    @Args('createUserBonusInput') createUserBonusInput: CreateUserBonusInput,
  ) {
    return this.userBonusService.create(createUserBonusInput);
  }

  @Query(() => [UserBonus], { name: 'userBonus' })
  findAll() {
    return this.userBonusService.findAll();
  }

  @Query(() => UserBonus, { name: 'userBonus' })
  findOne(@Args('id', { type: () => Int }) id: number) {
    return this.userBonusService.findOne(id);
  }

  @Mutation(() => UserBonus)
  updateUserBonus(
    @Args('updateUserBonusInput') updateUserBonusInput: UpdateUserBonusInput,
  ) {
    return this.userBonusService.update(
      updateUserBonusInput.id,
      updateUserBonusInput,
    );
  }

  @Mutation(() => UserBonus)
  removeUserBonus(@Args('id', { type: () => Int }) id: number) {
    return this.userBonusService.remove(id);
  }
}
