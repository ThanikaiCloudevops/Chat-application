import { Injectable } from '@nestjs/common';
import { CreateUserBonusInput } from './dto/create-user-bonus.input';
import { UpdateUserBonusInput } from './dto/update-user-bonus.input';

@Injectable()
export class UserBonusService {
  create(createUserBonusInput: CreateUserBonusInput) {
    return 'This action adds a new userBonus';
  }

  findAll() {
    return `This action returns all userBonus`;
  }

  findOne(id: number) {
    return `This action returns a #${id} userBonus`;
  }

  update(id: number, updateUserBonusInput: UpdateUserBonusInput) {
    return `This action updates a #${id} userBonus`;
  }

  remove(id: number) {
    return `This action removes a #${id} userBonus`;
  }
}
