import { CreateUserBonusInput } from './create-user-bonus.input';
import { InputType, Field, Int, PartialType } from '@nestjs/graphql';

@InputType()
export class UpdateUserBonusInput extends PartialType(CreateUserBonusInput) {
  @Field(() => Int)
  id: number;
}
