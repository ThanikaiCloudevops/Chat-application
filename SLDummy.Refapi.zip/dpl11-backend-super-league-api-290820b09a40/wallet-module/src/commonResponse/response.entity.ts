import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { BankAccount } from 'src/bank-verify/entities/user-bank.entity';
import { UserTransaction } from 'src/user-transaction/entities/user-transaction.entity';

@ObjectType()
export class UserWallet_message {
  @Field({ nullable: true, defaultValue: '' })
  message: string;
  @Field({ nullable: true, defaultValue: '' })
  location: string;
}

@ObjectType()
export class UserWallet_defaultFields {
  @Field()
  status: boolean;

  @Field({ nullable: true })
  error: UserWallet_message;

  @Field({ nullable: true })
  success: UserWallet_message;
}

@ObjectType()
class currencyConversionData {
  @Field()
  amount: number;
  @Field()
  cadPerUsd: number;
  @Field()
  usdPerCad: number;
}

@ObjectType()
export class currencyConversionResponse extends PartialType(
  UserWallet_defaultFields,
) {
  @Field(() => currencyConversionData, { nullable: true })
  data: currencyConversionData;
}

@ObjectType()
export class UserBankResponse extends PartialType(UserWallet_defaultFields) {
  @Field(() => [BankAccount], { nullable: 'itemsAndList' })
  data: BankAccount[];
}

@ObjectType()
class addMoneyData {
  @Field({ defaultValue: '' })
  transactionId: string;
  @Field({ defaultValue: false })
  kycVerified: boolean;
}
@ObjectType()
export class addMoneyResponse extends PartialType(UserWallet_defaultFields) {
  @Field(() => addMoneyData, { nullable: true })
  data: addMoneyData;
}
@ObjectType()
class checkMoneyData {
  @Field()
  transactionStatus: string;
}
@ObjectType()
class checkBonusData {
  @Field()
  entryfee: number;
  @Field()
  entryfeeAfterBonus: number;
  @Field()
  bonus: number;
}

@ObjectType()
export class checkTransactionResponse extends PartialType(
  UserWallet_defaultFields,
) {
  @Field(() => checkMoneyData, { nullable: true })
  data: checkMoneyData;
}

@ObjectType()
export class checkBonusresponse extends PartialType(UserWallet_defaultFields) {
  @Field(() => checkBonusData, { nullable: true })
  data: checkBonusData;
}

@ObjectType()
class transactionData {
  @Field(() => [UserTransaction], { nullable: 'itemsAndList' })
  data: UserTransaction[];

  @Field()
  page: number;
}

@ObjectType()
export class getUserTransactionsResponse extends PartialType(
  UserWallet_defaultFields,
) {
  @Field(() => transactionData)
  data: transactionData;
}

@ObjectType()
export class userTransactionsDefault extends PartialType(
  UserWallet_defaultFields,
) {
  @Field({ nullable: true })
  transactionId: string;
}

// an optional type //data?: Prettify<dataFields>;
export type Prettify<T> = {
  [K in keyof T]: T[K];
} & object;
