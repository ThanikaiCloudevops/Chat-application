import { GraphQLError } from 'graphql';

const errorMsg = {
  getWallet: 'Wallet Found',
  notFound: 'Wallet not found',
  balance: 'Insufficient Balance',
  walletExist: 'Wallet already exist',
  withdraw: 'Error in withdrawal',
  payment: 'Payment method not defined',
  transaction: 'Transaction not found',
  update: 'Transaction update error',
  incorrect: 'Incorrect transaction',
  pending: 'Transaction pending',
  code: 'Error fetching QR-code',
  addcash: 'Unable to add cash',
  currency: 'Currency conversion error',
  mail: 'Please add your email to proceed',
  kyc: 'Please verify KYC by click on add cash',
  pan: 'Please verify PAN by click on add cash',
  bank: 'Error verifying bank account',
  invalidbank: 'Invalid bank account details',
  bankmax: 'Maximum bank accounts reached',
  game: 'Error joining game',
  win: 'Error updating winnings',
};

export function commonErrors(errorType: string, data: any = null) {
  return { status: false, error: { message: errorMsg[errorType] }, data };
}
export function handleException(error) {
  throw new GraphQLError(error, {
    extensions: {
      code: 'FORBIDDEN',
    },
  });
}
