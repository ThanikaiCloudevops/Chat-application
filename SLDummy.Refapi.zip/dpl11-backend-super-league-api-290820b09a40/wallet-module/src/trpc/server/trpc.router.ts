import { INestApplication, Injectable } from '@nestjs/common';
import { z } from 'zod';
import { TrpcService } from './trpc.service';
import * as trpcExpress from '@trpc/server/adapters/express';
import { UserTransactionService } from 'src/user-transaction/user-transaction.service';
import { UserWalletService } from 'src/user-wallet/user-wallet.service';

@Injectable()
export class TrpcRouter {
  constructor(
    private readonly trpc: TrpcService,
    private userTransactionService: UserTransactionService,
    private userWalletService: UserWalletService,
  ) {}

  appRouter = this.trpc.router({
    transactionupdate: this.trpc.procedure
      .input(
        z.object({
          request: z.any(),
        }),
      )
      .query(({ input }) => {
        return this.userTransactionService.enterTransaction(input?.request);
      }),
    gettransactions: this.trpc.procedure
      .input(
        z.object({
          request: z.any(),
        }),
      )
      .query(({ input }) => {
        return this.userTransactionService.getTransactions(input?.request);
      }),
    walletcreation: this.trpc.procedure
      .input(
        z.object({
          request: z.any(),
        }),
      )
      .query(({ input }) => {
        return this.userWalletService.createWallet(input?.request);
      }),
    getwallet: this.trpc.procedure
      .input(
        z.object({
          request: z.any(),
        }),
      )
      .query(({ input }) => {
        return this.userWalletService.findOne(input?.request);
      }),
    walletupdation: this.trpc.procedure
      .input(
        z.object({
          request: z.any(),
        }),
      )
      .query(({ input }) => {
        return this.userTransactionService.updateBonus(input?.request);
      }),
  });

  async applyMiddleware(app: INestApplication) {
    app.use(
      `/trpc/wallet`,
      trpcExpress.createExpressMiddleware({
        router: this.appRouter,
      }),
    );
  }
}

export type AppRouter = TrpcRouter[`appRouter`];
