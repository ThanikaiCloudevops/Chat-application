// msg91.service.ts
import { MSG91APIKEY } from 'config/envirnment';
import { Injectable } from '@nestjs/common';
import msg91 from 'msg91';

@Injectable()
export class Msg91SmsService {
  private readonly apiKey: string;
  private readonly baseUrl: string;

  constructor() {
    this.apiKey = MSG91APIKEY.MSG91_AUTH_KEY;
    this.baseUrl = 'https://control.msg91.com/api/v5/flow/';
  }

  async sendSMS(mobile: string, message: any) {
    try {
      const headers = {
        'Content-Type': 'application/json',
        authkey: this.apiKey,
      };
      const data = {
        template_id: MSG91APIKEY.MSG91_TEMPLATE_ID,
        recipients: [
          {
            mobiles: '91' + mobile,
            amount: message.amount,
            paymentGateway: message.paymentGateway,
          },
        ],
      };
      const smsRequest = await fetch(this.baseUrl, {
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          authkey: this.apiKey,
        },
        method: 'POST',
        body: JSON.stringify(data),
      });
      return smsRequest.json();
    } catch (err) {
      return false;
    }
  }
}
