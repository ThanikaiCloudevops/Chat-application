import { Field, InputType } from '@nestjs/graphql';
import { IsIn } from 'class-validator';

@InputType()
export class filterTransactionInput {
  @Field({ defaultValue: '' })
  @IsIn(['Credit', 'Withdrawal', 'Winnings', 'Debit', 'Bonus', ''])
  transanctionType: string;

  @Field(() => [String], { defaultValue: [], nullable: 'itemsAndList' })
  // @IsIn(['Success', 'Pending', 'Failed'])
  transactionStatus: String[];

  @Field({ defaultValue: 1 })
  page?: number;
}

@InputType()
export class GameTransactionInput {
  @Field()
  gameId: string;

  @Field()
  gameName: string;

  @Field()
  amount: number;
}
