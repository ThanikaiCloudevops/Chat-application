import { Injectable } from '@nestjs/common';
import {
  CreateUserTransactionInput,
  addMoneyInput,
} from './dto/create-user-transaction.input';
import { successResponse } from 'src/commonResponse/success';
import { commonErrors } from 'src/commonResponse/errors';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import {
  UserTransaction,
  UserTransactionDocument,
} from './entities/user-transaction.entity';
import { UserWalletService } from 'src/user-wallet/user-wallet.service';
import {
  GameTransactionInput,
  filterTransactionInput,
} from './dto/transaction.filter.input';
import {
  BonusMaster,
  BonusMasterDocument,
} from './entities/bonus-master.entity';
import { User, userDocument } from './entities/user.entity';
import { trpcServices } from 'src/trpc/client/trpc';
import { NotificationService } from './notification.service';
import { Msg91SmsService } from './send-sms/sms.service';
import {
  Notification,
  notificationDocument,
} from './entities/notifications.entity';
import { Cron, CronExpression } from '@nestjs/schedule';

const options = { upsert: true, new: true, setDefaultsOnInsert: true };

@Injectable()
export class UserTransactionService {
  constructor(
    @InjectModel('BonusMaster')
    private BonusMasterModel: Model<BonusMasterDocument>,
    @InjectModel('UserTransaction')
    private UserTransactiontModel: Model<UserTransactionDocument>,
    @InjectModel('User')
    private UserModel: Model<userDocument>,
    @InjectModel('Notification')
    private notificationModel: Model<notificationDocument>,
    private userWalletService: UserWalletService,
    private trpcservice: trpcServices,
    private notificationService: NotificationService,
    private readonly smsService: Msg91SmsService,
  ) {}

  async enterTransaction(
    createUserTransactionInput: CreateUserTransactionInput,
  ) {
    const walletCheck = await this.userWalletService.getUserWallet(
      createUserTransactionInput.userId,
    );
    if (!walletCheck) return commonErrors('notFound');
    let bal = 0;
    if (createUserTransactionInput.transanctionRelatedType != 'EntryFee') {
      const totalBalance =
        walletCheck.unutilisedBalance + walletCheck.totalWinnings;
      const transactionObj: UserTransaction = {
        userId: createUserTransactionInput.userId,
        transanctionType: createUserTransactionInput.transanctionType,
        amount: createUserTransactionInput.amount,
        walletId: walletCheck._id,
        previousBalance: walletCheck.userBalance,
        afterBalance: totalBalance,
        transanctionRelatedType:
          createUserTransactionInput.transanctionRelatedType,
        transanctionTime: new Date(),
        transactionStatus: createUserTransactionInput.transactionStatus
          ? createUserTransactionInput.transactionStatus
          : 'Success',
        referId: createUserTransactionInput.referId
          ? createUserTransactionInput.referId
          : '',
        fixtureName: createUserTransactionInput.fixtureName
          ? createUserTransactionInput.fixtureName
          : '',
        contestName: createUserTransactionInput.contestName
          ? createUserTransactionInput.contestName
          : '',
      };
      await this.UserTransactiontModel.create(transactionObj);
      await this.userWalletService.updateWallet(
        walletCheck,
        transactionObj.amount,
        transactionObj.transanctionType == 'Credit',
        'Bonus',
        bal,
      );
    } else {
      var remBalance: number;
      if (walletCheck.totalBonus > 0) {
        bal = +((5 / 100) * createUserTransactionInput.amount).toFixed(2);
        if (bal >= walletCheck.totalBonus) {
          remBalance =
            createUserTransactionInput.amount - walletCheck.totalBonus;
          bal = walletCheck.totalBonus;
        } else remBalance = createUserTransactionInput.amount - bal;
      } else {
        remBalance = createUserTransactionInput.amount;
      }
      const totalBalance =
        walletCheck.unutilisedBalance + walletCheck.totalWinnings;
      // walletCheck.totalBonus;
      const transactionObj: UserTransaction = {
        userId: createUserTransactionInput.userId,
        transanctionType: createUserTransactionInput.transanctionType,
        amount: remBalance,
        walletId: walletCheck._id,
        previousBalance: walletCheck.userBalance,
        afterBalance:
          createUserTransactionInput.transanctionType == 'Debit'
            ? totalBalance - remBalance
            : totalBalance + createUserTransactionInput.amount,
        transanctionRelatedType:
          createUserTransactionInput.transanctionRelatedType,
        fixtureId: createUserTransactionInput.fixtureId,
        contestId: createUserTransactionInput.contestId,
        transanctionTime: new Date(),
        transactionStatus: 'Success',
        bonusUsed: bal,
        referId: createUserTransactionInput.referId
          ? createUserTransactionInput.referId
          : '',
        fixtureName: createUserTransactionInput.fixtureName
          ? createUserTransactionInput.fixtureName
          : '',
        contestName: createUserTransactionInput.contestName
          ? createUserTransactionInput.contestName
          : '',
      };

      if (transactionObj.afterBalance < 0) return commonErrors('balance');
      await this.UserTransactiontModel.create(transactionObj);
      await this.userWalletService.updateWallet(
        walletCheck,
        transactionObj.amount,
        transactionObj.transanctionType == 'Credit',
        transactionObj.transanctionRelatedType,
        bal,
      );
      return successResponse('transaction', {
        amount: transactionObj.afterBalance,
      });
    }
  }

  async getUserTransactions(userId: string) {
    const userTransactions = await this.UserTransactiontModel.find({ userId });
    return successResponse('found', userTransactions);
  }

  async getTransactions(userId: any) {
    let array: any = {};
    for (const key in userId) {
      if (key == 'ref_from') {
        const userTransactions = await this.UserTransactiontModel.find({
          userId: userId.ref_from, //user
          transanctionRelatedType: 'Referral Bonus From',
          transactionStatus: 'Success',
        }).select(['userId', 'amount']);
        const amount = userTransactions.map((e) => e.amount);
        const sum = amount.reduce(
          (accumulator, currentValue) => accumulator + currentValue,
          0,
        );
        const user = await this.UserModel.findOne({ _id: userId.ref_from });
        array['userName'] = user.userName;
        array['amount'] = sum;
      } else {
        let arr: any = [];
        const userTransaction: any = await this.UserTransactiontModel.find({
          //userId: { $in: userId.ref_to },
          // transanctionRelatedType: 'Referral Bonus To',
          referId: { $in: userId.ref_to },
        })
          .select(['userId', 'amount', 'referId'])
          .lean();

        for (const id in userTransaction) {
          let newarray: any = {};
          const user = await this.UserModel.findOne({
            _id: userTransaction[id].referId,
          });
          const userName = user.userName;
          newarray['userName'] = userName;
          newarray['amount'] = userTransaction[id].amount;
          arr.push(newarray);
        }
        array['referrals'] = arr;
      }
    }
    return array;
  }

  async filterUserTransactions(
    userId: string,
    filterInput: filterTransactionInput,
  ) {
    const queryObj: any = { userId };

    if (filterInput.transactionStatus.length > 0)
      queryObj.transactionStatus = { $in: filterInput.transactionStatus };

    if (filterInput.transanctionType) {
      if (filterInput.transanctionType == 'Winnings')
        queryObj['$or'] = [
          { transanctionRelatedType: 'Winnings' },
          { transanctionRelatedType: 'EntryFee' },
          { transanctionRelatedType: 'Refund' },
        ];
      else if (filterInput.transanctionType == 'Bonus')
        queryObj['$or'] = [
          { transanctionRelatedType: 'Signup Bonus' },
          { transanctionRelatedType: 'Cash Bonus' },
          {
            transanctionRelatedType: 'Referral Bonus From',
            transactionStatus: { $ne: 'Pending' },
          },
          {
            transanctionRelatedType: 'Referral Bonus To',
            amount: { $ne: 0 },
            transactionStatus: { $ne: 'Pending' },
          },
          { transanctionRelatedType: 'Admin' },
        ];
      else queryObj.transanctionRelatedType = filterInput.transanctionType;
    }

    const userTransactions = await this.UserTransactiontModel.find(queryObj)
      .sort('-transanctionTime')
      .skip((filterInput.page - 1) * 20)
      .limit(20);

    return successResponse('found', {
      data: userTransactions,
      page: filterInput.page,
    });
  }

  async withdrawbalance(
    user: any,
    amount: number,
    userIp: string,
    paymentType: number,
  ) {
    try {
      const walletCheck = await this.userWalletService.getUserWallet(user._id);
      if (!walletCheck) return commonErrors('notFound');
      if (!user.kycStatus) return commonErrors('kyc');
      if (!user.panStatus) return commonErrors('pan');

      if (amount > walletCheck.totalWinnings) return commonErrors('balance');

      const transactionObj: UserTransaction = {
        userId: user._id,
        transanctionType: 'Debit',
        amount: amount,
        walletId: walletCheck._id,
        previousBalance: walletCheck.userBalance,
        afterBalance: walletCheck.userBalance - amount,
        transanctionRelatedType: 'Withdrawal',
        transanctionTime: new Date(),
        transactionStatus: 'Pending',
      };
      const transaction = await this.UserTransactiontModel.create(
        transactionObj,
      );

      walletCheck.totalWinnings = walletCheck.totalWinnings - amount;
      walletCheck.userBalance = walletCheck.userBalance - amount;
      await walletCheck.save();
      return successResponse('withdraw');
    } catch (err) {
      console.log(err);
      return commonErrors('withdraw');
    }
  }

  async addMoney(user: any, addmoneyInput: addMoneyInput) {
    try {
      const walletCheck = await this.userWalletService.getUserWallet(user._id);
      const transactionObj: UserTransaction = {
        userId: user._id,
        walletId: walletCheck._id.toString(),
        amount: addmoneyInput.amount,
        transanctionTime: new Date(),
        transanctionType: 'Credit',
        transanctionRelatedType: 'Credit',
        transactionStatus: 'Success',
        previousBalance: walletCheck.userBalance,
        afterBalance: walletCheck.userBalance + addmoneyInput.amount,
      };

      const userTransaction = new this.UserTransactiontModel(transactionObj);
      walletCheck.userBalance += addmoneyInput.amount;
      walletCheck.unutilisedBalance += addmoneyInput.amount;

      await walletCheck.save();
      await userTransaction.save();
      return successResponse('add', {
        transactionId: userTransaction._id.toString(),
        kycVerified: user.kycStatus,
      });
    } catch (err) {
      return commonErrors('addcash');
    }
  }

  async updateBonus(userId: any) {
    try {
      var bonustyp = await this.BonusMasterModel.findOne({
        bonusType: 'referal',
        isactive: true,
      });

      for (const key in userId) {
        if (key == 'refFrom' && bonustyp.refFrom > 0) {
          await this.enterTransaction({
            userId: userId['refFrom'],
            transanctionType: 'Credit',
            amount: bonustyp.refFrom,
            transanctionRelatedType: 'Referral Bonus From',
            transactionStatus: 'Success',
            referId: userId['userId'],
          });
        } else if (key == 'refTo' /* && bonustyp.refTo > 0 */) {
          await this.enterTransaction({
            userId: userId['refTo'],
            transanctionType: 'Credit',
            amount: bonustyp.refTo,
            transanctionRelatedType: 'Referral Bonus To',
            transactionStatus: 'Success',
          });
        }
      }
      return true;
    } catch (error) {
      return false;
    }
  }

  async bonusConfirmation(user: any, team: number, entryfee: number) {
    try {
      const EntryFee = entryfee * team;
      const walletCheck = await this.userWalletService.getUserWallet(user._id);
      const bonus = +((5 / 100) * EntryFee).toFixed(2);
      let newbonus: number = 0;
      if (walletCheck.totalBonus > 0) {
        if (walletCheck.totalBonus < bonus) {
          newbonus = walletCheck.totalBonus;
        } else {
          newbonus = bonus;
        }
      }
      const remBalance = EntryFee - newbonus;
      const data: any = {};
      data.entryfeeAfterBonus = remBalance;
      data.bonus = newbonus;
      data.entryfee = EntryFee;
      return successResponse('bonus', data);
    } catch (error) {}
  }

  async notification() {
    const notificationObj = {
      notification: {
        title: 'payment added',
        body: `100₹ has been credited to your wallet `,
      },
      token:
        'ev2crVyWSfmuVHlwI0qzdr:APA91bEdwadsCnjBAL4TwXpLcy_vibWAUVmNjTzHMzNanRDGGYbiL2tu5Ru4iiRmyzhLndQYL-d_k5VW2pQWRNTcHYjMaxeChq6WVTzyOQ49ucS8DJXV5vX8jCqeaC7v_uSTr59wxP43',
    };
    await this.notificationService.sendNotification(notificationObj);
    return successResponse('getWallet');
  }

  async joinGame(gameInput: GameTransactionInput, userId: string) {
    try {
      const { amount, gameId, gameName } = gameInput;
      const userWallet = await this.userWalletService.getUserWallet(userId);
      if (userWallet.userBalance < amount) return commonErrors('balance');

      const transactionObj: UserTransaction = {
        userId,
        previousBalance: userWallet.userBalance,
        afterBalance: userWallet.userBalance - amount,
        amount,
        transactionStatus: 'Success',
        transanctionRelatedType: 'GameFee',
        transanctionTime: new Date(),
        transanctionType: 'Debit',
        walletId: userWallet._id,
        contestId: gameId,
        contestName: gameName,
      };
      userWallet.userBalance = userWallet.userBalance - amount;
      userWallet.unutilisedBalance = userWallet.unutilisedBalance - amount;
      if (userWallet.unutilisedBalance < 0) {
        userWallet.totalWinnings =
          userWallet.totalWinnings + userWallet.unutilisedBalance;
        userWallet.unutilisedBalance = 0;
      }
      await userWallet.save();
      await this.UserTransactiontModel.create(transactionObj);

      return successResponse('transaction');
    } catch (err) {
      return commonErrors('game');
    }
  }

  async winGame(gameInput: GameTransactionInput, userId: string) {
    try {
      const { amount, gameId, gameName } = gameInput;
      const userWallet = await this.userWalletService.getUserWallet(userId);

      const transactionObj: UserTransaction = {
        userId,
        previousBalance: userWallet.userBalance,
        afterBalance: userWallet.userBalance + amount,
        amount,
        transactionStatus: 'Success',
        transanctionRelatedType: 'GameFee',
        transanctionTime: new Date(),
        transanctionType: 'Debit',
        walletId: userWallet._id,
        contestId: gameId,
        contestName: gameName,
      };
      userWallet.userBalance = userWallet.userBalance + amount;
      userWallet.totalWinnings = userWallet.totalWinnings + amount;

      await userWallet.save();
      await this.UserTransactiontModel.create(transactionObj);

      return successResponse('transaction');
    } catch (err) {
      return commonErrors('win');
    }
  }
}
