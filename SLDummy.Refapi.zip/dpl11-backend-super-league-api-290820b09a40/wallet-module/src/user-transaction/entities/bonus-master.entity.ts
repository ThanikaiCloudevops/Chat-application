import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { UserWallet_defaultFields } from 'src/commonResponse/response.entity';

export type BonusMasterDocument = BonusMaster & Document;

@ObjectType()
@Schema()
export class BonusMaster {
  @Field()
  @Prop()
  bonusType: string;

  @Field({ nullable: true })
  @Prop()
  refFrom: number;

  @Field({ nullable: true })
  @Prop()
  refTo: number;

  @Field()
  @Prop()
  isactive: boolean;
}

export const BonusMasterSchema = SchemaFactory.createForClass(BonusMaster);
