import { Resolver, Query, Mutation, Args, Int, Context } from '@nestjs/graphql';
import { UserTransactionService } from './user-transaction.service';
import {
  UserTransaction,
  getUserTransaction,
} from './entities/user-transaction.entity';
import { UseGuards } from '@nestjs/common';
import { AuthGuard, HeaderGuard } from 'src/auth/auth.guard';
import {
  addMoneyResponse,
  getUserTransactionsResponse,
  checkBonusresponse,
  UserWallet_defaultFields,
} from 'src/commonResponse/response.entity';
import {
  GameTransactionInput,
  filterTransactionInput,
} from './dto/transaction.filter.input';
import { addMoneyInput } from './dto/create-user-transaction.input';
import { Msg91SmsService } from './send-sms/sms.service';

@Resolver(() => UserTransaction)
@UseGuards(AuthGuard)
export class UserTransactionResolver {
  constructor(
    private readonly userTransactionService: UserTransactionService,
    private readonly smsService: Msg91SmsService,
  ) {}

  @Query(() => addMoneyResponse, { name: 'addMoney' })
  addMoney(
    @Context('user') user: any,
    @Args('input') addmoneyInput: addMoneyInput,
  ) {
    return this.userTransactionService.addMoney(user, addmoneyInput);
  }

  @Query(() => UserWallet_defaultFields, { name: 'moneyWithdrawal' })
  withdrawMoney(
    @Context('user') user: any,
    @Args('amount') amount: number,
    @Args('userIp') userIp: string,
    @Args('withdrawalType') withdrawalType: number,
  ) {
    return this.userTransactionService.withdrawbalance(
      user,
      amount,
      userIp,
      withdrawalType,
    );
  }

  @Query(() => getUserTransactionsResponse, { name: 'getTransactions' })
  getTransactions(@Context('user') user: any, @Args('page') page: number) {
    return this.userTransactionService.getUserTransactions(user._id);
  }

  @Mutation(() => getUserTransactionsResponse, { name: 'filterTransactions' })
  filterUserTransactions(
    @Context('user') user: any,
    @Args('input') filterInput: filterTransactionInput,
  ) {
    return this.userTransactionService.filterUserTransactions(
      user?._id,
      filterInput,
    );
  }

  @Query(() => checkBonusresponse, { name: 'bonusConfirmation' })
  bonusConfirmation(
    @Args('team') team?: number,
    @Args('entryfee') entryfee?: number,
    @Context('user') user?: any,
  ) {
    return this.userTransactionService.bonusConfirmation(user, team, entryfee);
  }

  @Query(() => UserWallet_defaultFields, { name: 'testNotifications' })
  testNotification() {
    return this.userTransactionService.notification();
  }

  @Query(() => UserWallet_defaultFields, { name: 'testSms' })
  sendSMS(@Args('mobile') mobile: string, message: any) {
    return this.smsService.sendSMS(mobile, message);
  }

  @Query(() => UserWallet_defaultFields, { name: 'joinGame' })
  // @UseGuards(HeaderGuard)
  joinGame(
    @Args('input') gameInput: GameTransactionInput,
    @Context('user') user?: any,
  ) {
    return this.userTransactionService.joinGame(gameInput, user?._id);
  }

  @Query(() => UserWallet_defaultFields, { name: 'winGame' })
  // @UseGuards(HeaderGuard)
  winGame(
    @Args('input') gameInput: GameTransactionInput,
    @Context('user') user?: any,
  ) {
    return this.userTransactionService.winGame(gameInput, user?._id);
  }
}
