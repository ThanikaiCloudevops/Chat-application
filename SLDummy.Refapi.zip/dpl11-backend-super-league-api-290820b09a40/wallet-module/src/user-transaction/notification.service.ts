import { Injectable } from '@nestjs/common';
import { SERVICE_ACCOUNT } from 'config/envirnment';
import * as admin from 'firebase-admin';
import { Message } from 'firebase-admin/lib/messaging/messaging-api';

@Injectable()
export class NotificationService {
  private readonly firebaseAdmin: admin.app.App;

  constructor() {
    const firebaseApps = admin.apps;
    if (firebaseApps.length === 0) {
      this.firebaseAdmin = admin.initializeApp({
        credential: admin.credential.cert(
          SERVICE_ACCOUNT as admin.ServiceAccount,
        ),
      });
    } else {
      this.firebaseAdmin = firebaseApps[0];
    }
  }

  async sendNotification(message: any) {
    try {
      await this.firebaseAdmin.messaging().send(message);
      return { status: true };
    } catch (err) {
      return { status: false };
    }
  }
}
