import { Args, Context, Query, Resolver } from '@nestjs/graphql';
import { BankVerifyService } from './bank-verify.service';
import {
  UserBankResponse,
  UserWallet_defaultFields,
} from 'src/commonResponse/response.entity';
import { UseGuards } from '@nestjs/common';
import { AuthGuard } from 'src/auth/auth.guard';

@Resolver()
@UseGuards(AuthGuard)
export class BankVerifyResolver {
  constructor(private readonly bankVerifyService: BankVerifyService) {}

  @Query(() => UserWallet_defaultFields)
  verifyBank(
    @Context('user') user: any,
    @Args('ifscCode') ifscCode: string,
    @Args('accNo') accNo: string,
  ) {
    return this.bankVerifyService.bankVerify(user?._id, accNo, ifscCode);
  }

  @Query(() => UserBankResponse)
  getUserbank(@Context('user') user: any) {
    return this.bankVerifyService.getBankAccoounts(user?._id);
  }
}
