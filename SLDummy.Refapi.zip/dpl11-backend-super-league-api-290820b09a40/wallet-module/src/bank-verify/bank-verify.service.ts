import { Injectable } from '@nestjs/common';
import { cashfree } from 'config/envirnment';
import { commonErrors } from 'src/commonResponse/errors';
import { successResponse } from 'src/commonResponse/success';
import { UserBankDocument } from './entities/user-bank.entity';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

@Injectable()
export class BankVerifyService {
  constructor(
    @InjectModel('UserBank')
    private UserBankModel: Model<UserBankDocument>,
  ) {}

  async bankVerify(userId: string, accNo: string, ifscCode: string) {
    try {
      const userBanks = await this.UserBankModel.findOne({ userId });
      if (userBanks && userBanks.bankAccounts.length >= 2)
        return commonErrors('bankmax');

      const reqBody = { bank_account: accNo, ifsc: ifscCode };
      const res = await fetch(cashfree.bank, {
        method: 'POST',
        headers: {
          'x-client-id': cashfree.clientId,
          'x-client-secret': cashfree.clientSecret,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(reqBody),
      });

      const data = await res.json();
      if (data?.account_status != 'VALID') return commonErrors('invalidbank');

      if (!userBanks)
        await this.UserBankModel.create({
          userId,
          bankAccounts: [{ ...data, ...reqBody }],
        });
      else {
        userBanks.bankAccounts.push({ ...data, ...reqBody });
        await userBanks.save();
      }

      return successResponse('bank');
    } catch (err) {
      return commonErrors('bank');
    }
  }

  async getBankAccoounts(userId: string) {
    try {
      const userBanks = await this.UserBankModel.findOne({ userId });
      if (!userBanks) throw new Error();

      return successResponse('data', userBanks.bankAccounts);
    } catch (err) {
      return successResponse('data', []);
    }
  }
}
