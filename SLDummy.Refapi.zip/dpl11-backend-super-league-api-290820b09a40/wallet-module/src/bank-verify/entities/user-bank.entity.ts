import { ObjectType, Field } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type UserBankDocument = UserBank & Document;

@ObjectType()
export class BankAccount {
  @Field()
  reference_id: number;
  @Field()
  name_at_bank: string;
  @Field()
  bank_name: string;
  @Field()
  city: string;
  @Field()
  branch: string;
  @Field()
  micr: number;
  @Field()
  account_status: string;
  @Field()
  account_status_code: string;
  @Field()
  bank_account: string;
  @Field()
  ifsc: string;
}

@ObjectType()
@Schema()
export class UserBank {
  @Field()
  @Prop()
  userId: string;

  @Field(() => [BankAccount])
  @Prop()
  bankAccounts: BankAccount[];
}

export const UserBankSchema = SchemaFactory.createForClass(UserBank);
