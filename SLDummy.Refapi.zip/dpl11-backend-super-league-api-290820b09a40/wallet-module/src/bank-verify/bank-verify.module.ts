import { Module } from '@nestjs/common';
import { BankVerifyService } from './bank-verify.service';
import { BankVerifyResolver } from './bank-verify.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import { UserBank, UserBankSchema } from './entities/user-bank.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: UserBank.name, schema: UserBankSchema },
    ]),
  ],
  providers: [BankVerifyResolver, BankVerifyService],
})
export class BankVerifyModule {}
