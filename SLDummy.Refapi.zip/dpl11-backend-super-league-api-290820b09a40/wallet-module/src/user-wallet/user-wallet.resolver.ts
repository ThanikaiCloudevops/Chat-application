import { Resolver, Query, Mutation, Args, Int, Context } from '@nestjs/graphql';
import { UserWalletService } from './user-wallet.service';
import { UserWallet, getUserWallet } from './entities/user-wallet.entity';
import { CreateUserWalletInput } from './dto/create-user-wallet.input';
import { UpdateUserWalletInput } from './dto/update-user-wallet.input';
import { AuthGuard } from 'src/auth/auth.guard';
import { UseGuards } from '@nestjs/common';

@Resolver(() => UserWallet)
@UseGuards(AuthGuard)
export class UserWalletResolver {
  constructor(private readonly userWalletService: UserWalletService) {}

  @Query(() => getUserWallet, { name: 'getUserWallet' })
  find(@Context('user') user: any) {
    return this.userWalletService.findOne(user._id);
  }
}
