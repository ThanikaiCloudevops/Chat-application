export const MODULE = { NAME: 'Cron Module', PORT: 5100 };
export const DB = {
  URL: 'mongodb+srv://super-league_user01:RiBA5Y8HUiDFUpEo@cluster-1.fehzk.mongodb.net/superleague?retryWrites=true&w=majority&appName=Cluster-1',
};
export const SPORTS_DATA = {
  URL: 'https://cricket.thefantasysport.com/api/v1',
  FOOTBALL: 'https://soccer.thefantasysport.com/soccer/api/v1',
  KABADDI: 'http://3.210.67.57:3010/kabaddi/api/v1',
};
export const SERVICE_ACCOUNT = {
  type: 'service_account',
  project_id: 'super-league-pro',
  private_key_id: '19ce0bb5ba793d53d5337a2578416806ba345577',
  private_key:
    '-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCtl0uTC8l5Qkw9\nRdbASGvjTShPdjVMzHAVfwBYBbl04uBdhGbDdCFhZRlMr6Ln+MuUBhD9Bs1pvNre\ntHYpUp/5Tc09vkQLzA7OR9EG251N9Pp/cKtOcepiH46yV27vra40xPcvbcZbuVlj\nd0s6nv6TtaNWKv9kFnu+dIsLxxyAntT01+VE3jJydRz37U1QGLETasNmGc2tUb60\njEAMrs/lzE1VALBSLgOBJa1r79zxRaysUmiGxxOMjG3/uIpEcnq6o4yNYmhmwe30\nkEpo2C3epkmqAK6SZTR9OqFrqfivnlEC+HuiCWtesYT51mtEvBPR8RAztPnPU/QP\nglzxpIi7AgMBAAECggEAHDTeUdlzdmGgc8BaYcoixb9u0mKZzI3XlJabXrInbWfE\nH035SL8hAWtlDgHoDZtusPG/Zu3pCMpoIhHetV44olDTDbpR4jzZFwmyXFPpHpa0\n8WpEW63E8QbBsBbm7skg6nAq3ikPNy5J6RCkR7U4FpZIISNBdmj02ICla1eCOR/R\nVkVjJIxSg6XDAeULN6R4EN6xNaO1ov36rMMKeBYKWiBMyrn0230fi4YKWhZxyAim\nhA6my7PgmGbjuyts+KIVaZkhAUf26ryLQ6nT652ngw0aEUad2iKwKSpqUdGbCIaN\np9bNzBQYGKsd0eW+rfC7bsDuzqm9u2vYF8EpxA1pCQKBgQDcGA/OB6cpyMJwBIoJ\nHegmJ5ZkpYAHbTolkGeaApz0Pc5BJg8NX9Y2uETV4bokeq2KwAxulf/EMU3O5tgU\nnRf6BoyRQn41leD3FBIboFqw/MK1w07KhbT8dRBMS6m7EtKp9ZpP8Q7eoW+0aPW5\nlXJLsvsCRWjMMe7TDU/5osvqpwKBgQDJ6Ri8AnNS/qXlCzvpF7q03M989mEzvB9x\ndSoHKDo8APjbYcUmGOEXLB/mwQaIlqcrEKpk6MHSXeCZOuOtct+P4Vf+rBvxK540\nraV/czsu1Ql2LcnIh6m+uwH7ZxzNtDhhWfKZ6q1IFlfxkn+0HsyMon+Mdk0596aT\ntlIuGkp3zQKBgAJiaFltD8yOFj0sb2pl3ov7Rc/VUyvBbS3XAKhUeurSeJeQF/2n\nGiUBng1LIr8ebR7hscDI8zpm5lblfVXL1eSpiYBRXhiqhQNoPkH6XMEqG9noQcRD\n6pAJnKGW+EHElG+u73sKO4UB7rnfoTnfepuDVuDRa686o0G6FTG5J8hlAoGAX8pK\nhcfT1qghJEz0G126oluvxGVPMDAr6rPfQI4BMr5zUgFMewqKn2e7qsogw2RV4sSB\nUmZqrdcD2y5pHbzF+4i5KoWUrBI5eFx5i8Grbkh7uKl4db6G9YnbIt6Ed8LsjKMT\nyZngo7aV+nG6TEXgXUgqowTtFnc7fBCfZGfstHECgYBgBk2QgEzGMjgqoQEtQwOB\n9pyvP0ogW7pP6u6N+7Vhr2P1ULynjmZZexFFMum9C445D+q9XqQHoKs/KQXUESqU\nISqFBUREIY6p4b4g2n1iPLbN4UrAFnYNFVKf6h2QQ7MgGaf5WJl+YcC/v0Fzd1i5\nirkuknf6+lBLctSfPlxnJA==\n-----END PRIVATE KEY-----\n',
  client_email:
    'firebase-adminsdk-dfbuq@super-league-pro.iam.gserviceaccount.com',
  client_id: '111083884852419728629',
  auth_uri: 'https://accounts.google.com/o/oauth2/auth',
  token_uri: 'https://oauth2.googleapis.com/token',
  auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
  client_x509_cert_url:
    'https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-dfbuq%40super-league-pro.iam.gserviceaccount.com',
  universe_domain: 'googleapis.com',
};
