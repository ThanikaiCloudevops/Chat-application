import { PartialType } from '@nestjs/mapped-types';
import { CreatePointsCronDto } from './create-points-cron.dto';

export class UpdatePointsCronDto extends PartialType(CreatePointsCronDto) {}

export interface CreateUserTransactionInput {
  userId: string;
  transanctionType: string;
  amount: number;
  transanctionRelatedType: string;
  fixtureId?: string;
  contestId?: string;
  contestName?: string;
  fixtureName?: string;
}
