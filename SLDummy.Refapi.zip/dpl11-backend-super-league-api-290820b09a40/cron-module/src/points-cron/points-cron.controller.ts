import { Controller, Get, Param } from '@nestjs/common';
import { PointsCronService } from './points-cron.service';

@Controller('points-cron')
export class PointsCronController {
  constructor(private readonly pointsCronService: PointsCronService) {}

  @Get('/updateuserpoints')
  updateScorecard() {
    return this.pointsCronService.updateUserPoints();
  }
  @Get('/updaterank/:id')
  updateRank(@Param() params: any) {
    return this.pointsCronService.winningDeclaration(params.id, 3, 'cricket'); // have to change as 3 params
  }

  @Get('/seriespoints/:id')
  updateSeriesPoints(@Param() params: any) {
    return this.pointsCronService.updateSeriesPoints(params.id);
  }

  @Get('/userstats/:id')
  updateUserStats(@Param() params: any) {
    return this.pointsCronService.updateJoinedPlayerStats(params.id);
  }

  @Get('/jointstats/:id')
  updateJointStats(@Param() params: any) {
    return this.pointsCronService.updateJoinedPlayerStats(params.id);
  }

  @Get('/moveContestToLive/:id')
  moveContesttoLive(@Param() params: any) {
    return this.pointsCronService.moveContesttoLive(73816); // have to change as 3 params
  }

  @Get('/cancelIncompleteContests/:id/:name')
  cancelIncompleteContests(@Param() params: any) {
    return this.pointsCronService.cancelIncompleteContests(74718, 'LSG vs DC'); // have to change as 3 params
  }

  @Get('/declarewinner/:id')
  winnerDecleration(@Param() params: any) {
    return this.pointsCronService.winningDecleration(params.id);
  }

  @Get('/footballpoints/:id')
  updateFixtureFootballPoints(@Param() params: any) {
    return this.pointsCronService.updateFootballTeamPoints(params.id);
  }
}
