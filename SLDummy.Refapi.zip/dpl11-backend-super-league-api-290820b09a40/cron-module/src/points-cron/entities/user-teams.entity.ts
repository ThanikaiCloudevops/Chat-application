import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
export type userTeamsDocument = userTeams & Document;
@ObjectType()
export class team {
  @Field()
  @Prop()
  playerName: string;
  @Field({ nullable: true })
  @Prop()
  playerDisplayName: string;
  @Field()
  @Prop()
  playerAPIId: number;
  @Field()
  @Prop()
  playerType: string;
  @Field()
  @Prop()
  playerValue: number;
  @Field()
  @Prop()
  teamAPIId: number;
  @Field()
  @Prop()
  teamName: string;
  @Field()
  @Prop()
  teamDisplayName: string;
  @Field()
  @Prop()
  imgUrl: string;
  @Field()
  @Prop()
  cap: boolean;
  @Field()
  @Prop()
  vc: boolean;
  @Field({ defaultValue: 0 })
  @Prop()
  points: number;
}

@ObjectType()
export class userTeam {
  @Field()
  @Prop()
  _id: string;
  @Field()
  @Prop()
  userId: string;
  @Field()
  @Prop()
  userName: string;
  @Field()
  @Prop()
  teamName: string;
  @Field()
  @Prop()
  totalValue: number;
  @Field()
  @Prop()
  totalPoints: number;
  @Field(() => [team])
  @Prop()
  team: team[];
  @Field()
  @Prop()
  createdat: Date;
}

@ObjectType()
@Schema()
export class userTeams {
  @Field()
  @Prop({ index: true })
  fixtureAPIId: number;

  @Field(() => [userTeam])
  @Prop()
  userTeams: userTeam[];

  @Field()
  gameType: string;
}

export const userTeamSchema = SchemaFactory.createForClass(userTeams);
