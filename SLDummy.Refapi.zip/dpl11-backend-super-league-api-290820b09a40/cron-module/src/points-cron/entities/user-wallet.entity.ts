import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type UserWalletDocument = UserWallet & Document;

@Schema()
export class UserWallet {
  @Prop()
  userId: string;

  @Prop()
  userBalance: number;

  @Prop()
  totalWinnings: number;

  @Prop()
  totalBonus: number;

  @Prop()
  unutilisedBalance: number;
}

export const UserWalletSchema = SchemaFactory.createForClass(UserWallet);
