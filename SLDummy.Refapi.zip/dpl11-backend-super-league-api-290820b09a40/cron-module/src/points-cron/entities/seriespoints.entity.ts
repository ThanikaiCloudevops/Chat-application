import { ObjectType, Field } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type seriesPointsDocument = seriesPoints & Document;

@ObjectType()
class seriesPlayerPoints {
  @Field()
  playerAPIId: number;

  @Field()
  points: number;
}

@ObjectType()
@Schema()
export class seriesPoints {
  @Field()
  @Prop()
  seriesAPIId: number;

  @Field(() => [seriesPlayerPoints])
  @Prop({ type: Array })
  playerPoints: seriesPlayerPoints[];

  @Prop()
  gameType: string;
}

export const seriesPointsSchema = SchemaFactory.createForClass(seriesPoints);
