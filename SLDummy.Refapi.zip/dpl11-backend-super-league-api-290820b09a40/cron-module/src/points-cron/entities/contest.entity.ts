import { ObjectType, Field, PartialType, OmitType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import graphqlTypeJson from 'graphql-type-json';
import { Document } from 'mongoose';

export type contestDocument = Contest & Document;

@ObjectType()
class priceSplitUp {
  @Field({ nullable: true })
  rank: string;
  @Field({ nullable: true })
  price: number;
}

@ObjectType()
class Prize {
  @Field()
  @Prop()
  prizeType: string;

  @Field()
  @Prop()
  totalValue: number;

  @Field()
  @Prop()
  split: boolean;

  @Field(() => graphqlTypeJson)
  @Prop({ type: Object })
  prizeSplitUp: any;

  @Field(() => graphqlTypeJson)
  @Prop({ type: Object })
  prizeBreak: any;

  // for response only
  @Field(() => [priceSplitUp])
  priceSplitUp: priceSplitUp[];
}

@ObjectType()
@Schema()
export class Contest {
  @Field()
  @Prop({ index: true })
  fixtureAPIId: number;

  @Field({ nullable: true })
  @Prop({ required: false })
  contestCode?: string;

  @Field()
  @Prop()
  contestName: string;

  @Prop({ default: true })
  isJoin?: boolean;

  @Field()
  @Prop()
  constestCaption: string;

  @Field()
  @Prop()
  contestType: string;

  @Field()
  @Prop()
  poolType: string;

  @Field()
  @Prop()
  maxPrizepool: number;

  @Field()
  @Prop()
  totalPrizePool: number;

  @Field()
  @Prop()
  totalSpots: number;

  @Field()
  @Prop()
  remainingSpots: number;

  @Field()
  @Prop()
  maxTeamCount: number;

  @Field()
  @Prop()
  guaranteed: boolean;

  @Field()
  @Prop()
  enabledStatus: boolean;

  @Field()
  @Prop()
  isactive: boolean;

  @Field(() => Prize)
  @Prop()
  prize: Prize;

  @Field(() => graphqlTypeJson)
  @Prop({ type: Object })
  jointUsers: any;

  @Field({ defaultValue: false })
  position: boolean;

  @Field()
  @Prop()
  discountEntryFee: number;

  @Field()
  @Prop()
  winningPercentage: number;

  @Prop()
  startDate?: Date;

  @Field()
  @Prop()
  entryFee: number;

  @Prop()
  gameType: string;

  @Field({ nullable: true })
  @Prop()
  paid: boolean;

  @Field({ nullable: true })
  @Prop()
  order?: number;
}

export const ContestsSchema = SchemaFactory.createForClass(Contest);
