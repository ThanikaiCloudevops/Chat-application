import { Module } from '@nestjs/common';
import { PointsCronService } from './points-cron.service';
import { PointsCronController } from './points-cron.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { ScheduleModule } from '@nestjs/schedule';
import { userTeamSchema, userTeams } from './entities/user-teams.entity';
import { UserSchema, User } from './entities/user.entity';
import { FixturesSchema, cricketFixtures } from './entities/fixtures.entity';
import {
  playerPerformance,
  playerPerformanceSchema,
} from 'src/scorecard-cron/entities/playerPerformance.entity';
import { Contest, ContestsSchema } from './entities/contest.entity';
import {
  UserTransaction,
  UserTransactionSchema,
} from './entities/user-transaction.entity';
import { UserWallet, UserWalletSchema } from './entities/user-wallet.entity';
import { NotificationService } from 'src/notification/notification.service';
import { FirebaseService } from 'src/notification/firebase.service';
import {
  NotificationSchema,
  Notification,
} from './entities/notifications.entity';
import {
  seriesPoints,
  seriesPointsSchema,
} from './entities/seriespoints.entity';
import {
  joinedPlayerStats,
  joinedPlayerStatsSchema,
} from './entities/joinedstats.entity';
import {
  FootballFixtures,
  FootballFixturesSchema,
} from 'src/game-cron/entities/footballfixtures.entity';
import {
  FootballPlayerPerformance,
  FootballPlayerPerformanceSchema,
} from 'src/scorecard-cron/entities/football-playerperformance.entity';
import {
  KabaddiFixtures,
  kabaddiFixturesSchema,
} from 'src/game-cron/entities/kabaddifixtures.entity';
import {
  KabaddiPlayerPerformance,
  KabaddiPlayerPerformanceSchema,
} from 'src/scorecard-cron/entities/kabaddi-playerperformance.entity';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: userTeams.name, schema: userTeamSchema },
      { name: User.name, schema: UserSchema },
      { name: playerPerformance.name, schema: playerPerformanceSchema },
      { name: Contest.name, schema: ContestsSchema },
      { name: cricketFixtures.name, schema: FixturesSchema },
      { name: UserTransaction.name, schema: UserTransactionSchema },
      { name: UserWallet.name, schema: UserWalletSchema },
      { name: Notification.name, schema: NotificationSchema },
      { name: seriesPoints.name, schema: seriesPointsSchema },
      { name: joinedPlayerStats.name, schema: joinedPlayerStatsSchema },
      { name: FootballFixtures.name, schema: FootballFixturesSchema },
      {
        name: FootballPlayerPerformance.name,
        schema: FootballPlayerPerformanceSchema,
      },
      { name: KabaddiFixtures.name, schema: kabaddiFixturesSchema },
      {
        name: KabaddiPlayerPerformance.name,
        schema: KabaddiPlayerPerformanceSchema,
      },
    ]),
    ScheduleModule.forRoot(),
  ],
  controllers: [PointsCronController],
  providers: [PointsCronService, NotificationService, FirebaseService],
  exports: [PointsCronService],
})
export class PointsCronModule {}
