const successMsg = {
  series: 'Series updated successfully',
  fixture: 'Fixtures updated successfully',
  teamplayers: 'Team and players updated successfully',
  cronstart: 'Cron service has beens started',
  cronstop: 'Cron service has beens stopped',
  scorecard: 'Scorecard updated successfully',
};
export function successResponse(msg: string, data: any = null) {
  return { status: true, success: { message: successMsg[msg] }, data };
}
