import { Controller, Get } from '@nestjs/common';
import { ScorecardCronService } from './scorecard-cron.service';

@Controller('scorecard-cron')
export class ScorecardCronController {
  constructor(private readonly scorecardCronService: ScorecardCronService) {}

  @Get('/updatescorecard')
  updateScorecard() {
    return this.scorecardCronService.updateScorecard();
  }

  /* Temp */
  @Get('/points')
  points() {
    return this.scorecardCronService.pointsGet();
  }
  /* Temp */

  @Get('/football/updatescorecard')
  updateFootballScorecard() {
    return this.scorecardCronService.updateFootballScorecard();
  }

  @Get('/kabaddi/updatescorecard')
  updateKabaddiScorecard() {
    return this.scorecardCronService.updateKabaddiScorecard();
  }
}
