export class CreateScorecardCronDto {}
