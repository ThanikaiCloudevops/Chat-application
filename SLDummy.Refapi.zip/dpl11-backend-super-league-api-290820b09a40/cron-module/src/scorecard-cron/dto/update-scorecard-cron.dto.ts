import { PartialType } from '@nestjs/mapped-types';
import { CreateScorecardCronDto } from './create-scorecard-cron.dto';

export class UpdateScorecardCronDto extends PartialType(CreateScorecardCronDto) {}
