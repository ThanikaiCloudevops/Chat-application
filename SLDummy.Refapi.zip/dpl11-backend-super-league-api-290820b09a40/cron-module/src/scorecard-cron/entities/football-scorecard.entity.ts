import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type footballScorecardDocument = FootballScorecard & Document;

export class scorecardTeam {
  teamAPIId: number;
  shortName: string;
  logo: string;
  name: string;
  fullName: string;
}

export class scorecardTeams {
  away: scorecardTeam;
  home: scorecardTeam;
}

export class HomeAway {
  away: number;
  home: number;
}

export class Periods {
  ft: HomeAway;
  p1: HomeAway;
  p2: HomeAway;
}

export class GameStats extends HomeAway {
  name: string;
}

export class PlayerStats {
  playerAPIId: number;
  playerName: string;
  role: string;
  teamType: string;
  fouls: number;
  goals: number;
  saves: number;
  assist: number;
  keypass: number;
  punches: number;
  redcard: number;
  duelswon: number;
  owngoals: number;
  totalpass: number;
  wasfouled: number;
  cleansheet: number;
  crossesacc: number;
  duelstotal: number;
  penaltywon: number;
  totalcross: number;
  yellowcard: number;
  hitwoodwork: number;
  penaltymiss: number;
  penaltysave: number;
  accuratepass: number;
  dispossessed: number;
  goalconceded: number;
  longballsacc: number;
  shotsblocked: number;
  totalrunsout: number;
  challengelost: number;
  goodhighclaim: number;
  lastmantackle: number;
  minutesplayed: number;
  runsoutsucess: number;
  shotsontarget: number;
  tacklesuccess: number;
  dribblesuccess: number;
  errorledtogoal: number;
  errorledtoshot: number;
  shotsofftarget: number;
  totalclearance: number;
  totallongballs: number;
  bigchancemissed: number;
  dribbleattempts: number;
  interceptionwon: number;
  outfielderblock: number;
  passingaccuracy: number;
  tacklecommitted: number;
  bigchancecreated: number;
  clearanceoffline: number;
  penaltycommitted: number;
  savesfrominsidebox: number;
}

export class Result extends HomeAway {
  winner: string;
}

@Schema()
export class FootballScorecard {
  @Prop({ type: Number })
  fixtureAPIId: number;

  @Prop({ type: Number })
  seriesAPIId: number;

  @Prop()
  status: string;

  @Prop()
  result: Result;

  @Prop()
  teams: scorecardTeams;

  @Prop()
  periods: Periods;

  @Prop()
  gameStats: GameStats[];

  @Prop()
  playerStats: PlayerStats[];
}

export const FootballScorecardSchema =
  SchemaFactory.createForClass(FootballScorecard);
