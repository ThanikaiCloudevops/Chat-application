import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { BatTeam, BowlTeam, fieldTeam } from './scorecard.entity';
export type playerPerformanceDocument = playerPerformance & Document;

export interface playerStat extends BatTeam, BowlTeam, fieldTeam {}

export class playerPoint {
  player_id: number;
  player_name: string;
  player_role: string;
  playing11: number;
  rating: number;
  point: number;
  run: number;
  four: number;
  six: number;
  strike_rate: number;
  fifty: number;
  duck: number;
  wickets: number;
  maidenover: number;
  economic_rate: number;
  catch: number;
  runout_stumping: number;
  runout_thrower: number;
  runout_catcher: number;
  direct_runout: number;
  stumping: number;
  thirty: number;
  bonus: number;
  bonus_catch: number;
  bonus_bowedlbw: number;
}

@Schema()
export class playerPerformance {
  @Prop({ type: Number })
  fixtureAPIId: number;

  @Prop({ type: String })
  fixtureStatus: string;

  @Prop({ type: Number, default: 1 })
  innings: number;

  @Prop({ type: Array })
  playerStat?: playerStat[];

  @Prop({ type: Array })
  playerPoint?: playerPoint[];
}

export const playerPerformanceSchema =
  SchemaFactory.createForClass(playerPerformance);
