import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type pointDocument = Point & Document;

class commonPointStrikerateEconomy {
  min: number;
  points: object;
}

export class Bat {
  run: number;
  four: number;
  six: number;
  thirty: number;
  fifty: number;
  duck: number;
  strikerate: commonPointStrikerateEconomy;
}

export class Bowl {
  wicket: number;
  LBWBowledBonus: number;
  threeWicketBonus: number;
  fourWicketBonus: number;
  fiveWicketBonus: number;
  maiden: number;
  economy: commonPointStrikerateEconomy;
}

class Runout {
  direct: number;
  indirect: number;
}

class Catch {
  min: number;
  bonus: number;
}

export class Field {
  catch: number;
  bonus: Catch;
  stumping: number;
  runout: Runout;
}

class point {
  in11: number;
  substitute: number;
  cap: number;
  vc: number;
  bat: Bat;
  bowl: Bowl;
  field: Field;
}

@Schema()
export class Point {
  @Prop({ type: String })
  formatType: string;
  @Prop({ type: Object })
  points: point;
}

export const PointsSchema = SchemaFactory.createForClass(Point);
