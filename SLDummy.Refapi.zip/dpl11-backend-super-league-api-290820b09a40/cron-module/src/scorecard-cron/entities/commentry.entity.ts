import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
export type CommentryDocument = commentries & Document;
export class LiveScore {
  runs: number;
  overs: number;
  wickets: number;
  target: number;
  runrate: number;
  requiredRunrate: string;
}

export class Team {
  team_id: number;
  title: string;
  team_sh: string;
  alt_name: string;
  type: string;
  thumb_url: string;
  logo_url: string;
  country_sh: string;
  sex: string;
  scores_full: string;
  scores: string;
  overs: string;
}

class Teams {
  teamA: Team;
  teamB: Team;
}

export class Batsmen {
  name: string;
  batsman_id: number;
  runs: number;
  ballsFaced: number;
  foursHit: number;
  sixesHit: number;
  strikeRate: number;
}

export class Bowlers {
  name: string;
  bowler_id: number;
  oversBowled: number;
  runsConceded: number;
  wickets: number;
  maidens: number;
  econ: number;
}

@Schema()
export class commentries {
  @Prop({ type: Number })
  fixtureAPIId: number;

  @Prop({ type: Number })
  status: number;

  @Prop({ type: String })
  status_str: string;

  @Prop({ type: String })
  status_notes: string;

  @Prop({ type: String })
  remainingOvers: string;

  @Prop({ type: String })
  battingTeam: string;

  @Prop({ type: String })
  bowlingTeam: string;

  @Prop({ type: Number })
  inningsNumber: number;

  @Prop({ type: LiveScore })
  liveScore: LiveScore;

  @Prop({ type: Teams })
  teams: Teams;

  @Prop({ type: Array })
  batsmen: Batsmen[];

  @Prop({ type: Array })
  bowlers: Bowlers[];

  @Prop({ type: Object })
  liveInnings: object;

  @Prop({ type: Array })
  commentaries: any[];
}

export const CommentrySchema = SchemaFactory.createForClass(commentries);
