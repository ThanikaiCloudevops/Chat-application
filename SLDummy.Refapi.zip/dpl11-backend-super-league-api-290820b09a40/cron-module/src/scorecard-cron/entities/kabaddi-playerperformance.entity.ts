import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export type KabaddiPlayerPerformanceDocument = KabaddiPlayerPerformance &
  Document;

export class KabaddiPlayerStats {
  playerAPIId: number;
  playerName: string;
  side: string;
  greencardcount: number;
  yellowcardcount: number;
  redcardcount: number;
  totalpoint: number;
  raidtotalpoint: number;
  raidtouchpoint: number;
  raidbonuspoint: number;
  tackletotalpoint: number;
  tacklecapturepoint: number;
  tacklecapturebonuspoint: number;
  tackletotal: number;
  tacklesuccessful: number;
  tackleunsuccessful: number;
  supertackles: number;
  raidtotal: number;
  raidsuccessful: number;
  raidunsuccessful: number;
  raidempty: number;
  superraid: number;
  superten: number;
  highfive: number;
}

export class KabaddiPlayerPoints {
  playerAPIId: number;
  playerName: string;
  playerRole: string;
  fantasyCredit: number;
  playerPoints: number;
  in11Points: number;
  subPoints: number;
  raidtouchPoints: number;
  raidbonusPoints: number;
  superraidPoints: number;
  supertenPoints: number;
  tacklesucceessfulPoints: number;
  supertacklePoints: number;
  tackleunsucceessfulPoints: number;
  highfivePoints: number;
  greencardPoints: number;
  yellowcardPoints: number;
  redcardPoints: number;
  pushingalloutPoints: number;
  gettingalloutPoints: number;
}

@Schema()
export class KabaddiPlayerPerformance {
  @Prop({ type: Number })
  fixtureAPIId: number;

  @Prop({ type: String })
  fixtureStatus: string;

  @Prop()
  playerPoints: KabaddiPlayerPoints[];

  @Prop()
  playerStats: KabaddiPlayerStats[];
}

export const KabaddiPlayerPerformanceSchema = SchemaFactory.createForClass(
  KabaddiPlayerPerformance,
);
