import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export type FootballCommentaryDocument = FootballCommentary & Document;

export class FootballEvents {
  playerAPIId: number;
  playerName: string;
  type: string;
  time: number;
  card: string;
  name: string;
  team: string;
  injuryTime: number;
  playerAPIIdIn: number;
  playerAPIIdOut: number;
  inPlayerName: string;
  outPlayerName: string;
  status: number;
  statusStr: string;
}

export class FootballCommentaries {
  id: number;
  time: number;
  sentence: string;
  injuryTime: number;
}

@Schema()
export class FootballCommentary {
  @Prop()
  fixtureAPIId: number;

  @Prop()
  events: FootballEvents[];

  @Prop()
  commentary: FootballCommentaries[];
}

export const FootballCommentarySchema =
  SchemaFactory.createForClass(FootballCommentary);
