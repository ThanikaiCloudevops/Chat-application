import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type scorecardeDocument = Scorecard & Document;

class Toss {
  wonTeamId: number;
  text: string;
  result: string;
}

export class Team {
  name: string;
  shortName: string;
  teamAPIId: number;
  logo: string;
  scores_full: string;
  scores: string;
  overs: string;
}

class Teams {
  teamA: Team;
  teamB: Team;
}

class OutType {
  type?: string;
  duckOut?: false;
  bowledBy?: string;
  caughtBy?: string;
  stumpedBy?: string;
  runout?: string;
  FOW?: string;
  outComment?: string;
}
export interface BatTeam {
  playerName: string;
  playerAPIId: number;
  player_type: string;
  ballsFaced: number;
  battingPosition: string;
  runsScored: number;
  foursHit: number;
  sixesHit: number;
  strikeRate: number;
  outStatus: boolean;
  outType: OutType;
}

export interface BowlTeam {
  playerName: string;
  playerAPIId: number;
  player_type: string;
  bowlingPosition: string;
  oversBowled: number;
  runsGiven: number;
  maidensBowled: number;
  noBallsBowled: number;
  widesBowled: number;
  wicketsTaken: number;
  bowledMade: number;
  lbwMade: number;
  economy: number;
  bowlingStrikerate: number;
}

export interface fieldTeam {
  fielder_id: string;
  fielder_name: string;
  catches: number;
  runout_thrower: number;
  runout_catcher: number;
  runout_direct_hit: number;
  stumping: number;
  is_substitute: string;
}

class Bat {
  teamAPIId: number;
  team: [BatTeam];
}

class Bowl {
  teamAPIId: number;
  team: [BowlTeam];
}

class Field {
  teamAPIId: number;
  team: [fieldTeam];
}

export interface DNBTeam {
  playerId: string;
  playerName: string;
}

class DidnotBat {
  teamAPIId: number;
  team: [DNBTeam];
}

export class Inning {
  inningsNumber: number;
  bat: Bat;
  bowl: Bowl;
  fielders: Field;
  didNotBat: DidnotBat;
  extras: object;
  equations: object;
}

@Schema()
export class Scorecard {
  @Prop({ type: Number })
  fixtureAPIId: number;

  @Prop({ type: Number })
  sereisAPIId: number;

  @Prop({ type: String })
  fixtureType: string;

  @Prop({ type: Number })
  maxInningsCount: number;

  @Prop({ type: String })
  fixtureStatusNote: string;

  @Prop({ type: Number })
  currentInnings?: number;

  @Prop({ type: String })
  fixtureStatus: string;

  @Prop({ type: Object })
  teams: Teams;

  @Prop({ type: Array })
  innings?: Inning[];

  @Prop({ type: Object })
  toss?: Toss;
}

export const ScorecardSchema = SchemaFactory.createForClass(Scorecard);
