import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type footballPointsDocument = footballPoints & Document;

@Schema()
export class footballPoints {
  @Prop()
  isactive: boolean;
  @Prop()
  goalStriker: number;
  @Prop()
  goalMidfielder: number;
  @Prop()
  goalDefKeep: number;
  @Prop()
  assist: number;
  @Prop()
  chanceCreated: number;
  @Prop()
  shotOnTarget: number;
  @Prop()
  fivePass: number;
  @Prop()
  tackel: number;
  @Prop()
  interception: number;
  @Prop()
  goalSave: number;
  @Prop()
  penaltySave: number;
  @Prop()
  cleanSheet: number;
  @Prop()
  in11: number;
  @Prop()
  sub: number;
  @Prop()
  yellowCard: number;
  @Prop()
  redCard: number;
  @Prop()
  ownGoal: number;
  @Prop()
  goalsConceded: number;
  @Prop()
  penaltyMissed: number;
}

export const FootballPointsSchema =
  SchemaFactory.createForClass(footballPoints);
