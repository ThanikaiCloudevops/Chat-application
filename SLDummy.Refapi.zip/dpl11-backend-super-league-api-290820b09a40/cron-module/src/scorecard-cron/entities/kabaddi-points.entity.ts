import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type KabaddiPointsDocument = KabaddiPoints & Document;

@Schema()
export class KabaddiPoints {
  @Prop()
  isactive: boolean;
  @Prop()
  in11Points: number;
  @Prop()
  subPoints: number;
  @Prop()
  raidtouchPoints: number;
  @Prop()
  raidbonusPoints: number;
  @Prop()
  superraidPoints: number;
  @Prop()
  supertenPoints: number;
  @Prop()
  tacklesucceessfulPoints: number;
  @Prop()
  supertacklePoints: number;
  @Prop()
  tackleunsucceessfulPoints: number;
  @Prop()
  highfivePoints: number;
  @Prop()
  greencardPoints: number;
  @Prop()
  yellowcardPoints: number;
  @Prop()
  redcardPoints: number;
  @Prop()
  pushingalloutPoints: number;
  @Prop()
  gettingalloutPoints: number;
}

export const KabaddiPointsSchema = SchemaFactory.createForClass(KabaddiPoints);
