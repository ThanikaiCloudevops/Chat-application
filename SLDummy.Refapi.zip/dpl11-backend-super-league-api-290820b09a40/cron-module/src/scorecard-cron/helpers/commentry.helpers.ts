import { Injectable } from '@nestjs/common';
import {
  FootballCommentaries,
  FootballCommentary,
  FootballEvents,
} from '../entities/football-commentry.entity';

@Injectable()
export class commentryHelper {
  #teams(team: any) {
    return {
      team_id: team.tid,
      title: team.title,
      team_sh: team.abbr,
      alt_name: team.alt_name,
      type: team.type,
      thumb_url: team.thumb_url,
      logo_url: team.logo_url,
      country_sh: team.country,
      sex: team.sex,
      scores_full: team.scores_full,
      scores: team.scores,
      overs: team.overs,
    };
  }
  #batsmen(batsmen: any[]) {
    return batsmen.map((batsman) => {
      return {
        name: batsman.name,
        batsman_id: +batsman.batsman_id,
        runs: +batsman.runs,
        ballsFaced: +batsman.balls_faced,
        foursHit: +batsman.fours,
        sixesHit: +batsman.sixes,
        strikeRate: +batsman.strike_rate,
      };
    });
  }
  #bowlers(bowlers: any[]) {
    return bowlers.map((bowler) => {
      return {
        name: bowler.name,
        bowler_id: +bowler.bowler_id,
        oversBowled: +bowler.overs,
        runsConceded: +bowler.runs_conceded,
        wickets: +bowler.wickets,
        maidens: +bowler.maidens,
        econ: +bowler.econ,
      };
    });
  }
  #didNotBat(batsmen: { player_id: string | number; name: any }[]) {
    return batsmen.map((batsman: { player_id: string | number; name: any }) => {
      return {
        player_id: +batsman.player_id,
        name: batsman.name,
      };
    });
  }
  #fielder(
    fielders: {
      fielder_id: string | number;
      fielder_name: string;
      catches: string | number;
      runout_thrower: string | number;
      runout_direct_hit: string | number;
      stumping: string | number;
      is_substitute: boolean;
    }[],
  ) {
    return fielders.map((fielder: any) => {
      return {
        fielder_id: +fielder.fielder_id,
        fielder_name: fielder.fielder_name,
        catches: +fielder.catches,
        runout_thrower: +fielder.runout_thrower,
        runout_catcher: +fielder.runout_catcher,
        runout_direct_hit: +fielder.runout_direct_hit,
        stumping: +fielder.stumping,
        is_substitute: fielder.is_substitute,
      };
    });
  }
  #powerplay(powerPlay) {
    const power_play = {};
    for (const p in powerPlay) {
      power_play[p] = {
        startover: powerPlay[p].startover,
        endover: powerPlay[p].endover,
      };
    }
    return power_play;
  }

  #bats(_bats: any[]) {
    return _bats.map((bat) => ({
      runs: bat.runs,
      balls_faced: bat.balls_faced,
      fours: bat.fours,
      sixes: bat.sixes,
      batsman_id: bat.batsman_id,
    }));
  }
  #bowls(_bowls: any[]) {
    return _bowls.map((bowl) => ({
      runs_conceded: bowl.runs_conceded,
      maidens: bowl.maidens,
      wickets: bowl.wickets,
      bowler_id: bowl.bowler_id,
      overs: bowl.overs,
    }));
  }
  #review(reviewData: {
    total_review: number;
    review_success: number;
    review_failed: number;
    review_available: number;
  }) {
    return {
      total_review: reviewData.total_review,
      review_success: reviewData.review_success,
      review_failed: reviewData.review_failed,
      review_available: reviewData.review_available,
    };
  }
  #overs(over: any) {
    return {
      event_id: over.event_id,
      event: over.event,
      batsman_id: over.batsman_id,
      bowler_id: over.bowler_id,
      over: over.over,
      ball: over.ball,
      score: over.score,
      commentary: over.commentary,
      noball_dismissal: over.noball_dismissal,
      text: over.text,
      timestamp: over.timestamp,
      run: over.run,
      noball_run: over.noball_run,
      wide_run: over.wide_run,
      bye_run: over.bye_run,
      legbye_run: over.legbye_run,
      bat_run: over.bat_run,
      noball: over.noball,
      wideball: over.wideball,
      six: over.six,
      four: over.four,
    };
  }
  #overEnd(over_end: any) {
    return {
      event: over_end.event,
      over: over_end.over,
      runs: over_end.runs,
      score: over_end.score,
      bats: this.#bats(over_end.bats),
      bowls: this.#bowls(over_end.bowls),
      commentary: over_end.commentary,
    };
  }

  #commentaries(commentaries: any[]) {
    return commentaries.map((over) => {
      if (over.event == 'overend') return this.#overEnd(over);
      return this.#overs(over);
    });
  }

  #liveInnings(live_innings: any) {
    return {
      innings_id: +live_innings.iid,
      innings_number: +live_innings.number,
      name: live_innings.name,
      short_name: live_innings.short_name,
      status: +live_innings.status,
      issuperover: live_innings.issuperover,
      result: live_innings.result,
      batting_team_id: +live_innings.batting_team_id,
      fielding_team_id: +live_innings.fielding_team_id,
      scores: live_innings.scores,
      scores_full: live_innings.scores_full,
      max_over: live_innings.max_over,
      recent_scores: live_innings.recent_scores,
      last_five_overs: live_innings.last_five_overs,
      last_ten_overs: live_innings.last_ten_overs,
      did_not_bat: this.#didNotBat(live_innings.did_not_bat),
      fielder: this.#fielder(live_innings.fielder),
      last_wicket: {
        name: live_innings.last_wicket.name,
        batsman_id: +live_innings.last_wicket.batsman_id,
        runs: +live_innings.last_wicket.runs,
        balls: +live_innings.last_wicket.balls,
        how_out: live_innings.last_wicket.how_out,
        score_at_dismissal: +live_innings.last_wicket.score_at_dismissal,
        overs_at_dismissal: +live_innings.last_wicket.overs_at_dismissal,
        bowler_id: +live_innings.last_wicket.bowler_id,
        dismissal: live_innings.last_wicket.dismissal,
        number: +live_innings.last_wicket.number,
      },
      extra_runs: {
        byes: +live_innings.extra_runs.byes,
        legbyes: +live_innings.extra_runs.legbyes,
        wides: +live_innings.extra_runs.wides,
        noballs: +live_innings.extra_runs.noballs,
        penalty: +live_innings.extra_runs.penalty,
        total: +live_innings.extra_runs.total,
      },
      equations: {
        runs: +live_innings.equations.runs,
        wickets: +live_innings.equations.wickets,
        overs: live_innings.equations.overs,
        bowlers_used: +live_innings.equations.bowlers_used,
        runrate: live_innings.equations.runrate,
      },
      review: {
        batting: this.#review(live_innings.review.batting_team),
        bowling: this.#review(live_innings.review.bowling_team),
      },
      current_partnership: {
        runs: +live_innings.current_partnership.runs,
        balls: +live_innings.current_partnership.balls,
        overs: +live_innings.current_partnership.overs,
        batsmen: live_innings.current_partnership.batsmen.map(
          (batsman: {
            name: string;
            batsman_id: number;
            runs: number;
            balls: number;
          }) => ({
            name: batsman.name,
            batsman_id: batsman.batsman_id,
            runs: batsman.runs,
            balls: batsman.balls,
          }),
        ),
      },
      powerplay: this.#powerplay(live_innings.powerplay),
    };
  }

  formatCommentry(_data: any) {
    try {
      return {
        fixtureAPIId: +_data.match_id,
        status: +_data.status,
        status_str: _data.status_str,
        status_notes: _data.status_note,
        remainingOvers: _data.day_remaining_over,
        battingTeam: _data.team_batting,
        bowlingTeam: _data.team_bowling,
        inningsNumber: +_data.live_inning_number,
        liveScore: {
          runs: +_data.live_score.runs,
          overs: +_data.live_score.overs,
          wickets: +_data.live_score.wickets,
          target: +_data.live_score.target,
          runrate: +_data.live_score.runrate,
          requiredRunrate: _data.live_score.required_runrate,
        },
        teams: {
          teamA: this.#teams(_data.teams.teamA),
          teamB: this.#teams(_data.teams.teamB),
        },
        batsmen: this.#batsmen(_data.batsmen),
        bowlers: this.#bowlers(_data.bowlers),
        liveInnings: this.#liveInnings(_data.live_inning),
        commentaries: this.#commentaries(_data.commentaries),
      };
    } catch (err) {
      return null;
    }

    // });
  }

  formatFootballCommentries(commentry: any[]): FootballCommentaries[] {
    try {
      return commentry.map((e) => {
        return {
          id: +e?.id || 0,
          time: +e?.time || 0,
          sentence: e?.sentence || 0,
          injuryTime: +e?.injurytime || 0,
        };
      });
    } catch (err) {
      return [];
    }
  }

  formatFootballEvents(events: any[]): FootballEvents[] {
    try {
      return events.map((e) => {
        return {
          playerAPIId: +e?.pid,
          playerName: e?.pname || '',
          type: e?.type || '',
          time: +e?.time || 0,
          card: e?.card || '',
          name: e?.name || '',
          team: e?.team || '',
          injuryTime: +e?.injurytime || 0,
          playerAPIIdIn: +e?.player_in || 0,
          playerAPIIdOut: +e?.player_out || 0,
          inPlayerName: e?.player_in_name || '',
          outPlayerName: e?.player_out_name || '',
          status: +e?.status || 0,
          statusStr: e?.status_str || '',
        };
      });
    } catch (err) {
      return [];
    }
  }

  footballCommentry(commentaries: any): FootballCommentary {
    try {
      return {
        fixtureAPIId: +commentaries?.match_id,
        commentary: this.formatFootballCommentries(commentaries?.commentary),
        events: this.formatFootballEvents(commentaries?.event),
      };
    } catch (err) {
      console.log(err);
      return {
        fixtureAPIId: +commentaries?.match_id,
        commentary: [],
        events: [],
      };
    }
  }
}
