import { Module } from '@nestjs/common';
import { ScorecardCronService } from './scorecard-cron.service';
import { ScorecardCronController } from './scorecard-cron.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { ScheduleModule } from '@nestjs/schedule';
import { Scorecard, ScorecardSchema } from './entities/scorecard.entity';
import {
  FixturesSchema,
  cricketFixtures,
} from 'src/game-cron/entities/fixtures.entity';
import { ScorecardHelpers } from './helpers/scorecard.helpers';
import {
  playerPerformance,
  playerPerformanceSchema,
} from './entities/playerPerformance.entity';
import { commentries, CommentrySchema } from './entities/commentry.entity';
import { commentryHelper } from './helpers/commentry.helpers';
import { PointsCronModule } from 'src/points-cron/points-cron.module';
import { Point, PointsSchema } from './entities/points.entity';
import {
  LineUpSchema,
  Lineup,
} from 'src/lineup-cron/entities/lineup-cron.entity';
import {
  FootballFixtures,
  FootballFixturesSchema,
} from 'src/game-cron/entities/footballfixtures.entity';
import {
  FootballScorecard,
  FootballScorecardSchema,
} from './entities/football-scorecard.entity';
import {
  FootballPointsSchema,
  footballPoints,
} from './entities/football-points.entity';
import {
  FootballPlayerPerformance,
  FootballPlayerPerformanceSchema,
} from './entities/football-playerperformance.entity';
import {
  FootballLineup,
  FootballLineupSchema,
} from 'src/lineup-cron/entities/football-lineup.entity';
import {
  FootballCommentary,
  FootballCommentarySchema,
} from './entities/football-commentry.entity';
import {
  KabaddiFixtures,
  kabaddiFixturesSchema,
} from 'src/game-cron/entities/kabaddifixtures.entity';
import {
  KabaddiScorecard,
  KabaddiScorecardSchema,
} from './entities/kabaddi-scoreacard.entity';
import {
  KabaddiPoints,
  KabaddiPointsSchema,
} from './entities/kabaddi-points.entity';
import {
  KabaddiLineup,
  KabaddiLineupSchema,
} from 'src/lineup-cron/entities/kabaddi-lineup.entity';
import {
  KabaddiPlayerPerformance,
  KabaddiPlayerPerformanceSchema,
} from './entities/kabaddi-playerperformance.entity';
import { lineupHelpers } from 'src/lineup-cron/helpers/lineup.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Scorecard.name, schema: ScorecardSchema },
      { name: cricketFixtures.name, schema: FixturesSchema },
      { name: playerPerformance.name, schema: playerPerformanceSchema },
      { name: commentries.name, schema: CommentrySchema },
      { name: Point.name, schema: PointsSchema },
      { name: Lineup.name, schema: LineUpSchema },
      { name: FootballFixtures.name, schema: FootballFixturesSchema },
      { name: FootballScorecard.name, schema: FootballScorecardSchema },
      { name: footballPoints.name, schema: FootballPointsSchema },
      {
        name: FootballPlayerPerformance.name,
        schema: FootballPlayerPerformanceSchema,
      },
      { name: FootballLineup.name, schema: FootballLineupSchema },
      { name: FootballCommentary.name, schema: FootballCommentarySchema },
      { name: KabaddiFixtures.name, schema: kabaddiFixturesSchema },
      { name: KabaddiScorecard.name, schema: KabaddiScorecardSchema },
      { name: KabaddiPoints.name, schema: KabaddiPointsSchema },
      { name: KabaddiLineup.name, schema: KabaddiLineupSchema },
      {
        name: KabaddiPlayerPerformance.name,
        schema: KabaddiPlayerPerformanceSchema,
      },
    ]),
    ScheduleModule.forRoot(),
    PointsCronModule,
  ],
  controllers: [ScorecardCronController],
  providers: [
    ScorecardCronService,
    ScorecardHelpers,
    commentryHelper,
    lineupHelpers,
  ],
})
export class ScorecardCronModule {}
