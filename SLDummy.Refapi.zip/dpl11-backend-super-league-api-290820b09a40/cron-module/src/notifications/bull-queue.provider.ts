import { Provider } from '@nestjs/common';
import { BullModule } from '@nestjs/bull';
//import { Queue } from 'bull';
const Queue = require('bull');

export const BullQueue_pushNotification: Provider = {
  provide: 'BullQueue_pushNotification',
  useFactory: () => new Queue('pushNotification'),
};