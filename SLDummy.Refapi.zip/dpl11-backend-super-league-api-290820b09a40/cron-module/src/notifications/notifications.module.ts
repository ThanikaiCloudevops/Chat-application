import { Module } from '@nestjs/common';
import { FcmService } from './notifications.service';
import { NotificationController } from './notifications.controller';
import {
  Notification,
  NotificationSchema,
} from './entities/notifications.entity';
import { MongooseModule } from '@nestjs/mongoose';
import * as admin from 'firebase-admin';
import { BullModule } from '@nestjs/bull';
import { Queue } from 'bull';
import { PushNotificationQueueService } from './notifications.queue';
import { BullQueue_pushNotification } from './bull-queue.provider';

//import * as serviceAccount from 'config/credentials.json';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Notification.name, schema: NotificationSchema },
    ]),
    BullModule.registerQueue({
      name: 'pushNotification',
    }),
    BullModule.forRoot({
      redis: {
        host: 'localhost',
        port: 6379,
      },
    }),
  ],
  controllers: [NotificationController],
  providers: [
    FcmService,
    PushNotificationQueueService,
    BullQueue_pushNotification,
  ],
  exports: [FcmService],
})
export class NotificationModule {
  static configureAdmin(): void {
    // const path = require('path');
    // const serviceAccount = path.join(__dirname, '../config/credentials.json');
    //const serviceAccount = require('config/credentials.json');
    const serviceAccount = {};

    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount as admin.ServiceAccount),
    });
  }
}
