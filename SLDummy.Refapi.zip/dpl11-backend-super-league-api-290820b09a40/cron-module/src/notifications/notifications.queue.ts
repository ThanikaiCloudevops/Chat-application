import { Injectable } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';

import * as admin from 'firebase-admin';

@Injectable()
export class PushNotificationQueueService {
  constructor(@InjectQueue('pushNotification') private readonly pushNotificationQueue: Queue) {}

  async addNotificationToQueue(resultArray: any, payload: any) {
    console.log('retrying')
    await this.pushNotificationQueue.add( { resultArray, payload }, {
      attempts: 3, // Number of retry attempts
      backoff: 1000, // Delay between retry attempts in milliseconds
    });
  }
}