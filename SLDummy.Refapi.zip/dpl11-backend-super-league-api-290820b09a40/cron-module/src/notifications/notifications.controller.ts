import { Resolver, Query, Mutation, Args, Context } from '@nestjs/graphql';
import { FcmService } from './notifications.service';
import { Body, Controller, Get, Post } from '@nestjs/common';
import { SendNotificationDto } from './dto/notifications.dto';

@Controller('notifications')
export class NotificationController {
  constructor(private readonly fcmService: FcmService) {}

  @Post('/sendnotification')
  async sendNotification() {
   
    var deviceToken = ['eRGs7BMpQJq7_PhWs9J1Ow:APA91bGjgecjWiVkRZH5xxVS1A5Icp1Ky8sASzQ6OaLCPZc6aOqwlIRFvBCY7T8OJTA8lL3Yk8HYeBBrZcV605D7gSfj8SE6GAuQBqiPYdm-jTcrf-LRRo6vI-feQpYWF8Jqo9uWAWSY'];
    const payload = {
      notification: {
        title: 'Notification',
        body: 'Hi',
      },
    };
   
    await this.fcmService.sendNotification(deviceToken, payload); // Wait for the promise to resolve
    //return 'Notification sent successfully'; // Return a string directly
  }
  
}