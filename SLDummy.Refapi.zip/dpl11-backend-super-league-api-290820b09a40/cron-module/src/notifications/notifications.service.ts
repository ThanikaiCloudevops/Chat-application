import { Injectable } from '@nestjs/common';
import * as admin from 'firebase-admin';
import { InjectQueue } from '@nestjs/bull';
import { PushNotificationQueueService } from './notifications.queue';
import { Queue } from 'bull';

@Injectable()
export class FcmService {
  constructor(
    private readonly pushNotificationQueueService: PushNotificationQueueService,
  ) {}

  async sendNotification(
    deviceToken: string[],
    payload: admin.messaging.MessagingPayload,
  ): Promise<void> {
    try {
      // const response = await admin.messaging().sendToDevice(deviceToken, payload);
      await this.sendNotificationProcess(deviceToken, payload);
      // The messages were sent successfully
      //   const failedMessage = response.results.find((result) => result.error);
      //    if (failedMessage) {
      //    const errorMessage = failedMessage.error && failedMessage.error[0] && failedMessage.error[0].message;
      // if (errorMessage) {
      //  } else {
      //  }
      //    } else {
      //  }

      /*
      if (response.failureCount > 0) {
        const resultArray: string[] = [];
          
        // Iterate through the results to check for specific errors
        for (let index = 0; index < response.results.length; index++) {
          const result = response.results[index];
  
          if (result.error) {
            // Handle individual message errors
            // console.error(`Error for message ${index}:`, result.error);
  
            // Access the device token associated with the failed message
            const failedDeviceToken = deviceToken[index];
            resultArray.push(failedDeviceToken);
            console.error(`Failed device token for message ${index}:`, failedDeviceToken);
            //
          }
        }
        resultArray.push('eRGs7BMpQJq7_PhWs9J1Ow:APA91bGjgecjWiVkRZH5xxVS1A5Icp1Ky8sASzQ6OaLCPZc6aOqwlIRFvBCY7T8OJTA8lL3Yk8HYeBBrZcV605D7gSfj8SE6GAuQBqiPYdm-jTcrf-LRRo6vI-feQpYWF8Jqo9uWAWSY')
        await this.pushNotificationQueueService.addNotificationToQueue(resultArray, payload );
        throw new Error('Failed to send notification. Retrying...');
        // await this.sendNotificationProcess(resultArray, payload);
      }
    */
    } catch (error) {
      // Handle errors during the sending process
      console.error('Error sending messages:', error);
    }
  }

  async sendNotificationProcess(
    deviceToken: string[],
    payload: admin.messaging.MessagingPayload,
  ) {
    const Queue = require('bull');
    const pushNotificationQueue = new Queue('pushNotificationQueue');
    const maxRetries = 2;
    const retryDelay = 5000; // 5 seconds

    try {
      // Add the notification task to the queue with retry options
      await pushNotificationQueue.add(
        { deviceToken, payload },
        {
          attempts: maxRetries,
          backoff: {
            delay: retryDelay,
            type: 'fixed',
          },
        },
      );
    } catch (error) {
      console.error('Error adding job to pushNotificationQueue:', error);
      // Handle the error, if needed
    }
    return 8;
    await pushNotificationQueue.process(async (job) => {
      try {
        ``;
        await this.sendNotification(job.data.userId, job.data.notification);
      } catch (error) {
        // Retry failed notifications
        if (job.attemptsMade < job.opts.attempts) {
          throw new Error(
            `Failed to send notification to user ${job.data.userId}. Retrying...`,
          );
        } else {
          console.log(
            `Exceeded maximum retries for notification to user ${job.data.userId}`,
          );
          throw new Error(
            `Exceeded maximum retries for notification to user ${job.data.userId}`,
          );
        }
      }
    });
    // Usage example
    const userId = 'user123';
    const notification = {
      title: 'New Notification',
      message: 'You have a new notification!',
    };
    // Call the function to send the push notification
  }
}
