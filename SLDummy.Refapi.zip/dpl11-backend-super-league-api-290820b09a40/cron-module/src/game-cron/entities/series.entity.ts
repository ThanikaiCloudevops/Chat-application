import { ObjectType, Field } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type seriesDocument = Series & Document;

@ObjectType()
@Schema()
export class Series {
  @Field()
  @Prop()
  isLocal: boolean;

  @Field()
  @Prop()
  seriesName: string;

  @Field()
  @Prop({ index: true })
  apiId: number;

  @Field()
  @Prop()
  seriesDisplayName: string;

  @Field()
  @Prop()
  seriesStartDate: Date;

  @Field()
  @Prop()
  seriesStatus: string;

  @Field(() => [Number])
  @Prop()
  teams: number[];

  @Field()
  @Prop()
  seriesFormat: string;

  @Field()
  @Prop({ default: false })
  enabledStatus: boolean;

  @Field()
  @Prop({ default: true, index: true })
  isactive: boolean;
}

export const SeriesSchema = SchemaFactory.createForClass(Series);
