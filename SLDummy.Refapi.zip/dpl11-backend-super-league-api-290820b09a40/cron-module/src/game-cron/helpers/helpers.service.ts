import { Injectable } from '@nestjs/common';

@Injectable()
export class HelpersService {
  formatSeries(series: any) {
    return {
      seriesName: series.title,
      apiId: series.cid,
      seriesDisplayName: series.abbr,
      seriesStartDate: series.date_start,
      seriesStatus: series.status,
      seriesFormat: series.match_format,
    };
  }

  footballSeries(sereis: any) {
    return {
      apiId: +sereis?.cid,
      seriesName: sereis?.cname,
      seriesDisplayName: sereis?.ioc,
      seriesStatus: sereis?.status_str,
      seriesStartDate: new Date(sereis?.startdate),
      seriesFormat: '',
    };
  }

  kabaddiSeries(series: any) {
    return {
      apiId: +series?.cid,
      seriesName: series?.cname,
      seriesDisplayName: '',
      seriesCode: series?.status,
      seriesStatus: series?.status_str,
      seriesStartDate: new Date(series?.startdate),
      seriesFormat: '',
    };
  }

  formatFixtures(item: any) {
    const fixture = item.fixtureMatch;
    return {
      fixtureName: fixture.title,
      fixtureAPIId: fixture.match_id,
      fixtureDisplayName: fixture.short_title,
      fixtureStartDate: new Date(fixture./* date_start_ist */ date_start),
      fixtureStatusType: fixture.status,
      fixtureStatus: fixture.status_str,
      fixtureVenue: fixture.venue.name,
      fixtureType: fixture.format_str,
      fixtureFormat: +fixture.format,
      seriesName: item.title,
      seriesShortName: item.short_name,
      seriesAPIId: item.cid,
      fixtureTeams: {
        teamA: this.#team(fixture.teama),
        teamB: this.#team(fixture.teamb),
      },
    };
  }

  footballFixtures(sereis: any) {
    return {
      fixtureAPIId: sereis?.fixtureMatch?.match_id,
      fixtureName: `${sereis?.fixtureMatch?.teama?.fullname} vs ${sereis?.fixtureMatch?.teamb?.fullname}`,
      fixtureDisplayName: `${sereis?.fixtureMatch?.teama?.abbr} vs ${sereis?.fixtureMatch?.teamb?.abbr}`,
      fixtureStartDate: new Date(sereis?.fixtureMatch?.datestart),
      fixtureStatusType: +sereis?.fixtureMatch?.status,
      fixtureStatus: sereis?.fixtureMatch?.status_str,
      fixtureVenue: sereis?.fixtureMatch?.venue?.name,
      seriesName: sereis?.cname,
      seriesShortName: '',
      seriesAPIId: +sereis?.cid,
      fixtureTeams: {
        teamA: this.#footballTeam(sereis?.fixtureMatch?.teama),
        teamB: this.#footballTeam(sereis?.fixtureMatch?.teamb),
      },
    };
  }

  kabaddiFixtures(item: any) {
    return {
      fixtureAPIId: +item?.fixtureMatch?.match_id || 0,
      fixtureName: item?.fixtureMatch?.title || '',
      fixtureDisplayName: item?.fixtureMatch?.short_title || '',
      fixtureStartDate: new Date(item?.fixtureMatch?.datestart),
      fixtureStatusType: +item?.fixtureMatch?.status,
      fixtureStatus: item?.fixtureMatch?.status_str || '',
      fixtureVenue: item?.fixtureMatch?.venue?.name || '',
      seriesName: item?.cname || '',
      seriesShortName: '',
      seriesAPIId: +item?.cid,
      fixtureTeams: {
        teamA: this.#kabaddiTeam(item?.fixtureMatch?.teama),
        teamB: this.#kabaddiTeam(item?.fixtureMatch?.teamb),
      },
    };
  }

  #team(team: { name: any; short_name: any; team_id: any; logo_url: any }) {
    return {
      name: team.name,
      shortName: team.short_name,
      teamAPIId: team.team_id,
      logo: team.logo_url,
    };
  }

  #footballTeam(team: any) {
    return {
      teamAPIId: team?.tid,
      name: team?.fullname,
      shortName: team?.tname,
      logo: team?.logo_url,
    };
  }

  #kabaddiTeam(team: any) {
    return {
      teamAPIId: +team?.tid || 0,
      name: team?.tname || '',
      shortName: team?.short_name || '',
      logo: team?.logo_url || '',
    };
  }

  initilizeTeam(item: any) {
    return {
      teamName: item.team.title,
      teamDisplayName: item.team.abbr,
      teamAPIId: item.team.tid,
      teamLogo: item.team.logo_url,
      teamformat: item.format,
      seriesAPIId: +item.cid,
      teamformatstr: item.format_str,
      teamPlayers: [],
    };
  }

  formatTeamPlayers(item: any) {
    return {
      playerName: item.title,
      playerAPIId: item.pid,
      player_type: item.playing_role,
      playerDisplayName: item.short_name,
      player_value: {
        Test: item.fantasy_player_rating,
        ODI: item.fantasy_player_rating,
        T20: item.fantasy_player_rating,
      },
    };
  }

  initilizeFootballTeam(team: any) {
    return {
      teamAPIId: +team?.tid,
      teamName: team?.tname,
      teamFullName: team?.fullname,
      teamDisplayName: team?.abbr,
      isclub: eval(team?.isclub),
      founded: +team?.founded,
      teamLogo: team?.teamlogo,
      squads: [],
      isactive: true,
    };
  }

  formatFootballPlayers(player: any) {
    return {
      playerAPIId: +player?.pid,
      playerName: player?.fullname,
      birthdate: new Date(player?.birthdate),
      nationality: player?.nationality?.name,
      positionType: player?.positiontype,
      positionName: player?.positionname,
      height: +player?.height,
      weight: +player?.weight,
      foot: player?.foot,
      fantasyCredit: +player?.fantasy_player_rating,
    };
  }

  initilizeKabaddiTeam(team: any) {
    return {
      teamAPIId: +team?.tid,
      teamName: team?.tname,
      teamFullName: team?.fullname,
      teamDisplayName: team?.abbr,
      founded: +team?.founded,
      teamLogo: team?.teamlogo,
      squads: [],
      isactive: true,
    };
  }

  formatKabaddiPlayers(player: any) {
    return {
      playerAPIId: +player?.pid,
      playerName: player?.fullname,
      birthdate: new Date(player?.birthdate),
      nationality: player?.nationality?.name,
      positionType: player?.positiontype,
      positionName: player?.positionname,
      height: +player?.height,
      weight: +player?.weight,
      fantasyCredit: +player?.fantasy_player_rating,
    };
  }

  async pagination(url: string) {
    try {
      let datas = [];
      let totalPage: number,
        currentPage: number = 0;
      while (totalPage != currentPage) {
        const req = await fetch(
          url.includes('?')
            ? `${url}&page=${currentPage + 1}`
            : `${url}?page=${currentPage + 1}`,
        );
        const response: any = await req.json();

        datas = [...datas, ...response?.data];
        totalPage = response?.totalPage;
        currentPage++;
      }
      return datas;
    } catch (err) {
      console.log(err);
      return [];
    }
  }
}
