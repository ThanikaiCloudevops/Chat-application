import { Body, Controller, Get, Post } from '@nestjs/common';
import { Cron, GameService } from './game-cron.service';

@Controller('cron1')
export class FixtureSquadCron {
  constructor(
    private readonly cronService: Cron,
    private readonly gameService: GameService,
  ) {}

  @Get('/series')
  async seriesUpdation() {
    await this.gameService.seriesComplete();
    return await this.gameService.seriesUpdate();
  }

  @Get('/football/series')
  async footballSeriesUpdation() {
    return await this.gameService.footballSereisUpdate();
  }

  @Get('/kabaddi/series')
  async kabaddiSeriesUpdation() {
    return await this.gameService.kabaddiSeriesUpdate();
  }

  @Get('/fixtures')
  async fixturesUpdation() {
    return await this.gameService.fixturesUpdate();
  }

  @Get('/football/fixtures')
  async footballFixturesUpdation() {
    return await this.gameService.footBallFixturesUpdate();
  }

  @Get('/kabaddi/fixtures')
  async kabaddiFixturesUpdation() {
    return await this.gameService.kabaddiFixturesUpdate();
  }

  @Get('/football/dailyupdate')
  async footballDailyUpdation() {
    return await this.gameService.updateFootballCurrentDay();
  }

  @Get('/fixtureDailyUpdate')
  async fixtureWeeklyUpdate() {
    return await this.gameService.fixtureDailyUpdate();
  }

  @Get('/squadteams')
  async teamPlayersUpdation() {
    return await this.gameService.teamPlayersUpdate();
  }

  @Get('/football/squadteams')
  async footballTeamPlayersUpdation() {
    return await this.gameService.footBallTeamPlayersUpdate();
  }

  @Get('/kabaddi/squadteams')
  async kabaddiTeamPlayersUpdation() {
    return await this.gameService.kabaddiTeamPlayersUpdate();
  }

  @Get('/squadfixtures')
  async squadfixtures() {
    return await this.gameService.squadFixtureUpdate();
  }

  @Post('/series')
  async seriesCronStart(@Body('cron') cron: boolean) {
    return this.cronService.seriesCron(cron);
  }

  @Post('/fixtures')
  async fixturesCronStart(@Body('cron') cron: boolean) {
    return this.cronService.fixturesCron(cron);
  }

  @Post('/squadteams')
  async teamPlayersCronStart(@Body() cron: boolean) {
    return this.cronService.teamPlayersCron(cron);
  }
}
