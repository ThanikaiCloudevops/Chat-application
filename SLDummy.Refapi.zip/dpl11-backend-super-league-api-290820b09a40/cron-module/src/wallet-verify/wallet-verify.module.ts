import { Module } from '@nestjs/common';
import { WalletVerifyService } from './wallet-verify.service';
import { WalletVerifyController } from './wallet-verify.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { ScheduleModule } from '@nestjs/schedule';
import {
  UserWallet,
  UserWalletSchema,
} from 'src/points-cron/entities/user-wallet.entity';
import {
  UserTransaction,
  UserTransactionSchema,
} from 'src/points-cron/entities/user-transaction.entity';
import { User, UserSchema } from 'src/game-cron/entities/user.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: UserTransaction.name, schema: UserTransactionSchema },
      { name: UserWallet.name, schema: UserWalletSchema },
      { name: User.name, schema: UserSchema },
    ]),
    ScheduleModule.forRoot(),
  ],
  controllers: [WalletVerifyController],
  providers: [WalletVerifyService],
})
export class WalletVerifyModule {}
