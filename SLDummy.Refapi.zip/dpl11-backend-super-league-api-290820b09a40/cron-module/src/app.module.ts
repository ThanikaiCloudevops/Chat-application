import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { GameCronModule } from './game-cron/game-cron.module';
import { MongooseModule } from '@nestjs/mongoose';
import { DB } from 'config/envirnment';
import { LineupCronModule } from './lineup-cron/lineup-cron.module';
import { ScorecardCronModule } from './scorecard-cron/scorecard-cron.module';
import { PointsCronModule } from './points-cron/points-cron.module';
//import { NotificationModule } from './notifications/notifications.module';
import { FcmService } from './notifications/notifications.service';
import { BullModule } from '@nestjs/bull';
import { Queue } from 'bull';
import { PushNotificationQueueService } from './notifications/notifications.queue';
import { PushNotificationProcessor } from './notifications/notifications.processor';
import { BullQueue_pushNotification } from './notifications/bull-queue.provider';
import { NotificationModule } from './notification/notification.module';
import { NotificationService } from './notification/notification.service';
import { FirebaseService } from './notification/firebase.service';
import { WalletVerifyModule } from './wallet-verify/wallet-verify.module';

//NotificationModule.configureAdmin();
@Module({
  imports: [
    MongooseModule.forRoot(DB.URL, {
      maxConnecting: 5,
      maxPoolSize: 5,
      connectTimeoutMS: 3000,
      socketTimeoutMS: 8000,
      maxIdleTimeMS: 10000,
    }),
    GameCronModule,
    LineupCronModule,
    ScorecardCronModule,
    PointsCronModule,
    NotificationModule,
    WalletVerifyModule,
    //   BullModule.forRoot({
    //     redis:{
    //       host:'localhost',
    //       port:6379,
    //     },
    //   }),
    //   BullModule.registerQueue({
    //     name: 'pushNotification',
    //   }),
  ],
  controllers: [AppController],
  providers: [
    AppService,
    NotificationService,
    FirebaseService /*FcmService,PushNotificationQueueService, PushNotificationProcessor,BullQueue_pushNotification*/,
  ],
})
export class AppModule {}
