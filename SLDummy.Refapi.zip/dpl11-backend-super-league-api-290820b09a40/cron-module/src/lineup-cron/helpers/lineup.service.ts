import { Injectable } from '@nestjs/common';
import { Lineup, Team, playing11 } from '../entities/lineup-cron.entity';
import {
  FootballLineup,
  FootballLineupPlayers,
  FootballLineupTeams,
  footballIn11,
} from '../entities/football-lineup.entity';
import {
  KabaddiLineup,
  KabaddiTeamLineup,
} from '../entities/kabaddi-lineup.entity';

@Injectable()
export class lineupHelpers {
  formatSquads(players: any[]): playing11[] {
    const playing11: playing11[] = [];
    for (const player of players) {
      if (player?.playing11)
        playing11.push({
          playerId: player.player_id,
          name: player.name,
          role: player.role,
          in11: player.playing11,
          isSubstitute: player.substitute,
        });
    }
    return playing11;
  }

  formatTeam(team: any): Team {
    return {
      teamId: team?.tid,
      teamName: team?.title,
      squads: this.formatSquads(team?.squads),
    };
  }

  formatLineUp(lineUpResponse: any, fixtureAPIId: number): Lineup {
    return {
      fixtureAPIId,
      teamA: this.formatTeam(lineUpResponse?.teama),
      teamB: this.formatTeam(lineUpResponse?.teamb),
    };
  }

  footballLineupPlayers(player: any[]): FootballLineupPlayers[] {
    return player.map((e) => {
      return {
        playerAPIId: +e?.pid,
        position: e?.position,
        positionName: e?.name,
        playerName: e?.pname,
        order: +(e?.order || 0),
        gamePosition: e?.matchposition,
        shirtNumber: +e?.shirtnumber,
      };
    });
  }

  footballplaying11(formationPlayers: any): footballIn11 {
    return {
      formation: formationPlayers?.formation,
      players: this.footballLineupPlayers(formationPlayers?.player),
    };
  }

  footballLineupTeam(players: any): FootballLineupTeams {
    return {
      in11: this.footballplaying11(players?.lineup),
      subs: this.footballLineupPlayers(players?.substitutes),
    };
  }

  formatFootballLineup(lineup: any): FootballLineup {
    return {
      fixtureAPIId: +lineup?.matchId,
      homeTeam: this.footballLineupTeam(lineup?.home),
      awayTeam: this.footballLineupTeam(lineup?.away),
    };
  }

  kabaddiLineupTeam(players: any): KabaddiTeamLineup[] {
    try {
      return players
        .map((e: any) => {
          return {
            playerAPIId: +e?.pid || 0,
            playerName: e?.pname || '',
            role: e?.role || '',
            fantasyCredit: +e?.fantasy_credit || 0,
            in11: e?.starting7,
            isSubstitute: e?.substitute,
          };
        })
        .filter((e: any) => e.in11);
    } catch (err) {
      return [];
    }
  }

  formatKabaddiLineup(lineup: any): KabaddiLineup {
    try {
      const kabadiLineup = {
        fixtureAPIId: +lineup?.matchId,
        homeTeam: this.kabaddiLineupTeam(lineup?.home?.lineup),
        awayTeam: this.kabaddiLineupTeam(lineup?.away?.lineup),
      };
      if (kabadiLineup.awayTeam.length < 7 || kabadiLineup.homeTeam.length < 7)
        throw new Error();

      return kabadiLineup;
    } catch (err) {
      return null;
    }
  }
}
