export class CreateLineupCronDto {}
