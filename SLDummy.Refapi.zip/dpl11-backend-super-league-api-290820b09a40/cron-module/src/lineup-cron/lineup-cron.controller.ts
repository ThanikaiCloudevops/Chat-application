import { Controller, Get } from '@nestjs/common';
import { LineupCronService } from './lineup-cron.service';

@Controller('lineup-cron')
export class LineupCronController {
  constructor(private readonly lineupCronService: LineupCronService) {}

  @Get('/updatelineup')
  async updateLineup() {
    return await this.lineupCronService.updateLineup();
  }

  @Get('/football/updatelineup')
  async updateFootballLineup() {
    return await this.lineupCronService.footBallLineup();
  }

  @Get('/kabaddi/updatelineup')
  async updateKabaddiLineup() {
    return await this.lineupCronService.updateKabaddiLineup();
  }
}
