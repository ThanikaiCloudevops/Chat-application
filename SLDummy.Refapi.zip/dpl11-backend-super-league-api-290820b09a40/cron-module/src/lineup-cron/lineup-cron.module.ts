import { Module } from '@nestjs/common';
import { LineupCronService } from './lineup-cron.service';
import { LineupCronController } from './lineup-cron.controller';
import { GameCronModule } from 'src/game-cron/game-cron.module';
import { MongooseModule } from '@nestjs/mongoose';
import { LineUpSchema, Lineup } from './entities/lineup-cron.entity';
import { UserSchema, User } from './entities/user.entity';
import { ScheduleModule } from '@nestjs/schedule';
import { lineupHelpers } from './helpers/lineup.service';
import { PointsCronService } from 'src/points-cron/points-cron.service';
import { PointsCronModule } from 'src/points-cron/points-cron.module';
import {
  FootballLineup,
  FootballLineupSchema,
} from './entities/football-lineup.entity';
import {
  KabaddiLineup,
  KabaddiLineupSchema,
} from './entities/kabaddi-lineup.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Lineup.name, schema: LineUpSchema },
      { name: User.name, schema: UserSchema },
      { name: FootballLineup.name, schema: FootballLineupSchema },
      { name: KabaddiLineup.name, schema: KabaddiLineupSchema },
    ]),
    ScheduleModule.forRoot(),
    GameCronModule,
    PointsCronModule,
  ],
  controllers: [LineupCronController],
  providers: [LineupCronService, lineupHelpers],
})
export class LineupCronModule {}
