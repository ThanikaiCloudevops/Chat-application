import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { gamedefaultFields } from 'src/commonResponse/response.entity';

export type footballSeriesDocument = FootballSeries & Document;

@ObjectType()
@Schema()
export class FootballSeries {
  @Field()
  @Prop({ index: true })
  apiId: number;

  @Field()
  @Prop()
  seriesName: string;

  @Field({ defaultValue: '' })
  @Prop()
  seriesDisplayName: string;

  @Field({ defaultValue: '' })
  @Prop()
  seriesStartDate: string;
  @Field({ defaultValue: '' })
  @Prop()
  seriesStatus: string;

  @Field({ defaultValue: '' })
  @Prop()
  seriesFormat: string;

  @Field({ defaultValue: false })
  @Prop()
  enabledStatus: boolean;

  @Field()
  @Prop({ default: true, index: true })
  isactive: boolean;
  @Field(() => [Number])
  @Prop({ type: [Number] })
  teams: number[];
}
@ObjectType()
export class FootballSeriesCollection extends PartialType(gamedefaultFields) {
  @Field(() => [FootballSeries], { nullable: true })
  data: FootballSeries;
}

export const FootballSeriesSchema =
  SchemaFactory.createForClass(FootballSeries);
