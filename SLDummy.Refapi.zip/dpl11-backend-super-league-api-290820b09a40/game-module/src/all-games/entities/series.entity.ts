import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { gamedefaultFields } from 'src/commonResponse/response.entity';

export type seriesDocument = Series & Document;

@ObjectType()
@Schema()
export class Series {
  @Field()
  @Prop()
  seriesName: string;

  @Field()
  @Prop({ index: true })
  apiId: number;

  @Field()
  @Prop()
  seriesDisplayName: string;

  @Field()
  @Prop()
  seriesStartDate: Date;

  @Field()
  @Prop()
  seriesStatus: string;

  @Field(() => [Number])
  @Prop()
  teams: number[];

  @Field()
  @Prop()
  seriesFormat: string;

  @Field()
  @Prop({ default: false })
  enabledStatus: boolean;

  @Field()
  @Prop({ default: true, index: true })
  isactive: boolean;
}
@ObjectType()
export class seriesCollection extends PartialType(gamedefaultFields) {
  @Field(() => [Series], { nullable: true })
  data: Series;
}

export const SeriesSchema = SchemaFactory.createForClass(Series);
