import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type footballLineupDocument = FootballLineup & Document;

export class FootballLineupPlayers {
  playerAPIId: number;
  playerName: string;
  order: number;
  positionName: string;
  position: string;
  shirtNumber: number;
  gamePosition: string;
}

export class footballIn11 {
  formation: string;
  players: FootballLineupPlayers[];
}

export class FootballLineupTeams {
  in11: footballIn11;
  subs: FootballLineupPlayers[];
  players: any;
}

@Schema()
export class FootballLineup {
  @Prop()
  fixtureAPIId: number;

  @Prop()
  homeTeam: FootballLineupTeams;

  @Prop()
  awayTeam: FootballLineupTeams;
}

export const FootballLineupSchema =
  SchemaFactory.createForClass(FootballLineup);
