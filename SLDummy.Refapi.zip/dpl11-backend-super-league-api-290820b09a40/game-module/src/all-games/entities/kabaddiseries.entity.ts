import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { gamedefaultFields } from 'src/commonResponse/response.entity';

export type kabaddiSeriesDocument = KabaddiSeries & Document;

@ObjectType()
@Schema()
export class KabaddiSeries {
  @Field()
  @Prop({ index: true })
  apiId: number;

  @Field()
  @Prop()
  seriesName: string;

  @Field({ defaultValue: '' })
  @Prop()
  seriesDisplayName: string;

  @Field({ defaultValue: '' })
  @Prop()
  seriesStartDate: string;
  
  @Field({ defaultValue: '' })
  @Prop()
  seriesStatus: string;

  @Field({ defaultValue: false })
  @Prop()
  enabledStatus: boolean;

  @Field()
  @Prop({ default: true, index: true })
  isactive: boolean;
  @Field(() => [Number])
  @Prop({ type: [Number] })
  teams: number[];
}
@ObjectType()
export class KabaddiSeriesCollection extends PartialType(gamedefaultFields) {
  @Field(() => [KabaddiSeries], { nullable: true })
  data: KabaddiSeries;
}

export const kabaddiSeriesSchema =
  SchemaFactory.createForClass(KabaddiSeries);
