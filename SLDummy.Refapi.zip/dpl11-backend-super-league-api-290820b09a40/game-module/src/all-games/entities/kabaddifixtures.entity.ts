import { ObjectType, Field, PartialType, Int } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { gamedefaultFields } from 'src/commonResponse/response.entity';

export type kabaddiFixtureDocument = KabaddiFixtures & Document;

@ObjectType()
export class kabaddiTeams {
  @Field()
  teamAPIId: number;

  @Field()
  name: string;

  @Field({ defaultValue: '' })
  shortName: string;

  @Field()
  logo: string;
}

@ObjectType()
export class kabaddiFixtureTeams {
  @Field(() => kabaddiTeams)
  teamA: kabaddiTeams;

  @Field(() => kabaddiTeams)
  teamB: kabaddiTeams;
}

@ObjectType()
@Schema()
export class KabaddiFixtures {
  @Field()
  _id: string;

  @Field({ defaultValue: '' })
  @Prop()
  fixtureName: string;

  @Field()
  @Prop({ index: true })
  fixtureAPIId: number;

  @Field({ defaultValue: '' })
  @Prop()
  fixtureDisplayName: string;

  @Field()
  @Prop()
  fixtureStartDate: Date;

  @Field()
  @Prop()
  fixtureStatus: string;

  @Field()
  @Prop()
  fixtureStatusType: number;

  @Field()
  @Prop()
  fixtureVenue: string;

  @Field()
  @Prop()
  seriesName: string;

  @Field()
  @Prop()
  seriesShortName: string;

  @Field()
  @Prop()
  seriesAPIId: number;

  @Field(() => kabaddiFixtureTeams)
  @Prop()
  fixtureTeams: kabaddiFixtureTeams;

  @Field()
  @Prop({ default: false })
  lineupsOut: boolean;

  @Field()
  @Prop({ default: false })
  enabledStatus: boolean;

  @Field({ defaultValue: 'Mega Contest' })
  @Prop()
  contestStr: string;

  @Field()
  @Prop({ default: true, index: true })
  isactive: boolean;

  @Field(() => [String], { nullable: true })
  @Prop({ default: true, index: true })
  joinedUsers?: string[];

  @Field({ nullable: true })
  @Prop()
  maxPrize: number;

  @Field({ defaultValue: 0 })
  myContestCount: number;

  @Field({ defaultValue: 0 })
  myTeamsCount: number;
}

@ObjectType()
class kabaddipaginatedPayload {
  @Field(() => Int)
  totalPage: number;
  @Field(() => Int, { defaultValue: 1 })
  currentPage: number;
  @Field({ defaultValue: 20 })
  maxTeamCount: number;
  @Field(() => [KabaddiFixtures], { nullable: true })
  list: KabaddiFixtures[];
}

@ObjectType()
export class KabaddiFixturePagination extends PartialType(gamedefaultFields) {
  @Field({ nullable: true })
  data: kabaddipaginatedPayload;
}

@ObjectType()
export class kabaddiMyFixtureAll extends PartialType(gamedefaultFields) {
  @Field(() => [KabaddiFixtures], { nullable: 'itemsAndList' })
  data: KabaddiFixtures[];
}

@ObjectType()
export class kabaddiSingleFixture extends PartialType(gamedefaultFields) {
  @Field({ nullable: true })
  data: KabaddiFixtures;
}

export const KabaddiFixturesSchema =
  SchemaFactory.createForClass(KabaddiFixtures);
