import { Field, ObjectType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export type selectedByDocument = selectedBy & Document;

@ObjectType()
class selectedByPlayers {
  @Field()
  playerAPIId: number;
  @Field({ nullable: true })
  teamAPIId: number;
  @Field()
  selectedbyCount: number;
  @Field()
  selectedbyCountVC: number;
  @Field()
  selectedbyCountCAP: number;
}

@ObjectType()
@Schema()
export class selectedBy {
  @Field()
  @Prop()
  fixtureAPIId: number;
  @Field()
  @Prop()
  gameType: string;
  @Field(() => [selectedByPlayers], { nullable: 'items' })
  @Prop()
  players: selectedByPlayers[];

  @Field({ defaultValue: 0 })
  @Prop({ default: 0 })
  totalSelection: number;
}

export const selectedBySchema = SchemaFactory.createForClass(selectedBy);
