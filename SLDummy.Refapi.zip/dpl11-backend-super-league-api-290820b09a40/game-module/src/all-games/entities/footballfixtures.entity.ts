import { ObjectType, Field, PartialType, Int } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { gamedefaultFields } from 'src/commonResponse/response.entity';

export type footballFixtureDocument = FootballFixtures & Document;

@ObjectType()
export class footballTeams {
  // @Field()
  // id: string;

  @Field()
  teamAPIId: number;

  @Field()
  name: string;

  @Field({ defaultValue: '' })
  shortName: string;

  @Field()
  logo: string;
}

@ObjectType()
export class footballFixtureTeams {
  @Field(() => footballTeams)
  teamA: footballTeams;

  @Field(() => footballTeams)
  teamB: footballTeams;
}

@ObjectType()
@Schema()
export class FootballFixtures {
  @Field()
  _id: string;

  @Field({ defaultValue: '' })
  @Prop()
  fixtureName: string;

  @Field()
  @Prop({ index: true })
  fixtureAPIId: number;

  @Field({ defaultValue: '' })
  @Prop()
  fixtureDisplayName: string;

  @Field()
  @Prop()
  fixtureStartDate: Date;

  @Field()
  @Prop()
  fixtureStatus: string;

  @Field()
  @Prop()
  fixtureStatusType: number;

  @Field()
  @Prop()
  fixtureVenue: string;

  @Field({ defaultValue: '' })
  @Prop()
  fixtureType: string;

  @Field()
  @Prop()
  seriesName: string;

  @Field()
  @Prop()
  seriesShortName: string;

  @Field()
  @Prop()
  seriesAPIId: number;

  @Field(() => footballFixtureTeams)
  @Prop()
  fixtureTeams: footballFixtureTeams;

  @Field()
  @Prop({ default: false })
  lineupsOut: boolean;

  @Field()
  @Prop({ default: false })
  enabledStatus: boolean;

  @Field({ defaultValue: 'Mega Contest' })
  @Prop()
  contestStr: string;

  @Field()
  @Prop({ default: true, index: true })
  isactive: boolean;

  @Field(() => [String], { nullable: true })
  @Prop({ default: true, index: true })
  joinedUsers?: string[];

  @Field({ nullable: true })
  @Prop()
  maxPrize: number;

  @Field({ defaultValue: 0 })
  myContestCount: number;

  @Field({ defaultValue: 0 })
  myTeamsCount: number;
}

@ObjectType()
class footballgamepaginatedPayload {
  @Field(() => Int)
  totalPage: number;
  @Field(() => Int, { defaultValue: 1 })
  currentPage: number;
  @Field({ defaultValue: 20 })
  maxTeamCount: number;
  @Field(() => [FootballFixtures], { nullable: true })
  list: FootballFixtures[];
}
@ObjectType()
export class FootballFixturePagination extends PartialType(gamedefaultFields) {
  @Field({ nullable: true })
  data: footballgamepaginatedPayload;
}

@ObjectType()
export class footballMyFixtureAll extends PartialType(gamedefaultFields) {
  @Field(() => [FootballFixtures], { nullable: 'itemsAndList' })
  data: FootballFixtures[];
}
@ObjectType()
export class footballSingleFixture extends PartialType(gamedefaultFields) {
  @Field({ nullable: true })
  data: FootballFixtures;
}
export const FootballFixturesSchema =
  SchemaFactory.createForClass(FootballFixtures);
