import { Field, ObjectType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export type lineUpDocument = Lineup & Document;

@ObjectType()
export class playing11 {
  @Field()
  playerId: number;
  @Field()
  isSubstitute: boolean;
  @Field()
  role: string;
  @Field()
  name: string;
  @Field()
  in11: boolean;
}

@ObjectType()
export class Team {
  @Field()
  teamId: number;
  @Field()
  teamName: string;
  @Field(() => [playing11])
  squads: playing11[];
}

@ObjectType()
@Schema()
export class Lineup {
  @Field()
  @Prop({ index: true })
  fixtureAPIId: number;

  @Field()
  @Prop()
  teamA: Team;

  @Field()
  @Prop()
  teamB: Team;
}
export const LineUpSchema = SchemaFactory.createForClass(Lineup);
