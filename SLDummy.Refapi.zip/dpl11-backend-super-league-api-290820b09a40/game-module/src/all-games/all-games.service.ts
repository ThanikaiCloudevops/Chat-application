import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { cricketFixtures, fixtureDocument } from './entities/fixtures.entity';
import { teamplayersDocument } from './entities/team-players.entity';
import { successResponse } from 'src/commonResponse/success';
import { commonErrors } from 'src/commonResponse/errors';
import {
  FIXTURE_STATUS,
  Football_FIXTURE_STATUS,
  Kabaddi_FIXTURE_STATUS,
} from 'config/envirnment';
import { seriesDocument } from './entities/series.entity';
import { Lineup, lineUpDocument } from './entities/lineup.entity';
import { selectedBy, selectedByDocument } from './entities/selectedby.entity';
import { seriesPointsDocument } from './entities/seriespoints.entity';
import { joinedPlayerStatsDocument } from './entities/joinedstats.entity';
import { footballSeriesDocument } from './entities/footballseries.entity';
import { footballFixtureDocument } from './entities/footballfixtures.entity';
import { footballTeamPlayersDocument } from './entities/footballteamplayers.entity';
import {
  footballLineupDocument,
  FootballLineup,
} from './entities/football-lineup.entity';
import { kabaddiSeriesDocument } from './entities/kabaddiseries.entity';
import { kabaddiFixtureDocument } from './entities/kabaddifixtures.entity';
import { kabaddiTeamPlayersDocument } from './entities/kabadditeamplayers.entity';
import {
  KabaddiLineup,
  kabaddiLineupDocument,
} from './entities/kabaddi-lineup.entity';

@Injectable()
export class AllGamesService {
  constructor(
    @InjectModel('cricketFixtures')
    private fixtureModel: Model<fixtureDocument>,
    @InjectModel('Series') private seriesModel: Model<seriesDocument>,
    @InjectModel('TeamPlayers')
    private teamPlayerModel: Model<teamplayersDocument>,
    @InjectModel('Lineup')
    private lineUpModel: Model<lineUpDocument>,
    @InjectModel('FootballLineup')
    private footballLineupModel: Model<footballLineupDocument>,
    @InjectModel('selectedBy')
    private selectedbyModel: Model<selectedByDocument>,
    @InjectModel('seriesPoints')
    private seriesPointsModel: Model<seriesPointsDocument>,
    @InjectModel('joinedPlayerStats')
    private joinedPlayerStatsModel: Model<joinedPlayerStatsDocument>,
    @InjectModel('FootballSeries')
    private footballSeriesModel: Model<footballSeriesDocument>,
    @InjectModel('FootballFixtures')
    private footballFixtureModel: Model<footballFixtureDocument>,
    @InjectModel('FootballTeamPlayers')
    private footballTeamPlayersModel: Model<footballTeamPlayersDocument>,
    @InjectModel('KabaddiSeries')
    private kabaddiSeriesModel: Model<kabaddiSeriesDocument>,
    @InjectModel('KabaddiFixtures')
    private kabaddiFixtureModel: Model<kabaddiFixtureDocument>,
    @InjectModel('KabaddiTeamPlayers')
    private kabaddiTeamPlayersModel: Model<kabaddiTeamPlayersDocument>,
    @InjectModel('KabaddiLineup')
    private kabaddiLineupModel: Model<kabaddiLineupDocument>,
  ) {}

  async getAllFixtures(
    page: number,
    fixtureStatus: number,
    seriesAPIId?: number[],
  ) {
    const filterObj: any = {
      enabledStatus: true,
      isactive: true,
      is_pin: { $ne: true },
      fixtureStatus: FIXTURE_STATUS[fixtureStatus],
    };

    if (fixtureStatus == 1) {
      filterObj.fixtureStartDate = { $gte: new Date() };
    }

    if (seriesAPIId.length > 0) filterObj.seriesAPIId = { $in: seriesAPIId };

    const list = await this.fixtureModel
      .find(filterObj)
      .lean()
      .sort(
        FIXTURE_STATUS[fixtureStatus] == 'Completed'
          ? { fixtureStartDate: -1 }
          : { fixtureStartDate: 1 },
      )
      .skip((page - 1) * 10)
      .limit(10)
      .lean();

    const fixtures = await this.fixtureModel.count(filterObj).lean();
    const totalPage = Math.ceil(fixtures / 10) || 1;

    const currentPage = page;
    const payload = { list, totalPage, currentPage };
    if (list.length) return successResponse('getallfixtures', payload);
    else return commonErrors('getallfixtures', payload);
  }

  async getFixturesPremiumMatch(fixtureStatus: number) {
    const filterObj: any = {
      enabledStatus: true,
      isactive: true,
      is_pin: true,
      fixtureStatus: FIXTURE_STATUS[fixtureStatus],
    };

    const list = await this.fixtureModel
      .find(filterObj)
      .sort({ fixtureStartDate: 1 })
      .lean();

    if (list.length) return successResponse('getallfixtures', list);
    else return successResponse('nodata', list);
  }

  async getfootballFixturesPremiumMatch(fixtureStatus: number) {
    const filterObj: any = {
      enabledStatus: true,
      isactive: true,
      is_pin: true,
      fixtureStatus: Football_FIXTURE_STATUS[fixtureStatus],
    };

    const list = await this.footballFixtureModel
      .find(filterObj)
      .sort({ fixtureStartDate: 1 })
      .lean();

    if (list.length) return successResponse('getallfixtures', list);
    else return successResponse('nodata', list);
  }

  async getkabaddiFixturesPremiumMatch(fixtureStatus: number) {
    const filterObj: any = {
      enabledStatus: true,
      isactive: true,
      is_pin: true,
      fixtureStatus: Kabaddi_FIXTURE_STATUS[fixtureStatus],
    };

    const list = await this.kabaddiFixtureModel
      .find(filterObj)
      .sort({ fixtureStartDate: 1 })
      .lean();

    if (list.length) return successResponse('getallfixtures', list);
    else return successResponse('nodata', list);
  }

  async getfootballAllFixtures(
    page: number,
    fixtureStatus: number,
    seriesAPIId?: number[],
  ) {
    const filterObj: any = {
      enabledStatus: true,
      isactive: true,
      fixtureStatus: Football_FIXTURE_STATUS[fixtureStatus],
    };

    if (fixtureStatus == 1) {
      filterObj.fixtureStartDate = { $gte: new Date() };
    }

    if (seriesAPIId.length > 0) filterObj.seriesAPIId = { $in: seriesAPIId };

    const list = await this.footballFixtureModel
      .find(filterObj)
      .lean()
      .sort(
        Football_FIXTURE_STATUS[fixtureStatus] == 'completed'
          ? { fixtureStartDate: -1 }
          : { fixtureStartDate: 1 },
      )
      .skip((page - 1) * 10)
      .limit(10);

    const fixtures = await this.footballFixtureModel.count(filterObj).lean();
    const totalPage = Math.ceil(fixtures / 10) || 1;
    const currentPage = page;
    const payload = { list, totalPage, currentPage };
    if (list.length) return successResponse('getallfootballfixtures', payload);
    else return commonErrors('getallfixtures', payload);
  }

  async getkabaddiAllFixtures(
    page: number,
    fixtureStatus: number,
    seriesAPIId?: number[],
  ) {
    const filterObj: any = {
      enabledStatus: true,
      isactive: true,
      fixtureStatus: Kabaddi_FIXTURE_STATUS[fixtureStatus],
    };

    if (fixtureStatus == 1) {
      filterObj.fixtureStartDate = { $gte: new Date() };
    }

    if (seriesAPIId.length > 0) filterObj.seriesAPIId = { $in: seriesAPIId };

    const list = await this.kabaddiFixtureModel
      .find(filterObj)
      .lean()
      .sort(
        Kabaddi_FIXTURE_STATUS[fixtureStatus] == 'result'
          ? { fixtureStartDate: -1 }
          : { fixtureStartDate: 1 },
      )
      .skip((page - 1) * 10)
      .limit(10);

    const fixtures = await this.kabaddiFixtureModel.count(filterObj).lean();
    const totalPage = Math.ceil(fixtures / 10) || 1;
    const currentPage = page;
    const payload = { list, totalPage, currentPage };
    if (list.length) return successResponse('getkabaddiallfixtures', payload);
    else return commonErrors('getallfixtures', payload);
  }
  // my Games
  async getMyFixtures(page: number, fixtureStatus: number, userId: string) {
    const filterObj: any = {
      enabledStatus: true,
      isactive: true,
      joinedUsers: { $in: [userId] },
    };

    if (fixtureStatus) filterObj.fixtureStatus = FIXTURE_STATUS[fixtureStatus];

    const list = await this.fixtureModel
      .find(filterObj)
      .lean()
      .sort({
        fixtureStartDate: filterObj.fixtureStatus == 'Completed' ? -1 : 1,
      })
      .skip((page - 1) * 10)
      .limit(10);

    for (const listValue of list) {
      const userStats = await this.joinedPlayerStatsModel
        .findOne({
          fixtureAPIId: listValue.fixtureAPIId,
        })
        .lean();
      if (!userStats) continue;
      let userData: any = userStats.userStats.filter((e) => e.userId == userId);

      if (userData.length == 0) continue;
      userData = userData[0];

      listValue.myTeamsCount = userData?.userTeams || 0;
      listValue.myContestCount = userData?.userJoinedContest || 0;
    }

    const fixtures = await this.fixtureModel.count(filterObj).lean();
    const totalPage = Math.ceil(fixtures / 10) || 1;
    const currentPage = page;
    const payload = { list, totalPage, currentPage };
    if (list.length) return successResponse('getallfixtures', payload);
    else return commonErrors('getallfixtures', payload);
  }

  async getAllMyFixture(userId: string) {
    const filterObj: any = {
      enabledStatus: true,
      isactive: true,
      joinedUsers: { $in: [userId] },
      fixtureStatus: { $in: [FIXTURE_STATUS[1], FIXTURE_STATUS[3]] },
    };
    const list = await this.fixtureModel
      .find(filterObj)
      .sort({ fixtureStartDate: 1 })
      .lean();

    for (const listValue of list) {
      const userStats = await this.joinedPlayerStatsModel
        .findOne({
          fixtureAPIId: listValue.fixtureAPIId,
        })
        .lean();
      if (!userStats) continue;
      let userData: any = userStats.userStats.filter((e) => e.userId == userId);
      if (userData.length == 0) continue;
      userData = userData[0];

      listValue.myTeamsCount = userData?.userTeams || 0;
      listValue.myContestCount = userData?.userJoinedContest || 0;
    }

    if (list.length) return successResponse('getallfixtures', list);
    else return successResponse('nodata', list);
  }

  async fixturedetail(fixtureAPIId: number) {
    try {
      const data = await this.fixtureModel.findOne({ fixtureAPIId }).lean();
      return successResponse('getallfixtues', data);
    } catch (error) {
      return commonErrors('getallfixtues');
    }
  }

  async joinFixture(userId: string, fixtureAPIId: number, gameType: string) {
    if (gameType === 'cricket') {
      const fixture = await this.fixtureModel.findOne({ fixtureAPIId });
      if (!fixture) return commonErrors('fixturenotfound');
      if (!fixture?.joinedUsers.includes(userId)) {
        await this.fixtureModel.findByIdAndUpdate(fixture._id, {
          $push: { joinedUsers: userId },
        });
      }
    } else if (gameType === 'football') {
      const fixture = await this.footballFixtureModel.findOne({ fixtureAPIId });
      if (!fixture) return commonErrors('fixturenotfound');
      if (!fixture?.joinedUsers.includes(userId)) {
        await this.footballFixtureModel.findByIdAndUpdate(fixture._id, {
          $push: { joinedUsers: userId },
        });
      }
    } else {
      const fixture = await this.kabaddiFixtureModel.findOne({ fixtureAPIId });
      if (!fixture) return commonErrors('fixturenotfound');
      if (!fixture?.joinedUsers.includes(userId)) {
        await this.kabaddiFixtureModel.findByIdAndUpdate(fixture._id, {
          $push: { joinedUsers: userId },
        });
      }
    }

    return successResponse('fixturejoin');
  }

  async getAllSeries() {
    const series = await this.seriesModel
      .find({ enabledStatus: true })
      .sort({ seriesStartDate: 1 })
      .lean();

    if (series.length) return successResponse('seriesGet', series);
    return commonErrors('seriesGet', series);
  }

  async getTeamsbyFixture(fixtureAPIId: number) {
    const fixture: cricketFixtures = await this.fixtureModel
      .findOne({
        fixtureAPIId,
      })
      .lean();
    const seriesPoints = await this.seriesPointsModel
      .findOne({
        seriesAPIId: fixture.seriesAPIId,
      })
      .lean();
    const playerSeriesPoints = seriesPoints?.playerPoints.reduce(
      (total, value) => {
        total[value.playerAPIId] = value.points;
        return total;
      },
      {},
    );

    const { playing11Players, lineUpOut } = await this.getplaying11(
      fixtureAPIId,
    );

    if (!fixture) return commonErrors('getallfixtures');
    const teamIds = [
      fixture.fixtureTeams.teamA.teamAPIId,
      fixture.fixtureTeams.teamB.teamAPIId,
    ];
    console.log(teamIds);

    let fixtureTeams = await this.teamPlayerModel.aggregate([
      {
        $match: {
          teamAPIId: { $in: teamIds },
          sereisAPIId: fixture.seriesAPIId,
          teamformat: fixture.fixtureFormat,
        },
      },
      { $unwind: '$teamPlayers' },
    ]);
    if (!fixtureTeams) return commonErrors('teamGet');

    // cricket purpose only
    const fixture_Type = {
      T20I: 'T20',
      ODI: 'ODI',
      Test: 'Test',
      T20: 'T20',
      'Women T20': 'T20',
    };

    const selectedby = await this.selectedbyCalc(fixtureAPIId);
    fixtureTeams = fixtureTeams.map((player) => {
      return {
        lineUpOut,
        teamJersey: player?.teamJersey,
        playerName: player.teamPlayers.playerName,
        playerDisplayName: player.teamPlayers.playerDisplayName,
        playerAPIId: player.teamPlayers.playerAPIId,
        playerType: player.teamPlayers.player_type,
        teamName: player.teamName,
        teamAPIId: player.teamAPIId,
        teamDisplayName: player.teamDisplayName,
        imgUrl: player.teamLogo,
        playerImg: player?.teamPlayers?.playerImg || '',
        selected: +selectedby?.[player.teamPlayers.playerAPIId]?.selected || 0,
        selectedCap: +selectedby?.[player.teamPlayers.playerAPIId]?.cap || 0,
        selectedVC: +selectedby?.[player.teamPlayers.playerAPIId]?.vc || 0,
        playerValue:
          typeof player.teamPlayers.player_value == 'object'
            ? player.teamPlayers.player_value[fixture_Type[fixture.fixtureType]]
            : player.teamPlayers.player_value,
        in11: playing11Players.includes(player.teamPlayers.playerAPIId),
        points:
          typeof playerSeriesPoints?.[player.teamPlayers.playerAPIId] ==
          'number'
            ? playerSeriesPoints?.[player.teamPlayers.playerAPIId]
            : 0,
      };
    });

    return successResponse('teamGet', fixtureTeams);
  }

  // get all Football Fixture Service
  async getFootballMyFixtures(
    page: number,
    fixtureStatus: number,
    userId: string,
  ) {
    try {
      const filterObj: any = {
        enabledStatus: true,
        isactive: true,
        joinedUsers: { $in: [userId] },
      };
      if (fixtureStatus)
        filterObj.fixtureStatus = Football_FIXTURE_STATUS[fixtureStatus];

      const list = await this.footballFixtureModel
        .find(filterObj)
        .lean()
        .sort({
          fixtureStartDate: filterObj.fixtureStatus == 'result' ? -1 : 1,
        })
        .skip((page - 1) * 10)
        .limit(10);
      for (const listValue of list) {
        const userStats = await this.joinedPlayerStatsModel.findOne({
          fixtureAPIId: listValue.fixtureAPIId,
        });
        if (!userStats) continue;
        let userData: any = userStats.userStats.filter(
          (e) => e.userId == userId,
        );

        if (userData.length == 0) continue;
        userData = userData[0];

        listValue.myTeamsCount = userData?.userTeams || 0;
        listValue.myContestCount = userData?.userJoinedContest || 0;
      }

      const fixtures = await this.footballFixtureModel.count(filterObj).lean();
      const totalPage = Math.ceil(fixtures / 10) || 1;
      const currentPage = page;
      const payload = { list, totalPage, currentPage };
      if (list.length)
        return successResponse('getfootballallfixtures', payload);
      else return commonErrors('getfootballallfixtures', payload);
    } catch (error) {
      console.log(error);
    }
  }

  async getFootballAllMyFixture(userId: string) {
    const filterObj: any = {
      enabledStatus: true,
      isactive: true,
      joinedUsers: { $in: [userId] },
      fixtureStatus: {
        $in: [Football_FIXTURE_STATUS[1], Football_FIXTURE_STATUS[3]],
      },
    };

    const list = await this.footballFixtureModel
      .find(filterObj)
      .sort({ fixtureStartDate: 1 })
      .lean();

    for (const listValue of list) {
      const userStats = await this.joinedPlayerStatsModel
        .findOne({
          fixtureAPIId: listValue.fixtureAPIId,
        })
        .lean();
      if (!userStats) continue;
      let userData: any = userStats.userStats.filter((e) => e.userId == userId);
      if (userData.length == 0) continue;
      userData = userData[0];

      listValue.myTeamsCount = userData?.userTeams || 0;
      listValue.myContestCount = userData?.userJoinedContest || 0;
    }

    if (list.length) return successResponse('getallfixtures', list);
    else return successResponse('nodata', list);
  }

  async footballfixturedetail(fixtureAPIId: number) {
    try {
      const data = await this.footballFixtureModel
        .findOne({ fixtureAPIId })
        .lean();
      return successResponse('getallfixtues', data);
    } catch (error) {
      return commonErrors('getallfixtues');
    }
  }

  async getAllFootballSeries() {
    const series = await this.footballSeriesModel
      .find({ enabledStatus: true })
      .sort({ seriesStartDate: 1 })
      .lean();

    return successResponse('seriesGet', series);
  }

  async getFootballFixturePlayers(teamAPIId: any) {
    const team = await this.footballTeamPlayersModel
      .find({
        teamAPIId: { $in: teamAPIId },
      })
      .lean();

    if (team.length) return successResponse('teamGet', team);
    return commonErrors('teamGet', team);
  }

  async getFixturePlayers(teamAPIId: any) {
    const team = await this.teamPlayerModel
      .find({
        teamAPIId: { $in: teamAPIId },
      })
      .lean();

    if (team.length) return successResponse('teamGet', team);
    return commonErrors('teamGet', team);
  }

  async getFootballTeamsbyFixture(fixtureAPIId: number) {
    const fixture = await this.footballFixtureModel
      .findOne({
        fixtureAPIId,
      })
      .lean();

    const seriesPoints = await this.seriesPointsModel
      .findOne({
        seriesAPIId: fixture.seriesAPIId,
      })
      .lean();
    const playerSeriesPoints = seriesPoints?.playerPoints.reduce(
      (total, value) => {
        total[value.playerAPIId] = value.points;
        return total;
      },
      {},
    );

    const { playing11Players, lineUpOut } = await this.getfootballplaying11(
      fixtureAPIId,
    );

    if (!fixture) return commonErrors('getallfixtures');
    const teamIds = [
      +fixture.fixtureTeams.teamA.teamAPIId,
      +fixture.fixtureTeams.teamB.teamAPIId,
    ];

    let fixtureTeams = await this.footballTeamPlayersModel.aggregate([
      { $match: { teamAPIId: { $in: teamIds } } },
      { $unwind: '$squads' },
    ]);
    if (!fixtureTeams) return commonErrors('teamGet');

    const selectedby = await this.selectedbyCalc(fixtureAPIId);

    fixtureTeams = fixtureTeams.map((player) => {
      return {
        lineUpOut,
        teamJersey: player?.teamJersey,
        playerName: player.squads.playerName,
        // playerDisplayName: player.teamPlayers.playerDisplayName,
        playerAPIId: player.squads.playerAPIId ?? 0,
        positionType: player.squads.positionType,
        positionName: player.squads.positionName,
        teamName: player.teamName,
        teamAPIId: player.teamAPIId,
        teamDisplayName: player.teamDisplayName,
        imgUrl: player.teamLogo,
        playerImg: player?.squads?.playerImg || '',
        selected: +selectedby?.[player.squads.playerAPIId]?.selected || 0,
        selectedCap: +selectedby?.[player.squads.playerAPIId]?.cap || 0,
        selectedVC: +selectedby?.[player.squads.playerAPIId]?.vc || 0,
        playerValue: player.squads.fantasyCredit,
        in11: playing11Players.includes(player.squads.playerAPIId),
        points:
          typeof playerSeriesPoints?.[player.squads.playerAPIId] == 'number'
            ? playerSeriesPoints?.[player.squads.playerAPIId]
            : 0,
      };
    });

    return successResponse('teamGet', fixtureTeams);
  }

  async getLineup(fixtureAPIId: number, gameType: string) {
    if (gameType === 'cricket') {
      return {
        ...(await this.lineUpModel.findOne({ fixtureAPIId }).lean()),
        selby: await this.selectedbyModel.findOne({ fixtureAPIId }).lean(),
      };
    } else if (gameType === 'football') {
      const fixture = await this.footballFixtureModel
        .findOne({
          fixtureAPIId,
        })
        .lean();
      const teamIds = [
        +fixture.fixtureTeams.teamA.teamAPIId,
        +fixture.fixtureTeams.teamB.teamAPIId,
      ];
      const teamplayers = await this.footballTeamPlayersModel.aggregate([
        { $match: { teamAPIId: { $in: teamIds } } },
        { $unwind: '$squads' },
      ]);
      return {
        ...(await this.footballLineupModel.findOne({ fixtureAPIId }).lean()),
        teamplayers: teamplayers,
        selby: await this.selectedbyModel.findOne({ fixtureAPIId }).lean(),
      };
    } else {
      const fixture = await this.kabaddiFixtureModel
        .findOne({
          fixtureAPIId,
        })
        .lean();
      const teamIds = [
        +fixture.fixtureTeams.teamA.teamAPIId,
        +fixture.fixtureTeams.teamB.teamAPIId,
      ];
      const teamplayers = await this.kabaddiTeamPlayersModel.aggregate([
        { $match: { teamAPIId: { $in: teamIds } } },
        { $unwind: '$squads' },
      ]);
      return {
        ...(await this.kabaddiLineupModel.findOne({ fixtureAPIId }).lean()),
        teamplayers: teamplayers,
        selby: await this.selectedbyModel.findOne({ fixtureAPIId }).lean(),
      };
    }
  }

  async getplaying11(fixtureAPIId: number) {
    const playing11: Lineup = await this.lineUpModel
      .findOne({ fixtureAPIId })
      .lean();
    let playing11Players: number[] = [];
    let lineUpOut = false;

    if (playing11) {
      lineUpOut = true;
      playing11Players = [
        ...playing11.teamA.squads.filter((e) => e.in11).map((e) => e.playerId),
        ...playing11.teamB.squads.filter((e) => e.in11).map((e) => e.playerId),
      ];
    }

    return { lineUpOut, playing11Players };
  }

  async getfootballplaying11(fixtureAPIId: number) {
    const playing11: FootballLineup = await this.footballLineupModel
      .findOne({
        fixtureAPIId,
      })
      .lean();
    let playing11Players: number[] = [];
    let lineUpOut = false;

    if (playing11) {
      lineUpOut = true;
      playing11Players = [
        ...playing11.homeTeam.in11.players.map((e) => e.playerAPIId),
        ...playing11.awayTeam.in11.players.map((e) => e.playerAPIId),
      ];
    }

    return { lineUpOut, playing11Players };
  }

  async getkabaddiplaying11(fixtureAPIId: number) {
    const playing7: KabaddiLineup = await this.kabaddiLineupModel
      .findOne({
        fixtureAPIId,
      })
      .lean();
    let playing7Players: number[] = [];
    let lineUpOut = false;

    if (playing7) {
      lineUpOut = true;
      playing7Players = [
        ...playing7.homeTeam.map((e) => e.playerAPIId),
        ...playing7.awayTeam.map((e) => e.playerAPIId),
      ];
    }

    return { lineUpOut, playing7Players };
  }

  async getFixturebyAPIId(payload: any) {
    if (payload.gameType == 'cricket')
      return await this.fixtureModel.findOne({
        fixtureAPIId: payload.fixtureAPIId,
      });
    else if (payload.gameType == 'football')
      return await this.footballFixtureModel.findOne({
        fixtureAPIId: payload.fixtureAPIId,
      });
    else
      return this.kabaddiFixtureModel.findOne({
        fixtureAPIId: payload.fixtureAPIId,
      });
  }

  async updateSelby(request: any) {
    try {
      const selectedbyObj: selectedBy = {
        gameType: request?.gameType,
        fixtureAPIId: request?.fixtureAPIId,
        totalSelection: request?.total || 0,
        players: request.teams.map((e: any) => {
          return {
            playerAPIId: +e.playerAPIId,
            teamAPIId: e.teamAPIId,
            selectedbyCount: e.selectedCount,
            selectedbyCountVC: e.vcCount,
            selectedbyCountCAP: e.capCount,
          };
        }),
      };
      await this.selectedbyModel.findOneAndUpdate(
        { fixtureAPIId: selectedbyObj.fixtureAPIId },
        selectedbyObj,
        { upsert: true, new: true, setDefaultsOnInsert: true },
      );
      return true;
    } catch (err) {
      return false;
    }
  }

  async getSeriesTeams(seriesAPIId: number) {
    try {
      const series = await this.seriesModel.findOne({ apiId: seriesAPIId });
      if (!series) throw new Error();
      const teams = await this.teamPlayerModel
        .find({
          teamAPIId: { $in: series.teams },
        })
        .select(['-teamPlayers']);
      return successResponse('teamGet', teams);
    } catch (err) {
      return successResponse('nodata', []);
    }
  }

  async getFootballTeamsbySeries(seriesAPIId: number) {
    try {
      const series = await this.footballSeriesModel.findOne({
        apiId: seriesAPIId,
      });
      if (!series) throw new Error();
      const teams = await this.footballTeamPlayersModel
        .find({
          teamAPIId: { $in: series.teams },
        })
        .select(['-teamPlayers']);
      return successResponse('teamGet', teams);
    } catch (err) {
      return successResponse('nodata', []);
    }
  }

  // async multipleTeams(teams: number[]) {
  //   try {
  //     const Teams = await this.teamPlayerModel.find({
  //       teamAPIId: { $in: teams },
  //     });
  //     return successResponse('teamGet', Teams);
  //   } catch (err) {
  //     return commonErrors('teamGet');
  //   }
  // }

  // async footballmultipleTeams(teams: number[]) {
  //   try {
  //     const Teams = await this.footballTeamPlayersModel.find({
  //       teamAPIId: { $in: teams },
  //     });
  //     return successResponse('teamGet', Teams);
  //   } catch (error) {
  //     return commonErrors('teamGet');
  //   }
  // }

  async getAllKabaddiSeries() {
    const series = await this.kabaddiSeriesModel
      .find({ enabledStatus: true })
      .sort({ seriesStartDate: 1 })
      .lean();
    console.log(series);
    return successResponse('seriesGet', series);
  }

  async kabaddifixturedetail(fixtureAPIId: number) {
    try {
      const data = await this.kabaddiFixtureModel
        .findOne({ fixtureAPIId })
        .lean();
      return successResponse('getallfixtues', data);
    } catch (error) {
      return commonErrors('getallfixtues');
    }
  }

  async getKabaddiMyFixtures(
    page: number,
    fixtureStatus: number,
    userId: string,
  ) {
    try {
      const filterObj: any = {
        enabledStatus: true,
        isactive: true,
        joinedUsers: { $in: [userId] },
      };
      if (fixtureStatus)
        filterObj.fixtureStatus = Kabaddi_FIXTURE_STATUS[fixtureStatus];

      const list = await this.kabaddiFixtureModel
        .find(filterObj)
        .lean()
        .sort({
          fixtureStartDate: filterObj.fixtureStatus == 'result' ? -1 : 1,
        })
        .skip((page - 1) * 10)
        .limit(10);
      for (const listValue of list) {
        const userStats = await this.joinedPlayerStatsModel.findOne({
          fixtureAPIId: listValue.fixtureAPIId,
        });
        if (!userStats) continue;
        let userData: any = userStats.userStats.filter(
          (e) => e.userId == userId,
        );

        if (userData.length == 0) continue;
        userData = userData[0];

        listValue.myTeamsCount = userData?.userTeams || 0;
        listValue.myContestCount = userData?.userJoinedContest || 0;
      }

      const fixtures = await this.kabaddiFixtureModel.count(filterObj).lean();
      const totalPage = Math.ceil(fixtures / 10) || 1;
      const currentPage = page;
      const payload = { list, totalPage, currentPage };
      if (list.length) return successResponse('getkabaddiallfixtures', payload);
      else return commonErrors('getkabaddiallfixtures', payload);
    } catch (error) {
      console.log(error);
    }
  }

  async getKabaddiAllMyFixture(userId: string) {
    const filterObj: any = {
      enabledStatus: true,
      isactive: true,
      joinedUsers: { $in: [userId] },
      fixtureStatus: {
        $in: [Kabaddi_FIXTURE_STATUS[1], Kabaddi_FIXTURE_STATUS[3]],
      },
    };

    const list = await this.kabaddiFixtureModel
      .find(filterObj)
      .sort({ fixtureStartDate: 1 })
      .lean();

    for (const listValue of list) {
      const userStats = await this.joinedPlayerStatsModel
        .findOne({
          fixtureAPIId: listValue.fixtureAPIId,
        })
        .lean();
      if (!userStats) continue;
      let userData: any = userStats.userStats.filter((e) => e.userId == userId);
      if (userData.length == 0) continue;
      userData = userData[0];

      listValue.myTeamsCount = userData?.userTeams || 0;
      listValue.myContestCount = userData?.userJoinedContest || 0;
    }

    if (list.length) return successResponse('getkabaddiallfixtures', list);
    else return successResponse('nodata', list);
  }

  private async selectedbyCalc(fixtureAPIId: number) {
    try {
      const selby = await this.selectedbyModel.findOne({ fixtureAPIId });

      const total = selby.totalSelection;
      const selbyObj = {};
      for (const player of selby.players) {
        selbyObj[player.playerAPIId] = {
          selected: ((player.selectedbyCount / total) * 100).toFixed(2),
          cap: ((player.selectedbyCountCAP / total) * 100).toFixed(2),
          vc: ((player.selectedbyCountVC / total) * 100).toFixed(2),
        };
      }
      return selbyObj;
    } catch (err) {
      return {};
    }
  }

  async getTeamShortnames(data) {
    const teamShortnames = {};
    if (
      data?.fixtureTeams?.teamA &&
      data?.fixtureTeams?.teamA?.teamAPIId &&
      data?.fixtureTeams?.teamA?.shortName
    ) {
      teamShortnames[data?.fixtureTeams?.teamA?.teamAPIId] =
        data?.fixtureTeams?.teamA?.shortName;
    }

    if (
      data?.fixtureTeams?.teamB &&
      data?.fixtureTeams?.teamB?.teamAPIId &&
      data?.fixtureTeams?.teamB?.shortName
    ) {
      teamShortnames[data?.fixtureTeams?.teamB?.teamAPIId] =
        data?.fixtureTeams?.teamB?.shortName;
    }

    return teamShortnames;
  }

  async getKabaddiTeamsbyFixture(fixtureAPIId: number) {
    const fixture = await this.kabaddiFixtureModel
      .findOne({
        fixtureAPIId,
      })
      .lean();

    const shortnameData = await this.getTeamShortnames(fixture);

    const seriesPoints = await this.seriesPointsModel
      .findOne({
        seriesAPIId: fixture.seriesAPIId,
      })
      .lean();
    const playerSeriesPoints = seriesPoints?.playerPoints.reduce(
      (total, value) => {
        total[value.playerAPIId] = value.points;
        return total;
      },
      {},
    );
    const { playing7Players, lineUpOut } = await this.getkabaddiplaying11(
      fixtureAPIId,
    );
    if (!fixture) return commonErrors('getallfixtures');
    const teamIds = [
      +fixture.fixtureTeams.teamA.teamAPIId,
      +fixture.fixtureTeams.teamB.teamAPIId,
    ];

    let fixtureTeams = await this.kabaddiTeamPlayersModel.aggregate([
      { $match: { teamAPIId: { $in: teamIds } } },
      { $unwind: '$squads' },
    ]);

    fixtureTeams.forEach((team) => {
      if (shortnameData[team.teamAPIId]) {
        team.shortname = shortnameData[team.teamAPIId];
      }
    });

    if (!fixtureTeams) return commonErrors('teamGet');
    const selectedby = await this.selectedbyCalc(fixtureAPIId);

    fixtureTeams = fixtureTeams.map((player) => {
      return {
        lineUpOut,
        teamJersey: player?.teamJersey,
        playerName: player.squads.playerName,
        // playerDisplayName: player.teamPlayers.playerDisplayName,
        playerAPIId: player.squads.playerAPIId ?? 0,
        positionType: player.squads.positionType,
        positionName: player.squads.positionName,
        teamName: player.teamName,
        teamAPIId: player.teamAPIId,
        teamDisplayName: player.shortname,
        imgUrl: player.teamLogo,
        playerImg: player?.squads?.playerImg || '',
        selected: +selectedby?.[player.squads.playerAPIId]?.selected || 0,
        selectedCap: +selectedby?.[player.squads.playerAPIId]?.cap || 0,
        selectedVC: +selectedby?.[player.squads.playerAPIId]?.vc || 0,
        playerValue: player.squads.fantasyCredit,
        in11: playing7Players.includes(player.squads.playerAPIId),
        points:
          typeof playerSeriesPoints?.[player.squads.playerAPIId] == 'number'
            ? playerSeriesPoints?.[player.squads.playerAPIId]
            : 0,
      };
    });
    return successResponse('teamGet', fixtureTeams);
  }
}
