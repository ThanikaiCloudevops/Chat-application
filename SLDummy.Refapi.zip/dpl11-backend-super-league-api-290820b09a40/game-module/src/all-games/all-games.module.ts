import { Module } from '@nestjs/common';
import { AllGamesService } from './all-games.service';
import { AllGamesResolver } from './all-games.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import { cricketFixtures, FixturesSchema } from './entities/fixtures.entity';
import { Series, SeriesSchema } from './entities/series.entity';
import { TeamPlayers, TeamPlayerSchema } from './entities/team-players.entity';
import { Lineup, LineUpSchema } from './entities/lineup.entity';
import { selectedBy, selectedBySchema } from './entities/selectedby.entity';
import {
  seriesPoints,
  seriesPointsSchema,
} from './entities/seriespoints.entity';
import {
  joinedPlayerStats,
  joinedPlayerStatsSchema,
} from './entities/joinedstats.entity';
import {
  FootballSeries,
  FootballSeriesSchema,
} from './entities/footballseries.entity';
import {
  FootballFixtures,
  FootballFixturesSchema,
} from './entities/footballfixtures.entity';
import {
  FootballTeamPlayers,
  FootballTeamPlayersSchema,
} from './entities/footballteamplayers.entity';

import {
  FootballLineup,
  FootballLineupSchema,
} from './entities/football-lineup.entity';
import {
  KabaddiSeries,
  kabaddiSeriesSchema,
} from './entities/kabaddiseries.entity';
import {
  KabaddiFixtures,
  KabaddiFixturesSchema,
} from './entities/kabaddifixtures.entity';
import {
  KabaddiTeamPlayers,
  KabaddiTeamPlayersSchema,
} from './entities/kabadditeamplayers.entity';
import {
  KabaddiLineup,
  KabaddiLineupSchema,
} from './entities/kabaddi-lineup.entity';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Lineup.name, schema: LineUpSchema },
      { name: cricketFixtures.name, schema: FixturesSchema },
      { name: Series.name, schema: SeriesSchema },
      { name: TeamPlayers.name, schema: TeamPlayerSchema },
      { name: selectedBy.name, schema: selectedBySchema },
      { name: seriesPoints.name, schema: seriesPointsSchema },
      { name: joinedPlayerStats.name, schema: joinedPlayerStatsSchema },
      { name: FootballSeries.name, schema: FootballSeriesSchema },
      { name: FootballFixtures.name, schema: FootballFixturesSchema },
      { name: FootballTeamPlayers.name, schema: FootballTeamPlayersSchema },
      { name: FootballLineup.name, schema: FootballLineupSchema },
      { name: KabaddiSeries.name, schema: kabaddiSeriesSchema },
      { name: KabaddiFixtures.name, schema: KabaddiFixturesSchema },
      { name: KabaddiTeamPlayers.name, schema: KabaddiTeamPlayersSchema },
      { name: KabaddiLineup.name, schema: KabaddiLineupSchema },
    ]),
  ],
  providers: [AllGamesResolver, AllGamesService],
})
export class AllGamesModule {}
