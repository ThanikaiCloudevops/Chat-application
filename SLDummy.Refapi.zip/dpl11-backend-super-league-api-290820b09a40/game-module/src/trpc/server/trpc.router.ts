import { INestApplication, Injectable } from '@nestjs/common';
import { z } from 'zod';
import { TrpcService } from './trpc.service';
import * as trpcExpress from '@trpc/server/adapters/express';
import { AllGamesService } from 'src/all-games/all-games.service';

@Injectable()
export class TrpcRouter {
  constructor(
    private readonly trpc: TrpcService,
    private allGamesService: AllGamesService,
  ) {}

  appRouter = this.trpc.router({
    joinfixture: this.trpc.procedure
      .input(
        z.object({
          request: z.any(),
        }),
      )
      .query(
        async ({ input }) =>
          await this.allGamesService.joinFixture(
            input?.request?.userId,
            input?.request?.fixtureAPIId,
            input?.request?.gameType,
          ),
      ),
    getlineUp: this.trpc.procedure
      .input(
        z.object({
          request: z.any(),
        }),
      )
      .query(
        async ({ input }) =>
          await this.allGamesService.getLineup(
            input?.request?.fixtureAPIId,
            input?.request?.gameType,
          ),
      ),

    getplaying11: this.trpc.procedure
      .input(z.object({ request: z.any() }))
      .query(
        async ({ input }) =>
          await this.allGamesService.getplaying11(input?.request?.fixtureAPIId),
      ),

    updateSellectedby: this.trpc.procedure
      .input(z.object({ request: z.any() }))
      .query(
        async ({ input }) =>
          await this.allGamesService.updateSelby(input?.request),
      ),

    getfixture: this.trpc.procedure
      .input(z.object({ request: z.any() }))
      .query(
        async ({ input }) =>
          await this.allGamesService.getFixturebyAPIId(input?.request),
      ),
  });

  async applyMiddleware(app: INestApplication) {
    app.use(
      `/trpc/game`,
      trpcExpress.createExpressMiddleware({
        router: this.appRouter,
        createContext: () => ({}),
      }),
    );
  }
}

export type AppRouter = TrpcRouter[`appRouter`];
