const successMsg = {
  getallfixtures: 'Fixtures found',
  getfootballallfixtures: 'Football Fixture Retrived Successfully',
  getkabaddiallfixtures: 'Kabaddi Fixture Retrived Successfully',
  seriesGet: 'Series retrived successfully',
  teamGet: 'Teams retrived successfully',
  seriesupdate: 'Series updated successfully',
  teamplayersupdate: 'Team and players updated successfully',
  fixtureUpdated: 'Fixture updated successfully',
  fixturejoin: 'User joined in fixture successfully',
  seriesCronStart: 'Series cron started',
  seriesCronStop: 'Series cron stopped',
  nodata: 'No data found',
  getallfootballfixtures: 'Get All Football Fixtures',
};
export function successResponse(msg: string, data: any = null) {
  return { status: true, success: { message: successMsg[msg] }, data };
}
