import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { GameService } from '../game-cron.service';

@Injectable()
export class GameCronService {
  private readonly logger = new Logger(GameCronService.name);
  constructor(private readonly gameService: GameService) {}

  @Cron(CronExpression.EVERY_1ST_DAY_OF_MONTH_AT_MIDNIGHT, {
    name: 'series',
    disabled: true,
  })
  async startSeriesCron() {
    await this.gameService.seriesUpdate();
    this.logger.log('Series has been updated');
  }

  @Cron(CronExpression.EVERY_1ST_DAY_OF_MONTH_AT_MIDNIGHT, {
    name: 'cricketFixtures',
    disabled: true,
  })
  async startFixturesCron() {
    await this.gameService.fixturesUpdate();
    this.logger.log('Fixtures has been updated');
  }

  @Cron(CronExpression.EVERY_1ST_DAY_OF_MONTH_AT_MIDNIGHT, {
    name: 'teamplayers',
    disabled: true,
  })
  async startTeamPlayersCron() {
    await this.gameService.teamPlayersUpdate();
    this.logger.log('Teams and Players has been updated');
  }
}
