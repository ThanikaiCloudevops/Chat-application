import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { fixtureDocument } from 'src/all-games/entities/fixtures.entity';
import { seriesDocument } from 'src/all-games/entities/series.entity';
import { teamplayersDocument } from 'src/all-games/entities/team-players.entity';
import { successResponse } from 'src/commonResponse/success';
import { HelpersService } from './helpers/helpers.service';
import { SchedulerRegistry } from '@nestjs/schedule';

@Injectable()
export class GameService {
  constructor(
    @InjectModel('cricketFixtures')
    private fixtureModel: Model<fixtureDocument>,
    @InjectModel('Series') private seriesModel: Model<seriesDocument>,
    @InjectModel('TeamPlayers')
    private teamPlayerModel: Model<teamplayersDocument>,
    private cronHelpers: HelpersService,
  ) {}

  //series
  async seriesUpdate() {
    const existingAPIIds = (
      await this.seriesModel.find({ isactive: true }).select(['apiId'])
    ).map((e: any) => e.apiId);

    const req = await fetch('http://localhost:8080/series/getseries');
    const { data } = await req.json();
    const newSeries = [];
    const existingSeries = [];
    for (const key in data) {
      const series = data[key];
      if (!existingAPIIds.includes(series.cid))
        newSeries.push(this.cronHelpers.formatSeries(series));
      else existingSeries.push(this.cronHelpers.formatSeries(series));
    }

    existingSeries.forEach(async (element: any) => {
      await this.seriesModel.findOneAndUpdate(
        { apiId: element.apiId },
        element,
      );
    });

    await this.seriesModel.insertMany(newSeries);
    return successResponse('seriesupdate');
  }

  // Fixtures
  async fixturesUpdate() {
    const existingAPIIds = (
      await this.fixtureModel.find({ isactive: true }).select(['fixtureAPIId'])
    ).map((e: any) => e.fixtureAPIId);

    const req = await fetch('http://localhost:8080/fixture/getFixture');
    const { data } = await req.json();

    const newFixtures = [];
    const existingFixtures = [];
    for (const key in data) {
      const fixture = data[key];
      if (!existingAPIIds.includes(fixture.fixtureMatch.match_id))
        newFixtures.push(this.cronHelpers.formatFixtures(fixture));
      else existingFixtures.push(this.cronHelpers.formatFixtures(fixture));
    }

    existingFixtures.forEach(async (element: any) => {
      await this.fixtureModel.findOneAndUpdate(
        { fixtureAPIId: element.fixtureAPIId },
        element,
      );
    });

    await this.fixtureModel.insertMany(newFixtures);

    return successResponse('fixtureUpdated');
  }

  // teams
  async teamPlayersUpdate() {
    const existingAPIIds = (
      await this.teamPlayerModel.find().select(['teamAPIId'])
    ).map((e: any) => e.teamAPIId);

    const req = await fetch('http://localhost:8080/squad/getsquad');
    const { data } = await req.json();
    let updateDatas: any = {};

    let groupedSquad = data.reduce((value: any, item: any) => {
      if (!existingAPIIds.includes(item.team.tid)) {
        const key = item['team_id'];
        if (!value[key]) value[key] = this.cronHelpers.initilizeTeam(item);

        value[key]['teamPlayers'].push(
          this.cronHelpers.formatTeamPlayers(item),
        );
        return value;
      } else {
        const key = item['team_id'];

        if (!updateDatas[key])
          updateDatas[key] = this.cronHelpers.initilizeTeam(item);

        updateDatas[key]['teamPlayers'].push(
          this.cronHelpers.formatTeamPlayers(item),
        );
      }
    }, {});

    updateDatas = updateDatas ? Object.values(updateDatas) : [];
    updateDatas.forEach(async (element: any) => {
      await this.teamPlayerModel.findOneAndUpdate(
        { teamAPIId: element.teamAPIId },
        element,
      );
    });

    groupedSquad = groupedSquad ? Object.values(groupedSquad) : [];
    await this.teamPlayerModel.insertMany(groupedSquad);
    return successResponse('teamplayersupdate');
  }
}

@Injectable()
export class Cron {
  constructor(private schedulerRegistry: SchedulerRegistry) {}

  seriesCron(cron: boolean) {
    const seriesCronJob = this.schedulerRegistry.getCronJob('series');
    if (cron) {
      seriesCronJob.start();
      return successResponse('seriesCronStart');
    }
    seriesCronJob.stop();
    return successResponse('seriesCronStop');
  }

  teamPlayersCron(cron: boolean) {
    const seriesCronJob = this.schedulerRegistry.getCronJob('teamplayers');
    if (cron) {
      seriesCronJob.start();
      return successResponse('seriesCronStart');
    }
    seriesCronJob.stop();
    return successResponse('seriesCronStop');
  }

  fixturesCron(cron: boolean) {
    const seriesCronJob = this.schedulerRegistry.getCronJob('cricketFixtures');
    if (cron) {
      seriesCronJob.start();
      return successResponse('seriesCronStart');
    }
    seriesCronJob.stop();
    return successResponse('seriesCronStop');
  }
}
