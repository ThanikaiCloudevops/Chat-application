import { Module } from '@nestjs/common';
import { Cron, GameService } from './game-cron.service';
import { GameCronResolver } from './game-cron.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import {
  cricketFixtures,
  FixturesSchema,
} from '../all-games/entities/fixtures.entity';
import { Series, SeriesSchema } from 'src/all-games/entities/series.entity';
import {
  TeamPlayers,
  TeamPlayerSchema,
} from 'src/all-games/entities/team-players.entity';
import { ScheduleModule } from '@nestjs/schedule';
import { HelpersService } from './helpers/helpers.service';
import { GameCronService } from './cron-service/cron-service.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: cricketFixtures.name, schema: FixturesSchema },
      { name: Series.name, schema: SeriesSchema },
      { name: TeamPlayers.name, schema: TeamPlayerSchema },
    ]),
    ScheduleModule.forRoot(),
  ],
  exports: [],
  providers: [
    GameCronResolver,
    GameService,
    HelpersService,
    GameCronService,
    Cron,
  ],
})
export class GameCronModule {}
