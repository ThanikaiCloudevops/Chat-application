export const MODULE = { NAME: 'User Module', PORT: 5004 };
export const DB = {
  URL: 'mongodb+srv://super-league_user01:RiBA5Y8HUiDFUpEo@cluster-1.fehzk.mongodb.net/superleague?retryWrites=true&w=majority&appName=Cluster-1',
};
export const VERSION = {
  androidVersion: '1.1.0',
  iosVersion: '1.1.0',
};

export const TRPC = {
  // development
  /* USERAUTH: 'http://{devip}:5000/trpc/userauth',
  WALLET: 'http://{devip}:5005/trpc/wallet', */

  // Local
  USERAUTH: 'http://localhost:5000/trpc/userauth',
  WALLET: 'http://localhost:5005/trpc/wallet',
};

export const AWS = {
  AWS_ACCESSKEY: 'AKIA4CDUU23WS6NHWFVJ',
  AWS_SECRET: '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',
  S3_REGION: 'ap-south-1',
  S3_BUCKET: 'super-leagues',
};

export const constant = {
  S3BaseURL: 'https://super-leagues.s3.ap-south-1.amazonaws.com/',
};
export const cashfree = {
  clientId: '',
  clientSecret: '',
};
