import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { TrpcRouter } from './trpc/server/trpc.router';
import { ValidationPipe } from '@nestjs/common';
// import { graphqlUploadExpress } from 'graphql-upload-ts';
import { MODULE } from 'config/envirnment';
import * as bodyParser from 'body-parser';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors({ allowedHeaders: '*', origin: '*' });

  app.use(bodyParser.json({ limit: '10mb' }));
  app.use(bodyParser.urlencoded({ limit: '10mb', extended: true }));
  // app.use(graphqlUploadExpress({ maxFileSize: 1000000, maxFiles: 5 }));

  const trpc = app.get(TrpcRouter);
  trpc.applyMiddleware(app);
  app.useGlobalPipes(new ValidationPipe());
  await app.listen(MODULE.PORT, () =>
    console.log(`${MODULE.NAME} listening http://localhost:${MODULE.PORT}`),
  );
}
bootstrap();
