import { Injectable } from '@nestjs/common';
import {
  PutObjectCommand,
  PutObjectCommandInput,
  S3Client,
} from '@aws-sdk/client-s3';
import { AWS } from 'config/envirnment';

const s3Upload = new S3Client({
  credentials: {
    accessKeyId: AWS.AWS_ACCESSKEY,
    secretAccessKey: AWS.AWS_SECRET,
  },
  region: AWS.S3_REGION,
});

@Injectable()
export class graphFileUpload {
  constructor() {}

  async uploadImage(name: string, data: any, type: string) {
    try {
      const fileName: string = `${name}`;

      const uploadparams: PutObjectCommandInput = {
        Bucket: AWS.S3_BUCKET,
        Key: fileName,
        Body: Buffer.from(
          data.replace(/^data:image\/\w+;base64,/, ''),
          'base64',
        ),
        ContentEncoding: 'base64',
        ContentType: type,
      };
      const command = new PutObjectCommand(uploadparams);
      if (!command)
        return {
          status: false,
        };

      await s3Upload.send(command);
      const url = `https://${AWS.S3_BUCKET}.s3.${AWS.S3_REGION}.amazonaws.com/${fileName}`;
      return {
        status: true,
        url,
      };
    } catch (err) {
      console.log(err);
      return { status: false };
    }
  }
}
