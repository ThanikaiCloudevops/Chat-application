import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Cashfree } from 'cashfree-verification';
import axios from 'axios';
import { commonErrors } from 'src/commonResponse/errors';
import { trpcServices } from 'src/trpc/client/trpc';
import { userProfileDocument } from 'src/user-profile/entities/user-profile.entity';
import { cashfree } from 'config/envirnment';
import { successResponse } from 'src/commonResponse/success';

@Injectable()
export class KycVerifyService {
  constructor(
    @InjectModel('UserProfile')
    private userProfileModel: Model<userProfileDocument>,
    private trpcService: trpcServices,
  ) {
    Cashfree.XClientId = cashfree.clientId;
    Cashfree.XClientSecret = cashfree.clientSecret;
    Cashfree.XEnvironment = Cashfree.Environment.SANDBOX;
  }

  #base64ToFile(base64: string) {
    let arr = base64.split(',');
    let mime = arr[0].match(/:(.*?);/)![1];
    let data = arr[1];
    let dataStr = atob(data);
    let n = dataStr.length;
    let dataArr = new Uint8Array(n);
    while (n--) {
      dataArr[n] = dataStr.charCodeAt(n);
    }
    const checkFile = new File([dataArr], 'test.png', {
      type: mime,
      lastModified: Date.now(),
    });

    return checkFile;
  }

  async kycVerify(userId: string, Id: string, frontImg: any, backImg?: any) {
    try {
      const userProfile = await this.userProfileModel.findOne({ userId });
      if (!userProfile) return commonErrors('userprofile');
      const checkDuplicate = await this.userProfileModel.findOne({ kycId: Id });
      if (checkDuplicate) return commonErrors('kycexist');
      if (userProfile.kycStatus == 2) return commonErrors('kycverified');

      const file = this.#base64ToFile(frontImg);
      const formdata = new FormData();
      formdata.set('verification_id', Id);
      formdata.set('front_image', file);

      const { data } = await axios.post(
        'https://api.cashfree.com/verification/document/aadhaar',
        formdata,
        {
          headers: {
            'x-client-id': cashfree.clientId,
            'x-client-secret': cashfree.clientSecret,
          },
        },
      );
      if (!data.valid) return commonErrors('kycerror');

      await this.trpcService.userAuth('profilestatus', {
        userId,
        kycStatus: true,
      });
      userProfile.kycStatus = 2;
      userProfile.kycId = Id;
      userProfile.kycVerifiedAt = new Date();
      await userProfile.save();

      return successResponse('kycsuccess');
    } catch (err) {
      console.log(err);
      return commonErrors('kycupload');
    }
  }

  async panVerify(userId: string, Id: string, frontImg: any) {
    try {
      const userProfile = await this.userProfileModel.findOne({ userId });
      if (!userProfile) return commonErrors('userprofile');
      const checkDuplicate = await this.userProfileModel.findOne({ panId: Id });

      if (checkDuplicate) return commonErrors('panexist');
      if (userProfile.panStatus == 2) return commonErrors('kycverified');
      const file = this.#base64ToFile(frontImg);
      const formdata = new FormData();
      formdata.set('verification_id', Id);
      formdata.set('front_image', file);

      const { data } = await axios.post(
        'https://api.cashfree.com/verification/document/pan',
        formdata,
        {
          headers: {
            'x-client-id': cashfree.clientId,
            'x-client-secret': cashfree.clientSecret,
          },
        },
      );
      if (!data.valid) return commonErrors('kycerror');
      await this.trpcService.userAuth('profilestatus', {
        userId,
        panStatus: true,
      });
      userProfile.panStatus = 2;
      userProfile.panId = Id;
      userProfile.panVerifiedAt = new Date();
      await userProfile.save();

      return successResponse('pan');
    } catch (err) {
      console.log(err);
      return commonErrors('pan');
    }
  }
}
