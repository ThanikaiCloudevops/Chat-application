import { Module } from '@nestjs/common';
import { KycVerifyService } from './kyc-verify.service';
import { KycVerifyResolver } from './kyc-verify.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import { trpcServices } from 'src/trpc/client/trpc';
import {
  UserProfile,
  UserProfileSchema,
} from 'src/user-profile/entities/user-profile.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: UserProfile.name, schema: UserProfileSchema },
    ]),
  ],
  providers: [KycVerifyResolver, KycVerifyService, trpcServices],
})
export class KycVerifyModule {}
