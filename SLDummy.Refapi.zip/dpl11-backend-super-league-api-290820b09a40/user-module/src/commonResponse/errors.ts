import { GraphQLError } from 'graphql';

const errorMsg = {
  userprofile: 'User profile not found',
  upload: 'Error uploading image',
  kyc: 'KYC details not found',
  kycupload: 'Error uploading KYC details',
  kycexist: 'This aadhar number already exist',
  kycincom: 'KYC not uploaded yet',
  kyccomplete: 'Cannot complete KYC',
  kycerror: 'KYC verification failed',
  kycretry: 'Cannot retry KYC',
  profile: 'Unable to update user profile',
  undereighteen: 'under eighteen not eligible',
  pan: 'Error uploading PAN details',
  panexist: 'This PAN number already verified',
  kycverified: 'KYC details already verified ',
  panverified: 'PAN details already verified ',
};
export function commonErrors(errorType: string, data: any = null) {
  return { status: false, error: { message: errorMsg[errorType] }, data };
}
export function handleException(error: any) {
  throw new GraphQLError(error, {
    extensions: {
      code: 'FORBIDDEN',
    },
  });
}
