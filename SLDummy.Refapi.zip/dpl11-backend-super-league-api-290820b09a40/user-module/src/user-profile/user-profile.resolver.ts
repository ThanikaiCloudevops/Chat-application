import { Resolver, Query, Mutation, Args, Int, Context } from '@nestjs/graphql';
import { UserProfileService } from './user-profile.service';
// import { GraphQLUpload, FileUpload, Upload } from 'graphql-upload';
import { UseGuards } from '@nestjs/common';
import { AuthGuard } from 'src/auth/auth.guard';
import {
  UserProfileCollection,
  profileDefaultFields,
  uploadResponse,
  updateProfileResponse,
  NotificationCollection,
  BannerData,
} from 'src/commonResponse/response.entity';
import { UpdateUserProfileInput } from './dto/update-user-profile.input';

@Resolver()
@UseGuards(AuthGuard)
export class UserProfileResolver {
  constructor(private readonly userProfileService: UserProfileService) {}

  @Query(() => UserProfileCollection, { name: 'userProfile' })
  userProfile(@Context('user') user: any) {
    return this.userProfileService.findOne(user);
  }

  @Query(() => profileDefaultFields, { name: 'deleteUser' })
  deleteUser() {
    return this.userProfileService.deleteUser();
  }

  @Query(() => BannerData, { name: 'banner' })
  getbanner() {
    return this.userProfileService.getbanner();
  }

  @Mutation(() => updateProfileResponse)
  userProfileUpdate(
    @Args('input') userProfileInput: UpdateUserProfileInput,
    @Context('user') user: any,
    @Args('image', { nullable: true }) Image?: string,
  ) {
    return this.userProfileService.updateUserProfile(
      user._id,
      userProfileInput,
      Image,
    );
  }

  /* @Mutation(() => uploadResponse, { name: 'coverPhoto' })
  async uploadCoverPhoto(
    @Args('file', { type: () => GraphQLUpload }) file: FileUpload,
  ) {
    return this.userProfileService.imageUpload(file);
  } */

  @Query(() => NotificationCollection, { name: 'notifications' })
  userNotifications(@Context('user') user: any) {
    return this.userProfileService.userNotifications(user);
  }

  @Query(() => NotificationCollection, { name: 'readNotifications' })
  readNotifications(
    @Context('user') user: any,
    @Args('notificationId') notificationId: string,
  ) {
    return this.userProfileService.readNotification(user, notificationId);
  }
}
