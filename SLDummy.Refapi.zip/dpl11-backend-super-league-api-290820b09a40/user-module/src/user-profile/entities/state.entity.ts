import { ObjectType, Field, PartialType, OmitType, Int } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type statesDocument = States & Document;

@ObjectType()
@Schema()
export class States {
  @Field()
  @Prop()
  name: string;
  @Field()
  @Prop()
  usps: string;
  @Field()
  @Prop()
  iso: string;
  @Field()
  @Prop()
  uscg: string;
  @Field()
  @Prop()
  isbaned: boolean;
}

export const StatesSchema = SchemaFactory.createForClass(States);
