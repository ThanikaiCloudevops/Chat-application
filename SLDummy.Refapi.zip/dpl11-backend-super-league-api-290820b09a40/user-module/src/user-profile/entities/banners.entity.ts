import { ObjectType, Field, Int } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type bannerDocument = Banner & Document;

@ObjectType()
class CTA {
  @Field({ defaultValue: '' })
  url: string;

  @Field({ defaultValue: '' })
  screen: string;

  @Field({ defaultValue: '' })
  section: string;
}

@ObjectType()
@Schema()
export class Banner {
  @Field({ defaultValue: '' })
  @Prop()
  assets_url?: string;

  @Field({ defaultValue: '' })
  @Prop()
  pic?: string;

  @Field({ defaultValue: '' })
  @Prop()
  image?: string;

  @Field()
  @Prop()
  isactive: boolean;

  @Field()
  @Prop()
  enableStatus: boolean;

  @Field()
  @Prop()
  position: number;

  @Field()
  @Prop()
  bannerSportType: number;

  @Field({ defaultValue: '' })
  @Prop()
  updated_at: Date;

  @Field()
  @Prop()
  type: string;

  @Field(() => CTA)
  @Prop({ type: Object })
  cta: CTA;
}

export const BannerSchema = SchemaFactory.createForClass(Banner);
