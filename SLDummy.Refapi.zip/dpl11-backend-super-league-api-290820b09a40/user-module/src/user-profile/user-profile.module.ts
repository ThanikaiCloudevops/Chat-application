import { Module } from '@nestjs/common';
import { UserProfileService } from './user-profile.service';
import { UserProfileResolver } from './user-profile.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import { UserProfile, UserProfileSchema } from './entities/user-profile.entity';
import {
  Notification,
  NotificationSchema,
} from './entities/notifications.entity';
import { trpcServices } from 'src/trpc/client/trpc';
import { graphFileUpload } from 'src/helper/s3.upload';
import { States, StatesSchema } from './entities/state.entity';
import { Version, VersionSchema } from './entities/version.entity';
import { Banner, BannerSchema } from './entities/banners.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: UserProfile.name, schema: UserProfileSchema },
      { name: Notification.name, schema: NotificationSchema },
      { name: States.name, schema: StatesSchema },
      { name: Version.name, schema: VersionSchema },
      { name: Banner.name, schema: BannerSchema },
    ]),
    Notification,
  ],
  providers: [
    UserProfileResolver,
    UserProfileService,
    trpcServices,
    graphFileUpload,
  ],
})
export class UserProfileModule {}
