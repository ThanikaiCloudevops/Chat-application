import { InputType, OmitType } from '@nestjs/graphql';
import { userKYC } from '../entities/kyc.entity';

@InputType()
class inputKyc extends userKYC {}

@InputType()
export class KycInput extends OmitType(inputKyc, [
  'proofImgBack',
  'proofImgFront',
  'userId',
  'verified',
  'rejected',
  'rejectedReason',
]) {}
