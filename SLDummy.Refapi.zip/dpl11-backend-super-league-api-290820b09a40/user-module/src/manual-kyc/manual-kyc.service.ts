import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { userKYC, userKycDocument } from './entities/kyc.entity';
import { commonErrors } from 'src/commonResponse/errors';
import { successResponse } from 'src/commonResponse/success';
import { KycInput } from './dto/kyc.input';
import { graphFileUpload } from 'src/helper/s3.upload';
import { Readable } from 'stream';
import { userProfileDocument } from 'src/user-profile/entities/user-profile.entity';

@Injectable()
export class ManualKycService {
  constructor(
    @InjectModel('userKYC')
    private userKycModel: Model<userKycDocument>,
    @InjectModel('UserProfile')
    private userProfileModel: Model<userProfileDocument>,
    private upload: graphFileUpload,
  ) {}

  async getKYCDetails(userId: string) {
    const userKyc = await this.userKycModel.findOne({ userId }).lean();
    return successResponse('data', userKyc);
  }

  async uploadKyc(
    userId: string,
    userProfileInput: KycInput,
    frontImg?: string,
    backImg?: string,
  ) {
    try {
      let image1Upload: any, image2Upload: any;

      const { data } = await this.getKYCDetails(userId);
      if (data && !data.rejected) return commonErrors('kycexist');

      if (frontImg)
        image1Upload = this.upload.uploadImage(
          `${userId}KYC_f.jpeg`,
          frontImg,
          'image/jpeg',
        );
      if (backImg)
        image2Upload = this.upload.uploadImage(
          `${userId}KYC_b.jpeg`,
          frontImg,
          'backImg/jpeg',
        );

      const userKycObj = {
        ...userProfileInput,
        proofImgFront: image1Upload?.url || '',
        proofImgBack: image2Upload?.url || '',
      };

      const options = { upsert: true, new: true, setDefaultsOnInsert: true };

      await this.userKycModel.findOneAndUpdate({ userId }, userKycObj, options);
      await this.userProfileModel.updateOne(
        { userId },
        { $set: { kycStatus: 1 } },
      );

      return successResponse('kyc');
    } catch (err) {
      console.log(err);
      return commonErrors('kycupload');
    }
  }
}
