import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { graphqlUploadExpress } from 'graphql-upload';
import { MODULE } from 'config/envirnment';
import * as bodyParser from 'body-parser';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.use(bodyParser.json({ limit: '50mb' }));
  app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
  app.enableCors({ allowedHeaders: '*', origin: '*' });
  app.use(graphqlUploadExpress({ maxFileSize: 1000000, maxFiles: 5 }));
  await app.listen(MODULE.PORT, () =>
    console.log(`${MODULE.NAME} running http://localhost:${MODULE.PORT}`),
  );
}
bootstrap();
