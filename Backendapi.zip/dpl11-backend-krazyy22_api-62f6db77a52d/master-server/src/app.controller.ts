import { Controller, Get, Post, Req } from '@nestjs/common';
import { AppService } from './app.service';
import { userAuth, wallet } from 'config/envirnment';
import { Request } from 'express';

@Controller('/')
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }


  @Post('updatepayment')
  async gidadatPaymentReciver(@Req() req:Request) {
    try {
        console.log("req", req.body)
      await fetch(wallet.paymentURL, {
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        method: 'POST',
        body: JSON.stringify(req.body),
      })
      return { status: true, message: 'Transaction updated' };
    } catch (err) {
      console.log('sdfsdf', err)
      return { status: false, message: 'Transaction updated' };
    }
  }


  @Get('points')
  async pointsSystem() {
    try {
      const res = await fetch(userAuth.graphUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: `{
                getPoints {
                            status
                            error {
                                 message
                                    }
                            success {
                                  message
                                    }
                             data
                        }
                    }`,
        }),
      });
      const data = await res.json();
      return data;
    } catch (err) {
      return {
        data: {
          getPoints: {
            status: true,
            error: null,
            success: {
              message: 'Data found',
            },
            data: [],
          },
        },
      };
    }
  }
}
