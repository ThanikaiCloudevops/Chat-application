export const MODULE = { NAME: 'Master', PORT: 3000 };

export const userAuth = {
  graphUrl: 'http://3.7.135.45:5000/graphql',
  // graphUrl: 'http://localhost:5000/graphql',
};
export const wallet = {
  paymentURL: 'http://3.7.135.45:5005/payment/cashfree',

  // paymentURL: 'http://localhost:5005/payment/cashfree',
};

export const SUBGRAPH = [
  {
    name: 'user-auth',
    url: 'http://3.7.135.45:5000/graphql',
    // url: 'http://localhost:5000/graphql',
  },
  {
    name: 'game-module',
    url: 'http://3.7.135.45:5001/graphql',
    // url: 'http://localhost:5001/graphql',
  },
  {
    name: 'contest-module',
    url: 'http://3.7.135.45:5002/graphql',
    // url: 'http://localhost:5002/graphql',
  },
  {
    name: 'user-module',
    url: 'http://3.7.135.45:5004/graphql',
    // url: 'http://localhost:5004/graphql',
  },

  {
    name: 'scorecard-contest',
    url: 'http://3.7.135.45:4000/graphql',
    // url: 'http://localhost:4000/graphql',
  },
  {
    name: 'wallet-module',
    url: 'http://3.7.135.45:5005/graphql',
    // url: 'http://localhost:5005/graphql',
  },
  {
    name: 'masterData-module',
    url: 'http://3.7.135.45:5080/graphql',
    // url: 'http://localhost:5080/graphql',
  },
];
