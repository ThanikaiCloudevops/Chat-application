cd contests-module
nest build
pm2 start dist/src/main.js -f
cd ..

 

cd game-module
nest build
pm2 start dist/src/main.js -f
cd ..

 

cd scorcard-contest-module
nest build
pm2 start dist/src/main.js -f
cd ..

 

cd user-auth-module
nest build
pm2 start dist/src/main.js -f
cd ..

 

cd user-module
nest build
pm2 start dist/src/main.js -f
cd ..

 

cd wallet-module
nest build
pm2 start dist/src/main.js -f
cd ..

 

cd master-data-module
nest build
pm2 start dist/src/main.js -f
cd ..

 

cd master-server
nest build
pm2 start dist/src/main.js -f