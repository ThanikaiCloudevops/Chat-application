export const MODULE = { NAME: 'User Module', PORT: 5004 };
export const DB = {
  URL: 'mongodb+srv://sciflare:HEO6yUFoS7tmk3w0@krayzz22.vh8chph.mongodb.net/krayzz22',
};
export const VERSION = {
  androidVersion: '1.1.0',
  iosVersion: '1.1.0',
};

export const TRPC = {
  // development
  USERAUTH: 'http://3.7.135.45:5000/trpc/userauth',
  WALLET: 'http://3.7.135.45:5005/trpc/wallet',
  // Local
  // USERAUTH: 'http://localhost:5000/trpc/userauth',
  // WALLET: 'http://localhost:5005/trpc/wallet',
};

export const AWS = {
  AWS_ACCESSKEY: 'AKIA4CDUU23W5Y7HYZHZ',
  AWS_SECRET: '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',
  S3_REGION: 'ap-south-1',
  S3_BUCKET: 'krazyy22',
};

export const constant = {
  S3BaseURL: 'https://krazyy22.s3.ap-south-1.amazonaws.com/',
};
export const cashfree = {
  // clientId: 'CF10217085CPR9D5JHKINF28KR7UT0',
  // clientSecret: 'cfsk_ma_test_8b5b0e50e50620168997a97ca0b0adf5_dbf62e19',
  clientId: 'CF706614CQ74T4OQKEDS738EMIGG',
  clientSecret: 'cfsk_ma_prod_1f058b7e99b0f5650d7c088df3152e20_fb010853',
};
