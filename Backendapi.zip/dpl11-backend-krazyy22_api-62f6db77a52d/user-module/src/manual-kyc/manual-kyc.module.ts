import { Module } from '@nestjs/common';
import { ManualKycService } from './manual-kyc.service';
import { ManualKycResolver } from './manual-kyc.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import { userKYC, userKycSchema } from './entities/kyc.entity';
import { graphFileUpload } from 'src/helper/s3.upload';
import {
  UserProfile,
  UserProfileSchema,
} from 'src/user-profile/entities/user-profile.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: userKYC.name, schema: userKycSchema },
      { name: UserProfile.name, schema: UserProfileSchema },
    ]),
  ],
  providers: [ManualKycResolver, ManualKycService, graphFileUpload],
})
export class ManualKycModule {}
