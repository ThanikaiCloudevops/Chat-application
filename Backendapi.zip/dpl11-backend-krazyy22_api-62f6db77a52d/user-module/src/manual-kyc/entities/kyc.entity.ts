import { Field, ObjectType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export type userKycDocument = userKYC & Document;

@ObjectType()
@Schema()
export class userKYC {
  @Field()
  @Prop()
  userId: string;

  @Field()
  @Prop()
  DOB: string;

  @Field({ nullable: true })
  @Prop()
  firstName?: string;

  @Field({ nullable: true })
  @Prop()
  middleName?: string;

  @Field({ nullable: true })
  @Prop()
  lastName?: string;

  @Field({ nullable: true })
  @Prop()
  country?: string;

  @Field({ nullable: true })
  @Prop()
  address1?: string;

  @Field({ nullable: true })
  @Prop()
  address2?: string;

  @Field({ nullable: true })
  @Prop()
  city?: string;

  @Field({ nullable: true })
  @Prop()
  zipcode?: number;

  @Field({ nullable: true })
  @Prop()
  state?: string;

  @Field()
  @Prop()
  idProofType: string;

  @Field()
  @Prop()
  idProofId: string;

  @Prop()
  proofImgFront?: string;

  @Prop()
  proofImgBack?: string;

  @Field({ defaultValue: false })
  @Prop({ default: false })
  verified?: boolean;

  @Field({ defaultValue: false })
  @Prop({ default: false })
  rejected: boolean;

  @Field({ defaultValue: '' })
  @Prop()
  rejectedReason: string;
}

export const userKycSchema = SchemaFactory.createForClass(userKYC);
