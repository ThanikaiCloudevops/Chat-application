import { Args, Context, Mutation, Resolver, Query } from '@nestjs/graphql';
import { ManualKycService } from './manual-kyc.service';
import {
  kycDefaultFields,
  profileDefaultFields,
} from 'src/commonResponse/response.entity';
import { FileUpload, GraphQLUpload, Upload } from 'graphql-upload';
import { KycInput } from './dto/kyc.input';
import { UseGuards } from '@nestjs/common';
import { AuthGuard } from 'src/auth/auth.guard';

@Resolver()
@UseGuards(AuthGuard)
export class ManualKycResolver {
  constructor(private readonly manualKycService: ManualKycService) {}

  @Mutation(() => profileDefaultFields, { name: 'verifyKyc' })
  uploadCoverPhoto(
    @Args('frontImg')
    frontImg: string,
    @Args('backImg')
    backImg: string,
    @Args('input') userProfileInput: KycInput,
    @Context('user') user: any,
  ) {
    return this.manualKycService.uploadKyc(
      user?._id,
      userProfileInput,
      frontImg,
      backImg,
    );
  }
}
