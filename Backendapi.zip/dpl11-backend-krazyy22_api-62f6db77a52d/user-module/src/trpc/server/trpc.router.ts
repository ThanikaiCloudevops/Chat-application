import { INestApplication, Injectable } from '@nestjs/common';
import { z } from 'zod';
import { TrpcService } from './trpc.service';
import * as trpcExpress from '@trpc/server/adapters/express';
import { UserProfileService } from 'src/user-profile/user-profile.service';

@Injectable()
export class TrpcRouter {
  constructor(
    private readonly trpc: TrpcService,
    private userProfileService: UserProfileService,
  ) {}

  appRouter = this.trpc.router({
    balanceupdate: this.trpc.procedure
      .input(
        z.object({
          request: z.any(),
        }),
      )
      .query(({ input }) => {
        return this.userProfileService.updateBalance(input?.request);
      }),
    createUserProfile: this.trpc.procedure
      .input(
        z.object({
          request: z.any(),
        }),
      )
      .query(({ input }) => {
        return this.userProfileService.userProfileCreate(input?.request);
      }),
  });

  async applyMiddleware(app: INestApplication) {
    app.use(
      `/trpc/userprofile`,
      trpcExpress.createExpressMiddleware({
        router: this.appRouter,
        createContext: () => ({}),
      }),
    );
  }
}

export type AppRouter = TrpcRouter[`appRouter`];
