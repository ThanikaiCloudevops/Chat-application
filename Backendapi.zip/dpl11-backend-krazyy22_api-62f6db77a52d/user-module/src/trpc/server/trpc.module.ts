import { Module } from '@nestjs/common';
import { TrpcService } from './trpc.service';
import { TrpcRouter } from './trpc.router';
import { UserProfileService } from 'src/user-profile/user-profile.service';
import { graphFileUpload } from 'src/helper/s3.upload';
import { MongooseModule } from '@nestjs/mongoose';
import {
  UserProfile,
  UserProfileSchema,
} from 'src/user-profile/entities/user-profile.entity';
import {
  Notification,
  NotificationSchema,
} from 'src/user-profile/entities/notifications.entity';
import { trpcServices } from '../client/trpc';
import { States, StatesSchema } from 'src/user-profile/entities/state.entity';
import {
  Version,
  VersionSchema,
} from 'src/user-profile/entities/version.entity';
import { Banner, BannerSchema } from 'src/user-profile/entities/banners.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      // { name: userKYC.name, schema: userKycSchema },
      { name: UserProfile.name, schema: UserProfileSchema },
      { name: Notification.name, schema: NotificationSchema },
      { name: States.name, schema: StatesSchema },
      { name: Version.name, schema: VersionSchema },
      { name: Banner.name, schema: BannerSchema },
    ]),
    Notification,
  ],
  controllers: [],
  providers: [
    TrpcService,
    TrpcRouter,
    UserProfileService,
    graphFileUpload,
    trpcServices,
  ],
})
export class TrpcModule {}
