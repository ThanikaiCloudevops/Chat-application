import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { userKYC } from 'src/manual-kyc/entities/kyc.entity';
import { UserProfile } from 'src/user-profile/entities/user-profile.entity';
import { Notification } from 'src/user-profile/entities/notifications.entity';
import { States } from 'src/user-profile/entities/state.entity';
import { Banner } from 'src/user-profile/entities/banners.entity';
import { Schema } from '@nestjs/mongoose';

@ObjectType()
class updateProfileData {
  @Field({ defaultValue: '' })
  profilePic: string;
  @Field({ defaultValue: '' })
  gender: string;
  @Field({ defaultValue: '' })
  DOB: string;
  @Field({ defaultValue: '' })
  country: string;
}
@ObjectType()
export class usermessage {
  @Field({ nullable: true })
  message: string;
  @Field({ nullable: true, defaultValue: '' })
  location: string;
}

@ObjectType()
export class profileDefaultFields {
  @Field()
  status: boolean;

  @Field({ nullable: true })
  error: usermessage;

  @Field({ nullable: true })
  success: usermessage;
}

@ObjectType()
export class updateProfileResponse extends PartialType(profileDefaultFields) {
  @Field(() => updateProfileData, { nullable: true })
  data: updateProfileData;
}

@ObjectType()
@Schema()
export class BannerAllData {
  @Field(() => [Banner])
  cricket: Banner[];
  @Field(() => [Banner])
  football: Banner[];
  @Field(() => [Banner])
  kabaddi: Banner[];
}

@ObjectType()
export class BannerData extends PartialType(profileDefaultFields) {
  @Field(() => BannerAllData, { nullable: true })
  data: BannerAllData;
}

@ObjectType()
class plaidKYC {
  @Field({ nullable: true })
  webUrl: string;
  @Field({ nullable: true })
  kycId: string;
  @Field({ nullable: true })
  statusNumber: number;
}

@ObjectType()
export class plaidKycDefaultFields extends PartialType(profileDefaultFields) {
  @Field(() => plaidKYC, { nullable: true })
  data: plaidKYC;
}

@ObjectType()
export class kycDefaultFields extends PartialType(profileDefaultFields) {
  @Field(() => userKYC)
  data: userKYC;
}

@ObjectType()
class URL {
  @Field()
  url: string;
}

@ObjectType()
export class NotificationCollection extends PartialType(profileDefaultFields) {
  @Field(() => [Notification], { nullable: true })
  data: Notification[];
}

@ObjectType()
export class BankDets {
  @Field()
  name_at_bank: string;
  @Field()
  bank_name: string;
  @Field()
  city: string;
  @Field()
  branch: string;
  @Field()
  bank_account: string;
  @Field()
  ifsc: string;
}

@ObjectType()
class userProfileResponseData {
  @Field(() => UserProfile, { nullable: true })
  userProfile: UserProfile;
  @Field(() => [States], { nullable: 'itemsAndList' })
  states: States[];
  @Field(() => [Banner], { nullable: 'itemsAndList' })
  banners: Banner[];
  @Field({ defaultValue: '' })
  baseUrl: string;
  @Field({ defaultValue: 5 })
  bonusReductionPercentage: number;
  @Field(() => [BankDets], { nullable: 'itemsAndList' })
  bankAccounts: BankDets[];
}

@ObjectType()
export class UserProfileCollection extends PartialType(profileDefaultFields) {
  @Field(() => userProfileResponseData, { nullable: true })
  data: userProfileResponseData;
}

@ObjectType()
export class uploadResponse extends profileDefaultFields {
  @Field(() => URL, { nullable: true })
  data: URL;
}

// an optional type //data?: Prettify<dataFields>;
export type Prettify<T> = {
  [K in keyof T]: T[K];
} & object;
