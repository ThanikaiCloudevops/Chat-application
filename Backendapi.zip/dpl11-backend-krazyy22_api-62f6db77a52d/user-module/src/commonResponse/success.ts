const successMsg = {
  data: 'Data found',
  update: 'User profile updated successfully',
  upload: 'Image upload successful',
  kyc: 'KYC submitted for verification',
  kycip: 'KYC pending verification',
  kycsuccess: 'KYC verification success',
  kycerror: 'KYC verification failed',
  Notification: 'Notification list retrieved successfully',
  delete: 'User delete requested',
  banner: 'banner data found',
  pan: 'PAN verification successful',
};
export function successResponse(msg: string, data: any = null) {
  return { status: true, success: { message: successMsg[msg] }, data };
}
