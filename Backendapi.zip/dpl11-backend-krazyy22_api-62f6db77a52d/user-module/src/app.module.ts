import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserProfileModule } from './user-profile/user-profile.module';
import {
  ApolloFederationDriverConfig,
  ApolloFederationDriver,
} from '@nestjs/apollo';
import { MongooseModule } from '@nestjs/mongoose';
import { GraphQLModule } from '@nestjs/graphql';
import { TrpcModule } from './trpc/server/trpc.module';
import { DB } from 'config/envirnment';
import { KycVerifyModule } from './kyc-verify/kyc-verify.module';

@Module({
  imports: [
    MongooseModule.forRoot(DB.URL, {
      maxConnecting: 5,
      maxPoolSize: 5,
      connectTimeoutMS: 3000,
      socketTimeoutMS: 8000,
      maxIdleTimeMS: 10000,
    }),
    GraphQLModule.forRoot<ApolloFederationDriverConfig>({
      driver: ApolloFederationDriver,
      autoSchemaFile: {
        federation: 2,
      },
      includeStacktraceInErrorResponses: false,
    }),
    UserProfileModule,
    TrpcModule,
    KycVerifyModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
