import { ObjectType, Field, InputType } from '@nestjs/graphql';
import { Document } from 'mongoose';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export type versionDocument = Version & Document;

@Schema()
export class Version {

  @Prop()
  androidVersion: string;

  @Prop()
  iosVersion: string;

  @Prop()
  newAndroidVersion: number;

  @Prop()
  active: boolean;
}

export const VersionSchema = SchemaFactory.createForClass(Version);