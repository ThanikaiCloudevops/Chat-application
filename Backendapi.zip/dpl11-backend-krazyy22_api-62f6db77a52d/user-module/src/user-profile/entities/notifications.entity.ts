import { ObjectType, Field, PartialType, OmitType, Int } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
//import { defaultFields } from 'src/commonResponse/response.entity';

export type notificationDocument = Notification & Document;

@ObjectType()
@Schema()
export class Notification {
  @Field()
  @Prop()
  pn_title: string;
  @Field()
  @Prop()
  pn_message: string;
  @Field({ defaultValue: '' })
  @Prop()
  pn_image?: string;
  @Field({ nullable: true })
  @Prop()
  fixture_id?: number;
  @Field({ nullable: true })
  @Prop({ default: true })
  pn_receivers: string;
  @Field({ defaultValue: '' })
  @Prop()
  pn_sendType?: string;
  @Field()
  @Prop({ default: new Date() })
  pn_sendTime: Date;
  @Field({ defaultValue: 0 })
  @Prop()
  pn_status: number;
  @Field({ defaultValue: '' })
  @Prop({ default: true })
  pn_read?: string;
  @Field()
  @Prop({ default: false })
  status: boolean;
  @Field({ defaultValue: '' })
  @Prop()
  createdBy?: string;
  @Field()
  @Prop({ default: new Date() })
  createdat: Date;
  @Field({ defaultValue: '' })
  @Prop()
  updatedat?: Date;
  @Field({ defaultValue: '' })
  @Prop()
  deletedat?: Date;
}

@ObjectType()
class notificationResponse extends PartialType(
  OmitType(Notification, [] as const),
) {
  @Field()
  _id: string;
}

// @ObjectType()
// export class NotifiationRes extends PartialType(defaultFields) {
//   @Field({ nullable: true })
//   data: notificationResponse;
// }
@ObjectType()
class paginatedPayload {
  @Field(() => Int)
  totalPage: number;
  @Field(() => Int)
  currentPage: number;
  @Field(() => [notificationResponse], { nullable: true })
  list: notificationResponse[];
}

export const NotificationSchema = SchemaFactory.createForClass(Notification);
