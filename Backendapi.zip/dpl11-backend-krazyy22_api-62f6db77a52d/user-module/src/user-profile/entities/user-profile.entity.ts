import { ObjectType, Field, InputType } from '@nestjs/graphql';
import { Document } from 'mongoose';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export type userProfileDocument = UserProfile & Document;

@ObjectType()
@Schema()
export class UserProfile {
  @Field({ nullable: true, defaultValue: '' })
  @Prop({ index: true })
  userId?: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop({ default: '' })
  referalCode: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  userName: string;

  @Field({ defaultValue: '' })
  @Prop()
  firstName: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  lastName: string;

  @Field({ nullable: true, defaultValue: '' })
  email?: string;

  @Field({ nullable: true, defaultValue: '' })
  phone?: string;

  @Field({ defaultValue: 0 })
  @Prop({ default: 0 })
  kycStatus: number;

  @Field({ defaultValue: 0 })
  @Prop({ default: 0 })
  panStatus: number;

  @Field({ defaultValue: '' })
  @Prop()
  panId: string;

  @Field({ nullable: true })
  @Prop()
  panVerifiedAt?: Date;

  @Field({ defaultValue: false })
  @Prop({ default: false })
  profileStatus: boolean;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  primaryIdType?: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  primaryId?: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  secondaryIdType?: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  secondaryId?: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  country: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  city: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  address: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  zipcode: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  gender: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  DOB: string;

  @Field({ nullable: true, defaultValue: '' })
  @Prop()
  profilePic?: string;

  @Field(() => [Number], { nullable: true, defaultValue: [] })
  @Prop({ type: Array })
  favTeams: number[];

  @Field({ defaultValue: '' })
  @Prop()
  webUrl: string;

  @Field({ defaultValue: '' })
  @Prop()
  kycId: string;

  @Field({ nullable: true })
  @Prop()
  kycVerifiedAt?: Date;

  @Field({ defaultValue: 0 })
  userBalance: number;

  @Field({ defaultValue: 0 })
  totalWinnings: number;

  @Field({ defaultValue: 0 })
  totalBonus: number;

  @Field({ defaultValue: 0 })
  unutilisedBalance: number;

  @Field({ defaultValue: '' })
  androidVersion: string;

  @Field({ defaultValue: '' })
  iosVersion: string;

  @Field({ defaultValue: 0 })
  newAndroidVersion: number;
}

@InputType()
export class UserProfileInput extends UserProfile {}

export const UserProfileSchema = SchemaFactory.createForClass(UserProfile);
