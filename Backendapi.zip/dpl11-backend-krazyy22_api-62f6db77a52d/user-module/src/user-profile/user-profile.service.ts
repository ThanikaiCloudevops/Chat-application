import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { userProfileDocument } from './entities/user-profile.entity';
import { notificationDocument } from './entities/notifications.entity';
import { bannerDocument } from './entities/banners.entity';
import { successResponse } from 'src/commonResponse/success';
import { UpdateUserProfileInput } from './dto/update-user-profile.input';
import { trpcServices } from 'src/trpc/client/trpc';
import { commonErrors } from 'src/commonResponse/errors';
import { FileUpload, Upload } from 'graphql-upload';
import { graphFileUpload } from 'src/helper/s3.upload';
import { Readable } from 'stream';
import { statesDocument } from './entities/state.entity';
import { versionDocument } from './entities/version.entity';
import { VERSION, constant } from 'config/envirnment';

@Injectable()
export class UserProfileService {
  constructor(
    @InjectModel('UserProfile')
    private userProfileModel: Model<userProfileDocument>,
    @InjectModel('Notification')
    private notificationModel: Model<notificationDocument>,
    @InjectModel('States') private stateModel: Model<statesDocument>,
    @InjectModel('Version') private versionModel: Model<versionDocument>,
    private trpcService: trpcServices,
    private upload: graphFileUpload,
    @InjectModel('Banner')
    private bannerModel: Model<bannerDocument>,
  ) {}

  async findOne(user: any) {
    try {
      const id = user._id;
      let userbalance: any;
      try {
        userbalance = await this.trpcService.wallet('getwallet', id);
      } catch (err) {
        userbalance = {};
      }

      const banners = await this.bannerModel
        .find({ isactive: true })
        .sort({ position: 1 })
        .lean();

      const userProfile: any =
        (await this.userProfileModel
          .findOne({
            userId: user._id,
          })
          .lean()) || {};

      const versions = await this.versionModel.findOne({ active: true }).lean();
      userProfile.userName = user?.userName;
      userProfile.email = user?.email;
      userProfile.phone = user?.phone;
      userProfile.userBalance = userbalance?.data?.userBalance || 0;
      userProfile.totalWinnings = userbalance?.data?.totalWinnings || 0;
      userProfile.totalBonus = userbalance?.data?.totalBonus || 0;
      userProfile.unutilisedBalance = userbalance?.data?.unutilisedBalance || 0;
      userProfile.referalCode = user?.referral || '';
      userProfile.userId = user._id;
      userProfile.androidVersion = versions?.androidVersion || '1.1.0';
      userProfile.iosVersion = versions?.iosVersion || '1.1.0';
      userProfile.newAndroidVersion =
        versions?.newAndroidVersion || 7; /* Unique key for every build */
      const states = await this.stateModel.find({ isbaned: true });
      return successResponse('data', {
        banners,
        userProfile,
        states,
        baseUrl: constant.S3BaseURL || '',
        bankAccounts: userbalance?.data?.bankAccounts || [],
      });
    } catch (err) {
      return commonErrors('userprofile');
    }
  }

  async deleteUser() {
    return successResponse('delete');
  }

  async getbanner() {
    try {
      const banners = await this.bannerModel
        .find({ isactive: true, enableStatus: true })
        .sort({ position: 1 })
        .lean();
      const { cricket, football, kabaddi } = banners.reduce(
        (acc, item) => {
          switch (item.bannerSportType) {
            case 1:
              acc.cricket.push(item);
              break;
            case 2:
              acc.football.push(item);
              break;
            case 3:
              acc.kabaddi.push(item);
              break;
          }
          return acc;
        },
        { cricket: [], football: [], kabaddi: [] },
      );
      const data = { cricket, football, kabaddi };
      return successResponse('banner', data);
    } catch (error) {
      console.log(error);
    }
  }

  async updateUserProfile(
    userId: string,
    userProfileUpdate: UpdateUserProfileInput,
    Image?: string,
  ) {
    try {
      let dd = new Date(userProfileUpdate?.DOB?.split('-').reverse().join('-'));
      let currentDate = new Date();
      let isEligible = currentDate.getFullYear() - 18 >= dd.getFullYear();
      let yearDiff = currentDate.getFullYear() - dd.getFullYear() - 18;

      if (!userProfileUpdate?.DOB) isEligible = true;

      if (!isEligible) return commonErrors('undereighteen');

      if (!yearDiff) {
        let currentMonth = currentDate.getMonth() + 1;
        let currentDay = currentDate.getDate();
        let isMonth = dd.getMonth() + 1 > currentMonth;

        if (isMonth) return commonErrors('undereighteen');
        let isSameMonth = dd.getMonth() + 1 == currentMonth;
        if (isSameMonth && dd.getDate() > currentDay)
          return commonErrors('undereighteen');
      }

      userProfileUpdate.userId = userId;

      if (!(await this.userProfileModel.findOne({ userId }))) {
        userProfileUpdate.referalCode = this.#referalCodeGenerator(6);
        var UserProfile = await this.userProfileModel.create(userProfileUpdate);
        await this.trpcService.userAuth('profilestatus', {
          userId,
          profileStatus: true,
        });
      } else
        var UserProfile = await this.userProfileModel.findOneAndUpdate(
          { userId },
          { $set: userProfileUpdate },
        );

      if (Image) {
        const imgRes = await this.upload.uploadImage(
          `${userId}.png`,
          Image,
          'image/png',
        );
        UserProfile.profilePic = imgRes.url;
      }
      await UserProfile.save();

      return successResponse(
        'update',
        await this.userProfileModel.findOne({ userId }).lean(),
      );
    } catch (err) {
      console.log(err);
      return commonErrors('profile');
    }
  }

  async userProfileCreate(user: any) {
    console.log({user});
    var userProfile: any = {};
    var userProfileCreateResponse: any = {};
    if (!(await this.userProfileModel.findOne({ userId: user._id }))) {
      userProfile.userId = user._id;
      userProfile.referalCode = user.referral;
      userProfileCreateResponse = await this.userProfileModel.create(
        userProfile,
      );
    }
    return successResponse('created', userProfileCreateResponse);
  }

  async imageUpload(file: FileUpload) {
    try {
      const { status, url } = await this.upload.uploadImage(
        file.filename,
        file.createReadStream(),
        file.mimetype,
      );
      console.log(url);
      if (!status) throw new Error();

      return successResponse('upload', { url });
    } catch (err) {
      return commonErrors('upload');
    }
  }

  #referalCodeGenerator(length: number) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < length) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
    }
    return result;
  }

  async streamToBuffer(stream: Readable): Promise<Buffer> {
    const buffer: Uint8Array[] = [];

    return new Promise((resolve, reject) =>
      stream
        .on('error', (error) => reject(error))
        .on('data', (data) => buffer.push(data))
        .on('end', () => resolve(Buffer.concat(buffer))),
    );
  }

  async updateBalance(balanceObj: any) {
    try {
      return true;
    } catch (err) {
      return false;
    }
  }

  async userNotifications(user: any) {
    const data = await this.notificationModel
      .find({
        pn_receivers: user._id,
      })
      .sort('-pn_sendTime')
      .limit(30);
    return successResponse('notifications', data);
  }

  async readNotification(user: any, notificationId: string) {
    const notification = await this.notificationModel.findById({
      notificationId,
    });
  }
}
