import { UserProfileInput } from '../entities/user-profile.entity';
import { InputType, OmitType } from '@nestjs/graphql';

@InputType()
export class UpdateUserProfileInput extends OmitType(UserProfileInput, [
  'profileStatus',
  'kycStatus',
  'primaryId',
  'primaryIdType',
  'secondaryId',
  'secondaryIdType',
  'email',
  'phone',
  'webUrl',
  'kycId',
  'profilePic',
] as const) {}
