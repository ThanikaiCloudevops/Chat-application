import { Field, InputType } from '@nestjs/graphql';

@InputType()
export class kycInput {
  @Field()
  Id: string;

  @Field()
  frontImg: string;

  @Field({ nullable: true })
  backImg?: string;
}
