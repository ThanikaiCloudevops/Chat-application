import { Args, Context, Mutation, Resolver } from '@nestjs/graphql';
import { KycVerifyService } from './kyc-verify.service';
import { profileDefaultFields } from 'src/commonResponse/response.entity';
import { UseGuards } from '@nestjs/common';
import { AuthGuard } from 'src/auth/auth.guard';
import { kycInput } from './dto/kyc.input';

@Resolver()
@UseGuards(AuthGuard)
export class KycVerifyResolver {
  constructor(private readonly kycVerifyService: KycVerifyService) {}

  @Mutation(() => profileDefaultFields, { name: 'verifyUserKYC' })
  verifyUserKYC(@Context('user') user: any, @Args('input') kycInput: kycInput) {
    return this.kycVerifyService.kycVerify(
      user?._id,
      kycInput.Id,
      kycInput.frontImg,
      kycInput.backImg,
    );
  }

  @Mutation(() => profileDefaultFields, { name: 'verifyUserPAN' })
  verifyUserPAN(@Context('user') user: any, @Args('input') kycInput: kycInput) {
    return this.kycVerifyService.panVerify(
      user?._id,
      kycInput.Id,
      kycInput.frontImg,
    );
  }
}
