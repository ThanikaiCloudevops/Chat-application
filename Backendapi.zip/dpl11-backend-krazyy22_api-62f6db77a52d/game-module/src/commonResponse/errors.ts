import { GraphQLError } from 'graphql';

const errorMsg = {
  getkabaddiallfixtures: 'No Fixtures Found',
  getfootballallfixtures: 'No Fixtures Found',
  getallfixtures: 'No Fixtures Found',
  seriesGet: 'No series Found',
  teamGet: 'No teams Found',
  fixturenotfound: 'Fixture not found',
};
export function commonErrors(errorType: string, data: any = null) {
  return { status: false, error: { message: errorMsg[errorType] }, data };
}
export function handleException(error) {
  throw new GraphQLError(error, {
    extensions: {
      code: 'FORBIDDEN',
    },
  });
}
