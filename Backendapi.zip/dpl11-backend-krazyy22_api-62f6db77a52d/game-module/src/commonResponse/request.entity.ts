import { Field, InputType } from '@nestjs/graphql';

@InputType()
export class multiTeamsInput {
  @Field(() => [Number])
  teamIds: number[];
}

@InputType()
export class allFixturesInput {
  @Field()
  page: number;
  @Field()
  fixtureStatus: number;
  @Field(() => [Number], { defaultValue: [] })
  seriesAPIId?: number[];
}
