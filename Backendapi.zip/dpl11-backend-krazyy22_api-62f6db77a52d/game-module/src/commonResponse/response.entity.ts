import { ObjectType, Field, PartialType, InputType } from '@nestjs/graphql';

@ObjectType()
export class gamemessage {
  @Field({ nullable: true, defaultValue: '' })
  message: string;
  @Field({ nullable: true, defaultValue: '' })
  location: string;
}

@ObjectType()
class gamedataFields {
  @Field({ nullable: true, defaultValue: '' })
  token: string;
  @Field({ nullable: true, defaultValue: '' })
  user_id: string;
  @Field({ nullable: true, defaultValue: '' })
  email: string;
  @Field({ nullable: false, defaultValue: false })
  profileStatus: boolean;
}

@ObjectType()
export class gamedefaultFields {
  @Field()
  status: boolean;

  @Field({ nullable: true })
  error: gamemessage;

  @Field({ nullable: true })
  success: gamemessage;
}

@ObjectType()
export class gameJsonResponse extends PartialType(gamedefaultFields) {
  @Field({ nullable: true })
  data?: gamedataFields;
}

@ObjectType()
export class players {
  @Field({ defaultValue: '' })
  playerName: string;
  @Field({ defaultValue: '' })
  playerDisplayName: string;
  @Field({ defaultValue: 0 })
  playerAPIId: number;
  @Field({ defaultValue: '' })
  playerType: string;
  @Field({ defaultValue: '' })
  teamName: string;
  @Field({ defaultValue: 0 })
  teamAPIId: number;
  @Field({ defaultValue: '' })
  teamDisplayName: string;
  @Field({ defaultValue: '' })
  imgUrl: string;
  @Field({ defaultValue: 0 })
  playerValue: number;
  @Field({ defaultValue: 0 })
  selected: number;
  @Field({ defaultValue: 0 })
  selectedCap: number;
  @Field({ defaultValue: 0 })
  selectedVC: number;
  @Field({ defaultValue: '' })
  teamJersey: string;
  @Field({ defaultValue: 0 })
  points: number;
  @Field({ defaultValue: '' })
  playerImg: string;
}

@ObjectType()
export class playerResponse extends PartialType(players) {
  @Field({ defaultValue: false })
  in11: boolean;
  @Field({ defaultValue: false })
  lineUpOut: boolean;
}

@ObjectType()
export class playersCollection extends PartialType(gamedefaultFields) {
  @Field(() => [playerResponse], { nullable: true })
  data: playerResponse[];
}

@ObjectType()
export class footballplayers {
  @Field({ defaultValue: '' })
  playerName: string;
  // @Field({ defaultValue: '' })
  // playerDisplayName: string;
  @Field({ defaultValue: 0 })
  playerAPIId: number;
  @Field({ defaultValue: '' })
  positionType: string;
  @Field({ defaultValue: '' })
  teamName: string;
  @Field({ defaultValue: 0 })
  teamAPIId: number;
  @Field({ defaultValue: '' })
  teamDisplayName: string;
  @Field({ defaultValue: '' })
  positionName: string;
  @Field({ defaultValue: '' })
  imgUrl: string;
  @Field({ defaultValue: 0 })
  playerValue: number;
  @Field({ defaultValue: 0 })
  selected: number;
  @Field({ defaultValue: 0 })
  selectedCap: number;
  @Field({ defaultValue: 0 })
  selectedVC: number;
  @Field({ defaultValue: '' })
  teamJersey: string;
  @Field({ defaultValue: 0 })
  points: number;
  @Field({ defaultValue: '' })
  playerImg: string;
}

@ObjectType()
export class kabaddiplayers {
  @Field({ defaultValue: '' })
  playerName: string;
  // @Field({ defaultValue: '' })
  // playerDisplayName: string;
  @Field({ defaultValue: 0 })
  playerAPIId: number;
  @Field({ defaultValue: '' })
  positionType: string;
  @Field({ defaultValue: '' })
  teamName: string;
  @Field({ defaultValue: 0 })
  teamAPIId: number;
  @Field({ defaultValue: '' })
  teamDisplayName: string;
  @Field({ defaultValue: '' })
  positionName: string;
  @Field({ defaultValue: '' })
  imgUrl: string;
  @Field({ defaultValue: 0 })
  playerValue: number;
  @Field({ defaultValue: 0 })
  selected: number;
  @Field({ defaultValue: 0 })
  selectedCap: number;
  @Field({ defaultValue: 0 })
  selectedVC: number;
  @Field({ defaultValue: '' })
  teamJersey: string;
  @Field({ defaultValue: 0 })
  points: number;
  @Field({ defaultValue: '' })
  playerImg: string;
}

@ObjectType()
export class footballplayerResponse extends PartialType(footballplayers) {
  @Field({ defaultValue: false })
  in11: boolean;
  @Field({ defaultValue: false })
  lineUpOut: boolean;
}

@ObjectType()
export class kabaddiplayerResponse extends PartialType(kabaddiplayers) {
  @Field({ defaultValue: false })
  in11: boolean;
  @Field({ defaultValue: false })
  lineUpOut: boolean;
}

@ObjectType()
export class footballplayersCollection extends PartialType(gamedefaultFields) {
  @Field(() => [footballplayerResponse], { nullable: true })
  data: footballplayerResponse[];
}

@ObjectType()
export class kabaddiplayersCollection extends PartialType(gamedefaultFields) {
  @Field(() => [kabaddiplayerResponse], { nullable: true })
  data: kabaddiplayerResponse[];
}

// an optional type //data?: Prettify<dataFields>;
export type Prettify<T> = {
  [K in keyof T]: T[K];
} & object;
