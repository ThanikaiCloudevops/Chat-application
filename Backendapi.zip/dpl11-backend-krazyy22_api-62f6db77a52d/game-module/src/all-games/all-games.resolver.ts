import { Resolver, Query, Args, Context, Mutation } from '@nestjs/graphql';
import { AllGamesService } from './all-games.service';
import {
  fixturePagination,
  myFixtureAll,
  singleFixture,
} from './entities/fixtures.entity';
import { seriesCollection } from './entities/series.entity';
import {
  FootballTeamCollection,
  TeamCollection,
  myTeamsResponse,
  seriesTeamsResponse,
} from './entities/team-players.entity';
import { AuthGuard } from 'src/auth/auth.guard';
import { UseGuards } from '@nestjs/common';
import {
  footballplayersCollection,
  kabaddiplayersCollection,
  playersCollection,
} from 'src/commonResponse/response.entity';
import {
  allFixturesInput,
  multiTeamsInput,
} from 'src/commonResponse/request.entity';
import { FootballSeriesCollection } from './entities/footballseries.entity';
import {
  FootballFixturePagination,
  footballMyFixtureAll,
  footballSingleFixture,
} from './entities/footballfixtures.entity';
import { KabaddiSeriesCollection } from './entities/kabaddiseries.entity';
import {
  KabaddiFixturePagination,
  kabaddiMyFixtureAll,
  kabaddiSingleFixture,
} from './entities/kabaddifixtures.entity';
import { query } from 'express';

@Resolver()
@UseGuards(AuthGuard)
export class AllGamesResolver {
  constructor(private readonly allGamesService: AllGamesService) {}

  //Get fixtures pagination
  @Mutation(() => fixturePagination, {
    name: 'cricketAllFixtures',
    description: 'To get all fixtures',
  })
  getAllFixtures(
    @Context('user') user: any,
    @Args('input') getFixturesInput: allFixturesInput,
  ) {
    const page = !getFixturesInput.page ? 1 : getFixturesInput.page;
    return this.allGamesService.getAllFixtures(
      page,
      getFixturesInput.fixtureStatus,
      getFixturesInput.seriesAPIId,
    );
  }

  @Query(() => myFixtureAll, {
    name: 'cricketPremiumMatch',
    description: 'To get all fixtures',
  })
  getFixturesPin(@Args('fixtureStatus') fixtureStatus: number) {
    return this.allGamesService.getFixturesPremiumMatch(fixtureStatus);
  }

  @Query(() => footballMyFixtureAll, {
    name: 'footballPremiumMatch',
    description: 'To get all fixtures',
  })
  getfootballFixturesPin(@Args('fixtureStatus') fixtureStatus: number) {
    return this.allGamesService.getfootballFixturesPremiumMatch(fixtureStatus);
  }

  @Query(() => kabaddiMyFixtureAll, {
    name: 'kabaddiPremiumMatch',
    description: 'To get all fixtures',
  })
  getkabaddiFixturesPin(@Args('fixtureStatus') fixtureStatus: number) {
    return this.allGamesService.getkabaddiFixturesPremiumMatch(fixtureStatus);
  }

  //Get fixtures pagination
  @Query(() => fixturePagination, {
    name: 'myFixtures',
    description: 'To get all fixtures',
  })
  getMyFixtures(
    @Context('user') user: any,
    @Args('page') page: number,
    @Args('fixtureStatus') fixtureStatus: number,
  ) {
    page = !page ? 1 : page;
    return this.allGamesService.getMyFixtures(page, fixtureStatus, user['_id']);
  }

  //Get fixtures pagination
  @Query(() => myFixtureAll, {
    name: 'myFixturesAll',
    description: 'To get all fixtures',
  })
  getMyFixturesAll(@Context('user') user: any) {
    return this.allGamesService.getAllMyFixture(user['_id']);
  }

  //Get fixtures detail
  @Query(() => singleFixture, {
    name: 'cricketFixtureDatail',
    description: 'To get all fixtures',
  })
  getFixture(@Args('fixtureAPIId') fixtureAPIId: number) {
    return this.allGamesService.fixturedetail(fixtureAPIId);
  }

  @Query(() => seriesCollection, {
    name: 'cricketAllSeries',
    description: 'To get all series',
  })
  getAllSeries() {
    return this.allGamesService.getAllSeries();
  }

  @Query(() => TeamCollection, {
    name: 'cricketListTeams',
    description: 'To get all players by team Ids',
  })
  ListTeams(
    @Args('teamAId') teamAId: number,
    @Args('teamBId') teamBId: number,
  ) {
    return this.allGamesService.getFixturePlayers([teamAId, teamBId]);
  }

  // @Mutation(() => myTeamsResponse, {
  //   name: 'getMulitpleTeams',
  //   description: 'To get multiple teams by Ids',
  // })
  // testAPI(@Args('input') multiteamInput: multiTeamsInput) {
  //   return this.allGamesService.multipleTeams(multiteamInput.teamIds);
  // }

  @Query(() => playersCollection, {
    name: 'cricketGetTeamsbyFixture',
    description: 'To get all players in a fixture',
  })
  getTeamsbyFixture(@Args('fixtureAPIId') fixtureAPIId: number) {
    return this.allGamesService.getTeamsbyFixture(fixtureAPIId);
  }

  @Query(() => seriesTeamsResponse, {
    name: 'getTeamsbySeries',
    description: 'To get all players in a series',
  })
  getTeamsbySeries(@Args('seriesAPIId') seriesAPIId: number) {
    return this.allGamesService.getSeriesTeams(seriesAPIId);
  }

  @Mutation(() => FootballFixturePagination, {
    name: 'footballAllFixtures',
    description: 'To get all fixtures',
  })
  getfootballAllFixtures(
    @Context('user') user: any,
    @Args('input') getFixturesInput: allFixturesInput,
  ) {
    const page = !getFixturesInput.page ? 1 : getFixturesInput.page;
    return this.allGamesService.getfootballAllFixtures(
      page,
      getFixturesInput.fixtureStatus,
      getFixturesInput.seriesAPIId,
    );
  }

  //football fixture
  @Query(() => FootballFixturePagination, {
    name: 'footballMyFixtures',
    description: 'To get all football fixtures',
  })
  getFootbalMyFixtures(
    @Context('user') user: any,
    @Args('page') page: number,
    @Args('fixtureStatus') fixtureStatus: number,
  ) {
    page = !page ? 1 : page;
    return this.allGamesService.getFootballMyFixtures(
      page,
      fixtureStatus,
      user._id,
    );
  }

  @Query(() => footballMyFixtureAll, {
    name: 'footballMyFixturesAll',
    description: 'To get Football all fixtures',
  })
  getFootballMyFixturesAll(@Context('user') user: any) {
    return this.allGamesService.getFootballAllMyFixture(user['_id']);
  }

  //Get fixtures detail
  @Query(() => footballSingleFixture, {
    name: 'footballFixtureDatail',
    description: 'To get all fixtures',
  })
  getFootballFixture(@Args('fixtureAPIId') fixtureAPIId: number) {
    return this.allGamesService.footballfixturedetail(fixtureAPIId);
  }

  @Query(() => FootballSeriesCollection, {
    name: 'footballAllSeries',
    description: 'To get all football series',
  })
  getAllFootballSeries() {
    return this.allGamesService.getAllFootballSeries();
  }

  @Query(() => FootballTeamCollection, {
    name: 'footballListTeams',
    description: 'To get all players by team Ids',
  })
  FootballListTeams(
    @Args('teamAId') teamAId: number,
    @Args('teamBId') teamBId: number,
  ) {
    return this.allGamesService.getFootballFixturePlayers([teamAId, teamBId]);
  }

  // @Mutation(() => myTeamsResponse, {
  //   name: 'getFootballMulitpleTeams',
  //   description: 'To get multiple teams by Ids',
  // })
  // getFootballmultipleTeams(@Args('input') multiteamInput: multiTeamsInput) {
  //   return this.allGamesService.footballmultipleTeams(multiteamInput.teamIds);
  // }

  @Query(() => footballplayersCollection, {
    name: 'footballGetTeamsbyFixture',
    description: 'To get all players in a fixture',
  })
  getFootballTeamsbyFixture(@Args('fixtureAPIId') fixtureAPIId: number) {
    return this.allGamesService.getFootballTeamsbyFixture(fixtureAPIId);
  }

  @Query(() => seriesTeamsResponse, {
    name: 'getFootballTeamsbySeries',
    description: 'To get all players in a series',
  })
  getFootballTeamsbySeries(@Args('seriesAPIId') seriesAPIId: number) {
    return this.allGamesService.getFootballTeamsbySeries(seriesAPIId);
  }

  @Query(() => KabaddiSeriesCollection, {
    name: 'kabaddiAllSeries',
    description: 'To get all kabaddi series',
  })
  getAllKabadiSeries() {
    return this.allGamesService.getAllKabaddiSeries();
  }

  @Mutation(() => KabaddiFixturePagination, {
    name: 'kabaddiAllFixtures',
    description: 'To get all fixtures',
  })
  getkabaddiAllFixtures(
    @Context('user') user: any,
    @Args('input') getFixturesInput: allFixturesInput,
  ) {
    const page = !getFixturesInput.page ? 1 : getFixturesInput.page;
    return this.allGamesService.getkabaddiAllFixtures(
      page,
      getFixturesInput.fixtureStatus,
      getFixturesInput.seriesAPIId,
    );
  }

  @Query(() => kabaddiMyFixtureAll, {
    name: 'kabaddiMyFixturesAll',
    description: 'To get Kabaddi all fixtures',
  })
  getKabaddiMyFixturesAll(@Context('user') user: any) {
    return this.allGamesService.getKabaddiAllMyFixture(user['_id']);
  }

  @Query(() => KabaddiFixturePagination, {
    name: 'kabaddiMyFixtures',
    description: 'To get all kabaddi fixtures',
  })
  getKabaddiMyFixtures(
    @Context('user') user: any,
    @Args('page') page: number,
    @Args('fixtureStatus') fixtureStatus: number,
  ) {
    page = !page ? 1 : page;
    return this.allGamesService.getKabaddiMyFixtures(
      page,
      fixtureStatus,
      user._id,
    );
  }

  @Query(() => kabaddiplayersCollection, {
    name: 'kabaddiGetTeamsbyFixture',
    description: 'To get all players in a fixture',
  })
  getKabaddiTeamsbyFixture(@Args('fixtureAPIId') fixtureAPIId: number) {
    return this.allGamesService.getKabaddiTeamsbyFixture(fixtureAPIId);
  }

  @Query(() => kabaddiSingleFixture, {
    name: 'kabaddiFixtureDatail',
    description: 'To get all fixtures',
  })
  getKabadiFixture(@Args('fixtureAPIId') fixtureAPIId: number) {
    return this.allGamesService.kabaddifixturedetail(fixtureAPIId);
  }
}
