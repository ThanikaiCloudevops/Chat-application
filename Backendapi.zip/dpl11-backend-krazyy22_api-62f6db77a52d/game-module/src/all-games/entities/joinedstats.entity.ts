import { ObjectType, Field } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type joinedPlayerStatsDocument = joinedPlayerStats & Document;

@ObjectType()
export class userContestTeams {
  @Field({ defaultValue: '' })
  userId: string;

  @Field({ defaultValue: 0 })
  userTeams: number;

  @Field({ defaultValue: 0 })
  userJoinedContest: number;
}

@ObjectType()
@Schema()
export class joinedPlayerStats {
  @Field()
  @Prop({ index: true })
  fixtureAPIId: number;

  @Field(() => [userContestTeams])
  @Prop()
  userStats: userContestTeams[];
}

export const joinedPlayerStatsSchema =
  SchemaFactory.createForClass(joinedPlayerStats);
