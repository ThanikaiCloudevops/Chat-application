import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type kabaddiTeamPlayersDocument = KabaddiTeamPlayers & Document;

export class Squads {
  @Prop()
  playerAPIId: number;
  @Prop()
  playerName: string;
  @Prop()
  birthdate: Date;
  @Prop()
  nationality: string;
  @Prop()
  positionType: string;
  @Prop()
  positionName: string;
  @Prop()
  height: number;
  @Prop()
  weight: number;
  @Prop()
  foot: string;
  @Prop()
  fantasyCredit: number;
}

@Schema()
export class KabaddiTeamPlayers {
  @Prop()
  teamAPIId: number;
  @Prop()
  teamName: string;
  @Prop()
  teamFullName: string;
  @Prop()
  teamDisplayName: string;
  @Prop()
  isclub: boolean;
  @Prop()
  founded: number;
  @Prop()
  teamLogo: string;
  @Prop()
  squads: Squads[];
  @Prop()
  isactive: boolean;
}

export const KabaddiTeamPlayersSchema =
  SchemaFactory.createForClass(KabaddiTeamPlayers);
