import { ObjectType, Field, PartialType, OmitType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { gamedefaultFields } from 'src/commonResponse/response.entity';

export type teamplayersDocument = TeamPlayers & Document;

@ObjectType()
export class Values {
  @Field()
  Test: string;

  @Field()
  ODI: string;

  @Field()
  T20: string;
}

@ObjectType()
export class Players {
  @Field()
  playerName: string;

  @Field()
  playerAPIId: number;

  @Field()
  player_type: string;

  @Field()
  playerDisplayName: string;

  @Field(() => Values)
  player_value: Values;

  @Field({ defaultValue: '' })
  playerImg: string;
}

@ObjectType()
@Schema()
export class TeamPlayers {
  @Field()
  @Prop()
  teamName: string;

  @Field()
  @Prop()
  teamDisplayName: string;

  @Field()
  @Prop({ index: true })
  teamAPIId: number;

  @Field()
  @Prop({ index: true })
  sereisAPIId: number;

  @Field()
  @Prop()
  teamLogo: string;

  @Field(() => [Players])
  @Prop()
  teamPlayers: Players;

  @Field({ defaultValue: '' })
  @Prop()
  teamJersey: string;
}

@ObjectType()
export class FootballPlayers {
  @Field()
  playerName: string;

  @Field()
  playerAPIId: number;

  @Field()
  positionType: string;

  @Field()
  positionName: string;

  @Field()
  fantasyCredit: number;

  @Field()
  playerDisplayName: string;

  @Field(() => Values)
  player_value: Values;

  @Field({ defaultValue: '' })
  playerImg: string;
}

@ObjectType()
@Schema()
export class FootballTeamPlayers {
  @Field()
  @Prop()
  teamName: string;

  @Field()
  @Prop()
  teamDisplayName: string;

  @Field()
  @Prop({ index: true })
  teamAPIId: number;

  @Field()
  @Prop()
  teamLogo: string;

  @Field(() => [FootballPlayers])
  @Prop()
  squads: FootballPlayers;

  @Field({ defaultValue: '' })
  @Prop()
  teamJersey: string;
}

@ObjectType()
class TeamsRes extends PartialType(OmitType(TeamPlayers, ['teamPlayers'])) {}

@ObjectType()
export class seriesTeamsResponse extends PartialType(gamedefaultFields) {
  @Field(() => [TeamsRes], { nullable: true })
  data: TeamsRes[];
}

@ObjectType()
export class myteams extends PartialType(
  OmitType(TeamPlayers, ['teamPlayers' /* 'teamAPIId' */]),
) {
  // @Field()
  // teamAPIId: number;
}

@ObjectType()
export class myTeamsResponse extends PartialType(gamedefaultFields) {
  @Field(() => [myteams], { nullable: true })
  data: myteams[];
}

@ObjectType()
export class TeamCollection extends PartialType(gamedefaultFields) {
  @Field(() => [TeamPlayers], { nullable: true })
  data: TeamPlayers[];
}

@ObjectType()
export class FootballTeamCollection extends PartialType(gamedefaultFields) {
  @Field(() => [FootballTeamPlayers], { nullable: true })
  data: FootballTeamPlayers[];
}

export const TeamPlayerSchema = SchemaFactory.createForClass(TeamPlayers);
