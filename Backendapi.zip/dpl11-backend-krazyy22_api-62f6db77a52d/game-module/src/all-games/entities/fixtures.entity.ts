import { ObjectType, Field, PartialType, Int } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { gamedefaultFields } from 'src/commonResponse/response.entity';

export type fixtureDocument = cricketFixtures & Document;

@ObjectType()
export class Teams {
  // @Field()
  // id: string;

  @Field()
  teamAPIId: number;

  @Field()
  name: string;

  @Field()
  shortName: string;

  @Field()
  logo: string;
}

@ObjectType()
export class fixtureTeams {
  @Field(() => Teams)
  teamA: Teams;

  @Field(() => Teams)
  teamB: Teams;
}

@ObjectType()
@Schema()
export class cricketFixtures {
  @Field()
  _id: string;

  @Field()
  @Prop()
  fixtureName: string;

  @Field()
  @Prop({ index: true })
  fixtureAPIId: number;

  @Field()
  @Prop()
  fixtureDisplayName: string;

  @Field()
  @Prop()
  fixtureStartDate: Date;

  @Field()
  @Prop()
  fixtureStatus: string;

  @Field()
  @Prop()
  fixtureStatusType: number;

  @Field()
  @Prop()
  fixtureVenue: string;

  @Field()
  @Prop()
  fixtureType: string;

  @Field()
  @Prop()
  seriesName: string;

  @Field()
  @Prop()
  seriesShortName: string;

  @Field()
  @Prop()
  seriesAPIId: number;

  @Field(() => fixtureTeams)
  @Prop()
  fixtureTeams: fixtureTeams;

  @Field()
  @Prop({ default: false })
  lineupsOut: boolean;

  @Field()
  @Prop()
  fixtureFormat: number;

  @Field()
  @Prop({ default: false })
  enabledStatus: boolean;

  @Field({ defaultValue: 'Mega Contest' })
  @Prop()
  contestStr: string;

  @Field()
  @Prop({ default: true, index: true })
  isactive: boolean;

  @Field(() => [String], { nullable: true })
  @Prop({ default: true, index: true })
  joinedUsers?: string[];

  @Field({ nullable: true, defaultValue: 0 })
  @Prop()
  maxPrize: number;

  @Field({ defaultValue: 0 })
  myContestCount: number;

  @Field({ defaultValue: 0 })
  myTeamsCount: number;
  footballFixtureTeams: any;
}

@ObjectType()
class gamepaginatedPayload {
  @Field(() => Int)
  totalPage: number;
  @Field(() => Int)
  currentPage: number;
  @Field({ defaultValue: 20 })
  maxTeamCount: number;
  @Field(() => [cricketFixtures], { nullable: true })
  list: cricketFixtures[];
}
@ObjectType()
export class fixturePagination extends PartialType(gamedefaultFields) {
  @Field({ nullable: true })
  data: gamepaginatedPayload;
}

@ObjectType()
export class myFixtureAll extends PartialType(gamedefaultFields) {
  @Field(() => [cricketFixtures], { nullable: 'itemsAndList' })
  data: cricketFixtures[];
}
@ObjectType()
export class singleFixture extends PartialType(gamedefaultFields) {
  @Field({ nullable: true })
  data: cricketFixtures;
}
export const FixturesSchema = SchemaFactory.createForClass(cricketFixtures);
