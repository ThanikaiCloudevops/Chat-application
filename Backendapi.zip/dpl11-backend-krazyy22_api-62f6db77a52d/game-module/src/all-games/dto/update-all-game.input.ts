import { CreateAllGameInput } from './create-all-game.input';
import { InputType, Field, Int, PartialType } from '@nestjs/graphql';

@InputType()
export class UpdateAllGameInput extends PartialType(CreateAllGameInput) {
  @Field(() => Int)
  id: number;
}
