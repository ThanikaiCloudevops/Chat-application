import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import { TRPC } from 'config/envirnment';
import fetch from 'node-fetch';

const globalAny = global as any;
globalAny.AbortController = AbortController;
globalAny.fetch = fetch;

export const userAuth = createTRPCProxyClient({
  links: [httpBatchLink({ url: TRPC.USERAUTH })],
});
