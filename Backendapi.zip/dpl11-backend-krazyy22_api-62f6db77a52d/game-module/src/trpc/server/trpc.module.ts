import { Module } from '@nestjs/common';
import { TrpcService } from './trpc.service';
import { TrpcRouter } from './trpc.router';
import { MongooseModule } from '@nestjs/mongoose';
import {
  cricketFixtures,
  FixturesSchema,
} from 'src/all-games/entities/fixtures.entity';
import { Series, SeriesSchema } from 'src/all-games/entities/series.entity';
import {
  TeamPlayers,
  TeamPlayerSchema,
} from 'src/all-games/entities/team-players.entity';
import { AllGamesService } from 'src/all-games/all-games.service';
import { Lineup, LineUpSchema } from 'src/all-games/entities/lineup.entity';
import {
  selectedBy,
  selectedBySchema,
} from 'src/all-games/entities/selectedby.entity';
import {
  seriesPoints,
  seriesPointsSchema,
} from 'src/all-games/entities/seriespoints.entity';
import {
  joinedPlayerStats,
  joinedPlayerStatsSchema,
} from 'src/all-games/entities/joinedstats.entity';
import {
  FootballSeries,
  FootballSeriesSchema,
} from 'src/all-games/entities/footballseries.entity';
import {
  FootballFixtures,
  FootballFixturesSchema,
} from 'src/all-games/entities/footballfixtures.entity';
import {
  FootballTeamPlayers,
  FootballTeamPlayersSchema,
} from 'src/all-games/entities/footballteamplayers.entity';
import {
  FootballLineup,
  FootballLineupSchema,
} from 'src/all-games/entities/football-lineup.entity';
import {
  KabaddiSeries,
  kabaddiSeriesSchema,
} from 'src/all-games/entities/kabaddiseries.entity';
import {
  KabaddiFixtures,
  KabaddiFixturesSchema,
} from 'src/all-games/entities/kabaddifixtures.entity';
import {
  KabaddiTeamPlayers,
  KabaddiTeamPlayersSchema,
} from 'src/all-games/entities/kabadditeamplayers.entity';
import { KabaddiLineup } from 'src/all-games/entities/kabaddi-lineup.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Lineup.name, schema: LineUpSchema },
      { name: cricketFixtures.name, schema: FixturesSchema },
      { name: Series.name, schema: SeriesSchema },
      { name: TeamPlayers.name, schema: TeamPlayerSchema },
      { name: selectedBy.name, schema: selectedBySchema },
      { name: joinedPlayerStats.name, schema: joinedPlayerStatsSchema },
      { name: seriesPoints.name, schema: seriesPointsSchema },
      { name: FootballSeries.name, schema: FootballSeriesSchema },
      { name: FootballFixtures.name, schema: FootballFixturesSchema },
      { name: FootballTeamPlayers.name, schema: FootballTeamPlayersSchema },
      { name: FootballLineup.name, schema: FootballLineupSchema },
      { name: KabaddiSeries.name, schema: kabaddiSeriesSchema },
      { name: KabaddiFixtures.name, schema: KabaddiFixturesSchema },
      { name: KabaddiTeamPlayers.name, schema: KabaddiTeamPlayersSchema },
      { name: KabaddiLineup.name, schema: kabaddiSeriesSchema },
    ]),
  ],
  controllers: [],
  providers: [TrpcService, TrpcRouter, AllGamesService],
})
export class TrpcModule {}
