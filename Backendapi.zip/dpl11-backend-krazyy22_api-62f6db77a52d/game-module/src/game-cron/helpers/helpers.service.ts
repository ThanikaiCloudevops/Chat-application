import { Injectable } from '@nestjs/common';

@Injectable()
export class HelpersService {
  formatSeries(series: any) {
    return {
      seriesName: series.title,
      apiId: series.cid,
      seriesDisplayName: series.abbr,
      seriesStartDate: series.date_start,
      seriesStatus: series.status,
      seriesFormat: series.match_format,
    };
  }

  formatFixtures(item: any) {
    const fixture = item.fixtureMatch;
    return {
      fixtureName: fixture.title,
      fixtureAPIId: fixture.match_id,
      fixtureDisplayName: fixture.short_title,
      fixtureStartDate: fixture.date_start,
      fixtureStatus: fixture.status_str,
      fixtureVenue: fixture.venue.name,
      fixtureType: fixture.format_str,
      seriesName: item.title,
      seriesShortName: item.short_name,
      seriesAPIId: item.cid,
      fixtureTeams: {
        teamA: this.#team(fixture.teama),
        teamB: this.#team(fixture.teamb),
      },
    };
  }

  #team(team: { name: any; short_name: any; team_id: any; logo_url: any }) {
    return {
      name: team.name,
      shortName: team.short_name,
      teamAPIId: team.team_id,
      logo: team.logo_url,
    };
  }

  initilizeTeam(item: any) {
    return {
      teamName: item.team.title,
      teamDisplayName: item.team.abbr,
      teamAPIId: item.team.tid,
      teamLogo: item.team.logo_url,
      teamPlayers: [],
    };
  }

  formatTeamPlayers(item: any) {
    return {
      playerName: item.players.title,
      playerAPIId: item.players.pid,
      player_type: item.players.playing_role,
      playerDisplayName: item.players.short_name,
      player_value: {
        Test: item.players.fantasy_player_rating,
        ODI: item.players.fantasy_player_rating,
        T20: item.players.fantasy_player_rating,
      },
    };
  }
}
