import { Args, Query, Resolver } from '@nestjs/graphql';
import { gameJsonResponse } from 'src/commonResponse/response.entity';
import { Cron, GameService } from './game-cron.service';

@Resolver()
export class GameCronResolver {
  constructor(
    private readonly cronService: Cron,
    private readonly gameService: GameService,
  ) {}

  @Query(() => gameJsonResponse, {
    name: 'circketUpdateSeries',
    description: 'To update series manually',
  })
  async seriesUpdation() {
    return await this.gameService.seriesUpdate();
  }

  @Query(() => gameJsonResponse, {
    name: 'circketUpdateFixtures',
    description: 'To update fixtures manually',
  })
  async fixturesUpdation() {
    return await this.gameService.fixturesUpdate();
  }

  @Query(() => gameJsonResponse, {
    name: 'circketUpdateTeamPlayers',
    description: 'To update teams and players manually',
  })
  async teamPlayersUpdation() {
    return await this.gameService.teamPlayersUpdate();
  }

  @Query(() => gameJsonResponse, {
    name: 'circketSeriesCronStart',
    description: 'To start series updation cron',
  })
  async seriesCronStart(@Args('cron') cron: boolean) {
    return this.cronService.seriesCron(cron);
  }

  @Query(() => gameJsonResponse, {
    name: 'circketFixturesCronStart',
    description: 'To start series updation cron',
  })
  async fixturesCronStart(@Args('cron') cron: boolean) {
    return this.cronService.fixturesCron(cron);
  }

  @Query(() => gameJsonResponse, {
    name: 'circketTeamPlayersCronStart',
    description: 'To start series updation cron',
  })
  async teamPlayersCronStart(@Args('cron') cron: boolean) {
    return this.cronService.teamPlayersCron(cron);
  }
}
