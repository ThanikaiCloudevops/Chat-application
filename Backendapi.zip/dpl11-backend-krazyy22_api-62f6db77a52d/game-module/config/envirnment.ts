export const MODULE = { NAME: 'Cricket Game', PORT: 5001 };
export const DB = {
  URL: 'mongodb+srv://sciflare:HEO6yUFoS7tmk3w0@krayzz22.vh8chph.mongodb.net/krayzz22',
};

export const TRPC = {
  //development
  USERAUTH: 'http://3.7.135.45:5000/trpc/userauth',

  //local
  // USERAUTH: 'http://localhost:5000/trpc/userauth',
};

export const FIXTURE_STATUS = {
  1: 'Upcoming',
  2: 'Completed',
  3: 'Live',
  4: 'no result',
};

export const Football_FIXTURE_STATUS = {
  1: 'upcoming',
  2: 'result',
  3: 'live',
  4: 'cancelled',
};

export const Kabaddi_FIXTURE_STATUS = {
  1: 'upcoming',
  2: 'result',
  3: 'live',
  4: 'cancelled',
};

export const SPORTS_TYPE = {
  1: 'CRICKET',
  2: 'FOOTBALL',
  3: 'BASKETBALL',
};
