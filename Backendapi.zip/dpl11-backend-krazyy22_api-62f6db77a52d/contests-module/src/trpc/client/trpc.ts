import { Injectable } from '@nestjs/common';
import { createTRPCProxyClient, httpBatchLink } from '@trpc/client';
import { TRPC } from 'config/envirnment';
import fetch from 'node-fetch';

const globalAny = global as any;
globalAny.AbortController = AbortController;
globalAny.fetch = fetch;

export const userAuth = createTRPCProxyClient({
  links: [httpBatchLink({ url: TRPC.USERAUTH })],
});
export const scorecard = createTRPCProxyClient({
  links: [httpBatchLink({ url: TRPC.SCORECARD })],
});
export const game = createTRPCProxyClient({
  links: [httpBatchLink({ url: TRPC.CRICKETGAME })],
});
export const transaction = createTRPCProxyClient({
  links: [httpBatchLink({ url: TRPC.TRANSACTION })],
});

@Injectable()
export class trpcServices {
  async scorecard(urlKey: string, payload: any) {
    return await scorecard[urlKey].query({
      request: payload,
    });
  }

  async game(urlKey: string, payload: any) {
    return await game[urlKey].query({
      request: payload,
    });
  }

  async transaction(urlKey: string, payload: any) {
    try {
      return await transaction[urlKey].query({
        request: payload,
      });
    } catch (err) {
      console.log(err);

      return { status: false };
    }
  }
}
