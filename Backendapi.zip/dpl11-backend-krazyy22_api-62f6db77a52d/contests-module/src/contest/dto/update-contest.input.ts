import { JoinContestInput } from './join-contest.input';
import { InputType, Field, Int, PartialType } from '@nestjs/graphql';

@InputType()
export class UpdateContestInput extends PartialType(JoinContestInput) {
  @Field(() => Int)
  id: number;
}
