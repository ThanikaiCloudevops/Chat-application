import { InputType, Field, OmitType } from '@nestjs/graphql';
import { Contest, priceSplitUp } from '../entities/contest.entity';
import graphqlTypeJson from 'graphql-type-json';
import { teamList } from './join-contest.input';

@InputType()
class filterData {
  @Field(() => [String], { nullable: true })
  Entry?: string[];
  @Field(() => [String], { nullable: true })
  Spots?: string[];
  @Field(() => [String], { nullable: true })
  PrizePool?: string[];
  @Field(() => [String], { nullable: true })
  ContestType?: string[];
}
@InputType()
export class contestList {
  @Field()
  fixtureAPIId: number;
  @Field({ defaultValue: 0, nullable: true })
  SortBy?: number;
  @Field({ nullable: true })
  filterBy?: filterData;
  @Field({ nullable: true })
  contestName?: string;
  @Field({ nullable: true })
  page?: number;
  @Field()
  gameType: string;
}

@InputType()
class priceSplitUps {
  @Field({ nullable: true })
  rank: string;
  @Field({ nullable: true })
  price: number;
}

@InputType()
class Prizes {
  @Field()
  split: boolean;

  @Field(() => graphqlTypeJson)
  prizeSplitUp: prizeSplitUp[];

  @Field(() => graphqlTypeJson)
  prizeBreak: prizeBreak[];

  @Field()
  prizeType: string;

  @Field(() => [priceSplitUps])
  priceSplitUp: priceSplitUps[];

  @Field(() => [prizeBreakups])
  prizeBreakup: prizeBreakups[];
}

@InputType()
class prizeBreakups {
  @Field({ nullable: true })
  rank: string;
  @Field({ nullable: true })
  price: number;
}

@InputType()
class prizeBreak {
  @Field({ nullable: true })
  rank: string;
  @Field({ nullable: true })
  price: number;
}
@InputType()
export class prizeSplitUp {
  @Field()
  rank: string;
  @Field()
  price: number;
}

@InputType()
export class contestInput extends OmitType(Contest, ['prize']) {
  @Field(() => Prizes)
  prize: Prizes;
}

@InputType()
export class contestCreationInput {
  @Field()
  fixtureAPIId: number;

  @Field()
  seriesAPIId: number;

  @Field()
  maxPrizepool: number;

  @Field()
  totalPrizePool: number;

  @Field()
  totalSpots: number;

  @Field()
  maxTeamCount: number;

  @Field()
  entryFee: number;

  @Field()
  winningPercentage: number;

  @Field()
  gameType: string;

  @Field({ nullable: true })
  startDate?: Date;

  @Field(() => [prizeSplitUp])
  prizeSplitUp: prizeSplitUp[];

  @Field()
  prizeType: string;

  @Field()
  split: boolean;

  @Field(() => [teamList])
  joiningTeams: teamList[];
}
