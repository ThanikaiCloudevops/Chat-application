import { Injectable } from '@nestjs/common';
import { Contest } from '../entities/contest.entity';
import { contestCreationInput, prizeSplitUp } from '../dto/contest.input';

@Injectable()
export class ContestHelper {
  constructor() {}

  formatContest(inputContest: contestCreationInput): Contest | null {
    try {
      return {
        contestName: 'Private contest',
        constestCaption: `${inputContest.totalPrizePool} Contest`,
        contestType: 'private',
        currentWinning: 0,
        discountEntryFee: 0,
        enabledStatus: true,
        entryFee: inputContest.entryFee,
        fixtureAPIId: inputContest.fixtureAPIId,
        seriesAPIId: inputContest.seriesAPIId,
        guaranteed: true,
        previousContest: '',
        autoCreate: false,
        adminCumissionPercentage: 30,
        isactive: true,
        jointUsers: {},
        maxPrizepool: inputContest.maxPrizepool,
        maxTeamCount: inputContest.maxTeamCount,
        paid: true,
        poolType: 'max',
        position: false,
        contestCode: this.#contestCode(12),
        winningPercentage: inputContest.winningPercentage,
        totalSpots: inputContest.totalSpots,
        totalPrizePool: inputContest.totalPrizePool,
        remainingSpots: inputContest.totalSpots,
        gameType: inputContest.gameType,
        startDate: inputContest?.startDate,
        prize: {
          priceSplitUp: JSON.parse(JSON.stringify(inputContest.prizeSplitUp)),
          split:
            inputContest.totalPrizePool == inputContest.maxPrizepool
              ? false
              : true,
          prizeType: inputContest.prizeType,
          totalValue: inputContest.totalPrizePool,
          prizeBreak: this.#arrToObj(inputContest.prizeSplitUp),
          prizeBreakup: JSON.parse(JSON.stringify(inputContest.prizeSplitUp)),
          prizeSplitUp: this.#arrToObj(inputContest.prizeSplitUp),
        },
      };
    } catch (err) {
      return null;
    }
  }

  #arrToObj(arr: prizeSplitUp[]) {
    const obj = {};
    for (const priceRank of arr) {
      obj[priceRank.rank] = priceRank.price;
    }
    return obj;
  }

  #contestCode(length: number) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < length) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
    }
    return result;
  }

  contestCode(length: number) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < length) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
    }
    return result;
  }

  filterHelper(filterArr: any[], field: string) {
    const resArr = [];
    for (const filter of filterArr) {
      const filters = filter.split('-');
      if (!filters[1])
        resArr.push({
          [field]: { $gte: +filters[0] || 0 },
        });
      else
        resArr.push({ [field]: { $gte: +filters[0] || 0, $lte: +filters[1] } });
    }

    return { $or: resArr };
  }
}
