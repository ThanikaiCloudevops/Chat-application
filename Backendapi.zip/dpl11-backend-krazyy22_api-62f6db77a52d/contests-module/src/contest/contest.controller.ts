import { Body, Controller, Get, Post, Param } from '@nestjs/common';
import { ContestService } from './contest.service';

@Controller('contest')
export class ContestController {
  constructor(private readonly contestService: ContestService) {}

  // @Get('/contestbreakup/:id')
  // async contestbreakup(@Param() params: any) {
  //   return await this.contestService.dynamicBreakup(params.id);
  // }
}
