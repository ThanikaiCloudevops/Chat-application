import { Resolver, Query, Args, Mutation, Context } from '@nestjs/graphql';
import { ContestService } from './contest.service';
import {
  Contest,
  contestCollectionFormat,
  leaderBoardDownloadRes,
  leaderBoardTeamsCollection,
  myContestCollection,
  singleContest,
} from './entities/contest.entity';
import { JoinContestInput } from './dto/join-contest.input';
import {
  contestCreationResponse,
  contest_defaultFields,
  privateContestResponse,
  timeoutRes,
} from 'src/commonResponse/response.entity';
import { UseGuards } from '@nestjs/common';
import { AuthGuard } from 'src/auth/auth.guard';
import { contestCreationInput, contestList } from './dto/contest.input';

@Resolver(() => Contest)
@UseGuards(AuthGuard)
export class ContestResolver {
  constructor(private readonly contestService: ContestService) {}

  @Query(() => contest_defaultFields, { name: 'contestTimeout' })
  contestTimeout(@Args('input') time: number, @Context('user') user: any) {
    return this.contestService.EnableTimeOut(user._id, time);
  }

  @Query(() => timeoutRes, { name: 'checkTimeout' })
  checkTimeout(@Context('user') user: any) {
    return this.contestService.checkTimeout(user?._id);
  }

  @Mutation(() => contest_defaultFields)
  joinContest(
    @Args('input') joinContestInput: JoinContestInput,
    @Context('user') user: any,
  ) {
    return this.contestService.joinContest(joinContestInput, user);
  }

  @Mutation(() => contestCollectionFormat, { name: 'contestList' })
  findAll(@Args('input') input: contestList, @Context('user') user: any) {
    return this.contestService.getAllContest(user._id, input);
  }

  @Mutation(() => contestCreationResponse, { name: 'createContest' })
  createContest(
    @Args('input') input: contestCreationInput,
    @Context('user') user: any,
  ) {
    return this.contestService.contestCreation(input, user);
  }

  @Query(() => singleContest, { name: 'contestDetail' })
  find(
    @Args('contestId') contestId: string,
    @Args('gameType') gameType: string,
    @Context('user') user: any,
  ) {
    return this.contestService.getContestDetail(user._id, contestId, gameType);
  }

  @Query(() => myContestCollection, { name: 'myContestList' })
  myContest(
    @Context('user') user: any,
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('gameType') gameType: string,
    @Args('page') page: number,
  ) {
    return this.contestService.getMyContest(
      user._id,
      fixtureAPIId,
      gameType,
      page,
    );
  }

  @Query(() => leaderBoardTeamsCollection, { name: 'getLeaderBoard' })
  leaderBoard(
    @Args('contestId') contestID: string,
    @Args('page') page: number,
    @Context('user') user: any,
  ) {
    return this.contestService.getLeaderBoard(user._id, contestID, page);
  }

  @Query(() => leaderBoardDownloadRes, { name: 'downloadLeaderBoard' })
  downloadTeams(
    @Args('contestId') contestID: string,
    @Context('user') user: any,
  ) {
    return this.contestService.downloadLeaderboard(user._id, contestID);
  }

  @Query(() => privateContestResponse, { name: 'privateContestCheck' })
  privateContestCheck(
    @Args('contestCode') contestCode: string,
    @Args('gameType') gameType: string,
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Context('user') user: any,
  ) {
    return this.contestService.privateContestCheck(
      contestCode,
      fixtureAPIId,
      user?._id,
      gameType,
    );
  }

  @Mutation(() => contest_defaultFields)
  dynamicSplitup(
    @Args('contestId') contestId: string,
    @Context('user') user: any,
  ) {
    return this.contestService.dynamicSplitup(contestId);
  }

  @Query(() => singleContest, { name: 'dynamicBreakup' })
  dynamicBreakup(
    @Args('contestId') contestId: string,
    @Context('user') user: any,
  ) {
    return this.contestService.dynamicSplitupV2(contestId);
  }

  @Query(() => String)
  testFn() {
    return this.contestService.dynamicSplitupV2('665963c3ee3c43e4e6dab2e8');
  }
}
