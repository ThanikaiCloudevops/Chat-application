import { Field, ObjectType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type timeOutDocument = TimeOut & Document;

@ObjectType()
@Schema()
export class TimeOut {
  @Field({ nullable: false })
  @Prop({ index: true })
  userId: string;

  @Field({ nullable: false })
  @Prop()
  timeOutStartDate: Date;

  @Field({ nullable: false })
  @Prop()
  timeOutEndDate: Date;
}

export const TimeoutSchema = SchemaFactory.createForClass(TimeOut);
