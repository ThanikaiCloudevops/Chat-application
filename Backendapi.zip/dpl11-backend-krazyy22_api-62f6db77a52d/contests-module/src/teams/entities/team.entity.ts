import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { contest_defaultFields } from 'src/commonResponse/response.entity';
export type userTeamsDocument = userTeams & Document;

@ObjectType()
export class team {
  @Field()
  @Prop()
  playerName: string;
  @Field({ nullable: true })
  @Prop()
  playerDisplayName: string;
  @Field()
  @Prop()
  playerAPIId: number;
  @Field()
  @Prop()
  playerType: string;
  @Field()
  @Prop()
  playerValue: number;
  @Field({ nullable: true })
  @Prop()
  teamAPIId: number;
  @Field()
  @Prop()
  teamName: string;
  @Field()
  @Prop()
  teamDisplayName: string;
  @Field({ defaultValue: '' })
  @Prop()
  imgUrl: string;
  @Field({ defaultValue: '' })
  @Prop()
  jerseyUrl: string;
  @Field({ defaultValue: '' })
  @Prop()
  playerImageUrl: string;
  @Field()
  @Prop()
  cap: boolean;
  @Field()
  @Prop()
  vc: boolean;
  @Field({ defaultValue: 0 })
  @Prop()
  points: number;
  @Field({ defaultValue: false })
  in11?: boolean;
}

@ObjectType()
export class userTeam {
  @Field()
  @Prop()
  _id: string;
  @Field()
  @Prop()
  userId: string;
  @Field()
  @Prop()
  userName: string;
  @Field()
  @Prop()
  teamName: string;
  @Field({ defaultValue: 0 })
  @Prop()
  seriesAPIId: number;
  @Field()
  @Prop()
  totalValue: number;
  @Field()
  @Prop()
  totalPoints: number;
  @Field(() => [team])
  @Prop()
  team: team[];
  @Field({ defaultValue: false })
  lineUpOut?: boolean;
  @Field()
  @Prop()
  createdat: Date;
}

@ObjectType()
@Schema()
export class userTeams {
  @Field()
  @Prop({ index: true })
  fixtureAPIId: number;
  @Field({ defaultValue: 0, nullable: true })
  @Prop()
  seriesAPIId?: number;
  @Field(() => [userTeam])
  @Prop()
  userTeams: userTeam[];

  @Field()
  @Prop()
  gameType: string;
}

@ObjectType()
export class userTeamColletion extends PartialType(contest_defaultFields) {
  @Field({ nullable: true })
  data: userTeams;
}

@ObjectType()
class teamsOpt {
  @Field()
  teamId: string;
  @Field()
  teamName: string;
}
@ObjectType()
export class teamCreationOpt extends PartialType(contest_defaultFields) {
  @Field({ nullable: true })
  data: teamsOpt;
}

export const userTeamSchema = SchemaFactory.createForClass(userTeams);
