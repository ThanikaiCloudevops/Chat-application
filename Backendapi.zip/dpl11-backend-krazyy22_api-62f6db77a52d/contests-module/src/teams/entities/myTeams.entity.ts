import { ObjectType, Field, PartialType, OmitType } from '@nestjs/graphql';
import { userTeam, userTeams } from './team.entity';
import { contest_defaultFields } from 'src/commonResponse/response.entity';

@ObjectType()
class playersCount {
  @Field({ nullable: true, defaultValue: 0 })
  wk: number;
  @Field({ nullable: true, defaultValue: 0 })
  bat: number;
  @Field({ nullable: true, defaultValue: 0 })
  ar: number;
  @Field({ nullable: true, defaultValue: 0 })
  bowl: number;
  @Field({ nullable: true, defaultValue: 0 })
  G: number;
  @Field({ nullable: true, defaultValue: 0 })
  D: number;
  @Field({ nullable: true, defaultValue: 0 })
  M: number;
  @Field({ nullable: true, defaultValue: 0 })
  F: number;
  @Field({ nullable: true, defaultValue: 0 })
  defender: number;
  @Field({ nullable: true, defaultValue: 0 })
  allrounder: number;
  @Field({ nullable: true, defaultValue: 0 })
  raider: number;
}
@ObjectType()
class teamCount {
  @Field()
  count: number;
  @Field()
  teamName: string;
  @Field()
  teamDisplayName: string;
  @Field({ defaultValue: 0 })
  teamAPIId: number;
}

@ObjectType()
class teamAB {
  @Field(() => teamCount)
  teamA: teamCount;

  @Field(() => teamCount)
  teamB: teamCount;
}

@ObjectType()
class capVc {
  @Field({ defaultValue: '' })
  imgUrl: string;
  @Field({ defaultValue: '' })
  jerseyUrl: string;
  @Field({ defaultValue: '' })
  playerImageUrl: string;
  @Field()
  playerName: string;
  @Field()
  playerDisplayName: string;
  @Field()
  teamName: string;
}

@ObjectType()
class userTeamObj extends userTeam {
  @Field(() => playersCount)
  playerCount: playersCount;
  @Field(() => teamAB)
  teamCount: teamAB;
  @Field(() => capVc)
  captain: capVc;
  @Field(() => capVc)
  viceCaptain: capVc;
}
@ObjectType()
class myTeams extends OmitType(userTeams, ['userTeams']) {
  @Field(() => userTeamObj)
  userTeams: userTeamObj;
}

@ObjectType()
export class myTeamCollection extends PartialType(contest_defaultFields) {
  @Field(() => [myTeams], { nullable: 'itemsAndList' })
  data: myTeams[];
}

@ObjectType()
class footballplayersCount {
  @Field()
  G: number;
  @Field()
  D: number;
  @Field()
  M: number;
  @Field()
  F: number;
}

@ObjectType()
class userFootballTeamObj extends userTeam {
  @Field(() => footballplayersCount)
  playerCount: footballplayersCount;
  @Field(() => teamAB)
  teamCount: teamAB;
  @Field(() => capVc)
  captain: capVc;
  @Field(() => capVc)
  viceCaptain: capVc;
}

@ObjectType()
class myFootballTeams extends OmitType(userTeams, ['userTeams']) {
  @Field(() => userFootballTeamObj)
  userTeams: userFootballTeamObj;
}

@ObjectType()
export class myTeamFootballCollection extends PartialType(
  contest_defaultFields,
) {
  @Field(() => [myFootballTeams], { nullable: 'itemsAndList' })
  data: myFootballTeams[];
}

@ObjectType()
class joinedTeams {
  @Field(() => [myTeams])
  joined: myTeams[];

  @Field(() => [myTeams])
  notJoined: myTeams[];
}

@ObjectType()
export class joinedTeamCollection extends PartialType(contest_defaultFields) {
  @Field(() => joinedTeams)
  data: joinedTeams;
}

@ObjectType()
export class myTeamsDetail extends PartialType(contest_defaultFields) {
  @Field(() => myTeams, { nullable: true })
  data: myTeams;
}
