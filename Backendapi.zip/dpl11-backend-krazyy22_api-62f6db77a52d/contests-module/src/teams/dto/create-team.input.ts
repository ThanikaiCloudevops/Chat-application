import { InputType, Field } from '@nestjs/graphql';
import { Length } from 'class-validator';

@InputType()
class inputTeam {
  @Field()
  playerName: string;

  @Field()
  playerAPIId: number;

  @Field()
  playerDisplayName: string;

  @Field()
  playerType: string;

  @Field()
  playerValue: number;

  @Field()
  teamAPIId: number;

  @Field()
  teamName: string;

  @Field()
  teamDisplayName: string;

  @Field({ defaultValue: '' })
  imgUrl: string;

  @Field({ defaultValue: '' })
  jerseyUrl: string;

  @Field({ defaultValue: '' })
  playerImageUrl: string;

  @Field()
  cap: boolean;

  @Field()
  vc: boolean;

  @Field({ defaultValue: 0 })
  points?: number;
}

@InputType()
export class teamCreation {
  // @Field()
  // contestId: string;

  @Field()
  gameType: string;

  @Field()
  fixtureAPIId: number;
  @Field({ defaultValue: 0, nullable: true })
  seriesAPIId?: number;
  @Field()
  totalValue: number;

  @Field(() => [inputTeam], { nullable: true })
  userTeam?: inputTeam[];
}

@InputType()
export class editTeam extends teamCreation {
  @Field()
  teamId: string;
  @Field()
  gameType: string;
}

@InputType()
class whichTeam {
  @Field()
  @Length(24, 24)
  teamId: string;
  @Field()
  @Length(2, 2)
  teamName: string;
}
@InputType()
export class switchTeamsInput {
  @Field()
  gameType: string;
  @Field()
  contestId: string;
  @Field(() => whichTeam)
  from: whichTeam;
  @Field(() => whichTeam)
  To: whichTeam;
}
