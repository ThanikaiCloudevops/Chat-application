import { Module, forwardRef } from '@nestjs/common';
import { TeamsService } from './teams.service';
import { TeamsResolver } from './teams.resolver';
import {
  validateFootballTeamSelection,
  validateKabaddiTeamSelection,
  validateTeamSelection,
} from './helpers/validate-team.service';
import { MyTeamFormatter } from './helpers/formatMyteam.service';
import { AuthGuard } from 'src/auth/auth.guard';
import { MongooseModule } from '@nestjs/mongoose';
import { userTeamSchema, userTeams } from './entities/team.entity';
import { ContestModule } from 'src/contest/contest.module';
import { trpcServices } from 'src/trpc/client/trpc';
import { ContestService } from 'src/contest/contest.service';

@Module({
  imports: [
    forwardRef(() => ContestModule),
    MongooseModule.forFeature([
      { name: userTeams.name, schema: userTeamSchema },
    ]),
  ],
  providers: [
    TeamsResolver,
    TeamsService,
    validateTeamSelection,
    validateFootballTeamSelection,
    validateKabaddiTeamSelection,
    MyTeamFormatter,
    AuthGuard,
    trpcServices,
  ],
  exports: [TeamsService],
})
export class TeamsModule {}
