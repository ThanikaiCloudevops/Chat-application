import { Injectable } from '@nestjs/common';
import { userTeam } from '../entities/team.entity';
import { trpcServices } from 'src/trpc/client/trpc';

type count = {
  [player: string]: string;
};

@Injectable()
export class MyTeamFormatter {
  public lineUpOut = false;
  public playing11Players: number[] = [];
  constructor(private trpcservices: trpcServices) {}

  async structureMyTeam(teams: any[], fixtureAPIId = 0) {
    if (fixtureAPIId) {
      const playing11 = await this.trpcservices.game('getplaying11', {
        fixtureAPIId,
      });
      this.lineUpOut = playing11.lineUpOut;
      this.playing11Players = playing11.playing11Players;
    }
    if (!teams.length) return teams;
    return teams.map((item: any) => {
      return {
        fixtureAPIId: item.fixtureAPIId,
        seriesAPIId: item?.userTeams?.seriesAPIId || 0,
        userTeams: {
          _id: item.userTeams._id,
          userId: item.userTeams.userId,
          totalPoints: item.userTeams.totalPoints,
          seriesAPIId: item?.userTeams?.seriesAPIId || 0,
          totalValue: item.userTeams.totalValue,
          userName: item.userTeams.userName,
          teamName: item.userTeams.teamName,
          team: this.#addLinup(item.userTeams.team),
          lineUpOut: this.lineUpOut,
          createdat: item.userTeams.createdat,
          playerCount: this.#playerCount(item.userTeams.team),
          captain: this.#capVc(item.userTeams.team, 'cap'),
          viceCaptain: this.#capVc(item.userTeams.team, 'vc'),
          teamCount: this.#teams(item.userTeams.team),
        },
      };
    });
  }

  #teams(team: any) {
    const teamCount = team.reduce((value, item) => {
      if (!value[item['teamName']]) {
        value[item['teamName']] = {
          count: 1,
          teamName: item['teamName'],
          teamDisplayName: item['teamDisplayName'],
          teamAPIId: item['teamAPIId'],
        };
      } else value[item['teamName']]['count'] += 1;

      return value;
    }, {});

    const sortTeamCount = Object.values(teamCount).sort(
      (a, b) => b['count'] - a['count'],
    );
    return {
      teamA: sortTeamCount[0],
      teamB: sortTeamCount[1],
    };
  }

  #playerCount(player: any[]) {
    const count = player.reduce((total: { [x: string]: number }, item) => {
      if (!total[item['playerType']]) total[item['playerType']] = 1;
      else total[item['playerType']] += 1;
      return total;
    }, {});
    return count;
  }

  #capVc(player: any[], type: string) {
    const cap_vc = player.reduce(
      (value: count, item: count) => {
        if (item[type]) {
          value.imgUrl = item?.imgUrl;
          value.jerseyUrl = item?.jerseyUrl;
          value.playerImageUrl = item?.playerImageUrl;
          value.playerName = item?.playerName;
          value.playerDisplayName = item?.playerDisplayName || '';
          value.teamName = item.teamName;
        }
        return value;
      },
      {
        imgUrl: '',
        playerName: '',
        playerDisplayName: '',
      },
    );

    return cap_vc;
  }
  #addLinup(team: any[]) {
    return team.map((player) => {
      player.in11 = this.playing11Players.includes(player.playerAPIId)
        ? true
        : false;
      return player;
    });
  }

  formatPlayerPicks(UserTeams: userTeam[]) {
    return {
      teamA: UserTeams[0].team.reduce((value: any, player: any) => {
        value[
          JSON.stringify({
            [player.playerAPIId]: player.cap ? 2 : player.vc ? 1 : 0,
          })
        ] = player;
        return value;
      }, {}),
      teamB: UserTeams[1].team.reduce((value: any, player: any) => {
        value[
          JSON.stringify({
            [player.playerAPIId]: player.cap ? 2 : player.vc ? 1 : 0,
          })
        ] = player;
        return value;
      }, {}),
    };
  }

  initilizeCompareTeam() {
    return {
      teamA: {
        diffrent: [],
        common: [],
        capvcCommon: [],
        capvcDiffrent: [],
      },
      teamB: {
        diffrent: [],
        common: [],
        capvcCommon: [],
        capvcDiffrent: [],
      },
    };
  }
}
