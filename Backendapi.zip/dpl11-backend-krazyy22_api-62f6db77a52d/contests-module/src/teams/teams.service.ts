import { Injectable } from '@nestjs/common';
import { userTeam, userTeams } from './entities/team.entity';
import mongoose, { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import {
  validateFootballTeamSelection,
  validateKabaddiTeamSelection,
  validateTeamSelection,
} from '../teams/helpers/validate-team.service';
import { commonErrors } from '../commonResponse/errors';
import { successResponse } from '../commonResponse/success';
import { MyTeamFormatter } from '../teams/helpers/formatMyteam.service';
import { ContestService } from 'src/contest/contest.service';
import { Inject, forwardRef } from '@nestjs/common';
import { editTeam, switchTeamsInput } from './dto/create-team.input';
import { trpcServices } from 'src/trpc/client/trpc';
@Injectable()
export class TeamsService {
  constructor(
    @InjectModel(userTeams.name) private userteamsModel: Model<userTeams>,
    private validateTeam: validateTeamSelection,
    private validateFootballTeam: validateFootballTeamSelection,
    private validateKabaddiTeam: validateKabaddiTeamSelection,
    private formatTeam: MyTeamFormatter,
    @Inject(forwardRef(() => ContestService))
    private contest: ContestService,
    private trpcService: trpcServices,
  ) {}

  async teamCreation(request: any) {
    try {
      const {
        userId,
        // contestId,
        seriesAPIId,
        gameType,
        totalValue,
        userName,
        userTeam,
        fixtureAPIId,
      } = request;

      const fixture = await this.trpcService.game('getfixture', {
        fixtureAPIId,
        gameType,
      });
      if (fixture?.fixtureStatus == 'Live') return commonErrors('contestjoin');

      const isEdit = request?.teamId;

      const team = userTeam
        .map((e: any) => {
          e.points = 0;
          return e;
          // return { ...e, points: 0 };
        })
        .sort((e: any, f: any) => e.playerAPIId - f.playerAPIId);

      const isValidTeam =
        gameType === 'cricket'
          ? this.validateTeam.validateTeam(userTeam)
          : gameType === 'football'
          ? this.validateFootballTeam.validateFootballTeam(userTeam)
          : this.validateKabaddiTeam.validateKabaddiTeam(userTeam);
      if (!isValidTeam) return commonErrors('invalidTeam');

      const isfixtureAvailable = await this.userteamsModel.findOne({
        fixtureAPIId,
        gameType,
      });
      // db required payload
      const payload: userTeams = {
        seriesAPIId,
        fixtureAPIId,
        userTeams: [
          {
            _id: new mongoose.mongo.ObjectId().toString(),
            userId,
            userName,
            seriesAPIId,
            teamName: 'T1',
            totalValue,
            totalPoints: 0,
            team,
            createdat: new Date(),
          },
        ],
        gameType: gameType,
      };
      if (!isfixtureAvailable && !isEdit) {
        const data = await this.userteamsModel.create(payload);
        const resPayload = {
          teamId: data.userTeams[0]._id,
          teamName: data.userTeams[0].teamName,
        };

        return successResponse('teamCreated', resPayload);
      }

      /* Check duplicate start */
      const checkTeams = JSON.stringify(
        isfixtureAvailable.userTeams
          .filter((e) => e.userId == userId)
          .map((e) =>
            e.team.sort((f: any, g: any) => f.playerAPIId - g.playerAPIId),
          ),
      );

      if (checkTeams.includes(JSON.stringify(team)))
        return commonErrors('duplicate');
      /* Check duplicate end */

      /* Update team start */
      if (isEdit) {
        await this.userteamsModel.findOneAndUpdate(
          {
            fixtureAPIId,
            userTeams: { $elemMatch: { _id: isEdit } },
          },
          {
            $set: {
              'userTeams.$.team': JSON.parse(JSON.stringify(team)),
              'userTeams.$.createdat': new Date(),
            },
          },
        );

        return successResponse('updated');
      }
      /* Update team end */

      const getUserTeamsCount = isfixtureAvailable.userTeams.filter(
        (e) => e.userId == userId,
      ).length;

      if (getUserTeamsCount + 1 > 20) return commonErrors('max');

      const teamName = `T${getUserTeamsCount + 1}`;
      const updatePayload = {
        _id: new mongoose.mongo.ObjectId().toString(),
        seriesAPIId,
        userId,
        userName,
        teamName,
        totalValue,
        totalPoints: 0,
        team,
        createdat: new Date(),
      };
      isfixtureAvailable.userTeams.push(updatePayload);
      await this.userteamsModel.findByIdAndUpdate(
        isfixtureAvailable._id,
        isfixtureAvailable,
      );
      const resPayload = {
        teamId: updatePayload._id,
        teamName: updatePayload.teamName,
      };

      await this.updateSelBy(fixtureAPIId, gameType);
      return successResponse('teamCreated', resPayload);
    } catch (err) {
      return commonErrors('teamcreation');
    }
  }

  async editTeam(request: any, userId: string, userName: string) {
    try {
      const { totalValue, userTeam, fixtureAPIId, gameType } = request;
      const fixture = await this.trpcService.game('getfixture', {
        fixtureAPIId,
        gameType,
      });
      if (fixture?.fixtureStatus == 'Live') return commonErrors('contestjoin');

      const isEdit = request?.teamId;

      const team = userTeam
        .map((e: any) => {
          e.points = 0;
          return e;
          // return { ...e, points: 0 };
        })
        .sort((e: any, f: any) => e.playerAPIId - f.playerAPIId);
      const isValidTeam =
        gameType === 'cricket'
          ? this.validateTeam.validateTeam(userTeam)
          : gameType === 'football'
          ? this.validateFootballTeam.validateFootballTeam(userTeam)
          : this.validateKabaddiTeam.validateKabaddiTeam(userTeam);
      if (!isValidTeam) return commonErrors('invalidTeam');

      const isfixtureAvailable = await this.userteamsModel.findOne({
        fixtureAPIId,
        gameType,
      });

      /* Check duplicate start */
      const checkTeams = await JSON.stringify(
        isfixtureAvailable.userTeams
          .filter((e) => e.userId == userId)
          .map((e) =>
            e.team.sort((f: any, g: any) => f.playerAPIId - g.playerAPIId),
          ),
      );

      if (await checkTeams.includes(JSON.stringify(team)))
        return commonErrors('duplicate');
      /* Check duplicate end */

      /* Update team start */
      const updateIndex = await isfixtureAvailable.userTeams.findIndex(
        (e) => e._id == isEdit,
      );
      isfixtureAvailable.userTeams[updateIndex].team = await JSON.parse(
        JSON.stringify(team),
      );
      isfixtureAvailable.userTeams[updateIndex].totalValue = totalValue;
      isfixtureAvailable.userTeams[updateIndex].createdat = new Date();
      await this.userteamsModel.updateOne({ fixtureAPIId }, isfixtureAvailable);

      /* const update = await this.userteamsModel.updateOne(
        {
          fixtureAPIId,
          userTeams: { $elemMatch: { _id: isEdit } },
        },
        {
          $set: {
            'userTeams.$.team': JSON.parse(JSON.stringify(team)),
            'userTeams.$.createdat': new Date(),
          },
        },
      );
    */

      return successResponse('updated');
    } catch (err) {
      return commonErrors('teamcreation');
    }
  }

  async updateSelBy(fixtureAPIId: number, gameType: string) {
    try {
      const userTeams = await this.userteamsModel.findOne({ fixtureAPIId });

      const teams = userTeams.userTeams.map((e) => e.team).flat();
      const playersGrouping = teams.reduce((value, team) => {
        if (!value[team.playerAPIId]) value[team.playerAPIId] = [];
        value[team.playerAPIId].push(team);
        return value;
      }, {});
      const res = [];

      for (const playerAPIId in playersGrouping) {
        const playerArr = playersGrouping[playerAPIId];
        res.push({
          playerAPIId,
          selectedCount: playerArr.length,
          teamAPIId: playerArr[0].teamAPIId,
          capCount: playerArr.filter((e) => e.cap).length,
          vcCount: playerArr.filter((e) => e.vc).length,
        });
      }

      await this.trpcService.game('updateSellectedby', {
        gameType,
        fixtureAPIId,
        teams: res,
        total: userTeams.userTeams.length,
      });
      return 'Success';
    } catch (err) {
      return 'Error';
    }
  }

  async myTeams({ userId, fixtureAPIId, gameType }) {
    try {
      const my_teams = await this.aggregate(fixtureAPIId, gameType, {
        $and: [{ $eq: ['$$userTeams.userId', userId] }],
      });

      const formatTeams = await this.formatTeam.structureMyTeam(my_teams);

      if (!formatTeams.length) return successResponse('notfound', []);
      return successResponse('retrived', formatTeams);
    } catch (error) {
      console.log(error.message);
      return successResponse('notfound', []);
    }
  }

  async myTeamsDetail({ userId, fixtureAPIId, teamName, gameType }) {
    try {
      const my_teams = await this.aggregate(fixtureAPIId, gameType, {
        $and: [
          { $eq: ['$$userTeams.userId', userId] },
          { $eq: ['$$userTeams.teamName', teamName] },
        ],
      });
      if (!my_teams.length) return commonErrors('retrived');
      const formatTeams = await this.formatTeam.structureMyTeam(
        my_teams,
        fixtureAPIId,
      );

      return successResponse('retrived', formatTeams[0]);
    } catch (error) {
      console.log(error.message);
      return commonErrors('retrived');
    }
  }

  async getTeamCount(
    fixtureAPIId: number,
    userId: string,
    gameType: string,
    team_List: any = [],
  ) {
    if (team_List.length) {
      const totalCount = [];
      for (const ite of team_List) {
        const teamCount = await this.aggregate(fixtureAPIId, gameType, {
          $and: [
            { $eq: ['$$userTeams.userId', userId] },
            { $eq: ['$$userTeams.teamName', ite.teamName] },
            { $eq: ['$$userTeams._id', ite.teamId] },
          ],
        });

        totalCount.push(teamCount.length);
      }
      return totalCount.some((ite: any) => !ite);
    }
    const eq = { $and: [{ $eq: ['$$userTeams.userId', userId] }] };
    const teamCount = await this.aggregate(fixtureAPIId, gameType, eq);
    return teamCount.length;
  }

  async teamsToJoin(
    fixtureAPIId: number,
    userId: string,
    contestId: string,
    gameType: string,
  ) {
    const payload = {
      joined: [],
      notJoined: [],
    };

    const contestDetail = await this.contest.getContestDetail(
      userId,
      contestId,
      gameType,
    );

    const joinedTeams =
      contestDetail?.data?.contest?.jointUsers?.[userId] || {};
    const joinedTeamId = joinedTeams?.userTeams
      ? Object.keys(joinedTeams?.userTeams)
      : [];

    const userTeams = await this.myTeams({ userId, fixtureAPIId, gameType });
    const getjoinedTeamlist = userTeams?.data?.filter((ite: any) =>
      joinedTeamId.includes(ite.userTeams._id),
    );

    const getUnjoinedTeamlist = userTeams?.data?.filter(
      (ite: any) => !joinedTeamId.includes(ite.userTeams._id),
    );
    if (!getjoinedTeamlist && getUnjoinedTeamlist)
      return commonErrors('retrived', payload);

    payload.joined = getjoinedTeamlist || [];
    payload.notJoined = getUnjoinedTeamlist || [];

    return successResponse('retrived', payload);
  }

  async getUserJoinedTeam(
    fixtureAPIId: number,
    gameType: string,
    team_List: any = [],
  ) {
    if (!team_List.length) return team_List;
    let team_Id = [];
    for (const ite of team_List) {
      team_Id = [...team_Id, { $eq: ['$$userTeams._id', ite.teamId] }];
    }
    const teamCount = await this.aggregate(
      fixtureAPIId,
      gameType,
      { $or: team_Id },
      false,
    );

    return teamCount;
  }

  private async isInJoinedteam(
    contestDetail: any,
    teamId: string,
    userId: string,
  ) {
    const joinedTeams = contestDetail?.data?.contest?.jointUsers?.[userId];
    const joinedTeamId = joinedTeams?.userTeams?.[teamId];
    return joinedTeamId;
  }

  private async aggregate(
    fixtureAPIId: number,
    gameType: string,
    cond: any,
    and = true,
  ) {
    const aggregate: any = [
      {
        $match: { fixtureAPIId, gameType },
      },
      {
        $project: {
          fixtureAPIId: 1,
          userTeams: {
            $filter: {
              input: '$userTeams',
              as: 'userTeams',
              cond: cond,
            },
          },
        },
      },
    ];
    and && aggregate.push({ $unwind: '$userTeams' });

    return await this.userteamsModel.aggregate(aggregate);
  }

  async selectUserTeams(fixtureAPIId: number): Promise<userTeams> {
    return await this.userteamsModel.findOne({ fixtureAPIId });
  }

  async switchTeams(request: switchTeamsInput, userId: string) {
    const { contestId, from, To, gameType } = request;
    const contestDetail = await this.contest.getContestDetail(
      userId,
      contestId,
      gameType,
    );
    // check from Team is in joinedTeams
    const fromTeam_isJoined = await this.isInJoinedteam(
      contestDetail,
      from.teamId,
      userId,
    );

    if (!fromTeam_isJoined) return commonErrors('invalidTeam');

    // check To Team is in joinedTeams
    const toTeam_isJoined = await this.isInJoinedteam(
      contestDetail,
      To.teamId,
      userId,
    );

    if (toTeam_isJoined) return commonErrors('AlreadyJoined');

    // check to Team is in myTeams
    const fixtureAPIId = contestDetail?.data?.contest?.fixtureAPIId;
    const userTeams = await this.myTeams({ userId, fixtureAPIId, gameType });

    const toTeam_inInMyTeam = userTeams?.data?.find(
      (ite) => ite?.userTeams?._id == To.teamId,
    );

    if (!toTeam_inInMyTeam) return commonErrors('invalidTeam');

    const user_joined_Teams =
      contestDetail.data.contest.jointUsers[userId].userTeams;

    // const filterFromTeam = Object.values(user_joined_Teams)?.filter(
    //   (ite: any) => ite.teamId !== from.teamId,
    // );

    const switch_Team = {
      [To.teamId]: {
        ...To,
        points: 0,
        joinedAt: user_joined_Teams[from.teamId].joinedAt,
      },
    };
    delete user_joined_Teams[from.teamId];
    const filterFromTeam = { ...user_joined_Teams, ...switch_Team };
    // update contest
    // filterFromTeam.push(To);
    const contest = contestDetail.data.contest;
    contest.jointUsers[userId].userTeams = filterFromTeam;

    await this.contest.updateContest(contestId, contest);

    return successResponse('switched');
  }

  async singleUserTeam(fixtureAPIId: number, teamId: string, gameType: string) {
    try {
      const my_teams = await this.aggregate(fixtureAPIId, gameType, {
        $and: [{ $eq: ['$$userTeams._id', teamId] }],
      });
      if (!my_teams.length) return commonErrors('retrived');
      const formatTeams = await this.formatTeam.structureMyTeam(
        my_teams,
        fixtureAPIId,
      );

      return successResponse('retrived', formatTeams[0]);
    } catch (err) {
      return commonErrors('retrived');
    }
  }

  async switchTeam(request: switchTeamsInput, userId: string) {
    const { contestId, from, To, gameType } = request;
    const contestDetail = await this.contest.getContestDetail(
      userId,
      contestId,
      gameType,
    );
    // check from Team is in joinedTeams
    const fromTeam_isJoined = await this.isInJoinedteam(
      contestDetail,
      from.teamId,
      userId,
    );

    if (!fromTeam_isJoined) return commonErrors('invalidTeam');

    // check To Team is in joinedTeams
    const toTeam_isJoined = await this.isInJoinedteam(
      contestDetail,
      To.teamId,
      userId,
    );

    // const data = await this.isInJoinedteam(
    //   contestDetail,
    //   To.teamId,
    //   userId,
    // )

    if (toTeam_isJoined) return commonErrors('AlreadyJoined');

    // check to Team is in myTeams
    const fixtureAPIId = contestDetail?.data?.contest?.fixtureAPIId;
    const userTeams = await this.myTeams({ userId, fixtureAPIId, gameType });

    const toTeam_inInMyTeam = userTeams?.data?.find(
      (ite) => ite?.userTeams?._id == To.teamId,
    );

    if (!toTeam_inInMyTeam) return commonErrors('invalidTeam');

    const user_joined_Teams =
      contestDetail.data.contest.jointUsers[userId].userTeams;

    // const filterFromTeam = Object.values(user_joined_Teams)?.filter(
    //   (ite: any) => ite.teamId !== from.teamId,
    // );

    const switch_Team = {
      [To.teamId]: {
        ...To,
        points: 0,
        joinedAt: user_joined_Teams[from.teamId].joinedAt,
      },
    };
    delete user_joined_Teams[from.teamId];
    const filterFromTeam = { ...user_joined_Teams, ...switch_Team };
    // update contest
    // filterFromTeam.push(To);
    const contest = contestDetail.data.contest;
    contest.jointUsers[userId].userTeams = filterFromTeam;

    await this.contest.updateContest(contestId, contest);

    return successResponse('switched');
  }
}
