import { Args, Context, Mutation, Query, Resolver } from '@nestjs/graphql';
import { TeamsService } from './teams.service';
import {
  compareTeamResponse,
  contest_defaultFields,
  singleTeamResponse,
} from 'src/commonResponse/response.entity';
import {
  editTeam,
  switchTeamsInput,
  teamCreation,
} from './dto/create-team.input';
import { AuthGuard } from 'src/auth/auth.guard';
import { UseGuards } from '@nestjs/common';
import {
  joinedTeamCollection,
  myTeamCollection,
  myTeamFootballCollection,
  myTeamsDetail,
} from './entities/myTeams.entity';
import { teamCreationOpt } from './entities/team.entity';

@Resolver()
@UseGuards(AuthGuard)
export class TeamsResolver {
  constructor(private readonly teamsService: TeamsService) {}

  @Query(() => myTeamCollection, { name: 'getMyTeams' })
  getMyTeams(
    @Context('user') user: any,
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('gameType') gameType: string,
  ) {
    return this.teamsService.myTeams({
      userId: user._id,
      fixtureAPIId,
      gameType,
    });
  }

  @Query(() => myTeamFootballCollection, { name: 'getMyFootballTeams' })
  getMyFootballTeams(
    @Context('user') user: any,
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('gameType') gameType: string,
  ) {
    return this.teamsService.myTeams({
      userId: user._id,
      fixtureAPIId,
      gameType,
    });
  }

  @Query(() => myTeamsDetail, { name: 'getMyTeamsDetail' })
  getMyTeamsDetail(
    @Context('user') user: any,
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('gameType') gameType: string,
    @Args('teamName') teamName: string,
  ) {
    return this.teamsService.myTeamsDetail({
      userId: user._id,
      fixtureAPIId,
      teamName,
      gameType,
    });
  }

  @Query(() => joinedTeamCollection, { name: 'getTeamsToJoin' })
  findTeams(
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('gameType') gameType: string,
    @Context('user') user: any,
    @Args('contestId', { defaultValue: '' }) contestId?: string,
  ) {
    return this.teamsService.teamsToJoin(
      fixtureAPIId,
      user._id,
      contestId,
      gameType,
    );
  }

  @Query(() => String, { name: 'updateSelectedby' })
  updateSelectedby(
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('gameType') gameType: string,
    @Context('user') user: any,
  ) {
    return this.teamsService.updateSelBy(fixtureAPIId, gameType);
  }

  @Mutation(() => teamCreationOpt, { name: 'createTeam' })
  createTeam(@Context('user') user: any, @Args('input') input: teamCreation) {
    return this.teamsService.teamCreation({
      userId: user._id,
      userName: user?.userName || 'testuser',
      ...input,
    });
  }

  @Mutation(() => contest_defaultFields, { name: 'editTeam' })
  async editTeam(@Context('user') user: any, @Args('input') input: editTeam) {
    /* return this.teamsService.teamCreation({
      userId: user._id,
      userName: user?.userName || 'testuser',
      ...input,
    }); */
    return await this.teamsService.editTeam(
      input,
      user._id,
      user?.userName || 'guestUser',
    );
  }

  @Mutation(() => contest_defaultFields, { name: 'switchTeams' })
  switchTeams(
    @Args('input') input: switchTeamsInput,
    @Context('user') user: any,
  ) {
    return this.teamsService.switchTeams(input, user._id);
  }

  @Query(() => myTeamsDetail, { name: 'singleUserTeam' })
  getSingleTeambyFixture(
    @Args('fixtureAPIId') fixtureAPIId: number,
    @Args('teamId') teamId: string,
    @Args('gameType') gameType: string,
    @Context('user') user: any,
  ) {
    return this.teamsService.singleUserTeam(fixtureAPIId, teamId, gameType);
  }
}
