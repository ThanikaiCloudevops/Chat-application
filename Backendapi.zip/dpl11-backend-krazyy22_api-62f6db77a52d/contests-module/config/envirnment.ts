export const MODULE = { NAME: 'Contest Module', PORT: 5002 };
export const DB = {
  URL: 'mongodb+srv://sciflare:HEO6yUFoS7tmk3w0@krayzz22.vh8chph.mongodb.net/krayzz22',
};

export const TRPC = {
  //development
  USERAUTH: 'http://3.7.135.45:5000/trpc/userauth',
  SCORECARD: 'http://3.7.135.45:4000/trpc/scorecard',
  CRICKETGAME: 'http://3.7.135.45:5001/trpc/game',
  TRANSACTION: 'http://3.7.135.45:5005/trpc/wallet',
  // local
  // USERAUTH: 'http://localhost:5000/trpc/userauth',
  // SCORECARD: 'http:/localhost:4000/trpc/scorecard',
  // CRICKETGAME: 'http:/localhost:5001/trpc/game',
  // TRANSACTION: 'http://localhost:5005/trpc/wallet',
};
