import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { NotificationService } from './notification.service';
import { CreateNotificationDto } from './dto/create-notification.dto';
import { UpdateNotificationDto } from './dto/update-notification.dto';
import { Args } from '@nestjs/graphql';

@Controller('notification')
export class NotificationController {
  constructor(private readonly notificationService: NotificationService) {}

  @Get('/sendNotification')
  sendNotification(@Body() deviceToken:String[],@Body() payload:String) {
    try{
      return this.notificationService.sendNotification(deviceToken,payload);
    }
   catch (error) {
    console.error('Failed to send push notification:', error);
    return 'Failed to send push notification';
  }
   
  }
}
