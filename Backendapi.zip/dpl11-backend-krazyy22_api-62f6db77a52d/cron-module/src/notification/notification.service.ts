import { Injectable } from '@nestjs/common';
import BetterQueue from 'better-queue';
import * as admin from 'firebase-admin';
//const fcm = require("fcm-notification");
import { SERVICE_ACCOUNT } from 'config/envirnment';
import { FirebaseService } from './firebase.service';
//const FCM = new fcm(certPath);

@Injectable()
export class NotificationService {
  private notificationQueue: BetterQueue;

  constructor(private readonly firebaseService: FirebaseService) {
    this.notificationQueue = new BetterQueue(
      async (input, cb) => {
        try {
          var title = input.body.notification.title;
          var body = input.body.notification.body;
          var deviceid = input.value;
          const message = {
            notification: {
              title,
              body,
            },
            token: deviceid,
          };
          // await this.sendPush(message);
          await this.sendPushWithRetry(message);
          cb(null, 'Job completed');
        } catch (error) {
          console.error('Error sending notification:', error);
          cb(error);
        }
        // Process the job here
      },
      {
        // Options for better-queue
        store: {
          type: 'memory',
        },
        // Retry options
        maxRetries: 2,
        retryDelay: 1000,
        concurrent: 1,
      },
      // Adjust concurrency as needed
    );
  }

  async sendNotification(deviceToken: String[], payload: any) {
    const body = payload;
    deviceToken.forEach((value, index) => {
      this.notificationQueue.push({ value, body });
    });
  }
  /*       
  async sendPush(message) {
    try {
      await this.firebaseService.getFirebaseAdmin().messaging().send(message);
      // return 'success'
    } catch (error) {
      console.error('Error sending push notification:', error.errorInfo.code);
      var value = message.token;
      var body = message.notification.title;
      this.notificationQueue.on('task_failed', (taskId, errorMessage) => {
        console.error(`Job failed after retries: ${taskId}, ${errorMessage}`);
      });

      // await this.notificationQueue.push({ value,body });
    }
  }
*/
  async sendPushWithRetry(message, attempt = 1) {
    try {
      await this.sendPush(message);
    } catch (error) {
      console.error(`Error sending push notification (attempt ${attempt}):`);
      if (attempt <= 2) {
        await new Promise((resolve) => setTimeout(resolve, 1000)); // Wait before retrying
        await this.sendPushWithRetry(message, attempt + 1); // Retry the sendPush operation
      } else {
        console.log('Maximum number of retries reached');
      }
    }
  }

  async sendPush(message) {
    try {
      await this.firebaseService.getFirebaseAdmin().messaging().send(message);
    } catch (error) {
      // Handle specific error scenarios if needed
      throw error; // Rethrow the error to trigger retry logic
    }
  }
}
