// firebase.service.ts

import { Injectable } from '@nestjs/common';
import * as admin from 'firebase-admin';
import {SERVICE_ACCOUNT}from "../../config/envirnment";
import { catchError } from 'rxjs';

@Injectable()
export class FirebaseService {
  private readonly firebaseAdmin: admin.app.App;

 constructor() {
    
      const firebaseApps = admin.apps;
      if (firebaseApps.length === 0) {
        this.firebaseAdmin = admin.initializeApp({
          credential: admin.credential.cert(SERVICE_ACCOUNT as admin.ServiceAccount),
        });
      } else {
        this.firebaseAdmin = firebaseApps[0];
      }
  }

  getFirebaseAdmin(): admin.app.App {
    
      if (!this.firebaseAdmin) {
        throw new Error('Firebase Admin not initialized');
      }
      return this.firebaseAdmin;
      
}
}
