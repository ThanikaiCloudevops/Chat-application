import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type kabaddiScorecardDocument = KabaddiScorecard & Document;

export class KabaddiResult {
  home: number;
  away: number;
  winner: number;
  text: string;
  tie: boolean;
}

export class KabadiToss {
  winner: number;
  decision: string;
}

export class KabadiScorecardTeam {
  teamAPIId: number;
  teamName: string;
  teamDisplayName: string;
  logo: string;
}

export class KabaddiScorecardTeams {
  home: KabadiScorecardTeam;
  away: KabadiScorecardTeam;
}

export class KabaddiMatchStats {
  totalpoint: number;
  alloutpoint: number;
  extrapoint: number;
  declarepoint: number;
  raidtotalpoint: number;
  raidtouchpoint: number;
  raidbonuspoint: number;
  tackletotalpoint: number;
  tacklecapturepoint: number;
  tacklecapturebonuspoint: number;
  raidtotal: number;
  raidsuccessful: number;
  raidunsuccessful: number;
  raidempty: number;
  superraid: number;
  tackletotal: number;
  tacklesuccessful: number;
  tackleunsuccessful: number;
  supertackles: number;
  allouts: number;
  declare: number;
}

export class KabadiTeamStats {
  home: KabaddiMatchStats;
  away: KabaddiMatchStats;
}

@Schema()
export class KabaddiScorecard {
  @Prop({ type: Number })
  fixtureAPIId: number;

  @Prop({ type: Number })
  seriesAPIId: number;

  @Prop()
  status: string;

  @Prop()
  result: KabaddiResult;

  @Prop()
  toss: KabadiToss;

  @Prop()
  teams: KabaddiScorecardTeams;

  @Prop()
  gameStats: KabadiTeamStats;
}

export const KabaddiScorecardSchema =
  SchemaFactory.createForClass(KabaddiScorecard);
