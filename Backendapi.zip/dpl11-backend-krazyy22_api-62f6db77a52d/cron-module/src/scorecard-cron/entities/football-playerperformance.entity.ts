import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export type FootballPlayerPointsDocument = FootballPlayerPerformance & Document;

export class FootballPlayerPoints {
  @Prop()
  playerAPIId: number;
  @Prop()
  playerName: string;
  @Prop()
  playerRole: string;
  @Prop()
  playerTeamType: string;
  @Prop()
  goalStrikerPoints: number;
  @Prop()
  goalMidfielderPoints: number;
  @Prop()
  goalDefKeepPoints: number;
  @Prop()
  assistPoints: number;
  @Prop()
  chanceCreatedPoints: number;
  @Prop()
  shotOnTargetPoints: number;
  @Prop()
  fivePassPoints: number;
  @Prop()
  tacketPoints: number;
  @Prop()
  interceptionPoints: number;
  @Prop()
  goalSavePoints: number;
  @Prop()
  penaltySavePoints: number;
  @Prop()
  cleanSheetPoints: number;
  @Prop()
  in11Points: number;
  @Prop()
  subPoints: number;
  @Prop()
  yellowCardPoints: number;
  @Prop()
  redCardPoints: number;
  @Prop()
  ownGoalPoints: number;
  @Prop()
  goalsConcededPoints: number;
  @Prop()
  penaltyMissedPoints: number;
  @Prop()
  playerPoints: number;
}

export class FootballPlayerStats {
  @Prop()
  playerAPIId: number;
  @Prop()
  playerName: string;
  @Prop()
  playerRole: string;
  @Prop()
  playerTeamType: string;
  @Prop()
  goalStrikerMade: number;
  @Prop()
  goalMidfielderMade: number;
  @Prop()
  goalDefKeepMade: number;
  @Prop()
  assistMade: number;
  @Prop()
  chanceCreatedMade: number;
  @Prop()
  shotOnTargetMade: number;
  @Prop()
  fivePassMade: number;
  @Prop()
  tacketMade: number;
  @Prop()
  interceptionMade: number;
  @Prop()
  goalSaveMade: number;
  @Prop()
  penaltySaveMade: number;
  @Prop()
  cleanSheetMade: number;
  @Prop()
  yellowCardMade: number;
  @Prop()
  redCardMade: number;
  @Prop()
  ownGoalMade: number;
  @Prop()
  goalsConcededMade: number;
  @Prop()
  penaltyMissedMade: number;
}

@Schema()
export class FootballPlayerPerformance {
  @Prop({ type: Number })
  fixtureAPIId: number;

  @Prop({ type: String })
  fixtureStatus: string;

  @Prop()
  playerPoints: FootballPlayerPoints[];

  @Prop()
  playerStats: FootballPlayerStats[];
}

export const FootballPlayerPerformanceSchema = SchemaFactory.createForClass(
  FootballPlayerPerformance,
);
