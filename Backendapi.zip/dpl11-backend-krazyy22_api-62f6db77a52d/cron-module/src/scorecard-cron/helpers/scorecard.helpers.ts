import { Injectable } from '@nestjs/common';
import { Bat, Bowl, Field, pointDocument } from '../entities/points.entity';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import {
  BatTeam,
  BowlTeam,
  DNBTeam,
  Inning,
  Scorecard,
  Team,
  fieldTeam,
} from '../entities/scorecard.entity';
import { playerPoint, playerStat } from '../entities/playerPerformance.entity';
import { lineUpDocument } from 'src/lineup-cron/entities/lineup-cron.entity';
import {
  FootballScorecard,
  GameStats,
  PlayerStats,
  scorecardTeams,
} from '../entities/football-scorecard.entity';
import {
  FootballPlayerPerformance,
  FootballPlayerPoints,
  FootballPlayerStats,
} from '../entities/football-playerperformance.entity';
import { footballPointsDocument } from '../entities/football-points.entity';
import { footballLineupDocument } from 'src/lineup-cron/entities/football-lineup.entity';
import {
  KabaddiScorecard,
  KabadiTeamStats,
} from '../entities/kabaddi-scoreacard.entity';
import {
  KabaddiPlayerPoints,
  KabaddiPlayerStats,
} from '../entities/kabaddi-playerperformance.entity';
import { KabaddiPointsDocument } from '../entities/kabaddi-points.entity';
import { kabaddiLineupDocument } from 'src/lineup-cron/entities/kabaddi-lineup.entity';

@Injectable()
export class ScorecardHelpers {
  constructor(
    @InjectModel('Point')
    private pointsModel: Model<pointDocument>,
    @InjectModel('Lineup')
    private lineUpModel: Model<lineUpDocument>,
    @InjectModel('FootballLineup')
    private footballLineupModel: Model<footballLineupDocument>,
    @InjectModel('footballPoints')
    private footballPointsModel: Model<footballPointsDocument>,
    @InjectModel('KabaddiPoints')
    private kabaddiPointsModel: Model<KabaddiPointsDocument>,
    @InjectModel('KabaddiLineup')
    private kabaddiLineupodel: Model<kabaddiLineupDocument>,
  ) {}

  initilizeScorecard(scorecard: any): Scorecard {
    try {
      return {
        fixtureAPIId: scorecard?.fixtureAPIId,
        sereisAPIId: 0,
        fixtureType: scorecard?.fixtureType,
        fixtureStatus: scorecard?.fixtureStatus,
        fixtureStatusNote: scorecard.fixtureStatusNote,
        maxInningsCount: scorecard?.fixtureType == 'Test' ? 4 : 2,
        currentInnings: Object.keys(scorecard?.innings).length,
        teams: {
          teamA: this.team(scorecard?.teams?.teamA),
          teamB: this.team(scorecard?.teams?.teamB),
        },
      };
    } catch (err) {
      return null;
    }
  }

  team(teamName: Team): Team {
    return {
      logo: teamName?.logo,
      name: teamName?.name,
      shortName: teamName?.shortName,
      teamAPIId: teamName?.teamAPIId,
      scores_full: teamName?.scores_full,
      scores: teamName?.scores,
      overs: teamName?.overs,
    };
  }

  async batFormatting(batTeam: [any]): Promise<[BatTeam]> {
    try {
      const formattedTeam = [];
      for (const player of batTeam) {
        formattedTeam.push({
          playerName: player.playerName,
          playerAPIId: +player.playerAPIId,
          player_type: player.player_type,
          ballsFaced: +player.ballsFaced,
          battingPosition: player.battingPosition,
          runsScored: +player.runsScored,
          foursHit: +player.foursHit,
          sixesHit: +player.sixesHit,
          strikeRate: +player.strikeRate,
          outStatus: eval(player.outStatus),
          outType: player.outType,
        });
      }
      return formattedTeam as [BatTeam];
    } catch (err) {
      return null;
    }
  }

  async bowlFormatting(bowlTeam: [any]): Promise<[BowlTeam]> {
    try {
      const formattedTeam = [];
      for (const player of bowlTeam) {
        formattedTeam.push({
          playerName: player.playerName,
          playerAPIId: +player.playerAPIId,
          player_type: player.player_type || '',
          bowlingPosition: player.bowlingPosition,
          oversBowled: +player.oversBowled,
          runsGiven: +player.runsGiven,
          maidensBowled: +player.maidensBowled,
          noBallsBowled: +player.noBallsBowled,
          widesBowled: +player.widesBowled,
          wicketsTaken: +player.wicketsTaken,
          bowledMade: +player.bowledMade,
          lbwMade: +player.lbwMade,
          economy: +player.economy,
          bowlingStrikerate: +player.bowlingStrikerate || 0,
        });
      }
      return formattedTeam as [BowlTeam];
    } catch (err) {
      return null;
    }
  }

  async fildersFormatting(fieldTeam: [any]): Promise<[fieldTeam]> {
    try {
      const formattedTeam = [];
      for (const player of fieldTeam) {
        formattedTeam.push({
          fielder_id: player.fielder_id,
          fielder_name: player.fielder_name,
          catches: player.catches,
          runout_thrower: player.runout_thrower,
          runout_catcher: player.runout_catcher,
          runout_direct_hit: player.runout_direct_hit,
          stumping: player.stumping,
          is_substitute: player.is_substitute,
        });
      }
      return formattedTeam as [fieldTeam];
    } catch (error) {
      return null;
    }
  }

  async dnbTeamFormatting(dnbTeam: [any]): Promise<[DNBTeam]> {
    try {
      const formattedTeam = [];
      for (const player of dnbTeam) {
        formattedTeam.push({
          playerId: player.playerId,
          playerName: player.playerName,
        });
      }
      return formattedTeam as [DNBTeam];
    } catch (error) {
      return null;
    }
  }

  async inningsFormatting(scoreCardInnings: any): Promise<Inning> {
    try {
      const batTeam: [BatTeam] = await this.batFormatting(
        scoreCardInnings?.bat?.team,
      );
      const bowlTeam: [BowlTeam] = await this.bowlFormatting(
        scoreCardInnings?.bowl?.team,
      );
      const fieldTeam: [fieldTeam] = await this.fildersFormatting(
        scoreCardInnings?.field?.team,
      );
      const dnbTeam: [DNBTeam] = await this.dnbTeamFormatting(
        scoreCardInnings?.didNotBat?.team,
      );

      if (!batTeam || !bowlTeam) return null;

      return {
        inningsNumber: scoreCardInnings.innings_number,
        equations: scoreCardInnings?.equations,
        fielders: {
          teamAPIId: scoreCardInnings?.field?.teamAPIId,
          team: fieldTeam,
        },
        extras: scoreCardInnings?.extras,
        bat: {
          teamAPIId: scoreCardInnings?.bat?.teamAPIId,
          team: batTeam,
        },
        bowl: {
          teamAPIId: scoreCardInnings?.bowl?.teamAPIId,
          team: bowlTeam,
        },
        didNotBat: {
          teamAPIId: scoreCardInnings?.didNotBat?.teamAPIId,
          team: dnbTeam,
        },
      };
    } catch (err) {
      return null;
    }
  }

  async formatScorecard(scorecard: any): Promise<Scorecard> {
    try {
      const formattedScorecard: Scorecard = this.initilizeScorecard(scorecard);
      if (!formattedScorecard) return null;

      if (scorecard?.toss?.wonTeamId) {
        const toss = {
          result: scorecard?.toss?.result,
          text: scorecard?.toss?.text,
          wonTeamId: scorecard?.toss?.wonTeamId,
        };
        formattedScorecard.toss = toss;
      }
      const scoreCardInnings = scorecard?.innings;

      formattedScorecard.innings = [];
      for (const key in scoreCardInnings) {
        const inning = scoreCardInnings[key];
        const formattedInnings: Inning = await this.inningsFormatting(inning);
        if (!formattedInnings) return null;
        formattedScorecard.innings.push(formattedInnings);
      }

      return formattedScorecard;
    } catch (err) {
      return null;
    }
  }

  async combinedStats(playerMatchStats: any[]): Promise<any> {
    try {
      const distinctPlayers = playerMatchStats.reduce((value, item) => {
        const keys = item['playerAPIId']
          ? item['playerAPIId']
          : item['fielder_id'];
        if (!value[keys]) value[keys] = {};
        value[keys] = { ...value[keys], ...item };
        return value;
      }, {});
      return Object.values(distinctPlayers);
    } catch (err) {
      return null;
    }
  }

  economyStrikeratePointsCalc(rate: number, pointsObj: object) {
    try {
      for (const rates in pointsObj) {
        const point = pointsObj[rates];
        const range = rates.split('-');
        if (
          (rate >= eval(range[0]) || !eval(range[0])) &&
          (rate <= eval(range[1]) || !eval(range[1]))
        ) {
          return point;
        }
      }
      return 0;
    } catch (err) {
      return 0;
    }
  }

  bowlPoinsCalculation(bowlPoints: Bowl, playerStats: playerStat): any {
    try {
      bowlPoints.threeWicketBonus;
      const lbwBowled: number =
        (playerStats.bowledMade || 0) + (playerStats.lbwMade || 0);

      const wicketsTaken = playerStats.wicketsTaken || 0;
      const maidensBowled = playerStats.maidensBowled || 0;
      const bonusWickets =
        wicketsTaken > 4
          ? 'fiveWicketBonus'
          : wicketsTaken > 3
          ? 'fourWicketBonus'
          : wicketsTaken > 2
          ? 'threeWicketBonus'
          : null;

      return {
        LBWBowledBonus: lbwBowled * bowlPoints.LBWBowledBonus || 0,
        wicketBonus: wicketsTaken * bowlPoints.wicket || 0,
        bonus: bonusWickets ? bowlPoints[bonusWickets] : 0,
        maidenBonus: maidensBowled * bowlPoints.maiden || 0,
        economyBonus:
          playerStats.oversBowled >= bowlPoints.economy.min
            ? this.economyStrikeratePointsCalc(
                playerStats.economy,
                bowlPoints.economy.points,
              )
            : 0,
      };
    } catch (err) {
      return {
        LBWBowledBonus: 0,
        wicketBonus: 0,
        bonus: 0,
        maidenBonus: 0,
        economyBonus: 0,
      };
    }
  }

  batPointsCalculation(batlPoints: Bat, playerStats: playerStat): any {
    try {
      return {
        runPoints: playerStats.runsScored * batlPoints.run || 0,
        fourPoints: playerStats.foursHit * batlPoints.four || 0,
        sixPoints: playerStats.sixesHit * batlPoints.six || 0,
        thirtyPoints:
          playerStats.runsScored > 29 && playerStats.runsScored < 49
            ? batlPoints.thirty
            : 0,
        fiftyPoints:
          Math.floor(playerStats.runsScored / 50) * batlPoints.fifty || 0,
        duckPoints: playerStats.runsScored == 0 ? batlPoints.duck : 0,
        strike_rate:
          playerStats.ballsFaced >= batlPoints.strikerate.min
            ? this.economyStrikeratePointsCalc(
                playerStats.strikeRate,
                batlPoints.strikerate.points,
              )
            : 0,
      };
    } catch (err) {
      return {
        runPoints: 0,
        fourPoints: 0,
        sixPoints: 0,
        thirtyPoints: 0,
        fiftyPoints: 0,
        duckPoints: 0,
      };
    }
  }

  fieldingPointsCalculator(fieldPoints: Field, playerStats: playerStat): any {
    try {
      return {
        catchPoints: playerStats.catches * fieldPoints.catch || 0,
        bonus_catch:
          playerStats?.catches >= fieldPoints.bonus.min
            ? fieldPoints.bonus.bonus
            : 0,
        direct_runout:
          (playerStats.runout_direct_hit || 0) * fieldPoints.runout.direct,
        runout_catcher:
          (playerStats.runout_catcher || 0) * fieldPoints.runout.indirect,
        runout_thrower:
          (playerStats.runout_thrower || 0) * fieldPoints.runout.indirect,
        runout_stumping: 0,
        stumping: (playerStats.stumping || 0) * fieldPoints.stumping,
      };
    } catch (err) {
      return {
        catchPoints: 0,
        bonus_catch: 0,
        direct_runout: 0,
        runout_catcher: 0,
        runout_stumping: 0,
        runout_thrower: 0,
        stumping: 0,
      };
    }
  }

  async pointsCalculation(
    formatType: string,
    playerPerformance: playerStat[],
    fixtureAPIId: number,
  ): Promise<playerPoint[]> {
    try {
      const lineups = await this.lineUpModel.findOne({ fixtureAPIId });
      const completedPlayers = [];
      const playerPoints: playerPoint[] = [];
      const masterPoints = await this.pointsModel.findOne({ formatType });
      for (const playerStats of playerPerformance) {
        let playerPointsData: any = {};

        const {
          LBWBowledBonus,
          wicketBonus,
          bonus,
          maidenBonus,
          economyBonus,
        } = this.bowlPoinsCalculation(masterPoints.points.bowl, playerStats);

        const {
          runPoints,
          fourPoints,
          sixPoints,
          thirtyPoints,
          fiftyPoints,
          duckPoints,
          strike_rate,
        } = this.batPointsCalculation(masterPoints.points.bat, playerStats);

        const {
          catchPoints,
          bonus_catch,
          direct_runout,
          runout_catcher,
          runout_stumping,
          runout_thrower,
          stumping,
        } = this.fieldingPointsCalculator(
          masterPoints.points.field,
          playerStats,
        );

        playerPointsData.playing11 =
          playerStats.fielder_id && playerStats.is_substitute
            ? 0
            : masterPoints.points.in11;
        playerPointsData.bonus_bowedlbw = LBWBowledBonus;
        playerPointsData.bonus = bonus;
        playerPointsData.wickets = wicketBonus;
        playerPointsData.maidenover = maidenBonus;
        playerPointsData.economic_rate = economyBonus;
        playerPointsData.run = runPoints;
        playerPointsData.four = fourPoints;
        playerPointsData.six = sixPoints;
        playerPointsData.thirty = thirtyPoints;
        playerPointsData.fifty = fiftyPoints;
        playerPointsData.duck = duckPoints;
        playerPointsData.strike_rate = strike_rate;
        playerPointsData.catch = catchPoints;
        playerPointsData.bonus_catch = bonus_catch;
        playerPointsData.direct_runout = direct_runout;
        playerPointsData.runout_catcher = runout_catcher;
        playerPointsData.runout_thrower = runout_thrower;
        playerPointsData.runout_stumping = runout_stumping;
        playerPointsData.stumping = stumping;
        playerPointsData.rating = 0;
        playerPointsData.point = Object.values(playerPointsData).reduce(
          (a: number, b: number) => a + b,
          0,
        );

        playerPointsData.player_id =
          playerStats.playerAPIId || playerStats.fielder_id;
        playerPointsData.player_name =
          playerStats.playerName || playerStats.fielder_name;
        playerPointsData.player_role = playerStats.player_type;

        completedPlayers.push(playerPointsData.player_id);
        playerPoints.push(playerPointsData);
      }

      if (lineups) {
        const lineupPlayers = [
          ...lineups.teamA.squads,
          ...lineups.teamB.squads,
        ].filter((e) => !completedPlayers.includes(e.playerId));
        for (const player of lineupPlayers) {
          playerPoints.push({
            player_id: player.playerId,
            player_name: player.name,
            player_role: player.role,
            playing11: masterPoints.points.in11,
            rating: 0,
            point: masterPoints.points.in11,
            run: 0,
            four: 0,
            six: 0,
            strike_rate: 0,
            fifty: 0,
            duck: 0,
            wickets: 0,
            maidenover: 0,
            economic_rate: 0,
            catch: 0,
            runout_stumping: 0,
            runout_thrower: 0,
            runout_catcher: 0,
            direct_runout: 0,
            stumping: 0,
            thirty: 0,
            bonus: 0,
            bonus_catch: 0,
            bonus_bowedlbw: 0,
          });
        }
      }

      return playerPoints;
    } catch (err) {
      console.log(err);
      return null;
    }
  }

  footballTeams(teams: any): scorecardTeams {
    return {
      away: {
        teamAPIId: teams?.away?.tid,
        fullName: teams?.away?.fullname,
        logo: teams?.away?.logo,
        name: teams?.away?.tname,
        shortName: teams?.away?.abbr,
      },
      home: {
        teamAPIId: teams?.home?.tid,
        fullName: teams?.home?.fullname,
        logo: teams?.home?.logo,
        name: teams?.home?.tname,
        shortName: teams?.home?.abbr,
      },
    };
  }

  footballGameStats(gameStats: any[]): GameStats[] {
    return gameStats.map((e) => {
      return {
        away: +e?.away || 0,
        home: +e?.home || 0,
        name: e?.name,
      };
    });
  }

  footballPlayerStats(playerStats: any[]): PlayerStats[] {
    return playerStats.map((e) => {
      return {
        playerAPIId: +e?.pid,
        playerName: e?.pname,
        role: e?.role,
        teamType: e?.teamtype,
        fouls: e?.fouls || 0,
        goals: e?.goals || 0,
        saves: e?.saves || 0,
        assist: e?.assist || 0,
        keypass: e?.keypass || 0,
        punches: e?.punches || 0,
        redcard: e?.redcard || 0,
        duelswon: e?.duelswon || 0,
        owngoals: e?.owngoals || 0,
        totalpass: e?.totalpass || 0,
        wasfouled: e?.wasfouled || 0,
        cleansheet: e?.cleansheet || 0,
        crossesacc: e?.crossesacc || 0,
        duelstotal: e?.duelstotal || 0,
        penaltywon: e?.penaltywon || 0,
        totalcross: e?.totalcross || 0,
        yellowcard: e?.yellowcard || 0,
        hitwoodwork: e?.hitwoodwork || 0,
        penaltymiss: e?.penaltymiss || 0,
        penaltysave: e?.penaltysave || 0,
        accuratepass: e?.accuratepass || 0,
        dispossessed: e?.dispossessed || 0,
        goalconceded: e?.goalconceded || 0,
        longballsacc: e?.longballsacc || 0,
        shotsblocked: e?.shotsblocked || 0,
        totalrunsout: e?.totalrunsout || 0,
        challengelost: e?.challengelost || 0,
        goodhighclaim: e?.goodhighclaim || 0,
        lastmantackle: e?.lastmantackle || 0,
        minutesplayed: e?.minutesplayed || 0,
        runsoutsucess: e?.runsoutsucess || 0,
        shotsontarget: e?.shotsontarget || 0,
        tacklesuccess: e?.tacklesuccess || 0,
        dribblesuccess: e?.dribblesuccess || 0,
        errorledtogoal: e?.errorledtogoal || 0,
        errorledtoshot: e?.errorledtoshot || 0,
        shotsofftarget: e?.shotsofftarget || 0,
        totalclearance: e?.totalclearance || 0,
        totallongballs: e?.totallongballs || 0,
        bigchancemissed: e?.bigchancemissed || 0,
        dribbleattempts: e?.dribbleattempts || 0,
        interceptionwon: e?.interceptionwon || 0,
        outfielderblock: e?.outfielderblock || 0,
        passingaccuracy: e?.passingaccuracy || 0,
        tacklecommitted: e?.tacklecommitted || 0,
        bigchancecreated: e?.bigchancecreated || 0,
        clearanceoffline: e?.clearanceoffline || 0,
        penaltycommitted: e?.penaltycommitted || 0,
        savesfrominsidebox: e?.savesfrominsidebox || 0,
      };
    });
  }

  footballScorecard(scorecard: any): FootballScorecard {
    try {
      return {
        fixtureAPIId: +scorecard?.match_id,
        seriesAPIId: +scorecard?.seriesId,
        status: scorecard?.fixtureStatus,
        result: {
          away: +scorecard?.result?.away || 0,
          home: +scorecard?.result?.home || 0,
          winner: scorecard?.result?.winner,
        },
        teams: this.footballTeams(scorecard?.teams),
        periods: {
          ft: {
            away: +scorecard?.periods?.ft?.away || 0,
            home: +scorecard?.periods?.ft?.home || 0,
          },
          p1: {
            away: +scorecard?.periods?.p1?.away || 0,
            home: +scorecard?.periods?.p1?.home || 0,
          },
          p2: {
            away: +scorecard?.periods?.p2?.away || 0,
            home: +scorecard?.periods?.p2?.home || 0,
          },
        },
        gameStats: this.footballGameStats(scorecard?.statistics),
        playerStats: this.footballPlayerStats([
          ...(scorecard?.player_statistics?.away || []),
          ...(scorecard?.player_statistics?.home || []),
        ]),
      };
    } catch (err) {
      return null;
    }
  }

  footballPointsCalculation(
    playerStats: FootballPlayerStats[],
    points: footballPointsDocument,
    lineup: footballLineupDocument,
  ): FootballPlayerPoints[] {
    const playerPoints: FootballPlayerPoints[] = [];
    const in11Players = [
      ...lineup.homeTeam.in11.players,
      ...lineup.awayTeam.in11.players,
    ].map((e) => e.playerAPIId);
    const completedStatsCalPlayerId = [];

    for (const stats of playerStats) {
      const playerPoint: any = {
        assistPoints: stats.assistMade * points.assist || 0,
        chanceCreatedPoints:
          stats.chanceCreatedMade * points.chanceCreated || 0,
        cleanSheetPoints: stats.cleanSheetMade * points.cleanSheet || 0,
        fivePassPoints: stats.fivePassMade * points.fivePass || 0,
        goalDefKeepPoints: stats.goalDefKeepMade * points.goalDefKeep || 0,
        goalMidfielderPoints:
          stats.goalMidfielderMade * points.goalMidfielder || 0,
        goalSavePoints: stats.goalSaveMade * points.goalSave || 0,
        goalsConcededPoints:
          stats.goalsConcededMade * points.goalsConceded || 0,
        goalStrikerPoints: stats.goalStrikerMade * points.goalStriker || 0,
        in11Points: in11Players.includes(stats.playerAPIId) ? points.in11 : 0,
        interceptionPoints: stats.interceptionMade * points.interception || 0,
        ownGoalPoints: stats.ownGoalMade * points.ownGoal || 0,
        penaltyMissedPoints:
          stats.penaltyMissedMade * points.penaltyMissed || 0,
        penaltySavePoints: stats.penaltySaveMade * points.penaltySave || 0,
        redCardPoints: stats.redCardMade * points.redCard || 0,
        shotOnTargetPoints: stats.shotOnTargetMade * points.shotOnTarget || 0,
        tacketPoints: stats.tacketMade * points.tackel || 0,
        yellowCardPoints: stats.yellowCardMade * points.yellowCard || 0,
      };
      playerPoint.subPoints = playerPoint.in11Points > 0 ? 0 : points.sub;

      let totalPoints = 0;
      for (const player in playerPoint) {
        const point = playerPoint[player];
        totalPoints += point;
      }

      playerPoint.playerPoints = totalPoints;
      playerPoint.playerAPIId = stats.playerAPIId;
      playerPoint.playerName = stats.playerName;
      playerPoint.playerRole = stats.playerRole;
      playerPoint.playerTeamType = stats.playerTeamType;
      playerPoints.push(playerPoint);
      completedStatsCalPlayerId.push(stats.playerAPIId);
    }

    for (const playerLineup of [
      ...lineup.homeTeam.in11.players.map((e) => {
        return { ...e, playerTeamType: 'home' };
      }),
      ...lineup.awayTeam.in11.players.map((e) => {
        return { ...e, playerTeamType: 'away' };
      }),
    ].filter((e) => !completedStatsCalPlayerId.includes(e.playerAPIId))) {
      playerPoints.push({
        playerAPIId: playerLineup.playerAPIId,
        playerName: playerLineup.playerName,
        playerRole: playerLineup.positionName,
        playerTeamType: playerLineup.playerTeamType,
        goalStrikerPoints: 0,
        goalMidfielderPoints: 0,
        goalDefKeepPoints: 0,
        assistPoints: 0,
        chanceCreatedPoints: 0,
        shotOnTargetPoints: 0,
        fivePassPoints: 0,
        tacketPoints: 0,
        interceptionPoints: 0,
        goalSavePoints: 0,
        penaltySavePoints: 0,
        cleanSheetPoints: 0,
        in11Points: points.in11,
        subPoints: 0,
        yellowCardPoints: 0,
        redCardPoints: 0,
        ownGoalPoints: 0,
        goalsConcededPoints: 0,
        penaltyMissedPoints: 0,
        playerPoints: points.in11,
      });
    }

    return playerPoints;
  }

  async footballPointStats(
    scorecard: FootballScorecard,
  ): Promise<FootballPlayerPerformance> {
    try {
      const footballPoints = await this.footballPointsModel
        .findOne({
          isactive: true,
        })
        .lean();
      const matchLineup = await this.footballLineupModel
        .findOne({
          fixtureAPIId: scorecard.fixtureAPIId,
        })
        .lean();
      const playerStats: FootballPlayerStats[] = scorecard.playerStats.map(
        (e) => {
          return {
            playerAPIId: e.playerAPIId,
            playerName: e.playerName,
            playerRole: e.role,
            playerTeamType: e.teamType,
            assistMade: e.assist,
            chanceCreatedMade: e.bigchancecreated,
            cleanSheetMade: e.cleansheet,
            fivePassMade: e.totalpass % 5,
            goalDefKeepMade:
              e.role == 'Defender' || e.role == 'Goalkeeper' ? e.goals : 0,
            goalMidfielderMade: e.role == 'Midfielder' ? e.goals : 0,
            goalStrikerMade: e.role == 'Forward' ? e.goals : 0,
            goalSaveMade: e.saves,
            goalsConcededMade: e.goalconceded,
            interceptionMade: e.interceptionwon,
            ownGoalMade: e.owngoals,
            penaltyMissedMade: e.penaltymiss,
            penaltySaveMade: e.penaltysave,
            redCardMade: e.redcard,
            shotOnTargetMade: e.shotsontarget,
            tacketMade: e.tacklesuccess,
            yellowCardMade: e.yellowcard,
          };
        },
      );
      const playerPoints: FootballPlayerPoints[] =
        this.footballPointsCalculation(
          playerStats,
          footballPoints,
          matchLineup,
        );

      return {
        fixtureAPIId: scorecard.fixtureAPIId,
        fixtureStatus: scorecard.status,
        playerStats,
        playerPoints,
      };
    } catch (err) {
      console.log(err);
      return {
        fixtureAPIId: scorecard.fixtureAPIId,
        fixtureStatus: scorecard.status,
        playerPoints: [],
        playerStats: [],
      };
    }
  }

  kabaddiGameStats(gamedata: any): KabadiTeamStats {
    try {
      return {
        away: {
          totalpoint: gamedata?.away?.totalpoint || 0,
          alloutpoint: gamedata?.away?.alloutpoint || 0,
          extrapoint: gamedata?.away?.extrapoint || 0,
          declarepoint: gamedata?.away?.declarepoint || 0,
          raidtotalpoint: gamedata?.away?.raidtotalpoint || 0,
          raidtouchpoint: gamedata?.away?.raidtouchpoint || 0,
          raidbonuspoint: gamedata?.away?.raidbonuspoint || 0,
          tackletotalpoint: gamedata?.away?.tackletotalpoint || 0,
          tacklecapturepoint: gamedata?.away?.tacklecapturepoint || 0,
          tacklecapturebonuspoint: gamedata?.away?.tacklecapturebonuspoint || 0,
          raidtotal: gamedata?.away?.raidtotal || 0,
          raidsuccessful: gamedata?.away?.raidsuccessful || 0,
          raidunsuccessful: gamedata?.away?.raidunsuccessful || 0,
          raidempty: gamedata?.away?.raidempty || 0,
          superraid: gamedata?.away?.superraid || 0,
          tackletotal: gamedata?.away?.tackletotal || 0,
          tacklesuccessful: gamedata?.away?.tacklesuccessful || 0,
          tackleunsuccessful: gamedata?.away?.tackleunsuccessful || 0,
          supertackles: gamedata?.away?.supertackles || 0,
          allouts: gamedata?.away?.allouts || 0,
          declare: gamedata?.away?.declare || 0,
        },
        home: {
          totalpoint: gamedata?.home?.totalpoint || 0,
          alloutpoint: gamedata?.home?.alloutpoint || 0,
          extrapoint: gamedata?.home?.extrapoint || 0,
          declarepoint: gamedata?.home?.declarepoint || 0,
          raidtotalpoint: gamedata?.home?.raidtotalpoint || 0,
          raidtouchpoint: gamedata?.home?.raidtouchpoint || 0,
          raidbonuspoint: gamedata?.home?.raidbonuspoint || 0,
          tackletotalpoint: gamedata?.home?.tackletotalpoint || 0,
          tacklecapturepoint: gamedata?.home?.tacklecapturepoint || 0,
          tacklecapturebonuspoint: gamedata?.home?.tacklecapturebonuspoint || 0,
          raidtotal: gamedata?.home?.raidtotal || 0,
          raidsuccessful: gamedata?.home?.raidsuccessful || 0,
          raidunsuccessful: gamedata?.home?.raidunsuccessful || 0,
          raidempty: gamedata?.home?.raidempty || 0,
          superraid: gamedata?.home?.superraid || 0,
          tackletotal: gamedata?.home?.tackletotal || 0,
          tacklesuccessful: gamedata?.home?.tacklesuccessful || 0,
          tackleunsuccessful: gamedata?.home?.tackleunsuccessful || 0,
          supertackles: gamedata?.home?.supertackles || 0,
          allouts: gamedata?.home?.allouts || 0,
          declare: gamedata?.home?.declare || 0,
        },
      };
    } catch (err) {
      return null;
    }
  }

  kabaddiScorecard(data: any): KabaddiScorecard {
    try {
      return {
        fixtureAPIId: +data?.match_id,
        seriesAPIId: +data?.seriesId,
        status: data?.fixtureStatus,
        toss: {
          winner: +data?.toss?.winner || 0,
          decision: data?.toss?.decision || '',
        },
        result: {
          away: +data?.result?.away || 0,
          home: +data?.result?.home || 0,
          text: data?.result?.text || '',
          tie: eval(data?.result?.tie),
          winner: +data?.result?.winner || 0,
        },
        teams: {
          away: {
            logo: data?.teams?.away?.logo || '',
            teamAPIId: +data?.teams?.away?.tid || 0,
            teamDisplayName: data?.teams?.away?.shortname || '',
            teamName: data?.teams?.away?.tname || '',
          },
          home: {
            logo: data?.teams?.home?.logo || '',
            teamAPIId: +data?.teams?.home?.tid || 0,
            teamDisplayName: data?.teams?.home?.shortname || '',
            teamName: data?.teams?.home?.tname || '',
          },
        },
        gameStats: this.kabaddiGameStats(data?.team_statistics),
      };
    } catch (err) {
      return null;
    }
  }

  kabaddiPlayerPerformance(data: any): KabaddiPlayerStats[] {
    try {
      const combinedPlayers = [
        ...data?.home.map((e: any) => {
          return { ...e, side: 'home' };
        }),
        ...data?.away.map((e: any) => {
          return { ...e, side: 'away' };
        }),
      ];
      return combinedPlayers.map((e) => {
        return {
          playerAPIId: e?.pid,
          playerName: e?.pname,
          side: e?.side,
          greencardcount: e?.greencardcount,
          yellowcardcount: e?.yellowcardcount,
          redcardcount: e?.redcardcount,
          totalpoint: e?.totalpoint,
          raidtotalpoint: e?.raidtotalpoint,
          raidtouchpoint: e?.raidtouchpoint,
          raidbonuspoint: e?.raidbonuspoint,
          tackletotalpoint: e?.tackletotalpoint,
          tacklecapturepoint: e?.tacklecapturepoint,
          tacklecapturebonuspoint: e?.tacklecapturebonuspoint,
          tackletotal: e?.tackletotal,
          tacklesuccessful: e?.tacklesuccessful,
          tackleunsuccessful: e?.tackleunsuccessful,
          supertackles: e?.supertackles,
          raidtotal: e?.raidtotal,
          raidsuccessful: e?.raidsuccessful,
          raidunsuccessful: e?.raidunsuccessful,
          raidempty: e?.raidempty,
          superraid: e?.superraid,
          superten: e?.superten,
          highfive: e?.highfive,
        };
      });
    } catch (err) {
      return [];
    }
  }

  async kabaddiPoints(
    fixtureAPIId: number,
    homeTeamAllOut: number,
    awayTeamAllOut: number,
    playerStats: KabaddiPlayerStats[],
  ): Promise<KabaddiPlayerPoints[]> {
    try {
      const kabadiPoints = await this.kabaddiPointsModel
        .findOne({
          isactive: true,
        })
        .lean();
      const matchLineup = await this.kabaddiLineupodel
        .findOne({
          fixtureAPIId,
        })
        .lean();
      const in11Players = [
        ...matchLineup.homeTeam,
        ...matchLineup.awayTeam,
      ].map((e) => e.playerAPIId);
      const activePlayers = [];
      const playerPoints = [];
      for (const playerStat of playerStats) {
        const playerPointObj: any = {
          in11Points: in11Players.includes(playerStat.playerAPIId)
            ? kabadiPoints.in11Points
            : 0,
          subPoints: in11Players.includes(playerStat.playerAPIId)
            ? 0
            : kabadiPoints.subPoints,
          raidtouchPoints:
            playerStat.raidtouchpoint * kabadiPoints.raidtouchPoints || 0,
          raidbonusPoints:
            playerStat.raidbonuspoint * kabadiPoints.raidbonusPoints || 0,
          superraidPoints:
            playerStat.superraid * kabadiPoints.superraidPoints || 0,
          supertenPoints:
            playerStat.superten * kabadiPoints.supertenPoints || 0,
          tacklesucceessfulPoints:
            playerStat.tacklesuccessful *
              kabadiPoints.tacklesucceessfulPoints || 0,
          supertacklePoints:
            playerStat.supertackles * kabadiPoints.supertacklePoints || 0,
          tackleunsucceessfulPoints:
            playerStat.tackleunsuccessful *
              kabadiPoints.tackleunsucceessfulPoints || 0,
          highfivePoints:
            playerStat.highfive * kabadiPoints.highfivePoints || 0,
          greencardPoints:
            playerStat.greencardcount * kabadiPoints.greencardPoints || 0,
          yellowcardPoints:
            playerStat.yellowcardcount * kabadiPoints.yellowcardPoints || 0,
          redcardPoints:
            playerStat.redcardcount * kabadiPoints.redcardPoints || 0,
          pushingalloutPoints:
            playerStat.side == 'home'
              ? homeTeamAllOut * kabadiPoints.pushingalloutPoints || 0
              : awayTeamAllOut * kabadiPoints.pushingalloutPoints || 0,
          gettingalloutPoints:
            playerStat.side == 'home'
              ? awayTeamAllOut * kabadiPoints.gettingalloutPoints || 0
              : homeTeamAllOut * kabadiPoints.gettingalloutPoints || 0,
        };
        playerPointObj.gettingalloutPoints = playerPointObj?.subPoints
          ? 0
          : playerPointObj.gettingalloutPoints;

        const totalPoints = Object.values(playerPointObj).reduce(
          (total: any, value) => {
            total += value;
            return total;
          },
          0,
        );

        playerPointObj.playerAPIId = playerStat.playerAPIId;
        playerPointObj.playerName = playerStat.playerName;
        playerPointObj.playerRole = '';
        playerPointObj.fantasyCredit = 0;
        playerPointObj.playerPoints = totalPoints;
        playerPoints.push(playerPointObj);
        activePlayers.push(playerPointObj.playerAPIId);
      }

      for (const playerId of in11Players) {
        if (!activePlayers.includes(playerId)) {
          playerPoints.push({
            playerAPIId: playerId,
            playerName:
              [...matchLineup.homeTeam, ...matchLineup.awayTeam].filter(
                (e) => e.playerAPIId == playerId,
              )[0].playerName || '',
            playerRole: '',
            fantasyCredit: 0,
            playerPoints: kabadiPoints.in11Points,
            in11Points: kabadiPoints.in11Points,
            subPoints: 0,
            raidtouchPoints: 0,
            raidbonusPoints: 0,
            superraidPoints: 0,
            supertenPoints: 0,
            tacklesucceessfulPoints: 0,
            supertacklePoints: 0,
            tackleunsucceessfulPoints: 0,
            highfivePoints: 0,
            greencardPoints: 0,
            yellowcardPoints: 0,
            redcardPoints: 0,
            pushingalloutPoints: 0,
          });
        }
      }

      return playerPoints;
    } catch (err) {
      return [];
    }
  }
}
