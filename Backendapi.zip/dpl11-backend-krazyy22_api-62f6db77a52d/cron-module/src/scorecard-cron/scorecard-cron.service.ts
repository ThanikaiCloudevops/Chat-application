import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Scorecard, scorecardeDocument } from './entities/scorecard.entity';
import { fixtureDocument } from 'src/game-cron/entities/fixtures.entity';
import { ScorecardHelpers } from './helpers/scorecard.helpers';
import { successResponse } from 'src/common-response/success.response';
import { playerPerformanceDocument } from './entities/playerPerformance.entity';
import { SPORTS_DATA } from 'config/envirnment';
import { commentries, CommentryDocument } from './entities/commentry.entity';
import { commentryHelper } from './helpers/commentry.helpers';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PointsCronService } from 'src/points-cron/points-cron.service';
import { pointDocument } from './entities/points.entity';
import { footballFixtureDocument } from 'src/game-cron/entities/footballfixtures.entity';
import {
  FootballScorecard,
  footballScorecardDocument,
} from './entities/football-scorecard.entity';
import { FootballPlayerPointsDocument } from './entities/football-playerperformance.entity';
import {
  FootballCommentary,
  FootballCommentaryDocument,
} from './entities/football-commentry.entity';
import { kabaddiFixtureDocument } from 'src/game-cron/entities/kabaddifixtures.entity';
import {
  KabaddiScorecard,
  kabaddiScorecardDocument,
} from './entities/kabaddi-scoreacard.entity';
import {
  KabaddiPlayerPerformanceDocument,
  KabaddiPlayerPoints,
  KabaddiPlayerStats,
} from './entities/kabaddi-playerperformance.entity';
import { lineupHelpers } from 'src/lineup-cron/helpers/lineup.service';
import { lineUpDocument } from 'src/lineup-cron/entities/lineup-cron.entity';

const options = { upsert: true, new: true, setDefaultsOnInsert: true };

@Injectable()
export class ScorecardCronService {
  constructor(
    @InjectModel('Scorecard')
    private scorecardModel: Model<scorecardeDocument>,
    @InjectModel('commentries')
    private commentaryModel: Model<CommentryDocument>,
    @InjectModel('cricketFixtures')
    private fixtureModel: Model<fixtureDocument>,
    @InjectModel('FootballFixtures')
    private footballFixturesModel: Model<footballFixtureDocument>,
    @InjectModel('KabaddiFixtures')
    private kabaddiFixturesModel: Model<kabaddiFixtureDocument>,
    @InjectModel('playerPerformance')
    private playerPerformanceModel: Model<playerPerformanceDocument>,
    @InjectModel('Point')
    private pointsModel: Model<pointDocument>,
    @InjectModel('FootballScorecard')
    private footballScorecardModel: Model<footballScorecardDocument>,
    @InjectModel('FootballPlayerPerformance')
    private footballPlayerPerformanceModel: Model<FootballPlayerPointsDocument>,
    @InjectModel('FootballCommentary')
    private footballCommentaryModel: Model<FootballCommentaryDocument>,
    @InjectModel('KabaddiScorecard')
    private kabaddiScorecardModel: Model<kabaddiScorecardDocument>,
    @InjectModel('KabaddiPlayerPerformance')
    private kabaddiPlayerPerformanceModel: Model<KabaddiPlayerPerformanceDocument>,
    @InjectModel('Lineup')
    private lineUpModel: Model<lineUpDocument>,
    private readonly scorecardHelpers: ScorecardHelpers,
    private readonly commentry_Helper: commentryHelper,
    private pointsService: PointsCronService,
    private readonly lineupHelpers: lineupHelpers,
  ) {}

  @Cron(CronExpression.EVERY_MINUTE, {
    name: 'scorecard',
    disabled: false,
  })
  async updateScorecard() {
    console.log('Scorecard updated');

    const liveFixtures = await this.fixtureModel.find({
      fixtureStatus: 'Live',
      enabledStatus: true,
    });

    for (const key in liveFixtures) {
      try {
        const fixture = liveFixtures[key];
        if (!fixture.lineupsOut) {
          const req = await fetch(
            `${SPORTS_DATA.URL}/scorecard/${fixture.fixtureAPIId}/lineup?token=A12345BCDefg1985`,
          );
          const { data } = await req.json();
          if (data) {
            const lineUp = this.lineupHelpers.formatLineUp(
              data?.teams,
              fixture.fixtureAPIId,
            );
            await this.lineUpModel.findOneAndUpdate(
              { fixtureAPIId: fixture.fixtureAPIId },
              lineUp,
              options,
            );
            await fixture.save();
          }
        }

        const commentaryReq = await (
          await fetch(
            `${SPORTS_DATA.URL}/scorecard/${fixture.fixtureAPIId}/commentry?token=A12345BCDefg1985`,
          )
        )?.json();

        const req: any = await fetch(
          `${SPORTS_DATA.URL}/scorecard/${fixture.fixtureAPIId}?token=A12345BCDefg1985`,
        );

        const { data } = await req.json();
        if (!data) continue;

        const players: any = {};
        const scorecard: Scorecard =
          await this.scorecardHelpers.formatScorecard(data);
        if (!scorecard) continue;
        scorecard.sereisAPIId = fixture.seriesAPIId;

        const commentaries: commentries = this.commentry_Helper.formatCommentry(
          commentaryReq.data,
        );

        const previousCommentry = await this.commentaryModel.findOne({
          fixtureAPIId: fixture.fixtureAPIId,
        });

        let allCommentries: any;
        if (previousCommentry && commentaries)
          allCommentries = [
            ...commentaries?.commentaries,
            ...previousCommentry.commentaries,
          ];
        else if (commentaries) allCommentries = [...commentaries?.commentaries];
        if (allCommentries?.length > 0) {
          const jsonObject = allCommentries.map(JSON.stringify);
          const uniqueSet = new Set(jsonObject);
          const uniqueCommentries = Array.from(uniqueSet).map((e: any) =>
            JSON.parse(e),
          );
          commentaries.commentaries = uniqueCommentries;
        }

        const playerPerformance = await this.scorecardHelpers.combinedStats(
          Object.values(scorecard.innings)
            .slice(0, 2)
            .map((e) => [...e.bat.team, ...e.bowl.team, ...e.fielders.team])
            .flat(),
        );
        const playerPoints = await this.scorecardHelpers.pointsCalculation(
          fixture.fixtureType,
          playerPerformance,
          fixture.fixtureAPIId,
        );

        let players2: any = {},
          playerPerformance2,
          playerPoints2;
        if (Object.values(scorecard.innings).slice(2, 4).length > 0) {
          playerPerformance2 = await this.scorecardHelpers.combinedStats(
            Object.values(scorecard.innings)
              .slice(2, 4)
              .map((e) => [...e.bat.team, ...e.bowl.team, ...e.fielders.team])
              .flat(),
          );
          playerPoints2 = await this.scorecardHelpers.pointsCalculation(
            fixture.fixtureType,
            playerPerformance2,
            fixture.fixtureAPIId,
          );
          players2['fixtureAPIId'] = fixture.fixtureAPIId;
          players2['fixtureStatus'] = fixture.fixtureStatus;
          players2['playerStat'] = playerPerformance2;
          players2['playerPoint'] = playerPoints2;
          players2['innings'] = 2;
        }

        players['fixtureAPIId'] = fixture.fixtureAPIId;
        players['fixtureStatus'] = fixture.fixtureStatus;
        players['playerStat'] = playerPerformance;
        players['playerPoint'] = playerPoints;

        if (data.fixtureStatus == 'Completed') {
          await this.playerPerformanceModel.findOneAndUpdate(
            { fixtureAPIId: fixture.fixtureAPIId, innings: 1 },
            players,
            options,
          );
          if (players2['fixtureAPIId']) {
            await this.playerPerformanceModel.findOneAndUpdate(
              { fixtureAPIId: fixture.fixtureAPIId, innings: 2 },
              players2,
              options,
            );
          }

          await this.pointsService.updateUserPoints();
          await this.pointsService.winningDeclaration(
            scorecard.fixtureAPIId,
            3,
            'cricket',
          );

          scorecard.fixtureStatus = 'Completed';
          players.fixtureStatus = 'Completed';
          if (players2) players2.fixtureStatus = 'Completed';
          commentaries ? (commentaries.status_str = 'Completed') : null;

          await this.fixtureModel.findOneAndUpdate(
            { fixtureAPIId: fixture.fixtureAPIId },
            { fixtureStatus: 'Completed' },
          );
          await this.pointsService.updateWinnerTransactions(
            fixture.fixtureAPIId,
            fixture.fixtureDisplayName,
            fixture.fixtureStartDate,
            'cricket',
          );
          await this.pointsService.updateSeriesPoints(fixture.seriesAPIId);
        }

        if (data.fixtureStatus == 'Cancelled') {
          await this.fixtureModel.findOneAndUpdate(
            { fixtureAPIId: fixture.fixtureAPIId },
            { fixtureStatus: 'Cancelled' },
          );

          await this.pointsService.cancelAllContests(
            fixture.fixtureAPIId,
            fixture.fixtureDisplayName,
          );

          scorecard.fixtureStatus = 'Cancelled';
          players.fixtureStatus = 'Cancelled';
          if (players2) players2.fixtureStatus = 'Cancelled';
          commentaries ? (commentaries.status_str = 'Cancelled') : null;
        }

        await this.scorecardModel.findOneAndUpdate(
          { fixtureAPIId: fixture.fixtureAPIId },
          scorecard,
          options,
        );

        // performance update
        await this.playerPerformanceModel.findOneAndUpdate(
          { fixtureAPIId: fixture.fixtureAPIId, innings: 1 },
          players,
          options,
        );
        if (players2['fixtureAPIId']) {
          await this.playerPerformanceModel.findOneAndUpdate(
            { fixtureAPIId: fixture.fixtureAPIId, innings: 2 },
            players2,
            options,
          );
        }
        if (commentaries)
          await this.commentaryModel.findOneAndUpdate(
            { fixtureAPIId: fixture.fixtureAPIId },
            commentaries,
            options,
          );
      } catch (err) {
        console.log(err);
        continue;
      }
    }

    return successResponse('scorecard');
  }

  async pointsGet() {
    return {
      status: true,
      message: 'Data found',
      data: await this.pointsModel.find(),
    };
  }

  @Cron('*/55 */4 * * * *', {
    name: 'footballscorecard',
    disabled: false,
  })
  async updateFootballScorecard() {
    try {
      const liveFixtures = await this.footballFixturesModel.find({
        fixtureStatus: 'live',
      });

      for (const key in liveFixtures) {
        try {
          const fixture = liveFixtures[key];

          const req: any = await fetch(
            `${SPORTS_DATA.FOOTBALL}/scorecard/${fixture.fixtureAPIId}?token=ORTJXUNJXPb8Sk8`,
          );
          const { data } = await req.json();
          if (!data) continue;
          const scorecard: FootballScorecard =
            this.scorecardHelpers.footballScorecard(data);
          const playerPerformance =
            await this.scorecardHelpers.footballPointStats(scorecard);

          const request: any = await fetch(
            `${SPORTS_DATA.FOOTBALL}/commentry/${fixture.fixtureAPIId}?token=ORTJXUNJXPb8Sk8`,
          );
          const res = await request.json();

          const commentary: FootballCommentary =
            this.commentry_Helper.footballCommentry(res?.data);
          if (!commentary.fixtureAPIId)
            commentary.fixtureAPIId = scorecard.fixtureAPIId;

          if (scorecard.status == 'result') {
            playerPerformance.fixtureStatus = 'live';
            await this.footballPlayerPerformanceModel.findOneAndUpdate(
              { fixtureAPIId: fixture.fixtureAPIId },
              playerPerformance,
              options,
            );
            await this.pointsService.updateFootballTeamPoints(
              fixture.fixtureAPIId,
            );
            await this.footballFixturesModel.findOneAndUpdate(
              { fixtureAPIId: fixture.fixtureAPIId },
              { fixtureStatus: 'result' },
            );
            await this.pointsService.updateWinnerTransactions(
              fixture.fixtureAPIId,
              fixture.fixtureDisplayName,
              fixture.fixtureStartDate,
              'football',
            );

            await this.pointsService.updateFootballSeriesPoints(
              fixture.seriesAPIId,
            );

            playerPerformance.fixtureStatus = 'result';
          }

          await this.footballScorecardModel.findOneAndUpdate(
            { fixtureAPIId: fixture.fixtureAPIId },
            scorecard,
            options,
          );
          await this.footballPlayerPerformanceModel.findOneAndUpdate(
            { fixtureAPIId: fixture.fixtureAPIId },
            playerPerformance,
            options,
          );
          await this.footballCommentaryModel.findOneAndUpdate(
            { fixtureAPIId: fixture.fixtureAPIId },
            commentary,
            options,
          );
        } catch (err) {
          console.log(err);
          continue;
        }
      }

      return { status: true, message: 'Scorecard updated successfully' };
    } catch (err) {
      return { status: false, message: err.message };
    }
  }

  @Cron(CronExpression.EVERY_MINUTE, {
    name: 'kabaddiscorecard',
    disabled: true,
  })
  async updateKabaddiScorecard() {
    try {
      const liveFixtures = await this.kabaddiFixturesModel.find({
        fixtureStatus: 'live',
      });

      for (const key in liveFixtures) {
        try {
          const fixture = liveFixtures[key];

          const req: any = await fetch(
            `${SPORTS_DATA.KABADDI}/scorecard/${fixture.fixtureAPIId}`,
          );
          const { data } = await req.json();

          const scorecard: KabaddiScorecard =
            this.scorecardHelpers.kabaddiScorecard(data);
          if (!scorecard) continue;

          const playerStats: KabaddiPlayerStats[] =
            this.scorecardHelpers.kabaddiPlayerPerformance(
              data?.player_statistics,
            );

          const playerPoints: KabaddiPlayerPoints[] =
            await this.scorecardHelpers.kabaddiPoints(
              fixture.fixtureAPIId,
              scorecard?.gameStats?.home?.allouts,
              scorecard?.gameStats?.away?.allouts,
              playerStats,
            );
          const playerPerformance = {
            fixtureAPIId: fixture.fixtureAPIId,
            fixtureStatus: scorecard.status,
            playerStats,
            playerPoints,
          };

          if (scorecard.status == 'result') {
            playerPerformance.fixtureStatus = 'live';
            await this.kabaddiPlayerPerformanceModel.findOneAndUpdate(
              { fixtureAPIId: fixture.fixtureAPIId },
              playerPerformance,
              options,
            );

            await this.pointsService.updateKabaddiTeamPoints(
              fixture.fixtureAPIId,
            );

            await this.kabaddiFixturesModel.findOneAndUpdate(
              { fixtureAPIId: fixture.fixtureAPIId },
              { fixtureStatus: 'result' },
            );
            await this.pointsService.updateWinnerTransactions(
              fixture.fixtureAPIId,
              fixture.fixtureDisplayName,
              fixture.fixtureStartDate,
              'kabaddi',
            );

            await this.pointsService.updateKabaddiSereisPoints(
              scorecard.seriesAPIId,
            );
            playerPerformance.fixtureStatus = 'result';
          }

          await this.kabaddiPlayerPerformanceModel.findOneAndUpdate(
            { fixtureAPIId: fixture.fixtureAPIId },
            playerPerformance,
            options,
          );
          await this.kabaddiScorecardModel.findOneAndUpdate(
            { fixtureAPIId: fixture.fixtureAPIId },
            scorecard,
            options,
          );
        } catch (err) {
          console.log(err);
          continue;
        }
      }

      return { status: true, message: 'Scorecard updated successfully' };
    } catch (err) {
      console.log(err);
      return { status: false };
    }
  }
}
