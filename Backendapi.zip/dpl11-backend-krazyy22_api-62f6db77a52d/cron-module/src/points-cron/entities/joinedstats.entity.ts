import { ObjectType, Field } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type joinedPlayerStatsDocument = joinedPlayerStats & Document;

@ObjectType()
class userContestTeams {
  @Field()
  userId: string;

  @Field()
  userTeams: number;

  @Field()
  userJoinedContest: number;
}

@ObjectType()
@Schema()
export class joinedPlayerStats {
  @Field()
  @Prop({ index: true })
  fixtureAPIId: number;

  @Field(() => [userContestTeams])
  @Prop()
  userStats: userContestTeams[];

  @Prop()
  gameType: string;
}

export const joinedPlayerStatsSchema =
  SchemaFactory.createForClass(joinedPlayerStats);
