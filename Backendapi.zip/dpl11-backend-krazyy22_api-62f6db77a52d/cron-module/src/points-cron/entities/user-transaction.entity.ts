import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { IsIn } from 'class-validator';

export type UserTransactionDocument = UserTransaction & Document;

@Schema()
export class UserTransaction {
  @Prop()
  userId: string;

  @Prop()
  @IsIn(['Credit', 'Debit', 'Others'])
  transanctionType: string;

  @Prop()
  amount: number;

  @Prop()
  bonusUsed?: number;

  @Prop()
  transanctionTime: Date;

  @Prop()
  walletId: string;

  @Prop()
  previousBalance: number;

  @Prop()
  afterBalance: number;

  @Prop()
  @IsIn([
    'Winnings',
    'Referral',
    'System',
    'Withdrawal',
    'EntryFee',
    'Admin',
    'Bonus',
    'Credit',
    'Refund',
  ])
  transanctionRelatedType: string;

  @Prop({ default: 'Success' })
  transactionStatus?: string;

  @Prop()
  fixtureId?: string;

  @Prop()
  fixtureName?: string;

  @Prop()
  contestId?: string;

  @Prop()
  contestName?: string;
}

export const UserTransactionSchema =
  SchemaFactory.createForClass(UserTransaction);
