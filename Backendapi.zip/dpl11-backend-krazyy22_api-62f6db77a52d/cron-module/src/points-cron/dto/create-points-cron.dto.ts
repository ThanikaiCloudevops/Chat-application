export class CreatePointsCronDto {}
