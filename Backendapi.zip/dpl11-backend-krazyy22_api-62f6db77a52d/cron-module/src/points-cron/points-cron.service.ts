import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { playerPerformanceDocument } from 'src/scorecard-cron/entities/playerPerformance.entity';
import mongoose, { Model } from 'mongoose';
import { userTeamsDocument } from './entities/user-teams.entity';
import { fixtureDocument } from './entities/fixtures.entity';
import { Contest, contestDocument } from './entities/contest.entity';
import {
  UserTransaction,
  UserTransactionDocument,
} from './entities/user-transaction.entity';
import { UserWalletDocument } from './entities/user-wallet.entity';
import { CreateUserTransactionInput } from './dto/update-points-cron.dto';
import { Cron, CronExpression } from '@nestjs/schedule';
import { userDocument } from 'src/lineup-cron/entities/user.entity';
import {
  notificationDocument,
  Notification,
} from './entities/notifications.entity';
import { NotificationService } from 'src/notification/notification.service';
import { seriesPointsDocument } from './entities/seriespoints.entity';
import { joinedPlayerStatsDocument } from './entities/joinedstats.entity';
import { Transaction } from 'typeorm';
import { footballFixtureDocument } from 'src/game-cron/entities/footballfixtures.entity';
import { FootballPlayerPointsDocument } from 'src/scorecard-cron/entities/football-playerperformance.entity';
import { KabaddiPlayerPerformanceDocument } from 'src/scorecard-cron/entities/kabaddi-playerperformance.entity';
import { kabaddiFixtureDocument } from 'src/game-cron/entities/kabaddifixtures.entity';

const options = { upsert: true, new: true, setDefaultsOnInsert: true };

@Injectable()
export class PointsCronService {
  constructor(
    @InjectModel('User') private userModel: Model<userDocument>,
    @InjectModel('cricketFixtures')
    private fixtureModel: Model<fixtureDocument>,
    @InjectModel('playerPerformance')
    private playerPerformanceModel: Model<playerPerformanceDocument>,
    @InjectModel('userTeams')
    private userTeamsModel: Model<userTeamsDocument>,
    @InjectModel('Contest') private contestModel: Model<contestDocument>,
    @InjectModel('UserTransaction')
    private UserTransactiontModel: Model<UserTransactionDocument>,
    @InjectModel('UserWallet')
    private UserWalletModel: Model<UserWalletDocument>,
    private fcmService: NotificationService,
    @InjectModel('Notification')
    private notificationModel: Model<notificationDocument>,
    @InjectModel('seriesPoints')
    private seriesPointsModel: Model<seriesPointsDocument>,
    @InjectModel('joinedPlayerStats')
    private joinedPlayerStatsModel: Model<joinedPlayerStatsDocument>,
    @InjectModel('FootballFixtures')
    private footballFixturesModel: Model<footballFixtureDocument>,
    @InjectModel('FootballPlayerPerformance')
    private footballPlayerPerformanceModel: Model<FootballPlayerPointsDocument>,
    @InjectModel('KabaddiPlayerPerformance')
    private kabaddiPlayerPerformanceModel: Model<KabaddiPlayerPerformanceDocument>,
    @InjectModel('KabaddiFixtures')
    private kabaddiFixturesModel: Model<kabaddiFixtureDocument>,
  ) {}
  @Cron(CronExpression.EVERY_MINUTE, {
    name: 'points',
    disabled: false,
  })
  async updateUserPoints() {
    try {
      console.log('point updates');
      const testMatchMatches = await this.playerPerformanceModel.find({
        fixtureStatus: 'Live',
        innings: 2,
      });

      const testMatchFixtureIds = testMatchMatches.map((e) => e.fixtureAPIId);
      if (testMatchFixtureIds.length > 0)
        await this.updateTestMatchPoints(testMatchFixtureIds);
      const getMatches = await this.playerPerformanceModel.find({
        fixtureStatus: 'Live',
        innings: 1,
        fixtureAPIId: { $nin: testMatchFixtureIds },
      });

      const liveMatches: number[] = [];
      let allPlayers = {};
      for (let match = 0; match < getMatches.length; match++) {
        liveMatches.push(getMatches[match].fixtureAPIId);
        const _allPlayers = getMatches[match].playerPoint.reduce(
          (players, player) => {
            players[player['player_id']] = player;
            return players;
          },
          {},
        );
        allPlayers = { ...allPlayers, ..._allPlayers };
      }

      // await this.winningDeclaration(liveMatches, 3);

      // live match contest list
      const contestData = await this.contestModel.find({
        fixtureAPIId: { $in: liveMatches },
        isactive: true,
        enabledStatus: true,
      });

      // get live matche teams
      const liveMatchTeams = await this.userTeamsModel.find({
        fixtureAPIId: { $in: liveMatches },
        gameType: 'cricket',
      });
      for (let team = 0; team < liveMatchTeams.length; team++) {
        const user_Teams = liveMatchTeams[team].userTeams;
        for (let teamKey = 0; teamKey < user_Teams.length; teamKey++) {
          let totalPoint = 0;
          const userteamList = user_Teams[teamKey].team;
          for (let ind = 0; ind < userteamList.length; ind++) {
            const findPlayer = userteamList[ind];
            const _newplayer = allPlayers[findPlayer.playerAPIId];
            if (findPlayer.playerAPIId == _newplayer?.['player_id']) {
              if (findPlayer.cap) {
                findPlayer.points = _newplayer['point'] * 2;
                totalPoint += +findPlayer.points;
              } else if (findPlayer.vc) {
                findPlayer.points = _newplayer['point'] * 1.5;
                totalPoint += +findPlayer.points;
              } else {
                findPlayer.points = _newplayer['point'];
                totalPoint += +findPlayer.points;
              }
            }
          }
          user_Teams[teamKey].totalPoints = totalPoint;

          // points update in contest list
          for (
            let contestIndex = 0;
            contestIndex < contestData.length;
            contestIndex++
          ) {
            const joinedTeamList = contestData?.[contestIndex]?.jointUsers;

            for (const index in joinedTeamList) {
              const userjoinedTeams =
                joinedTeamList[index]['userTeams'][user_Teams[teamKey]?._id];

              if (userjoinedTeams) userjoinedTeams.points = totalPoint;
            }

            await this.contestModel.findOneAndUpdate(
              { _id: contestData?.[contestIndex]._id },
              contestData?.[contestIndex],
            );
          }
        }
        // points update in userteams
        await this.userTeamsModel.findOneAndUpdate(
          {
            fixtureAPIId: liveMatchTeams[team].fixtureAPIId,
            gameType: 'cricket',
          },
          liveMatchTeams[team],
        );
      }
      await this.winningDeclaration(liveMatches, 3, 'cricket');
      return 'Success';
    } catch (error) {
      console.log(error.message);
    }
  }

  async updateTestMatchPoints(fixtureAPIIds: number[]) {
    try {
      const playerPoints: any = {};
      for (const fixtureAPIId of fixtureAPIIds) {
        const playerPerformance = await this.playerPerformanceModel
          .find({
            fixtureAPIId,
          })
          .select(['playerPoint']);
        for (const playersInnings of playerPerformance) {
          for (const player of playersInnings.playerPoint) {
            if (!playerPoints[player.player_id])
              playerPoints[player.player_id] = { point: 0 };
            playerPoints[player.player_id]['point'] += player.point;
          }
        }

        const liveMatchTeams = await this.userTeamsModel
          .findOne({
            fixtureAPIId,
            gameType: 'cricket',
          })
          .lean();
        const teamPoints = {};
        for (let index = 0; index < liveMatchTeams.userTeams.length; index++) {
          const userTeam = liveMatchTeams.userTeams[index];
          let totalPoints: number = 0;
          for (let ind = 0; ind < userTeam.team.length; ind++) {
            const player = userTeam.team[ind];

            liveMatchTeams.userTeams[index].team[ind].points =
              (playerPoints?.[player.playerAPIId]?.point || 0) *
              (player.cap ? 2 : player.vc ? 1.5 : 1);

            totalPoints +=
              (playerPoints?.[player.playerAPIId]?.point || 0) *
              (player.cap ? 2 : player.vc ? 1.5 : 1);
          }
          liveMatchTeams.userTeams[index].totalPoints = totalPoints;
          teamPoints[liveMatchTeams.userTeams[index]._id] = totalPoints;
        }

        await this.userTeamsModel.findByIdAndUpdate(
          liveMatchTeams._id,
          liveMatchTeams,
        );

        const contestData = await this.contestModel.find({
          fixtureAPIId,
          isactive: true,
          enabledStatus: true,
        });
        for (let index = 0; index < contestData.length; index++) {
          const contest = contestData[index];
          for (const userId in contest.jointUsers) {
            const jointUser = contest.jointUsers[userId];
            for (const teamId in jointUser.userTeams) {
              contestData[index].jointUsers[userId].userTeams[teamId].points =
                teamPoints[teamId];
            }
          }
          await this.contestModel.findByIdAndUpdate(
            contestData[index]._id,
            contestData[index],
          );
        }
      }
      await this.winningDeclaration(fixtureAPIIds, 3, 'cricket');
    } catch (err) {
      console.log(err);
    }
  }

  async winningDeclaration(
    match_id: number[] | number,
    match_status: number,
    gameType: string,
  ) {
    console.log('Winnig declaration updates');

    const contestData: Contest[] = await this.contestModel.find({
      fixtureAPIId: { $in: match_id },
      gameType,
      isactive: true,
      enabledStatus: true,
    });
    //group  team data from all users
    for (let index = 0; index < contestData.length; index++) {
      // prize split  up by rank
      const newSplit = {};

      if (contestData[index].guaranteed) {
        //Guranteed contest prizeSplitup
        const allocated_prizes = contestData[index]?.prize?.prizeSplitUp;
        for (const rank_key in allocated_prizes) {
          const rank = rank_key.split('-');
          const start_index = +rank[0] || 1;
          const end_index = +rank[rank.length - 1];

          for (let i = start_index; i <= end_index; i++) {
            newSplit[i] = allocated_prizes[rank_key];
          }
        }
      } else {
        //Flexible contest prizeBreak
        const allocated_prizes = contestData[index]?.prize?.prizeBreak;
        for (const rank_key in allocated_prizes) {
          const rank = rank_key.split('-');
          const start_index = +rank[0] || 1;
          const end_index = +rank[rank.length - 1];

          for (let i = start_index; i <= end_index; i++) {
            newSplit[i] = allocated_prizes[rank_key];
          }
        }
      }
      // add rank and price according
      const teamList = contestData[index]?.jointUsers;
      teamList.userteamList = [];
      for (const key in teamList) {
        const { userTeams } = teamList[key];

        for (const ite in userTeams) {
          teamList.userteamList.push(userTeams[ite]);
        }
      }

      const sortedTeams = teamList.userteamList.sort(
        (a: { [x: string]: number }, b: { [x: string]: number }) =>
          b['points'] - a['points'],
      );

      let rank = 1;
      let prevPoints = sortedTeams[0]?.points;
      let sameRankCount = 0;
      const newsplit = {};
      const rankObj = {};
      sortedTeams.forEach((team, index) => {
        if (team.points !== prevPoints) {
          rank += sameRankCount; // Increase rank by the count of same ranks
          sameRankCount = 0; // Reset same rank count
        }
        sameRankCount++;
        team.rank = rank;
        if (!rankObj[rank]) rankObj[rank] = 0;
        rankObj[rank]++;
        //asign rank to the team
        prevPoints = team.points;
      });
      const rankPrizes = {};

      for (const rankk in rankObj) {
        const repeatTimes = rankObj[rankk];
        if (repeatTimes > 1) {
          let currentCombinedPrize = 0;

          for (
            let index = Number(rankk);
            index < repeatTimes + Number(rankk);
            index++
          ) {
            currentCombinedPrize += newSplit[index.toString()] || 0;
          }
          rankPrizes[rankk] = currentCombinedPrize / repeatTimes;
        } else {
          rankPrizes[rankk] = newSplit[rankk.toString()] || 0;
        }
      }
      sortedTeams.forEach((team, index) => {
        const numberOfSameRankTeams = sortedTeams.filter(
          (t) => t.rank === team.rank,
        ).length;
        team.price = Math.floor(rankPrizes[team.rank]);
      });
      delete teamList.userteamList;

      if (match_status === 2) {
        for (const key in teamList) {
          const totalPrice: any = Object.values(teamList[key].userTeams).reduce(
            (total: number, value) => {
              total += Number(value?.['price']);
              return total;
            },
            0,
          );
          const fixName =
            gameType == 'cricket'
              ? await this.fixtureModel.findOne({
                  fixtureAPIId: contestData?.[index]?.fixtureAPIId,
                })
              : gameType == 'football'
              ? await this.footballFixturesModel.findOne({
                  fixtureAPIId: contestData?.[index]?.fixtureAPIId,
                })
              : await this.kabaddiFixturesModel.findOne({
                  fixtureAPIId: contestData?.[index]?.fixtureAPIId,
                });
          if (totalPrice > 0) {
            const payload: CreateUserTransactionInput = {
              userId: key,
              transanctionType: 'Credit',
              amount: totalPrice,
              transanctionRelatedType: 'Winnings',
              fixtureId: `${contestData?.[index]?.fixtureAPIId}`,
              fixtureName: fixName.fixtureDisplayName,
              contestId: contestData?.[index]?.['_id'],
              contestName: contestData?.[index]?.['contestName'],
            };
            await this.enterTransaction(payload);
          }
        }
        const fixId = contestData[index].fixtureAPIId;
        const fixture =
          gameType == 'cricket'
            ? await this.fixtureModel.findOne({
                fixtureAPIId: fixId,
              })
            : gameType == 'football'
            ? await this.footballFixturesModel.findOne({ fixtureAPIId: fixId })
            : await this.kabaddiFixturesModel.findOne({ fixtureAPIId: fixId });
        const fixName = fixture.fixtureDisplayName;
        for (const x in teamList) {
          const totalPrice: any = Object.values(teamList[x].userTeams).reduce(
            (total: number, value) => {
              total += Number(value?.['price']);
              return total;
            },
            0,
          );
          if (totalPrice > 0) {
            const notificationPayload = {
              notification: {
                title: 'Hurray!!!',
                body: "You've won ₹" + totalPrice + ' for the match ' + fixName,
              },
            };
            const Notification = {
              pn_title: notificationPayload.notification.title,
              pn_message: notificationPayload.notification.body,
              fixture_id: fixId,
              pn_receivers: x,
              pn_sendTime: new Date(),
              pn_status: 1,
              createdat: new Date(),
            };
            await this.notificationModel.create(Notification);
            const userdetail = await this.userModel.findById(x);
            if (userdetail && userdetail?.deviceToken) {
              await this.fcmService.sendNotification(
                [userdetail.deviceToken],
                notificationPayload,
              );
            }
          }
        }
      }
      await this.contestModel.findOneAndUpdate(
        {
          _id: contestData?.[index]?.['_id'],
        },
        contestData[index],
      );
    }

    return contestData;
  }

  async updateWinnerTransactions(
    fixtureAPIId: number,
    fixtureName: string,
    fixtureTime: Date,
    gameType: string,
  ) {
    const errorNotes = [];
    try {
      const contests = await this.contestModel.find({
        fixtureAPIId,
        isactive: true,
        enabledStatus: true,
        gameType,
      });

      const winnerNotifications = {};
      const winnerTransactions = {};

      for (const contest of contests) {
        for (const userId in contest.jointUsers) {
          let userContestPrize = 0;
          const userObj: any = contest.jointUsers[userId]; //Joint users

          for (const userTeamPrize of Object.values(userObj.userTeams)) {
            const userPrize: any = userTeamPrize; //Joint users team

            //Check team joint time
            /*  if (userPrize.joinedAt > fixtureTime)
              errorNotes.push({
                error: 'joinTime',
                teamId: userPrize.teamId,
                userId,
              }); */

            if (userPrize?.price > 0) {
              if (!winnerNotifications[userId]) winnerNotifications[userId] = 0;
              userContestPrize += userPrize.price;
              winnerNotifications[userId] =
                winnerNotifications[userId] + userPrize.price;
            }
          }
          if (userContestPrize > 0) {
            if (!winnerTransactions[userId]) winnerTransactions[userId] = [];
            winnerTransactions[userId].push({
              userContestPrize,
              userId,
              contestId: contest._id.toString(),
              contestName: contest.contestName,
              fixtureAPIId,
              fixtureName,
            });
          }
        }
      }

      const winningUserIds = Object.keys(winnerNotifications);

      const winningUsers = await this.userModel
        .find({
          _id: { $in: winningUserIds },
        })
        .select('deviceToken')
        .lean();
      const winnerUserWallet = await this.UserWalletModel.find({
        userId: { $in: winningUserIds },
      })
        .select(['_id', 'userId'])
        .lean();

      if (winningUserIds.length != winningUsers.length) {
        console.log('User missing');
        const winningUserStr = JSON.stringify(winningUsers);
        for (const userId of winningUserIds) {
          if (!winningUserStr.includes(userId))
            errorNotes.push({ error: 'userMiss', userId });
        }
      }

      if (winningUserIds.length != winnerUserWallet.length) {
        console.log('Wallet missing');
        const winningUserStr = JSON.stringify(winnerUserWallet);
        for (const userId of winningUserIds) {
          if (!winningUserStr.includes(userId))
            errorNotes.push({ error: 'walletMiss', userId });
        }
      }

      if (errorNotes.length) {
        console.log(errorNotes);
        return { status: false, errorNotes };
      }

      const usersbyId = winningUsers.reduce((total, value) => {
        total[value._id.toString()] = value;
        return total;
      }, {});

      const tSession = await this.UserTransactiontModel.startSession();
      const wSession = await this.UserWalletModel.startSession();
      const tOptions = { session: tSession };
      const wOptions = { session: wSession };

      tSession.startTransaction();
      wSession.startTransaction();

      try {
        const userWallets = (
          await this.UserWalletModel.find({
            userId: { $in: winningUserIds },
          })
        ).reduce((total, value) => {
          total[value.userId] = value;
          return total;
        }, {});
        for (const userId in winnerTransactions) {
          const contestWinnings = winnerTransactions[userId];
          for (const contestWinData of contestWinnings) {
            // const userWallet = await this.UserWalletModel.findOne({ userId });
            const transactionObj: UserTransaction = {
              userId,
              walletId: userWallets[userId]._id.toString(),
              fixtureName,
              fixtureId: `${fixtureAPIId}`,
              contestId: contestWinData.contestId,
              contestName: contestWinData.contestName,
              transanctionTime: new Date(),
              amount: contestWinData.userContestPrize,
              previousBalance: userWallets[userId].userBalance,
              afterBalance:
                userWallets[userId].userBalance +
                contestWinData.userContestPrize,
              transanctionRelatedType: 'Winnings',
              transanctionType: 'Credit',
            };
            // userWallet.totalWinnings += transactionObj.amount;
            // userWallet.userBalance += transactionObj.amount;
            userWallets[userId].totalWinnings += transactionObj.amount;
            userWallets[userId].userBalance += transactionObj.amount;

            const checkDuplpicate = await this.UserTransactiontModel.findOne({
              userId,
              contestId: contestWinData.contestId,
              fixtureId: fixtureAPIId,
              transanctionRelatedType: { $in: ['Winnings', 'Refund'] },
            });
            if (checkDuplpicate)
              throw new Error(
                `Duplicate transaction userId: ${userId} contestId:${contestWinData.contestId}`,
              );

            await this.UserTransactiontModel.create([transactionObj], tOptions);
            // await this.UserWalletModel.findOneAndUpdate(
            //   { userId },
            //   userWallet,
            //   wOptions,
            // );
          }
        }
        for (const userId in userWallets) {
          const userWallet = userWallets[userId];
          await this.UserWalletModel.findOneAndUpdate(
            { userId },
            userWallet,
            wOptions,
          );
        }
      } catch (err) {
        console.log(err.message);
        await tSession.abortTransaction();
        await wSession.abortTransaction();
        await tSession.endSession();
        await wSession.endSession();
        errorNotes.push({ error: 'Transactions error', message: err.message });
      }

      if (errorNotes.length) {
        console.log(errorNotes);
        return { status: false, errorNotes };
      }

      await tSession.commitTransaction();
      await wSession.commitTransaction();
      await tSession.endSession();
      await wSession.endSession();

      for (const userId in winnerNotifications) {
        const winningAmount = winnerNotifications[userId];
        const notificationPayload = {
          notification: {
            title: 'Hurray!!!',
            body: `You've won ₹${winningAmount} for the match ${fixtureName}`,
          },
        };
        const Notification = {
          pn_title: 'Hurray!!!',
          pn_message: `You've won ₹${winningAmount} for the match ${fixtureName}`,
          fixture_id: fixtureAPIId,
          pn_receivers: userId,
          pn_sendTime: new Date(),
          pn_status: 1,
          createdat: new Date(),
        };
        await this.notificationModel.create(Notification);
        if (usersbyId[userId]?.deviceToken) {
          await this.fcmService.sendNotification(
            [usersbyId[userId].deviceToken],
            notificationPayload,
          );
        }
      }

      return { status: true, message: 'Winners declared successful' };
    } catch (err) {
      console.log(err);
      return { status: false, errorNotes };
    }
  }

  async enterTransaction(
    createUserTransactionInput: CreateUserTransactionInput,
  ) {
    const walletCheck = await this.UserWalletModel.findOne({
      userId: createUserTransactionInput.userId,
    });

    if (!walletCheck) return 'notFound';

    const totalBalance =
      walletCheck.unutilisedBalance + walletCheck.totalWinnings;
    //  walletCheck.totalBonus;

    const transactionObj: UserTransaction = {
      userId: createUserTransactionInput.userId,
      transanctionType: createUserTransactionInput.transanctionType,
      amount: createUserTransactionInput.amount,
      walletId: walletCheck._id,
      previousBalance: walletCheck.userBalance,
      afterBalance:
        createUserTransactionInput.transanctionType == 'Debit'
          ? totalBalance - createUserTransactionInput.amount
          : totalBalance + createUserTransactionInput.amount,
      transanctionRelatedType:
        createUserTransactionInput.transanctionRelatedType,
      fixtureId: createUserTransactionInput.fixtureId,
      contestId: createUserTransactionInput.contestId,
      contestName: createUserTransactionInput.contestName,
      fixtureName: createUserTransactionInput.fixtureName,
      transanctionTime: new Date(),
    };

    if (transactionObj.afterBalance < 0) return '0 balance';

    await this.UserTransactiontModel.create(transactionObj);
    await this.updateWallet(
      walletCheck,
      transactionObj.amount,
      transactionObj.transanctionType == 'Credit',
      transactionObj.transanctionRelatedType,
    );
  }

  async updateWallet(
    userWallet: UserWalletDocument,
    amount: number,
    updateType: boolean, //true is credit and false is debit
    transanctionRelatedType: string,
  ) {
    if (updateType)
      transanctionRelatedType == 'Winnings'
        ? (userWallet.totalWinnings += amount)
        : transanctionRelatedType == 'Bonus'
        ? (userWallet.totalBonus += amount)
        : transanctionRelatedType == 'Credit'
        ? (userWallet.unutilisedBalance += amount)
        : null;
    else {
      let temp = -amount;
      const debitBalanceTypes = [
        'totalBonus',
        'unutilisedBalance',
        'totalWinnings',
      ];

      for (const index in debitBalanceTypes) {
        const debitType = debitBalanceTypes[index];
        userWallet[debitType] += temp;
        temp = userWallet[debitType];
      }

      userWallet.totalBonus < 0 ? (userWallet.totalBonus = 0) : null;
      userWallet.unutilisedBalance < 0
        ? (userWallet.unutilisedBalance = 0)
        : null;
      userWallet.totalWinnings < 0 ? (userWallet.totalWinnings = 0) : null;
    }

    userWallet.userBalance =
      // userWallet.totalBonus +
      +(
        Number(userWallet.unutilisedBalance) + Number(userWallet.totalWinnings)
      ).toFixed(2);

    return await userWallet.save();
  }

  async updateJoinedPlayerStats(fixtureAPIId: number, gameType = 'cricket') {
    try {
      const contests = await this.contestModel.find({
        fixtureAPIId,
        gameType,
        isactive: true,
        enabledStatus: true,
      });
      const userTeams = await this.userTeamsModel.findOne({
        fixtureAPIId,
        gameType,
      });
      const userTeamsContestCountObj = userTeams.userTeams.reduce(
        (total, value) => {
          if (!total[value.userId])
            total[value.userId] = {
              userId: value.userId,
              userTeams: 0,
              userJoinedContest: 0,
            };
          total[value.userId].userTeams++;
          return total;
        },
        {},
      );
      for (const userId in userTeamsContestCountObj) {
        for (const contest of contests) {
          if (contest.jointUsers[userId])
            userTeamsContestCountObj[userId].userJoinedContest++;
        }
      }

      const options = { upsert: true, new: true, setDefaultsOnInsert: true };

      await this.joinedPlayerStatsModel.findOneAndUpdate(
        { fixtureAPIId },
        {
          fixtureAPIId,
          gameType,
          userStats: Object.values(userTeamsContestCountObj),
        },
        options,
      );
      return 'Success';
    } catch (err) {
      return 'Error';
    }
  }

  async updateSeriesPoints(seriesAPIId: number) {
    try {
      const completedFixtures = await this.fixtureModel.find({
        seriesAPIId,
        fixtureStatus: 'Completed',
      });
      const fixtureIds = completedFixtures.map((e) => e.fixtureAPIId);
      const playerPerformances = await this.playerPerformanceModel.find({
        fixtureAPIId: { $in: fixtureIds },
      });
      const playerPointsArr = [];
      for (const playerStats of playerPerformances) {
        playerPointsArr.push(...playerStats.playerPoint);
      }

      const playerPointsSum = playerPointsArr.reduce((total, value) => {
        if (!total[value.player_id])
          total[value.player_id] = { playerAPIId: value.player_id, points: 0 };
        total[value.player_id].points += value.point;

        return total;
      }, {});

      await this.seriesPointsModel.findOneAndUpdate(
        { seriesAPIId: +seriesAPIId },
        {
          seriesAPIId: +seriesAPIId,
          playerPoints: Object.values(playerPointsSum),
          gameType: 'cricket',
        },
        options,
      );

      return { success: 'Success' };
    } catch (err) {
      console.log(err);
      return { error: 'Error' };
    }
  }

  async moveContesttoLive(fixtureAPIId: number) {
    try {
      const gonnaBeLiveContests = await this.contestModel.find({
        fixtureAPIId,
        isactive: true,
        enabledStatus: true,
      });

      for (const contest of gonnaBeLiveContests) {
        const deviceTokens = [];
        const joinedUsers: any = Object.values(contest.jointUsers);
        const userIdObj = Object.keys(contest.jointUsers);

        if (joinedUsers.length == 1) {
          const user = joinedUsers[0];
          const userTeamsLen = Object.values(user.userTeams).length;
          await this.contestModel.findByIdAndUpdate(contest._id, {
            isactive: false,
            enabledStatus: false,
          });
          const fixture = await this.fixtureModel.findOne({
            fixtureAPIId: fixtureAPIId,
          });
          const fixName = fixture.fixtureDisplayName;
          const notificationPayload = {
            notification: {
              title: 'Match Refunded',
              body:
                contest.constestCaption + ' refunded for the match ' + fixName,
            },
          };
          const Notification = {
            pn_title: notificationPayload.notification.title,
            pn_message: notificationPayload.notification.body,
            fixture_id: fixtureAPIId,
            pn_receivers: userIdObj[0],
            pn_sendTime: new Date(),
            pn_status: 1,
            createdat: new Date(),
          };

          await this.notificationModel.create(Notification);
          const amount = Number(contest.entryFee * userTeamsLen);

          const walletCheck = await this.UserWalletModel.findOne({
            userId: userIdObj[0],
          });
          const userTransaction = {
            userId: userIdObj[0],
            transanctionType: 'Credit',
            amount: amount,
            walletId: walletCheck._id,
            previousBalance: walletCheck.userBalance,
            afterBalance: walletCheck.userBalance + amount,
            transanctionRelatedType: 'Refund',
            transanctionTime: new Date(),
            transactionStatus: 'Success',
            fixtureId: fixtureAPIId,
            fixtureName: fixName,
            contestId: contest._id,
            contestName: contest.contestName ? contest.contestName : '',
          };
          await this.UserTransactiontModel.create(userTransaction);
          const userwallet = {
            userBalance: walletCheck.userBalance + amount,
            unutilisedBalance: walletCheck.unutilisedBalance + amount,
          };

          await this.UserWalletModel.findByIdAndUpdate(
            walletCheck._id,
            userwallet,
          );
          const userdetail = await this.userModel.findById(userIdObj[0]);
          if (userdetail && userdetail?.deviceToken) {
            deviceTokens.push(userdetail.deviceToken);
            await this.fcmService.sendNotification(
              deviceTokens,
              notificationPayload,
            );
          }
        }
      }
    } catch (err) {
      return { status: false };
    }
  }

  async cancelContestsbyFixture(fixtureAPIId: number) {
    try {
      const contests = await this.contestModel.find({
        isactive: true,
        enabledStatus: true,
        fixtureAPIId,
      });
      const userRefunds = {};
      for (const contest of contests) {
        for (const userId in contest['jointUsers']) {
          const element = contest['jointUsers'][userId];

          if (!userRefunds[userId]) userRefunds[userId] = 0;
          const teamCount = Object.keys(element['userTeams']).length;
          const refundAmount = teamCount * contest.entryFee;
          userRefunds[userId] += refundAmount;
        }
      }

      /* Initiate refund */
      for (const userId in userRefunds) {
        const amount = userRefunds[userId];
        const userWallet = await this.UserWalletModel.findOne({ userId });
        if (!userWallet) continue;
        const transactionObj: UserTransaction = {
          userId,
          walletId: userWallet._id.toString(),
          amount,
          previousBalance: userWallet.userBalance,
          afterBalance: userWallet.userBalance + amount,
          transanctionTime: new Date(),
          fixtureId: `${fixtureAPIId}`,
          transanctionRelatedType: 'Refund',
          transanctionType: 'Credit',
        };
        userWallet.userBalance += amount;
        userWallet.unutilisedBalance += amount;
        await userWallet.save();
        await this.UserTransactiontModel.create(transactionObj);
      }

      await this.contestModel.updateMany(
        { fixtureAPIId },
        { isactive: false, enabledStatus: false },
      );
    } catch (err) {
      console.log(err);
    }
  }

  async cancelIncompleteContests(
    fixtureAPIId: number,
    fixtureName: string,
    gameType = 'cricket',
  ) {
    try {
      await this.contestModel.updateMany(
        { fixtureAPIId, gameType },
        { $set: { isJoin: false } },
      );
      const errorNotes = [];
      const flexibleContests = (
        await this.contestModel
          .find({
            fixtureAPIId,
            gameType,
            isactive: true,
            enabledStatus: true,
            guaranteed: false,
          })
          .select(['jointUsers', 'entryFee', 'contestName', 'constestCaption'])
      ).filter((e) => Object.keys(e.jointUsers).length === 1);

      const normalContest = await this.contestModel
        .find({
          fixtureAPIId,
          gameType,
          isactive: true,
          enabledStatus: true,
          guaranteed: true,
          remainingSpots: { $ne: 0 },
        })
        .select(['jointUsers', 'entryFee', 'contestName', 'constestCaption']);

      const tobeRefundContests = [...flexibleContests, ...normalContest];
      const userContestRefunds = {};
      const winnerTransactions = {};
      let contestCaption = '';
      for (const contest of tobeRefundContests) {
        for (const userId in contest.jointUsers) {
          contestCaption = contest.constestCaption;
          let userContestPrize = 0;
          const userObj: any = contest.jointUsers[userId]; //Joint users teams

          if (!userContestRefunds[userId]) userContestRefunds[userId] = 0;
          userContestRefunds[userId] +=
            Object.values(userObj.userTeams).length * (contest?.entryFee ?? 0);
          if (userContestRefunds[userId] != 0) {
            if (!winnerTransactions[userId]) winnerTransactions[userId] = [];
            winnerTransactions[userId].push({
              userContestPrize: userContestRefunds[userId],
              userId,
              contestId: contest._id.toString(),
              contestName: contest.contestName,
              fixtureAPIId,
              fixtureName,
            });
          }
        }
      }

      const userIdsList = Object.keys(userContestRefunds);

      const userFCMList = await this.userModel // notification purpose
        .find({
          _id: { $in: userIdsList },
        })
        .select('deviceToken')
        .lean();
      const UserWallet = await this.UserWalletModel.find({
        userId: { $in: userIdsList },
      })
        .select(['_id', 'userId'])
        .lean();

      if (userIdsList.length != userFCMList.length) {
        console.log('User missing');
        const winningUserStr = JSON.stringify(userFCMList);
        for (const userId of userIdsList) {
          if (!winningUserStr.includes(userId))
            errorNotes.push({ error: 'userMiss', userId });
        }
      }

      if (userIdsList.length != UserWallet.length) {
        console.log('Wallet missing');
        const winningUserStr = JSON.stringify(UserWallet);
        for (const userId of userIdsList) {
          if (!winningUserStr.includes(userId))
            errorNotes.push({ error: 'walletMiss', userId });
        }
      }

      if (errorNotes.length) {
        console.log(errorNotes);
        return { status: false };
      }

      const tSession = await this.UserTransactiontModel.startSession();
      const wSession = await this.UserWalletModel.startSession();
      const contestSession = await this.contestModel.startSession();
      const tOptions = { session: tSession };
      const wOptions = { session: wSession };
      const cOptions = { session: contestSession };

      tSession.startTransaction();
      wSession.startTransaction();
      contestSession.startTransaction();

      try {
        const userWallets = (
          await this.UserWalletModel.find({
            userId: { $in: userIdsList },
          })
        ).reduce((total, value) => {
          total[value.userId] = value;
          return total;
        }, {});

        for (const userId in winnerTransactions) {
          const contestWinnings = winnerTransactions[userId];
          for (const contestWinData of contestWinnings) {
            const entryFeeTransactions = await this.UserTransactiontModel.find({
              userId,
              contestId: contestWinData.contestId,
              transanctionRelatedType: 'EntryFee',
            });
            const totalAmout: number =
              entryFeeTransactions?.reduce((total, value) => {
                total += value.amount;
                return total;
              }, 0) ?? 0;
            const bonusAmout: number =
              entryFeeTransactions?.reduce((total, value) => {
                total += value.bonusUsed ? value.bonusUsed : 0;
                return total;
              }, 0) ?? 0;
            // const bonusAmout = contestWinData.userContestPrize - totalAmout;

            // const userWallet = await this.UserWalletModel.findOne({ userId });
            if (totalAmout > 0) {
              const transactionObj: UserTransaction = {
                userId,
                walletId: userWallets[userId]._id.toString(),
                fixtureName,
                fixtureId: `${fixtureAPIId}`,
                contestId: contestWinData.contestId,
                contestName: contestWinData.contestName,
                transanctionTime: new Date(),
                amount: totalAmout,
                bonusUsed: +bonusAmout || 0,
                previousBalance: userWallets[userId].userBalance,
                afterBalance: userWallets[userId].userBalance + totalAmout,
                transanctionRelatedType: 'Refund',
                transanctionType: 'Credit',
              };
              userWallets[userId].unutilisedBalance += transactionObj.amount;
              userWallets[userId].userBalance += transactionObj.amount;
              userWallets[userId].totalBonus += bonusAmout;
              // userWallet.unutilisedBalance += transactionObj.amount;
              // userWallet.userBalance += transactionObj.amount;
              // userWallet.totalBonus += bonusAmout;
              await this.UserTransactiontModel.create(
                [transactionObj],
                tOptions,
              );
              // await this.UserWalletModel.updateOne(
              //   { userId },
              //   userWallet,
              //   wOptions,
              // );
            }
            await this.contestModel.updateOne(
              {
                _id: contestWinData.contestId,
              },
              {
                enabledStatus: false,
                isactive: false,
              },
              cOptions,
            );
          }
        }
        for (const userId in userWallets) {
          const userWallet = userWallets[userId];
          await this.UserWalletModel.findOneAndUpdate(
            { userId },
            userWallet,
            wOptions,
          );
        }
      } catch (err) {
        console.log(err);
        await tSession.abortTransaction();
        await wSession.abortTransaction();
        await contestSession.abortTransaction();
        await tSession.endSession();
        await wSession.endSession();
        await contestSession.endSession();
        errorNotes.push({ error: 'Transactions error', message: err.message });
      }

      if (errorNotes.length) {
        console.log(errorNotes);
        return { status: false };
      }

      await tSession.commitTransaction();
      await wSession.commitTransaction();
      await contestSession.commitTransaction();
      await tSession.endSession();
      await wSession.endSession();
      await contestSession.endSession();

      const usersbyId = userFCMList.reduce((total, value) => {
        total[value._id.toString()] = value;
        return total;
      }, {});

      for (const userId in userContestRefunds) {
        const refundAmount = userContestRefunds[userId];
        if (refundAmount != 0) {
          const notificationPayload = {
            notification: {
              title: 'Refund!!!',
              body: `${refundAmount}₹ refunded for the match ${fixtureName}`,
            },
          };
          const Notification = {
            pn_title: 'Refund!!!',
            pn_message: `${refundAmount}₹ refunded for the match ${fixtureName}`,
            fixture_id: fixtureAPIId,
            pn_receivers: userId,
            pn_sendTime: new Date(),
            pn_status: 1,
            createdat: new Date(),
          };
          await this.notificationModel.create(Notification);
          if (usersbyId[userId]?.deviceToken) {
            await this.fcmService.sendNotification(
              [usersbyId[userId].deviceToken],
              notificationPayload,
            );
          }
        }
      }

      return { status: true };
    } catch (err) {
      console.log(err.message);
      return { status: false };
    }
  }

  async cancelAllContests(fixtureAPIId: number, fixtureName: string) {
    const errorNotes = [];
    try {
      const tobeRefundContests = await this.contestModel.find({
        fixtureAPIId,
        isactive: true,
        enabledStatus: true,
      });

      const userContestRefunds = {};
      const winnerTransactions = {};

      for (const contest of tobeRefundContests) {
        for (const userId in contest.jointUsers) {
          const userObj: any = contest.jointUsers[userId]; //Joint users teams

          if (!userContestRefunds[userId]) userContestRefunds[userId] = 0;
          userContestRefunds[userId] +=
            Object.values(userObj.userTeams).length * contest.entryFee;

          if (userContestRefunds[userId] != 0) {
            if (!winnerTransactions[userId]) winnerTransactions[userId] = [];
            winnerTransactions[userId].push({
              userContestPrize: userContestRefunds[userId],
              userId,
              contestId: contest._id.toString(),
              contestName: contest.constestCaption,
              fixtureAPIId,
              fixtureName,
            });
          }
        }
      }

      const userIdsList = Object.keys(userContestRefunds);

      const userFCMList = await this.userModel // notification purpose
        .find({
          _id: { $in: userIdsList },
        })
        .select('deviceToken')
        .lean();
      const UserWallet = await this.UserWalletModel.find({
        userId: { $in: userIdsList },
      })
        .select(['_id', 'userId'])
        .lean();

      if (userIdsList.length != userFCMList.length) {
        console.log('User missing');
        const winningUserStr = JSON.stringify(userFCMList);
        for (const userId of userIdsList) {
          if (!winningUserStr.includes(userId))
            errorNotes.push({ error: 'userMiss', userId });
        }
      }

      if (userIdsList.length != UserWallet.length) {
        console.log('Wallet missing');
        const winningUserStr = JSON.stringify(UserWallet);
        for (const userId of userIdsList) {
          if (!winningUserStr.includes(userId))
            errorNotes.push({ error: 'walletMiss', userId });
        }
      }

      if (errorNotes.length) {
        console.log(errorNotes);
        return { status: false };
      }

      const tSession = await this.UserTransactiontModel.startSession();
      const wSession = await this.UserWalletModel.startSession();
      const cSession = await this.contestModel.startSession();
      const tOptions = { session: tSession };
      const wOptions = { session: wSession };
      const cOptions = { session: cSession };

      tSession.startTransaction();
      wSession.startTransaction();
      cSession.startTransaction();

      try {
        const userWallets = (
          await this.UserWalletModel.find({
            userId: { $in: userIdsList },
          })
        ).reduce((total, value) => {
          total[value.userId] = value;
          return total;
        }, {});
        for (const userId in winnerTransactions) {
          const contestWinnings = winnerTransactions[userId];
          for (const contestWinData of contestWinnings) {
            const entryFeeTransactions = await this.UserTransactiontModel.find({
              userId,
              contestId: contestWinData.contestId,
              transanctionRelatedType: 'EntryFee',
            });
            const totalAmout: number =
              entryFeeTransactions?.reduce((total, value) => {
                total += value.amount;
                return total;
              }, 0) ?? 0;
            const bonusAmout: number =
              entryFeeTransactions?.reduce((total, value) => {
                total += value.bonusUsed ? value.bonusUsed : 0;
                return total;
              }, 0) ?? 0;
            // const bonusAmout = contestWinData.userContestPrize - totalAmout;

            // const userWallet = await this.UserWalletModel.findOne({ userId });

            const transactionObj: UserTransaction = {
              userId,
              walletId: userWallets[userId]._id.toString(),
              fixtureName,
              fixtureId: `${fixtureAPIId}`,
              contestId: contestWinData.contestId,
              contestName: contestWinData.contestName,
              transanctionTime: new Date(),
              amount: totalAmout,
              bonusUsed: +bonusAmout || 0,
              previousBalance: userWallets[userId].userBalance,
              afterBalance: userWallets[userId].userBalance + totalAmout,
              transanctionRelatedType: 'Refund',
              transanctionType: 'Credit',
            };

            userWallets[userId].unutilisedBalance += transactionObj.amount;
            userWallets[userId].userBalance += transactionObj.amount;
            userWallets[userId].totalBonus += bonusAmout;
            // userWallet.unutilisedBalance += transactionObj.amount;
            // userWallet.userBalance += transactionObj.amount;
            // userWallet.totalBonus += bonusAmout;
            await this.UserTransactiontModel.create([transactionObj], tOptions);
            // await this.UserWalletModel.updateOne(
            //   { userId },
            //   userWallet,
            //   wOptions,
            // );
          }
        }
        for (const userId in userWallets) {
          const userWallet = userWallets[userId];
          await this.UserWalletModel.findOneAndUpdate(
            { userId },
            userWallet,
            wOptions,
          );
        }
        await this.contestModel.updateMany(
          { fixtureAPIId },
          { isactive: false, enabledStatus: false },
          cOptions,
        );
      } catch (err) {
        console.log(err);
        await tSession.abortTransaction();
        await wSession.abortTransaction();
        await cSession.abortTransaction();
        await tSession.endSession();
        await wSession.endSession();
        await cSession.endSession();
        errorNotes.push({ error: 'Transactions error', message: err.message });
      }

      if (errorNotes.length) {
        console.log(errorNotes);
        return { status: false };
      }

      await tSession.commitTransaction();
      await wSession.commitTransaction();
      await cSession.commitTransaction();
      await tSession.endSession();
      await wSession.endSession();
      await cSession.endSession();

      const usersbyId = userFCMList.reduce((total, value) => {
        total[value._id.toString()] = value;
        return total;
      }, {});

      for (const userId in userContestRefunds) {
        const refundAmount = userContestRefunds[userId];
        const notificationPayload = {
          notification: {
            title: 'Refund!!!',
            body: `${refundAmount}₹ refunded for the match ${fixtureName}`,
          },
        };
        const Notification = {
          pn_title: 'Refund!!!',
          pn_message: `${refundAmount}₹ refunded for the match ${fixtureName}`,
          fixture_id: fixtureAPIId,
          pn_receivers: userId,
          pn_sendTime: new Date(),
          pn_status: 1,
          createdat: new Date(),
        };
        await this.notificationModel.create(Notification);
        if (usersbyId[userId]?.deviceToken) {
          await this.fcmService.sendNotification(
            [usersbyId[userId].deviceToken],
            notificationPayload,
          );
        }
      }

      return { status: true };
    } catch (err) {
      console.log(err);
      return { status: false };
    }
  }

  async winningDecleration(fixtureAPIId: any) {
    try {
      const findFixture = await this.fixtureModel.findOne({ fixtureAPIId });
      if (!findFixture) return { status: false, message: 'Fixture not found' };
      if (findFixture.fixtureStatus != 'Completed')
        return { status: false, message: 'Fixture not completed' };

      const response = await this.updateWinnerTransactions(
        fixtureAPIId,
        findFixture.fixtureDisplayName,
        findFixture.fixtureStartDate,
        'cricket',
      );

      return response;
    } catch (err) {
      return { status: false, message: 'Error declearing winners' };
    }
  }

  async updateFootballSeriesPoints(seriesAPIId: number) {
    try {
      const completedFixtures = await this.footballFixturesModel.find({
        seriesAPIId,
        fixtureStatus: 'result',
      });

      const fixtureIds = completedFixtures.map((e) => e.fixtureAPIId);

      const playerPerformances = await this.footballPlayerPerformanceModel.find(
        {
          fixtureAPIId: { $in: fixtureIds },
        },
      );

      const playerPointsArr = [];
      for (const playerStats of playerPerformances) {
        playerPointsArr.push(...playerStats.playerPoints);
      }

      const playerPointsSum = playerPointsArr.reduce((total, value) => {
        if (!total[value.playerAPIId])
          total[value.playerAPIId] = {
            playerAPIId: value.playerAPIId,
            points: 0,
          };
        total[value.playerAPIId].points += value.playerPoints;

        return total;
      }, {});

      await this.seriesPointsModel.findOneAndUpdate(
        { seriesAPIId: +seriesAPIId },
        {
          seriesAPIId: +seriesAPIId,
          playerPoints: Object.values(playerPointsSum),
          gameType: 'football',
        },
        options,
      );

      return { success: 'Success' };
    } catch (err) {
      console.log(err);
      return { error: 'Error' };
    }
  }

  @Cron(CronExpression.EVERY_MINUTE, {
    name: 'Footballteampoints',
    disabled: false,
  })
  async updateFootballTeamPoints(fixtureId?: number) {
    try {
      const allPlayerPoints = [];
      const fixtures = (
        await this.footballFixturesModel
          .find(
            fixtureId ? { fixtureAPIId: fixtureId } : { fixtureStatus: 'live' },
          )
          .lean()
      ).map((e) => e.fixtureAPIId);

      const footballPlayerPerformance =
        await this.footballPlayerPerformanceModel
          .find({
            fixtureAPIId: { $in: fixtures },
          })
          .select('playerPoints')
          .lean();
      for (const playerPerformance of footballPlayerPerformance) {
        allPlayerPoints.push(...playerPerformance.playerPoints);
      }
      const playerPoints = allPlayerPoints.reduce((total, value) => {
        total[value.playerAPIId] = { points: value.playerPoints };
        return total;
      }, {});

      for (const fixtureAPIId of fixtures) {
        const liveMatchTeams = await this.userTeamsModel
          .findOne({
            fixtureAPIId,
            gameType: 'football',
          })
          .lean();
        const teamPoints = {};
        for (let index = 0; index < liveMatchTeams.userTeams.length; index++) {
          const userTeam = liveMatchTeams.userTeams[index];

          let totalPoints: number = 0;
          for (let ind = 0; ind < userTeam.team.length; ind++) {
            const player = userTeam.team[ind];

            liveMatchTeams.userTeams[index].team[ind].points =
              (playerPoints?.[player.playerAPIId]?.points || 0) *
              (player.cap ? 2 : player.vc ? 1.5 : 1);

            totalPoints +=
              (playerPoints?.[player.playerAPIId]?.points || 0) *
              (player.cap ? 2 : player.vc ? 1.5 : 1);
          }
          liveMatchTeams.userTeams[index].totalPoints = totalPoints;
          teamPoints[liveMatchTeams.userTeams[index]._id] = totalPoints;
        }

        await this.userTeamsModel.findByIdAndUpdate(
          liveMatchTeams._id,
          liveMatchTeams,
        );

        const contestData = await this.contestModel.find({
          fixtureAPIId,
          isactive: true,
          gameType: 'football',
          enabledStatus: true,
        });
        for (let index = 0; index < contestData.length; index++) {
          const contest = contestData[index];
          for (const userId in contest.jointUsers) {
            const jointUser = contest.jointUsers[userId];
            for (const teamId in jointUser.userTeams) {
              contestData[index].jointUsers[userId].userTeams[teamId].points =
                teamPoints[teamId];
            }
          }
          await this.contestModel.findByIdAndUpdate(
            contestData[index]._id,
            contestData[index],
          );
        }
      }
      await this.winningDeclaration(fixtures, 3, 'football');
      return { status: true };
    } catch (err) {
      return { status: false };
    }
  }

  async updateKabaddiSereisPoints(seriesAPIId: number) {
    try {
      const completedFixtures = await this.kabaddiFixturesModel.find({
        seriesAPIId,
        fixtureStatus: 'result',
      });

      const fixtureIds = completedFixtures.map((e) => e.fixtureAPIId);

      const playerPerformances = await this.kabaddiPlayerPerformanceModel.find({
        fixtureAPIId: { $in: fixtureIds },
      });

      const playerPointsArr = [];
      for (const playerStats of playerPerformances) {
        playerPointsArr.push(...playerStats.playerPoints);
      }

      const playerPointsSum = playerPointsArr.reduce((total, value) => {
        if (!total[value.playerAPIId])
          total[value.playerAPIId] = {
            playerAPIId: value.playerAPIId,
            points: 0,
          };
        total[value.playerAPIId].points += value.playerPoints;

        return total;
      }, {});

      await this.seriesPointsModel.findOneAndUpdate(
        { seriesAPIId: +seriesAPIId },
        {
          seriesAPIId: +seriesAPIId,
          playerPoints: Object.values(playerPointsSum),
          gameType: 'kabaddi',
        },
        options,
      );

      return { success: 'Success' };
    } catch (err) {
      console.log(err);
      return { error: 'Error' };
    }
  }

  @Cron(CronExpression.EVERY_MINUTE, {
    name: 'Kabadditeampoints',
    disabled: false,
  })
  async updateKabaddiTeamPoints(fixtureId?: number) {
    try {
      const allPlayerPoints = [];
      const fixtures = (
        await this.kabaddiFixturesModel
          .find(
            fixtureId ? { fixtureAPIId: fixtureId } : { fixtureStatus: 'live' },
          )
          .lean()
      ).map((e) => e.fixtureAPIId);

      const footballPlayerPerformance = await this.kabaddiPlayerPerformanceModel
        .find({
          fixtureAPIId: { $in: fixtures },
        })
        .select('playerPoints')
        .lean();
      for (const playerPerformance of footballPlayerPerformance) {
        allPlayerPoints.push(...playerPerformance.playerPoints);
      }
      const playerPoints = allPlayerPoints.reduce((total, value) => {
        total[value.playerAPIId] = { points: value.playerPoints };
        return total;
      }, {});

      for (const fixtureAPIId of fixtures) {
        const liveMatchTeams = await this.userTeamsModel
          .findOne({
            fixtureAPIId,
            gameType: 'kabaddi',
          })
          .lean();
        const teamPoints = {};
        for (let index = 0; index < liveMatchTeams.userTeams.length; index++) {
          const userTeam = liveMatchTeams.userTeams[index];

          let totalPoints: number = 0;
          for (let ind = 0; ind < userTeam.team.length; ind++) {
            const player = userTeam.team[ind];

            liveMatchTeams.userTeams[index].team[ind].points =
              (playerPoints?.[player.playerAPIId]?.points || 0) *
              (player.cap ? 2 : player.vc ? 1.5 : 1);

            totalPoints +=
              (playerPoints?.[player.playerAPIId]?.points || 0) *
              (player.cap ? 2 : player.vc ? 1.5 : 1);
          }
          liveMatchTeams.userTeams[index].totalPoints = totalPoints;
          teamPoints[liveMatchTeams.userTeams[index]._id] = totalPoints;
        }

        await this.userTeamsModel.findByIdAndUpdate(
          liveMatchTeams._id,
          liveMatchTeams,
        );

        const contestData = await this.contestModel.find({
          fixtureAPIId,
          gameType: 'kabaddi',
          isactive: true,
          enabledStatus: true,
        });
        for (let index = 0; index < contestData.length; index++) {
          const contest = contestData[index];
          for (const userId in contest.jointUsers) {
            const jointUser = contest.jointUsers[userId];
            for (const teamId in jointUser.userTeams) {
              contestData[index].jointUsers[userId].userTeams[teamId].points =
                teamPoints[teamId];
            }
          }
          await this.contestModel.findByIdAndUpdate(
            contestData[index]._id,
            contestData[index],
          );
        }
      }
      await this.winningDeclaration(fixtures, 3, 'kabaddi');
      return { status: true };
    } catch (err) {
      return { status: false };
    }
  }
}
