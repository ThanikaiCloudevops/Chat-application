import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export type kabaddiLineupDocument = KabaddiLineup & Document;

export class KabaddiTeamLineup {
  playerAPIId: number;
  playerName: string;
  role: string;
  fantasyCredit: number;
  in11: boolean;
  isSubstitute: boolean;
}

@Schema()
export class KabaddiLineup {
  @Prop()
  fixtureAPIId: number;

  @Prop()
  homeTeam: KabaddiTeamLineup[];

  @Prop()
  awayTeam: KabaddiTeamLineup[];
}

export const KabaddiLineupSchema = SchemaFactory.createForClass(KabaddiLineup);
