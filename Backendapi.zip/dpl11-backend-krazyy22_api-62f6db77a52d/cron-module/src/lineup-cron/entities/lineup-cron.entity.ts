import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

export type lineUpDocument = Lineup & Document;

export class playing11 {
  playerId: number;
  isSubstitute: boolean;
  role: string;
  name: string;
  in11: boolean;
}

export class Team {
  teamId: number;
  teamName: string;
  squads: playing11[];
}

@Schema()
export class Lineup {
  @Prop({ index: true })
  fixtureAPIId: number;

  @Prop()
  teamA: Team;

  @Prop()
  teamB: Team;
}
export const LineUpSchema = SchemaFactory.createForClass(Lineup);
