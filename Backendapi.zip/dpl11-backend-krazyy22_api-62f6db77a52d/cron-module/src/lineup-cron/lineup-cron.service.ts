import { Injectable } from '@nestjs/common';
import { lineupHelpers } from './helpers/lineup.service';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { GameService } from 'src/game-cron/game-cron.service';
import { Lineup, lineUpDocument } from './entities/lineup-cron.entity';
import { SPORTS_DATA } from 'config/envirnment';
import { Cron, CronExpression } from '@nestjs/schedule';
import { PointsCronService } from 'src/points-cron/points-cron.service';
import {
  FootballLineup,
  footballLineupDocument,
} from './entities/football-lineup.entity';
import {
  KabaddiLineup,
  kabaddiLineupDocument,
} from './entities/kabaddi-lineup.entity';

const options = { upsert: true, new: true, setDefaultsOnInsert: true };

@Injectable()
export class LineupCronService {
  constructor(
    @InjectModel('Lineup')
    private lineUpModel: Model<lineUpDocument>,
    @InjectModel('FootballLineup')
    private footballLineupModel: Model<footballLineupDocument>,
    @InjectModel('KabaddiLineup')
    private kabaddiLineupodel: Model<kabaddiLineupDocument>,
    private gameService: GameService,
    private pointysService: PointsCronService,
    private readonly lineupHelpers: lineupHelpers,
  ) {}

  @Cron(CronExpression.EVERY_MINUTE, {
    name: 'lineup',
    disabled: false,
  })
  async updateLineup() {
    try {
      console.log('Line up cron running');
      const toBeLiveFixtures: any[] = await this.gameService.upComingFixtures();
     console.log(toBeLiveFixtures)
      // toBeLiveFixtures.push({ fixtureAPIId: 79188 });
      for (const fixture of toBeLiveFixtures) {
        const req = await fetch(
          `${SPORTS_DATA.URL}/scorecard/${fixture.fixtureAPIId}/lineup?token=A12345BCDefg1985`,
        );

        const { data } = await req.json();
        if (!data) continue;

        const lineUp: Lineup = this.lineupHelpers.formatLineUp(
          data?.teams,
          fixture.fixtureAPIId,
        );

        await this.lineUpModel.findOneAndUpdate(
          { fixtureAPIId: fixture.fixtureAPIId },
          lineUp,
          options,
        );
        await this.gameService.updateFixtureLineup(fixture.fixtureAPIId);
      }
      return { message: 'Lineup updated successfully' };
    } catch (err) {
      return { message: 'Error updating lineup' };
    }
  }

  @Cron(CronExpression.EVERY_5_MINUTES, {
    name: 'footballLineup',
    disabled: false,
  })
  async footBallLineup() {
    try {
      const toBeLiveFixtures: any[] = await this.gameService.upComingFixtures(
        'football',
      );
      // toBeLiveFixtures.push({ fixtureAPIId: 232667 }); //Testing
      for (const fixture of toBeLiveFixtures) {
        const req = await fetch(
          `${SPORTS_DATA.FOOTBALL}/scorecard/${fixture.fixtureAPIId}/lineup?token=ORTJXUNJXPb8Sk8`,
        );

        const { data } = await req.json();
        if (!data) continue;

        const lineUp: FootballLineup =
          this.lineupHelpers.formatFootballLineup(data);

        await this.footballLineupModel.findOneAndUpdate(
          { fixtureAPIId: fixture.fixtureAPIId },
          lineUp,
          options,
        );

        await this.gameService.updateFootballFixtureLineup(
          fixture.fixtureAPIId,
        );
      }
      return { message: 'Lineup updated successfully' };
    } catch (err) {
      console.log(err);

      return { message: 'Error updating lineup' };
    }
  }

  @Cron(CronExpression.EVERY_MINUTE, {
    name: 'live',
    disabled: false,
  })
  async updateFixtureToLive() {
    try {
      console.log('Live cron runing');

      const currentDateTime = new Date();
      currentDateTime.setSeconds(0, 0);

      const liveCheck = await this.gameService.getUpComingLineUpFixtures();
      liveCheck.forEach(async (fixtures) => {
        if (
          fixtures.fixtureStartDate.toString() == currentDateTime.toString() ||
          currentDateTime > fixtures.fixtureStartDate
        ) {
          const res = await this.pointysService.cancelIncompleteContests(
            fixtures.fixtureAPIId,
            fixtures.fixtureDisplayName,
          );
          if (res.status) {
            await this.gameService.fixtureLiveChange(fixtures.fixtureAPIId);
            //Update lineup
            const req = await fetch(
              `${SPORTS_DATA.URL}/scorecard/${fixtures.fixtureAPIId}/lineup?token=A12345BCDefg1985`,
            );
            const { data } = await req.json();
            if (data) {
              const lineUp: Lineup = this.lineupHelpers.formatLineUp(
                data?.teams,
                fixtures.fixtureAPIId,
              );

              await this.lineUpModel.findOneAndUpdate(
                { fixtureAPIId: fixtures.fixtureAPIId },
                lineUp,
                options,
              );
            }
          }
        }
      });

      return { status: true };
    } catch (err) {
      console.log(err);
      return { status: false };
    }
  }

  @Cron(CronExpression.EVERY_5_MINUTES, {
    name: 'footballLive',
    disabled: false,
  })
  async updateFootballFixtureToLive() {
    try {
      console.log('Live cron runing');

      const currentDateTime = new Date();
      currentDateTime.setSeconds(0, 0);

      const liveCheck = await this.gameService.getUpComingLineUpFixtures(
        'football',
      );
      liveCheck.forEach(async (fixtures) => {
        if (
          fixtures.fixtureStartDate.toString() == currentDateTime.toString() ||
          currentDateTime > fixtures.fixtureStartDate
        ) {
          const res = await this.pointysService.cancelIncompleteContests(
            fixtures.fixtureAPIId,
            fixtures.fixtureDisplayName,
            'football',
          );
          if (res.status) {
            await this.gameService.fixtureLiveChange(
              fixtures.fixtureAPIId,
              'football',
            );
          }
        }
      });

      return { status: true };
    } catch (err) {
      console.log(err);
      return { status: false };
    }
  }

  @Cron(CronExpression.EVERY_MINUTE, {
    name: 'KabaddiLineup',
    disabled: true,
  })
  async updateKabaddiLineup() {
    try {
      const toBeLiveFixtures: any[] = await this.gameService.upComingFixtures(
        'kabaddi',
      );
      // toBeLiveFixtures.push({ fixtureAPIId: 2632 });
      for (const fixture of toBeLiveFixtures) {
        const req = await fetch(
          `${SPORTS_DATA.KABADDI}/scorecard/${fixture.fixtureAPIId}/lineup`,
        );

        const { data } = await req.json();
        if (!data) continue;

        const lineUp: KabaddiLineup =
          this.lineupHelpers.formatKabaddiLineup(data);
        if (!lineUp) continue;

        await this.kabaddiLineupodel.findOneAndUpdate(
          { fixtureAPIId: fixture.fixtureAPIId },
          lineUp,
          options,
        );

        await this.gameService.updateKabaddiFixtureLineup(fixture.fixtureAPIId);
      }
      return { message: 'Lineup updated successfully' };
    } catch (err) {
      console.log(err);
      return { messag: 'Error updating lineup' };
    }
  }

  @Cron(CronExpression.EVERY_MINUTE, {
    name: 'kabaddiLive',
    disabled: true,
  })
  async updateKabaddiFixturetoLive() {
    try {
      const currentDateTime = new Date();
      currentDateTime.setSeconds(0, 0);

      const liveCheck = await this.gameService.getUpComingLineUpFixtures(
        'kabaddi',
      );
      liveCheck.forEach(async (fixtures) => {
        if (
          fixtures.fixtureStartDate.toString() == currentDateTime.toString() ||
          currentDateTime > fixtures.fixtureStartDate
        ) {
          const res = await this.pointysService.cancelIncompleteContests(
            fixtures.fixtureAPIId,
            fixtures.fixtureDisplayName,
            'kabaddi',
          );
          if (res.status) {
            await this.gameService.fixtureLiveChange(
              fixtures.fixtureAPIId,
              'kabaddi',
            );
          }
        }
      });

      return { status: true };
    } catch (err) {
      console.log(err);
      return { status: false };
    }
  }

  @Cron(CronExpression.EVERY_MINUTE, {
    name: 'cricketDelay',
    disabled: false,
  })
  async fixtureDelayTimeUpdate() {
    try {
      const upcomingFixtures =
        await this.gameService.upComingFixturesDelayUpdate();

      upcomingFixtures.forEach(async (fixture) => {
        const req = await fetch(
          `${SPORTS_DATA.URL}/fixture/${fixture.seriesAPIId}?match_id=${fixture.fixtureAPIId}&token=C12345BCDeAG7800`,
        );
        const { data } = await req.json();
        if (data?.fixtureMatch?.date_start) {
          fixture.fixtureStartDate = new Date(data.fixtureMatch.date_start);
          await fixture.save();
        }
      });
    } catch (err) {
      console.log(err);
      return { status: false, message: 'Error updating delay' };
    }
  }
}
