import { PartialType } from '@nestjs/mapped-types';
import { CreateLineupCronDto } from './create-lineup-cron.dto';

export class UpdateLineupCronDto extends PartialType(CreateLineupCronDto) {}
