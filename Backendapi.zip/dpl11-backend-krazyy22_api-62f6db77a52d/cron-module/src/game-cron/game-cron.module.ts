import { Module } from '@nestjs/common';
import { Cron, GameService } from './game-cron.service';
import { FixtureSquadCron } from './game-cron.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { cricketFixtures, FixturesSchema } from './entities/fixtures.entity';
import { Series, SeriesSchema } from './entities/series.entity';
import { TeamPlayers, TeamPlayerSchema } from './entities/team-players.entity';
import { ScheduleModule } from '@nestjs/schedule';
import { HelpersService } from './helpers/helpers.service';
import { GameCronService } from './cron-service/cron-service.service';
//import { FcmService } from 'src/notifications/notifications.service';
import { NotificationService } from 'src/notification/notification.service';
import { FirebaseService } from 'src/notification/firebase.service';
import { PointsCronModule } from 'src/points-cron/points-cron.module';
import { NotificationModule } from 'src/notifications/notifications.module';
import { PushNotificationQueueService } from 'src/notifications/notifications.queue';
import { BullQueue_pushNotification } from 'src/notifications/bull-queue.provider';
import { BullModule } from '@nestjs/bull';
import { User, UserSchema } from './entities/user.entity';
import {
  NotificationSchema,
  Notification,
} from './entities/notifications.entity';
import {
  FootballSeries,
  FootballSeriesSchema,
} from './entities/footballseries.entity';
import {
  FootballFixtures,
  FootballFixturesSchema,
} from './entities/footballfixtures.entity';
import {
  FootballTeamPlayers,
  FootballTeamPlayersSchema,
} from './entities/footballteamplayers.entity';
import { KabaddiSeriesSchema, KabaddiSeries } from './entities/kabaddiseries.entity';
import { KabaddiFixtures, kabaddiFixturesSchema } from './entities/kabaddifixtures.entity';
import { KabaddiTeamPlayers, KabaddiTeamPlayersSchema } from './entities/kabadditeamplayers.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: cricketFixtures.name, schema: FixturesSchema },
      { name: Notification.name, schema: NotificationSchema },
      { name: Series.name, schema: SeriesSchema },
      { name: TeamPlayers.name, schema: TeamPlayerSchema },
      { name: User.name, schema: UserSchema },
      { name: FootballSeries.name, schema: FootballSeriesSchema },
      { name: FootballFixtures.name, schema: FootballFixturesSchema },
      { name: FootballTeamPlayers.name, schema: FootballTeamPlayersSchema },
      { name: KabaddiSeries.name, schema: KabaddiSeriesSchema},
      { name: KabaddiFixtures.name, schema: kabaddiFixturesSchema},
      { name: KabaddiTeamPlayers.name, schema: KabaddiTeamPlayersSchema}
      ]),
    BullModule.registerQueue({
      name: 'pushNotification',
    }),
    ScheduleModule.forRoot(),
    PointsCronModule,
    NotificationModule,
  ],
  controllers: [FixtureSquadCron],
  exports: [GameService],
  providers: [
    GameService,
    HelpersService,
    GameCronService,
    Cron,
    // FcmService,
    NotificationService,
    FirebaseService,
    PushNotificationQueueService,
    BullQueue_pushNotification,
  ],
})
export class GameCronModule {}
