import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { GameService } from '../game-cron.service';

@Injectable()
export class GameCronService {
  private readonly logger = new Logger(GameCronService.name);
  constructor(private readonly gameService: GameService) {}

  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT, {
    name: 'series',
    disabled: false,
  })
  async startSeriesCron() {
    await this.gameService.seriesUpdate();
    await this.gameService.footballSereisUpdate();
    await this.gameService.kabaddiSeriesUpdate();
    await this.gameService.seriesComplete();
    this.logger.log('Series has been updated');
  }

  @Cron(CronExpression.EVERY_DAY_AT_1AM, {
    name: 'cricketFixtures',
    disabled: false,
  })
  async startFixturesCron() {
    await this.gameService.fixturesUpdate();
    await this.gameService.footBallFixturesUpdate();
    this.logger.log('Fixtures has been updated');
  }

  @Cron(CronExpression.EVERY_DAY_AT_1AM, {
    name: 'teamplayers',
    disabled: false,
  })
  async startTeamPlayersCron() {
    await this.gameService.teamPlayersUpdate();
    await this.gameService.footBallTeamPlayersUpdate();
    this.logger.log('Teams and Players has been updated');
  }
}
