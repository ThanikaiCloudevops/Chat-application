import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { fixtureDocument } from './entities/fixtures.entity';
import { seriesDocument } from './entities/series.entity';
import { userDocument } from './entities/user.entity';
import { teamplayersDocument } from './entities/team-players.entity';
import { HelpersService } from './helpers/helpers.service';
import { SchedulerRegistry } from '@nestjs/schedule';
import { successResponse } from 'src/common-response/success.response';
import { PointsCronService } from 'src/points-cron/points-cron.service';
//import { sendNotification } from 'src/notifications/notifications.service';
import { NotificationService } from 'src/notification/notification.service';
import {
  notificationDocument,
  Notification,
} from './entities/notifications.entity';
import { SPORTS_DATA } from 'config/envirnment';
import { footballSeriesDocument } from './entities/footballseries.entity';
import { footballFixtureDocument } from './entities/footballfixtures.entity';
import { footballTeamPlayersDocument } from './entities/footballteamplayers.entity';
import { kabaddiSeriesDocument } from './entities/kabaddiseries.entity';
import { kabaddiFixtureDocument } from './entities/kabaddifixtures.entity';
import { kabaddiTeamPlayersDocument } from './entities/kabadditeamplayers.entity';
const options = { upsert: true, new: true, setDefaultsOnInsert: true };

@Injectable()
export class GameService {
  constructor(
    @InjectModel('cricketFixtures')
    private fixtureModel: Model<fixtureDocument>,
    @InjectModel('Series') private seriesModel: Model<seriesDocument>,
    @InjectModel('TeamPlayers')
    private teamPlayerModel: Model<teamplayersDocument>,
    @InjectModel('User') private userModel: Model<userDocument>,
    private cronHelpers: HelpersService,
    private pointService: PointsCronService,
    private fcmService: NotificationService,
    @InjectModel('Notification')
    private notificationModel: Model<notificationDocument>,
    @InjectModel('FootballSeries')
    private footballSeriesModel: Model<footballSeriesDocument>,
    @InjectModel('FootballFixtures')
    private footballFixturesModel: Model<footballFixtureDocument>,
    @InjectModel('FootballTeamPlayers')
    private footballTeamPlayersModel: Model<footballTeamPlayersDocument>,
    @InjectModel('KabaddiSeries')
    private kabaddiSeriesModel: Model<kabaddiSeriesDocument>,
    @InjectModel('KabaddiFixtures')
    private kabaddiFixturesModel: Model<kabaddiFixtureDocument>,
    @InjectModel('KabaddiTeamPlayers')
    private kabaddiTeamPlayersModel: Model<kabaddiTeamPlayersDocument>,
  ) {}

  private sports = {
    cricket: {
      fixture: this.fixtureModel,
    },
    football: {
      fixture: this.footballFixturesModel,
    },
    kabaddi: {
      fixture: this.kabaddiFixturesModel,
    },
  };

  //series
  async seriesUpdate() {
    const existingAPIIds = (
      await this.seriesModel.find({ isactive: true }).select(['apiId'])
    ).map((e: any) => e.apiId);

    const data = await this.cronHelpers.pagination(
      `${SPORTS_DATA.URL}/series?token=A12345BCDefg1985`,
    );

    const newSeries = [];
    const existingSeries = [];
    for (const key in data) {
      const series = data[key];
      if (!existingAPIIds.includes(series.cid))
        newSeries.push(this.cronHelpers.formatSeries(series));
      else existingSeries.push(this.cronHelpers.formatSeries(series));
    }

    existingSeries.forEach(async (element: any) => {
      await this.seriesModel.findOneAndUpdate(
        { apiId: element.apiId },
        element,
      );
    });

    await this.seriesModel.insertMany(newSeries);
    return successResponse('series');
  }
  async seriesComplete() {
    try {
      const seriesList = await this.seriesModel.find({
        $or: [{ seriesStatus: 'upcoming' }, { seriesStatus: 'live' }],
      });
      seriesList.forEach(async (series) => {
        const completeCheck = await this.fixtureModel.findOne({
          seriesAPIId: series.apiId,
          fixtureStatus: 'Upcoming',
        });
        if (!completeCheck) {
          series.seriesStatus = 'result';
          await series.save();
        }
      });
    } catch (err) {
      console.log(err);
      return { status: false, message: 'Unable to complete sereis' };
    }
  }
  async footballSereisUpdate() {
    const existingAPIIds = (
      await this.footballSeriesModel.find({ isactive: true }).select(['apiId'])
    ).map((e) => e.apiId);

    const data = await this.cronHelpers.pagination(
      `${SPORTS_DATA.FOOTBALL}/series?token=ORTJXUNJXPb8Sk8&status=1`,
    );

    const newSeries = [];
    const existingSeries = [];
    for (const key in data) {
      const series = data[key];
      if (!existingAPIIds.includes(+series.cid))
        newSeries.push(this.cronHelpers.footballSeries(series));
      else existingSeries.push(this.cronHelpers.footballSeries(series));
    }

    existingSeries.forEach(async (element: any) => {
      await this.footballSeriesModel.findOneAndUpdate(
        { sereisAPIId: element.sereisAPIId },
        element,
      );
    });

    await this.footballSeriesModel.insertMany(newSeries);
    return successResponse('series');
  }
  async kabaddiSeriesUpdate() {
    const existingAPIIds = (
      await this.kabaddiSeriesModel.find({ isactive: true }).select(['apiId'])
    ).map((e: any) => e.apiId);

    const data = await this.cronHelpers.pagination(
      `${SPORTS_DATA.KABADDI}/series?status=2`,
    );

    const newSeries = [];
    const existingSeries = [];
    for (const key in data) {
      const series = data[key];
      if (!existingAPIIds.includes(series.cid))
        newSeries.push(this.cronHelpers.kabaddiSeries(series));
      else existingSeries.push(this.cronHelpers.kabaddiSeries(series));
    }

    existingSeries.forEach(async (element: any) => {
      await this.kabaddiSeriesModel.findOneAndUpdate(
        { apiId: element.apiId },
        element,
      );
    });
    console.log('series kabaddi');
    await this.kabaddiSeriesModel.insertMany(newSeries);
    return successResponse('series');
  }

  // Fixtures
  async fixturesUpdate() {
    try {
      const existingAPIIds = (
        await this.fixtureModel
          .find({ isactive: true })
          .select(['fixtureAPIId'])
      ).map((e: any) => e.fixtureAPIId);

      const upcomingSeries = await this.seriesModel.find({
        seriesStatus: 'upcoming',
      });

      let data = [];

      for (const series of upcomingSeries) {
        const datas = await this.cronHelpers.pagination(
          `${SPORTS_DATA.URL}/fixture/${series.apiId}?token=A12345BCDefg1985`,
        );
        data = [...data, ...datas];
      }

      const newFixtures = [];
      const existingFixtures = [];
      for (const key in data) {
        const fixture = data[key];
        if (!existingAPIIds.includes(fixture.fixtureMatch.match_id))
          newFixtures.push(this.cronHelpers.formatFixtures(fixture));
        else existingFixtures.push(this.cronHelpers.formatFixtures(fixture));
      }

      existingFixtures.forEach(async (element: any) => {
        await this.fixtureModel.findOneAndUpdate(
          { fixtureAPIId: element.fixtureAPIId },
          element,
        );
      });

      await this.fixtureModel.insertMany(newFixtures);

      return successResponse('fixture');
    } catch (err) {
      console.log(err);

      return { status: false };
    }
  }
  async footBallFixturesUpdate() {
    try {
      const existingAPIIds = (
        await this.footballFixturesModel
          .find({ isactive: true })
          .select(['fixtureAPIId'])
      ).map((e) => e.fixtureAPIId);

      const upcomingSeries = await this.footballSeriesModel.find({
        $or: [{ seriesStatus: 'upcoming' }, { seriesStatus: 'live' }],
      });

      let data = [];

      for (const series of upcomingSeries) {
        const datas = await this.cronHelpers.pagination(
          `${SPORTS_DATA.FOOTBALL}/fixture/${series.apiId}?token=ORTJXUNJXPb8Sk8&`,
        );
        data = [...data, ...datas];
      }

      const newFixtures = [];
      const existingFixtures = [];
      for (const key in data) {
        const fixture = data[key];
        if (!existingAPIIds.includes(fixture.fixtureMatch.match_id))
          newFixtures.push(this.cronHelpers.footballFixtures(fixture));
        else existingFixtures.push(this.cronHelpers.footballFixtures(fixture));
      }

      existingFixtures.forEach(async (element: any) => {
        await this.footballFixturesModel.findOneAndUpdate(
          { fixtureAPIId: element.fixtureAPIId },
          element,
        );
      });

      await this.footballFixturesModel.insertMany(newFixtures);

      return successResponse('fixture');
    } catch (err) {
      console.log(err);

      return { status: false };
    }
  }
  async kabaddiFixturesUpdate() {
    try {
      const existingAPIIds = (
        await this.kabaddiFixturesModel
          .find({ isactive: true })
          .select(['fixtureAPIId'])
      ).map((e) => e.fixtureAPIId);

      const upcomingSeries = await this.kabaddiSeriesModel.find({
        $or: [{ seriesStatus: 'upcoming' }, { seriesStatus: 'live' }],
      });

      let data = [];

      for (const series of upcomingSeries) {
        const datas = await this.cronHelpers.pagination(
          `${SPORTS_DATA.KABADDI}/fixture/${series.apiId}`,
        );
        data = [...data, ...datas];
      }

      const newFixtures = [];
      const existingFixtures = [];
      for (const key in data) {
        const fixture = data[key];
        if (!existingAPIIds.includes(fixture.fixtureMatch.match_id))
          newFixtures.push(this.cronHelpers.kabaddiFixtures(fixture));
        else existingFixtures.push(this.cronHelpers.kabaddiFixtures(fixture));
      }

      existingFixtures.forEach(async (element: any) => {
        await this.kabaddiFixturesModel.findOneAndUpdate(
          { fixtureAPIId: element.fixtureAPIId },
          element,
        );
      });
      await this.kabaddiFixturesModel.insertMany(newFixtures);

      return successResponse('fixture');
    } catch (err) {
      console.log(err);

      return { status: false };
    }
  }

  // Fixtures
  async fixtureDailyUpdate() {
    try {
      const currentDate = new Date();
      const futureDate = new Date();
      futureDate.setDate(currentDate.getDate() + 1);

      const upcomingFixtures = await this.fixtureModel.find({
        $and: [
          {
            fixtureStartDate: { $gte: currentDate },
          },
          {
            fixtureStartDate: {
              $lte: futureDate,
            },
          },
          {
            fixtureStatus: 'Upcoming',
            enabledStatus: true,
            lineupsOut: false,
          },
        ],
      });
      let data = [];
      const newFixtures = [];
      for (const fixtures of upcomingFixtures) {
        const req = await fetch(
          `${SPORTS_DATA.URL}/fixture/${fixtures.seriesAPIId}?match_id=${fixtures.fixtureAPIId}&token=A12345BCDefg1985`,
        );
        const { data } = await req.json();
        newFixtures.push(this.cronHelpers.formatFixtures(data));
      }
      newFixtures.forEach(async (element: any) => {
        await this.fixtureModel.findOneAndUpdate(
          { fixtureAPIId: element.fixtureAPIId },
          element,
        );
      });
      return newFixtures;
    } catch (error) {}
  }

  // teams
  // async teamPlayersUpdate() {
  //   const upcomingSeries = await this.seriesModel.find({
  //     seriesStatus: 'upcoming',
  //   });

  //   let datas = [];

  //   for (const series of upcomingSeries) {
  //     const req = await fetch(
  //       `${SPORTS_DATA.URL}/squad/${series.apiId}?token=A12345BCDefg1985`,
  //     );
  //     const { data } = await req.json();
  //     const teamIds = data.map((e: any) => e.team_id);
  //     await this.seriesModel.findOneAndUpdate(
  //       { apiId: series.apiId },
  //       { teams: teamIds },
  //     );

  //     datas = [...datas, ...data];
  //   }

  //   const updateTeamPlayers = [];
  //   const insertTeamPlayers = [];
  //   for (const teamPlayers of datas) {
  //     const team = this.cronHelpers.initilizeTeam(teamPlayers);
  //     for (const players of teamPlayers.players) {
  //       team.teamPlayers.push(this.cronHelpers.formatTeamPlayers(players));
  //     }
  //     if (existingAPIIds.includes(team.teamAPIId))
  //       updateTeamPlayers.push(team);
  //     else insertTeamPlayers.push(team);
  //   }
  //   updateTeamPlayers.forEach(async (element: any) => {
     
  //     await teamPlayerModel.findOneAndUpdate(
  //       { teamAPIId: element.teamAPIId, seriesAPIId:element.seriesAPIId, teamformatstr:element.teamformatstr},
  //       element,
  //       options

  //     );
  //   });

  //   await teamPlayerModel.insertMany(insertTeamPlayers);
  //   return successResponse('teamplayers', insertTeamPlayers);

  // }

  async teamPlayersUpdate() {
    const existingAPIIds = (
      await this.teamPlayerModel.find().select(['teamAPIId'])
    ).map((e: any) => e.teamAPIId);
    const upcomingSeries = await this.seriesModel.find({
      seriesStatus: 'upcoming',
    });

    let datas = [];

    for (const series of upcomingSeries) {
      const req = await fetch(
        `${SPORTS_DATA.URL}/squad/${series.apiId}?token=A12345BCDefg1985`,
      );
      const { data } = await req.json();
      const teamIds = data.map((e: any) => e.team_id);
      await this.seriesModel.findOneAndUpdate(
        { apiId: series.apiId },
        { teams: teamIds },
      );

      datas = [...datas, ...data];
    }

    const updateTeamPlayers = [];
    const insertTeamPlayers = [];
    for (const teamPlayers of datas) {
      const team = this.cronHelpers.initilizeTeam(teamPlayers);
      for (const players of teamPlayers.players) {
        team.teamPlayers.push(this.cronHelpers.formatTeamPlayers(players));
      }
      if (existingAPIIds.includes(team.teamAPIId)) updateTeamPlayers.push(team);
      else insertTeamPlayers.push(team);
    }

    updateTeamPlayers.forEach(async (element: any) => {
      if (element?.teamPlayers.length)
        await this.teamPlayerModel.findOneAndUpdate(
          { teamAPIId: element.teamAPIId, seriesAPIId:element.seriesAPIId, teamformatstr:element.teamformatstr },
          element,
          options
        );
    });

    await this.teamPlayerModel.insertMany(insertTeamPlayers);
    return successResponse('teamplayers');
  }
  async footBallTeamPlayersUpdate() {
    const upcomingSeries = await this.footballSeriesModel.find({
      $or: [{ seriesStatus: 'upcoming' }, { seriesStatus: 'live' }],
    });
    let datas = [];

    for (const series of upcomingSeries) {
      const data = await this.cronHelpers.pagination(
        `${SPORTS_DATA.FOOTBALL}/squads/${series.apiId}?token=ORTJXUNJXPb8Sk8`,
      );

      datas = [...datas, ...data];
    }

    for (const teamPlayers of datas) {
      const team = this.cronHelpers.initilizeFootballTeam(teamPlayers);
      for (const players of teamPlayers.squads) {
        team.squads.push(this.cronHelpers.formatFootballPlayers(players));
      }
      await this.footballTeamPlayersModel.findOneAndUpdate(
        { teamAPIId: team.teamAPIId },
        team,
        options,
      );
    }
    return successResponse('teamplayers');
  }

  async kabaddiTeamPlayersUpdate() {
    const existingAPIIds = (
      await this.kabaddiTeamPlayersModel.find().select(['teamAPIId'])
    ).map((e: any) => e.teamAPIId);
    const upcomingSeries = await this.kabaddiSeriesModel.find({
      seriesStatus: 'live',
    });

    let datas = [];

    for (const series of upcomingSeries) {
      const req = await fetch(`${SPORTS_DATA.KABADDI}/squads/${series.apiId}`);
      const { data } = await req.json();
      const teamIds = data.map((e: any) => e.team_id);
      await this.kabaddiSeriesModel.findOneAndUpdate(
        { apiId: series.apiId },
        { teams: teamIds },
      );

      datas = [...datas, ...data];
    }

    const updateTeamPlayers = [];
    const insertTeamPlayers = [];

    for (const teamPlayers of datas) {
      const team = this.cronHelpers.initilizeKabaddiTeam(teamPlayers);
      for (const players of teamPlayers.squads) {
        team.squads.push(this.cronHelpers.formatKabaddiPlayers(players));
      }
      if (existingAPIIds.includes(team.teamAPIId)) updateTeamPlayers.push(team);
      else insertTeamPlayers.push(team);
    }

    updateTeamPlayers.forEach(async (element: any) => {
      await this.kabaddiTeamPlayersModel.findOneAndUpdate(
        { teamAPIId: element.teamAPIId },
        element,
      );
    });

    await this.kabaddiTeamPlayersModel.insertMany(insertTeamPlayers);
    return successResponse('teamplayers');
  }

  async squadFixtureUpdate(fixtureAPIId?: number) {
    const currentDate = new Date();
    const futureDate = new Date();
    futureDate.setDate(currentDate.getDate() + 1);

    const existingAPIIds = (
      await this.teamPlayerModel.find().select(['teamAPIId'])
    ).map((e: any) => e.teamAPIId);
    let filterObj;
    if (fixtureAPIId) {
      filterObj = { fixtureAPIId };
    } else {
      filterObj = {
        $and: [
          {
            fixtureStartDate: { $gte: currentDate },
          },
          {
            fixtureStartDate: {
              $lte: futureDate,
            },
          },
          {
            fixtureStatus: 'Upcoming',
            enabledStatus: true,
            //lineupsOut: false,
          },
        ],
      };
    }
    const upcomingFixtures = await this.fixtureModel.find(filterObj);
    let datas = [];
    for (const fixture of upcomingFixtures) {
      const req = await fetch(
        `${SPORTS_DATA.URL}/squad/${fixture.seriesAPIId}?match_id=${fixture.fixtureAPIId}&token=A12345BCDefg1985`,
      );
      const { data } = await req.json();
      const teamIds = data.map((e: any) => e.team_id);
      await this.seriesModel.findOneAndUpdate(
        { apiId: fixture.seriesAPIId },
        { teams: teamIds },
      );

      datas = [...datas, ...data];
    }

    const updateTeamPlayers = [];
    const insertTeamPlayers = [];
    for (const teamPlayers of datas) {
      const team = this.cronHelpers.initilizeTeam(teamPlayers);
      for (const players of teamPlayers.players) {
        team.teamPlayers.push(this.cronHelpers.formatTeamPlayers(players));
      }
      if (existingAPIIds.includes(team.teamAPIId)) updateTeamPlayers.push(team);
      else insertTeamPlayers.push(team);
    }
    // changed
   
    updateTeamPlayers.forEach(async (element: any) => {
      await this.teamPlayerModel.findOneAndUpdate(
        { teamAPIId: element.teamAPIId, seriesAPIId:element.seriesAPIId, teamformat:element.teamformat  },
        element,
      );
    });

    await this.teamPlayerModel.insertMany(insertTeamPlayers);
    return successResponse('teamplayers');
  }

  async upComingFixtures(gameType = 'cricket') {
    try {
      const Fixture = this.sports[gameType].fixture;
      console.log(Fixture)
      const currentDate = new Date();
      const futureDate = new Date();
      futureDate.setFullYear(currentDate.getFullYear());
      futureDate.setMonth(currentDate.getMonth());
      futureDate.setDate(currentDate.getDate());
      futureDate.setHours(currentDate.getHours() + 1); //Added One hour to current time for get upcoming matches from our database

      return await Fixture.find({
        $and: [
          {
            fixtureStartDate: { $gte: currentDate },
          },
          {
            fixtureStartDate: {
              $lte: futureDate,
            },
          },
          {
            $or: [{ fixtureStatus: 'Upcoming' }, { fixtureStatus: 'upcoming' }],
            enabledStatus: true,
            lineupsOut: false,
          },
        ],
      });
    } catch (err) {
      return [];
    }
  }

  async updateFixtureLineup(fixtureAPIId: number) {
    await this.squadFixtureUpdate(fixtureAPIId);
    const fixusers = await this.fixtureModel.findOne({ fixtureAPIId });
    const joinedusers = fixusers.joinedUsers;

    const entities = await this.userModel
      .find({ isactive: true, deviceToken: { $ne: '' } })
      .exec();
      console.log(entities)
    const devicetokens: string[] = [];

    for (const fixtures of entities) {
      devicetokens.push(fixtures.deviceToken);
    }
    console.log(devicetokens)
    const displayname = fixusers.fixtureDisplayName;
    const payload = {
      notification: {
        title: 'Lineups Out!!!',
        body: displayname + ' check it out',
      },
    };

    for (const id in joinedusers) {
      var Notification = {
        pn_title: payload.notification.title,
        pn_message: payload.notification.body,
        fixture_id: fixtureAPIId,
        pn_receivers: joinedusers[id],
        pn_sendTime: new Date(),
        pn_status: 0,
        status: false,
        createdat: new Date(),
      };
      await this.notificationModel.create(Notification);
    }
    await this.fcmService.sendNotification(devicetokens, payload);
    return await this.fixtureModel.findOneAndUpdate(
      { fixtureAPIId },
      { lineupsOut: true },
    );
  }

  async updateFootballFixtureLineup(fixtureAPIId: number) {
    try {
      //Update match squads todo

      const fixture = await this.footballFixturesModel.findOne({
        fixtureAPIId,
      });
      fixture.lineupsOut = true;
      await fixture.save();
      const jointUsers = fixture.joinedUsers;
      const joinUserObjs = await this.userModel
        .find({
          _id: { $in: jointUsers },
        })
        .lean();
      const devicetokens = [];

      const payload = {
        notification: {
          title: 'Lineups Out!!!',
          body:
            fixture.fixtureTeams.teamA.name +
            'vs' +
            fixture.fixtureTeams.teamB.name +
            ' check it out',
        },
      };

      for (const userObj of joinUserObjs) {
        const Notification = {
          pn_title: payload.notification.title,
          pn_message: payload.notification.body,
          fixture_id: fixtureAPIId,
          pn_receivers: userObj._id,
          pn_sendTime: new Date(),
          pn_status: 0,
          status: false,
          createdat: new Date(),
        };
        await this.notificationModel.create(Notification);
        if (userObj.deviceToken) devicetokens.push(userObj.deviceToken);
      }
      await this.fcmService.sendNotification(devicetokens, payload);

      return { status: true };
    } catch (err) {
      console.log(err);
      return { status: false };
    }
  }

  async updateKabaddiFixtureLineup(fixtureAPIId: number) {
    try {
      //Update match squads todo

      const fixture = await this.kabaddiFixturesModel.findOne({
        fixtureAPIId,
      });
      fixture.lineupsOut = true;
      await fixture.save();
      const jointUsers = fixture.joinedUsers;
      const joinUserObjs = await this.userModel
        .find({
          _id: { $in: jointUsers },
        })
        .lean();
      const devicetokens = [];

      const payload = {
        notification: {
          title: 'Lineups Out!!!',
          body:
            fixture.fixtureTeams.teamA.name +
            'vs' +
            fixture.fixtureTeams.teamB.name +
            ' check it out',
        },
      };

      for (const userObj of joinUserObjs) {
        const Notification = {
          pn_title: payload.notification.title,
          pn_message: payload.notification.body,
          fixture_id: fixtureAPIId,
          pn_receivers: userObj._id,
          pn_sendTime: new Date(),
          pn_status: 0,
          status: false,
          createdat: new Date(),
        };
        await this.notificationModel.create(Notification);
        if (userObj.deviceToken) devicetokens.push(userObj.deviceToken);
      }
      await this.fcmService.sendNotification(devicetokens, payload);

      return { status: true };
    } catch (err) {
      console.log(err);
      return { status: false };
    }
  }

  async getUpComingLineUpFixtures(gameType = 'cricket') {
    try {
      if (gameType == 'cricket')
        return await this.fixtureModel.find({
          enabledStatus: true,
          fixtureStatus: 'Upcoming',
        });
      else if (gameType == 'football')
        return this.footballFixturesModel.find({
          lineupsOut: true,
          enabledStatus: true,
          fixtureStatus: 'upcoming',
        });
      else
        return this.kabaddiFixturesModel.find({
          lineupsOut: true,
          enabledStatus: true,
          fixtureStatus: 'upcoming',
        });
    } catch (err) {
      return [];
    }
  }

  async fixtureLiveChange(fixtureAPIId: number, gameType = 'cricket') {
    await this.pointService.updateJoinedPlayerStats(fixtureAPIId, gameType);

    if (gameType == 'cricket')
      return await this.fixtureModel.findOneAndUpdate(
        { fixtureAPIId },
        { fixtureStatus: 'Live' },
      );
    else if (gameType == 'football')
      return await this.footballFixturesModel.findOneAndUpdate(
        { fixtureAPIId },
        { fixtureStatus: 'live' },
      );
    else
      return await this.kabaddiFixturesModel.findOneAndUpdate(
        { fixtureAPIId },
        { fixtureStatus: 'live' },
      );
  }

  //Get all upcoming Fixtures
  async getAllUpcomingFixtures() {
    try {
      const currentDate = new Date();
      const futureDate = new Date();
      futureDate.setFullYear(currentDate.getFullYear());
      futureDate.setMonth(currentDate.getMonth());
      futureDate.setDate(currentDate.getDate());
      futureDate.setHours(currentDate.getHours() + 1); //Added One hour to current time for get upcoming matches from our database
      const live_gonnabe = await this.fixtureModel.find({
        $and: [
          {
            fixtureStartDate: { $gte: currentDate },
          },
          {
            fixtureStartDate: {
              $lte: futureDate,
            },
          },
          {
            fixtureStatus: 'Upcoming',
            enabledStatus: true,
          },
        ],
      });

      if (live_gonnabe.length > 0) {
        for (const key in live_gonnabe) {
          const fixture_between = [
            //Get teams ids and prepare array for get squads
            live_gonnabe[key].fixtureTeams.teamA.teamAPIId,
            live_gonnabe[key].fixtureTeams.teamB.teamAPIId,
          ];

          const match_id = live_gonnabe[key].fixtureAPIId;

          const squads = await this.getSquads(fixture_between); //Call Squads Function

          if (squads.length < 2) continue;

          const req = await fetch(
            `${SPORTS_DATA.URL}/fixture/getfixture?match_id=${match_id}&token=A12345BCDefg1985`,
          );
          const { data } = await req.json();
          const matchStatus = data.fixtureMatch.status;
          if (matchStatus == 4) {
            return 'match Cancellecd';
          } else if (matchStatus == 1) {
            //Upcoming
          } else if (matchStatus == 2) {
            //completed
            const updateMatch = await this.matchStausUpdate(
              match_id,
              'Completed',
            );
            // if (updateMatch)
            //   await this.pointService.winningDeclaration(match_id, 2);
          } else if (matchStatus == 3) {
            //live
            await this.matchStausUpdate(match_id, 'Live');
          }
        }
      } else {
        return 'No Live Match Yet';
      }
    } catch (error) {
      return { error };
    }
    return `This action returns all lineupCron`;
  }

  //get all live matches
  async getAllLiveMatches() {
    const getLiveMatches = await this.fixtureModel.find({
      fixtureStatus: 'Live',
      enabledStatus: true,
    });
    return getLiveMatches;
  }

  async getSquads(fixture_between) {
    const squads = await this.teamPlayerModel.find({
      teamAPIId: { $in: fixture_between },
    });
    return squads;
  }

  async matchStausUpdate(match_id: number, match_status: string) {
    try {
      return await this.fixtureModel.findOneAndUpdate(
        { fixtureAPIId: match_id },
        {
          $set: { fixtureStatus: match_status },
        },
      );
    } catch (err) {
      console.log(err);
      return false;
    }
  }

  async updateFootballCurrentDay() {
    try {
      const startDate = new Date();
      const endDate = new Date();
      startDate.setHours(0, 0, 0, 0);
      endDate.setHours(0, 0, 0, 0);
      endDate.setDate(endDate.getDate() + 1);

      const todaysFixtures = (
        await this.footballFixturesModel
          .find({
            $and: [
              { fixtureStartDate: { $gte: startDate } },
              { fixtureStartDate: { $lte: endDate } },
            ],
          })
          .lean()
      ).map((e) => e.fixtureAPIId);

      await this.updateFootballFixtures(todaysFixtures);

      return { status: true };
    } catch (err) {
      return { status: false };
    }
  }

  async updateFootballFixtures(fixtureAPIIds: number[]) {
    try {
      const fixtures = await this.footballFixturesModel
        .find({ fixtureAPIId: { $in: fixtureAPIIds } })
        .select(['seriesAPIId', 'fixtureAPIId'])
        .lean();
      fixtures.forEach(async (fixture) => {
        const req = await fetch(
          `${SPORTS_DATA.FOOTBALL}/fixture/${fixture.seriesAPIId}?match_id=${fixture.fixtureAPIId}&token=ORTJXUNJXPb8Sk8`,
        );
        const { data } = await req.json();
        const fixtureUpdate = this.cronHelpers.footballFixtures(data);
        await this.footballFixturesModel.updateOne(
          { fixtureAPIId: fixture.fixtureAPIId },
          fixtureUpdate,
        );
      });

      return { status: true };
    } catch (err) {
      return { status: false };
    }
  }

  async updateFootballTeams(fixtureAPIIds: number[]) {
    fixtureAPIIds.forEach(async (fixtureAPIId) => {
      //TODO
    });
  }

  async upComingFixturesDelayUpdate() {
    const currentDate = new Date();
    const futureDate = new Date();
    futureDate.setFullYear(currentDate.getFullYear());
    futureDate.setMonth(currentDate.getMonth());
    futureDate.setDate(currentDate.getDate());
    futureDate.setHours(currentDate.getHours());
    futureDate.setMinutes(currentDate.getMinutes() + 15);

    return await this.fixtureModel.find({
      $and: [
        {
          fixtureStartDate: { $gte: currentDate },
        },
        {
          fixtureStartDate: {
            $lte: futureDate,
          },
        },
        {
          fixtureStatus: 'Upcoming',
          enabledStatus: true,
        },
      ],
    });
  }
}

@Injectable()
export class Cron {
  constructor(private schedulerRegistry: SchedulerRegistry) {}

  seriesCron(cron: boolean) {
    const seriesCronJob = this.schedulerRegistry.getCronJob('series');
    if (cron) {
      seriesCronJob.start();
      return successResponse('cronstart');
    }
    seriesCronJob.stop();
    return successResponse('cronstop');
  }

  teamPlayersCron(cron: boolean) {
    const seriesCronJob = this.schedulerRegistry.getCronJob('teamplayers');
    if (cron) {
      seriesCronJob.start();
      return successResponse('cronstart');
    }
    seriesCronJob.stop();
    return successResponse('cronstop');
  }

  fixturesCron(cron: boolean) {
    const seriesCronJob = this.schedulerRegistry.getCronJob('cricketFixtures');
    if (cron) {
      seriesCronJob.start();
      return successResponse('cronstart');
    }
    seriesCronJob.stop();
    return successResponse('cronstop');
  }
}
