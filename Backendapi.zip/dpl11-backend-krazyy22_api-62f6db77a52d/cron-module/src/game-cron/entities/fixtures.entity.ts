import { ObjectType, Field } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type fixtureDocument = cricketFixtures & Document;

@ObjectType()
export class Teams {
  @Field()
  id: string;

  @Field()
  teamAPIId: number;

  @Field()
  name: string;

  @Field()
  shortName: string;

  @Field()
  logo: string;
}

@ObjectType()
export class fixtureTeams {
  @Field(() => Teams)
  teamA: Teams;

  @Field(() => Teams)
  teamB: Teams;
}

@ObjectType()
@Schema()
export class cricketFixtures {
  @Field()
  _id: string;

  @Field()
  @Prop()
  fixtureName: string;

  @Field()
  @Prop({ index: true })
  fixtureAPIId: number;

  @Field()
  @Prop()
  fixtureDisplayName: string;

  @Field()
  @Prop()
  fixtureStartDate: Date;

  @Field()
  @Prop()
  fixtureStatus: string;

  @Field()
  @Prop()
  fixtureStatusType: number;
// changed
  @Field()
  @Prop()
  fixtureFormat:number;

  @Field()
  @Prop()
  fixtureVenue: string;

  @Field()
  @Prop()
  fixtureType: string;

  @Field()
  @Prop()
  seriesName: string;

  @Field()
  @Prop()
  seriesShortName: string;

  @Field()
  @Prop()
  seriesAPIId: number;

  @Field(() => fixtureTeams)
  @Prop()
  fixtureTeams: fixtureTeams;

  @Field({ defaultValue: false })
  @Prop({ default: false })
  lineupsOut: boolean;

  @Field({ defaultValue: false })
  @Prop({ default: false })
  enabledStatus: boolean;

  @Field({ defaultValue: true })
  @Prop({ default: true, index: true })
  isactive: boolean;

  @Field()
  @Prop({ type: Object })
  joinedUsers?: any = {};
}

export const FixturesSchema = SchemaFactory.createForClass(cricketFixtures);
