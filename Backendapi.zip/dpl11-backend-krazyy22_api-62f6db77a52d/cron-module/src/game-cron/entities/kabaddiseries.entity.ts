import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type kabaddiSeriesDocument = KabaddiSeries & Document;

@Schema()
export class KabaddiSeries {
  @Prop()
  seriesName: string;

  @Prop({ index: true })
  apiId: number;

  @Prop()
  seriesDisplayName: string;

  @Prop()
  seriesStartDate: Date;

  @Prop()
  seriesCode: number;

  @Prop()
  seriesStatus: string;

  @Prop({ default: false })
  enabledStatus: boolean;

  @Prop({ default: true, index: true })
  isactive: boolean;
}

export const KabaddiSeriesSchema =
  SchemaFactory.createForClass(KabaddiSeries);
