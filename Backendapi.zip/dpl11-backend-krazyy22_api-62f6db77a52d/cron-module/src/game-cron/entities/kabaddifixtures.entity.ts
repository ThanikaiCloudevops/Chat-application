import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type kabaddiFixtureDocument = KabaddiFixtures & Document;

export class KabaddiTeams {
  @Prop()
  teamAPIId: number;

  @Prop()
  name: string;

  @Prop()
  shortName: string;

  @Prop()
  logo: string;
}

export class KabaddiFixtureTeams {
  @Prop()
  teamA: KabaddiTeams;

  @Prop()
  teamB: KabaddiTeams;
}

@Schema()
export class KabaddiFixtures {
  @Prop({ index: true })
  fixtureAPIId: number;

  @Prop()
  fixtureStartDate: Date;

  @Prop()
  fixtureStatus: string;

  @Prop()
  fixtureName: string;

  @Prop()
  fixtureDisplayName: string;

  @Prop()
  fixtureStatusType: number;

  @Prop()
  fixtureVenue: string;

  @Prop()
  seriesName: string;

  @Prop()
  seriesShortName: string;

  @Prop()
  seriesAPIId: number;

  @Prop()
  fixtureTeams: KabaddiFixtureTeams;

  @Prop({ default: false })
  enabledStatus: boolean;

  @Prop({ default: true, index: true })
  isactive: boolean;

  @Prop({ default: [], index: true })
  joinedUsers?: string[];

  @Prop({ default: false })
  lineupsOut: boolean;
}

export const kabaddiFixturesSchema =
  SchemaFactory.createForClass(KabaddiFixtures);
