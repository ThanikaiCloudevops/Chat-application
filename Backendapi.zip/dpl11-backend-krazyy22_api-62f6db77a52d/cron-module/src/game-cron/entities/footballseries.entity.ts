import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type footballSeriesDocument = FootballSeries & Document;

@Schema()
export class FootballSeries {
  @Prop()
  seriesName: string;

  @Prop({ index: true })
  apiId: number;

  @Prop()
  seriesDisplayName: string;

  @Prop()
  seriesStartDate: Date;

  @Prop()
  seriesStatus: string;

  @Prop()
  seriesFormat: string;

  @Prop()
  teams: number[];

  @Prop({ default: false })
  enabledStatus: boolean;

  @Prop({ default: true, index: true })
  isactive: boolean;
}

export const FootballSeriesSchema =
  SchemaFactory.createForClass(FootballSeries);
