import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type teamplayersDocument = TeamPlayers & Document;

@ObjectType()
export class Values {
  @Field()
  Test: string;

  @Field()
  ODI: string;

  @Field()
  T20: string;
}

@ObjectType()
export class Players {
  @Field()
  playerName: string;

  @Field()
  playerAPIId: number;

  @Field()
  player_type: string;

  @Field()
  playerDisplayName: string;

  @Field(() => Values)
  player_value: Values;
}

@ObjectType()
@Schema()
export class TeamPlayers {
  @Field()
  @Prop()
  teamName: string;

  @Field()
  @Prop()
  teamDisplayName: string;

  @Field()
  @Prop({ index: true })
  teamAPIId: number;

  // @Field()
  // @Prop({ index: true })
  // sereisAPIId: number;
@Field()
  @Prop()
  teamformat: number;

  @Field()
  @Prop()
  teamformatstr: string;

  @Field()
  @Prop()
  seriesAPIId: number;
  @Field()
  @Prop()
  teamLogo: string;

  @Field(() => [Players])
  @Prop()
  teamPlayers: Players;
}

export const TeamPlayerSchema = SchemaFactory.createForClass(TeamPlayers);
