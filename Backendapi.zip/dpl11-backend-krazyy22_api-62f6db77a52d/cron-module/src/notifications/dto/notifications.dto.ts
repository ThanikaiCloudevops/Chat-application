export class SendNotificationDto {
    deviceToken: string[];
    message: string;
  }