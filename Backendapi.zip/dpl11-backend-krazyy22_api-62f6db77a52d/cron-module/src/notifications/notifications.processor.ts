import { Process, Processor } from '@nestjs/bull';
import { Job } from 'bull';

@Processor('pushNotification')
export class PushNotificationProcessor {
   
  @Process()
  async handleNotification(job: Job) {
    console.log('processing')
    const { deviceToken, message } = job.data;

    try {
      // Your FCM logic here
      // ...
      // If successful, continue with your logic
    } catch (error) {
      // Handle failed attempts or log the error
      console.error(`Failed to send notification to ${deviceToken}: ${error.message}`);
      throw new Error('Failed to send notification. Retrying...');
    }
  }
}