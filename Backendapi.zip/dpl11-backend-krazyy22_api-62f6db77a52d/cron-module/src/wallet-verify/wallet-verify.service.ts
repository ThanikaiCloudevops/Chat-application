import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Cron, CronExpression } from '@nestjs/schedule';
import { Model } from 'mongoose';
import { userDocument } from 'src/game-cron/entities/user.entity';
import {
  UserTransaction,
  UserTransactionDocument,
} from 'src/points-cron/entities/user-transaction.entity';
import {
  UserWallet,
  UserWalletDocument,
} from 'src/points-cron/entities/user-wallet.entity';

@Injectable()
export class WalletVerifyService {
  constructor(
    @InjectModel('User') private userModel: Model<userDocument>,
    @InjectModel('UserTransaction')
    private UserTransactiontModel: Model<UserTransactionDocument>,
    @InjectModel('UserWallet')
    private UserWalletModel: Model<UserWalletDocument>,
  ) {}

  async transationAudit(startDate?: Date, endDate?: Date, userId?: string) {
    try {
      const failedAudits = [];
      const transationFilterObj = { $and: [] };
      if (userId) transationFilterObj.$and.push({ userId });
      if (startDate)
        transationFilterObj.$and.push({ transanctionTime: { $gte: endDate } });
      if (endDate)
        transationFilterObj.$and.push({ transanctionTime: { $lte: endDate } });

      const userWallets = (
        await this.UserWalletModel.find(userId ? { userId } : {})
      ).reduce((total, value) => {
        total[value.userId] = value;
        return total;
      }, {});
      const userTransations = (
        await this.UserTransactiontModel.find(transationFilterObj)
      ).reduce((total, value) => {
        if (!total[value.userId]) total[value.userId] = [];
        total[value.userId].push(value);
        return total;
      }, {});
      const userIds = Object.keys(userWallets);
      for (const userId of userIds) {
        const res = await this.transactionCheck(
          userWallets[userId].userBalance,
          userTransations[userId][0].previousBalance,
          userTransations[userId],
        );
        if (!res.status) failedAudits.push(res);
      }

      return {
        status: true,
        message: 'Tally Audit completed',
        data: failedAudits,
      };
    } catch (err) {
      return { status: false, message: 'Error in transation audit' };
    }
  }

  async transactionCheck(
    userBalance: number,
    initialAmount: number,
    transactions: UserTransaction[],
  ) {
    try {
      let amount = transactions.reduce((total, value) => {
        if (value.transanctionType == 'Credit') total += value.amount;
        else total -= value.amount;
        return total;
      }, 0);
      if (amount + initialAmount != userBalance)
        return {
          status: false,
          message: 'Transation tally failed',
          userId: transactions[0].userId,
        };
    } catch (err) {
      return { status: false, message: 'Audit error' };
    }
  }
}
