import { Controller, Get } from '@nestjs/common';
import { WalletVerifyService } from './wallet-verify.service';

@Controller('wallet-verify')
export class WalletVerifyController {
  constructor(private readonly walletVerifyService: WalletVerifyService) {}

  @Get()
  checkWalletTransactions() {
    return this.walletVerifyService.transationAudit();
  }
}
