import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { MODULE } from 'config/envirnment';
import * as admin from 'firebase-admin';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors({ allowedHeaders: '*', origin: '*' });

  await app.listen(MODULE.PORT, () =>
    console.log(` ${MODULE.NAME} listening http://localhost:${MODULE.PORT}`),
  );
}
bootstrap();
