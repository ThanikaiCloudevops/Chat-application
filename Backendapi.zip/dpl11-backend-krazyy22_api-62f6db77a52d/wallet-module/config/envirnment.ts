export const MODULE = { NAME: 'Wallet Module', PORT: 5005 };
export const DB = {
  URL: 'mongodb+srv://sciflare:HEO6yUFoS7tmk3w0@krayzz22.vh8chph.mongodb.net/krayzz22',
};

export const TRPC = {
  USERAUTH: 'http://3.7.135.45:5000/trpc/userauth',
  // USERAUTH: 'http://localhost:5000/trpc/userauth',
};

export const MSG91APIKEY = {
  MSG91_AUTH_KEY: '',
  MSG91_TEMPLATE_ID: '',
};

// export const SERVICE_ACCOUNT = {
//   type: 'service_account',
//   project_id: 'krazyy22-development',
//   private_key_id: '0bf94218f12887ab1eae1ff2f02f92da4897ced2',
//   private_key:
//     '-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCIR0bI54aNsmyo\nZPFFxLslmUJsGz7VGbnIaS8jugw/nc+pCo48vBdRkKgeHaOIqtpCar0QKx/3xUo5\nTDUITEC72DTCcYj+orwMbBK6v4avoQmmFuFcIEF+Cfp0T03LrXpEd/xRIza1PsAw\n3+zii7+VqQx6ec6ML2c/67rld7su1L0O3TtkbIEO7xRZD2w/8J1boOeWG8qo71+V\nJVFOsxebdpQ+SlVT3+Sa91EqEti3bauf58k9OdkBM7ggHahcQnPgGVyrkA7ESNvG\nq1lv48uA7GT3yRCNV51L1O5MUgAAAL13E85nOWuRgoAy8guQ01XGDvePnIrja9in\nOjuej7UdAgMBAAECggEAAmWCfKj5qEdBeuqfhZMSmXQrA1ytS7ESn9AduJqeeYXs\nb3QUkUPbgx8wnar2w8IBaZaX8Y9YlhJdnklVS2qP3t3L+7lkZ9nzxaIm6CrTEwaZ\ndVbEqsqUbEN/qIj2fMT1t/uGL+UXIrPSTGm7sDY17ctVwVegBr4Uqj6agEuNOqMT\nh9lz61/DyHxSK7InhRPJLv7qNvHKPCgV737B/yTul0LUHPZoAOTewDDOhK8/LDmt\njX6kt4KuaVspP2ToVNjSWzRGLPNdDtSEB0On42QG4S3grdWxQO1NM6mTxYVcoX1S\nLCPEELVkcwMJ7jHlcHdUM3bXJZ52OUe757+2sirLTwKBgQC/HilbsqmIk4sMdknQ\n5rm5oH8KXZcyXsMo8XZYQtcyK1agu2MTQTE5oDYpWjfSj4giZluDZB5x1YErZ7sC\ncK2duqT3qjf5af6lq9qkQxmT87gPQLdwLWqDprlT4DHVslf5mQ0lHCTTwLceYWsH\nHtYpNhNEHp1CJKVY2auVVenFiwKBgQC2ixVwOcXSxqsTiy6f2cHh5DQkjeye9yMy\nZqrBF6XBogKMKH5sGV/H9BP2R6IxCEbgXu69GG9+tS1cupJ3VA69ClOL8DtQ81F2\nPKYGkuAlvFlZqowb9hIqpUSZn4SkukoagU1c4z7755Ckg+7U1HEymxSN6UERfkHZ\nUs5pcqHU9wKBgQCZVrPMNM69G9QGjamwCE6fVtxXDrxO16Ux5noTWp2aTRdWIsLd\nIgNCvv51s0Lyl+Kb5xApnVyn7KuUjceHr6w8zxGo/FOos5hyiC4GeSe+g178LeqA\nAJBjTJOJbmnNkSfwxRG84pXRp9/Ealka/2zI5/ARSZbXCNv5K7v1N1c2/QKBgF2G\nwUMwtoSZuYlX5FmOTmIYdAbOmI+R+/yU0aQBI7Ij+b4p+SwVjBd8nMWwSg9pODc5\nLITCAk4fMdCy3tw4uxxsMAYg3aNKJ1C3HjF8C1AKQpVIZmTlHMWwy4cSTfnAYLtX\nyHVxERIrwNYpqrJs7lqJTmyvN+FomQBqBsvMKdJdAoGALyhUtHWenn68f1ixkxpQ\n6X8P7QSfXEJaFH/+qy7sBDjjkAsCpmUv7DcETP0gp/ZPnN5ipWs/grGwZVoa72/r\nSg0z3Fc4omrG4wrsnLcQUSSr65AmZIJm4hek+brAwrkl/SHUX1PubRntq/L+gLhc\nG5H3XaFwkcTdpmWx0k6IPB0=\n-----END PRIVATE KEY-----\n',
//   client_email:
//     'firebase-adminsdk-190xk@krazyy22-development.iam.gserviceaccount.com',
//   client_id: '117297776542043186982',
//   auth_uri: 'https://accounts.google.com/o/oauth2/auth',
//   token_uri: 'https://oauth2.googleapis.com/token',
//   auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
//   client_x509_cert_url:
//     'https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-190xk%40krazyy22-development.iam.gserviceaccount.com',
//   universe_domain: 'googleapis.com',
// };

 export const SERVICE_ACCOUNT = {
  type: "service_account",
  project_id: "krazyy22-dev",
  private_key_id: "3d5fa5c1941771e61728cb2b4b8c3d4cefce8fa2",
  private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCyasAly1Jj/fP7\npPh8WbbXLlocoJEJFYaMOGae82CnXVM3FnRGc2Ng9Dx40v02/0/cn+nDPdGHX4n9\nvMVRkT9D1MnPsX08qFcTlkpbTEgGtW6Zb7LGdf92kjZTlxSAuwRZdvFua12vp4iJ\nNdY4NUFDf+ulJSR+wYOqyPQH4IcggIZYPHFDZ76f/1hHZogUKqIi3rs8RPNvP9Fu\n3Cbi3UDCaA5AJq7q0IaQmBho2yjy7VvmTc8q3Mer3b+net2MqFC/CfooKRYG2eeQ\nmJlTYZEemu3i/zIHCTxyTMh7xAPiZh5vqfW+/ZCPZfiHDXIHlMMn9r0io2XpA1Rw\nbuipF9PrAgMBAAECggEAT0wy6plbnSWZ8xZ3eo1FPo5TbrXOwILYsim/MpZpNvm7\nqphIRaezW7wxxGHCOVdwX1aTxzsKjWhhJG1qJb6wp61DpRP13afUS9hYZAubV5/7\n8CY9Bwga6tBBZRWY/z4fyMOcur7tfMyxWoqbE5BX2XBZg6Tme4/2vUljbLzWUhMN\nNhBIvVG2Khs8tPrUO8Q7VcvP63DziESr7yrhkDUrkP/ctOEtGeQQFqcckdm2a6Ni\nxaoId8PT0WJXFUDbQ0tCpXP6BTng+gb5P7WiJBaJzDE0nPL3FxoXrUQXXqA9dMkX\nYRUW5VG88qaYROAaWifYkYwCXgxhtgOTNR91Th7MQQKBgQD65b9UKCWfDYAHrF0u\n8tnv9mNTc/s8jD2h/dCKnt6S821wOnVANajQZ7pOoowNsTnO8pZC+43AaWdnUKb0\nJE6W8VR2wJNFtcdGu6/OFYanTm2jDyhyTNCwmsoLO4pchuswzbmRRfcSj6MPbGRq\nV43gfzqA+K5DrB7/9AZZ92bc7QKBgQC2C6WNe8XatHHlYWLXs3yB2kv3Sti8FDlX\njhgMhisC+G6URxmvb7+ihOjeb/ulTJVmw6cchCKzi2Prbpfctxxu6rBioSKXQrra\nJWyuDDXF3FBwvbHe7VN8YRMvsTemMC6I29Xiup6NtcOEh6NXeFJf8J9flQ0cl4u6\nbgqr9ukxNwKBgBeXFoBBLhhgWpNeH3zUlK09S2WDWDH/NaRPixYdjevfO4D73h5l\nbTP7LMdL/UMkUL0mjf5KTK+0uWY7bRczergyhLCNtsstJkl+SC9mUrzUYPad7D2i\n/1Q7mZeox3+fp+l0zmfcXji+jKRcmqxtAwgCrmuF9kyimF+UgCxhWKiZAoGAYNRj\nE5VxUPpH1rVtKMRshnlBjOC/1ZKASaTn/8lhmWvhDXegHuO2r9A4ORChbnQEx6tr\n+MwD1TJgTHr/xcOUGR82ANAqoQA6eQwM+aq+82ZTVxRfRu8/R9oupWCC9B+OsPcV\nlkqjSUcUHysyY7U5Q5SugN28IqgtB1W+0Wc89BMCgYATzWqulER9XPavT2G2b09E\n9c9hLne8QoIdn7yp8IPjiQsqfb+TMvM5hD8mE6buw5XMbB1lcyY4dm8PwOQjXKDH\nwQM4nh9f+UJ1ySvpsoGRpLFAXxpGYAr6eqiBFpvWt7ONVSSRHYmVnhoLWTVxEeuu\nMAeKtAuykCjI2MPtwROujg==\n-----END PRIVATE KEY-----\n",
  client_email: "firebase-adminsdk-e8zvi@krazyy22-dev.iam.gserviceaccount.com",
  client_id: "105865361180411963493",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-e8zvi%40krazyy22-dev.iam.gserviceaccount.com",
  universe_domain: "googleapis.com"
}
export const CASH_FREE = {
  bank: 'https://sandbox.cashfree.com/verification/bank-account/sync',
  clientId: 'CF10217085CPR9D5JHKINF28KR7UT0',
  clinetSecret: 'cfsk_ma_test_8b5b0e50e50620168997a97ca0b0adf5_dbf62e19',
  cashfree_api_version:'2023-08-01'
};
