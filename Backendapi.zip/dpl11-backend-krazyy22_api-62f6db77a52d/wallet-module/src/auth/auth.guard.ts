import {
  CanActivate,
  ExecutionContext,
  HttpException,
  HttpStatus,
  Injectable,
} from '@nestjs/common';
import { GqlExecutionContext } from '@nestjs/graphql';
import { Observable } from 'rxjs';
import { userAuth } from 'src/trpc/client/trpc';

const serverSecretToken =
    '$2a$15$rshdP7mf42gtBt/ReZZ09uZUQ1aYK2Xc0P3rSKKTvegEp0P2iavQG',
  serverClientId = 'sci-game-sg24vds2fsbvd35vxz';

@Injectable()
export class AuthGuard implements CanActivate {
  async canActivate(context: ExecutionContext): Promise<boolean> {
    try {
      const ctx = GqlExecutionContext.create(context).getContext();
      const token = ctx.req.headers?.authorization.split(' ')[1];
      const verify = await userAuth['verify'].query({ token });

      // const req = context.switchToHttp().getRequest();
      // req.user = verify;
      ctx.user = verify;
      return verify;
    } catch (error) {
      throw new HttpException('UnAuthendicated', HttpStatus.UNAUTHORIZED);
    }
  }
}

@Injectable()
export class HeaderGuard implements CanActivate {
  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    try {
      const ctx = GqlExecutionContext.create(context).getContext();
      const headers = ctx.req.headers;
      const { secretToken, clientId, deviceType } = headers;
      if (deviceType != 'Android' || deviceType != 'IOS') throw new Error();
      if (secretToken != serverSecretToken) throw new Error();
      if (clientId != serverClientId) throw new Error();

      return true;
    } catch (err) {
      throw new HttpException('UnAuthendicated', HttpStatus.UNAUTHORIZED);
    }
  }
}
