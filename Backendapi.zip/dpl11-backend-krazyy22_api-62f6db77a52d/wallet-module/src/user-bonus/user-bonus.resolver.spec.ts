import { Test, TestingModule } from '@nestjs/testing';
import { UserBonusResolver } from './user-bonus.resolver';
import { UserBonusService } from './user-bonus.service';

describe('UserBonusResolver', () => {
  let resolver: UserBonusResolver;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [UserBonusResolver, UserBonusService],
    }).compile();

    resolver = module.get<UserBonusResolver>(UserBonusResolver);
  });

  it('should be defined', () => {
    expect(resolver).toBeDefined();
  });
});
