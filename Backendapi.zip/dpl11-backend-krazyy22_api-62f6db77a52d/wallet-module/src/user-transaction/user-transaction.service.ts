import { Injectable } from '@nestjs/common';
import {
  CreateUserTransactionInput,
  addMoneyInput,
} from './dto/create-user-transaction.input';
import { successResponse } from 'src/commonResponse/success';
import { commonErrors } from 'src/commonResponse/errors';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import {
  UserTransaction,
  UserTransactionDocument,
} from './entities/user-transaction.entity';
import { UserWalletService } from 'src/user-wallet/user-wallet.service';
import {
  GameTransactionInput,
  filterTransactionInput,
} from './dto/transaction.filter.input';
import {
  BonusMaster,
  BonusMasterDocument,
} from './entities/bonus-master.entity';
import { User, userDocument } from './entities/user.entity';
import { trpcServices } from 'src/trpc/client/trpc';
import { NotificationService } from './notification.service';
import * as BetterQueue from 'better-queue';
import { Msg91SmsService } from './send-sms/sms.service';
import {
  Notification,
  notificationDocument,
} from './entities/notifications.entity';
import { Cron, CronExpression } from '@nestjs/schedule';
import { Cashfree } from 'cashfree-pg';
import { CASH_FREE } from 'config/envirnment';

import axios from 'axios';
const options = { upsert: true, new: true, setDefaultsOnInsert: true };

@Injectable()
export class UserTransactionService {
  private gigadatQueue: BetterQueue;
  constructor(
    @InjectModel('BonusMaster')
    private BonusMasterModel: Model<BonusMasterDocument>,
    @InjectModel('UserTransaction')
    private UserTransactiontModel: Model<UserTransactionDocument>,
    @InjectModel('User')
    private UserModel: Model<userDocument>,
    @InjectModel('Notification')
    private notificationModel: Model<notificationDocument>,
    private userWalletService: UserWalletService,
    private trpcservice: trpcServices,
    private notificationService: NotificationService,
    private readonly smsService: Msg91SmsService,
  ) {
    this.gigadatQueue = new (BetterQueue as any)(
      async (input, cb) => {
        try {
          const transactionId = input.transactionId;
          const paymentMethod = input.paymentMethod;
          await this.checkout(transactionId);
          cb(null, 'Job completed');
        } catch (error) {
          console.error('Error sending notification:', error);
          cb(error);
        }
      },
      {
        store: {
          type: 'memory',
        },
        maxRetries: 2,
        retryDelay: 1000,
        concurrent: 1,
      },
    );
  }

  async enterTransaction(
    createUserTransactionInput: CreateUserTransactionInput,
  ) {
    const walletCheck = await this.userWalletService.getUserWallet(
      createUserTransactionInput.userId,
    );
    if (!walletCheck) return commonErrors('notFound');
    let bal = 0;
    if (createUserTransactionInput.transanctionRelatedType != 'EntryFee') {
      const totalBalance =
        walletCheck.unutilisedBalance + walletCheck.totalWinnings;
      const transactionObj: UserTransaction = {
        userId: createUserTransactionInput.userId,
        transanctionType: createUserTransactionInput.transanctionType,
        amount: createUserTransactionInput.amount,
        walletId: walletCheck._id,
        previousBalance: walletCheck.userBalance,
        afterBalance: totalBalance,
        transanctionRelatedType:
          createUserTransactionInput.transanctionRelatedType,
        transanctionTime: new Date(),
        transactionStatus: createUserTransactionInput.transactionStatus
          ? createUserTransactionInput.transactionStatus
          : 'Success',
        referId: createUserTransactionInput.referId
          ? createUserTransactionInput.referId
          : '',
        fixtureName: createUserTransactionInput.fixtureName
          ? createUserTransactionInput.fixtureName
          : '',
        contestName: createUserTransactionInput.contestName
          ? createUserTransactionInput.contestName
          : '',
      };
      await this.UserTransactiontModel.create(transactionObj);
      await this.userWalletService.updateWallet(
        walletCheck,
        transactionObj.amount,
        transactionObj.transanctionType == 'Credit',
        'Bonus',
        bal,
      );
    } else {
      var remBalance: number;
      if (walletCheck.totalBonus > 0) {
        bal = +((5 / 100) * createUserTransactionInput.amount).toFixed(2);
        if (bal >= walletCheck.totalBonus) {
          remBalance =
            createUserTransactionInput.amount - walletCheck.totalBonus;
          bal = walletCheck.totalBonus;
        } else remBalance = createUserTransactionInput.amount - bal;
      } else {
        remBalance = createUserTransactionInput.amount;
      }
      const totalBalance =
        walletCheck.unutilisedBalance + walletCheck.totalWinnings;
      // walletCheck.totalBonus;
      const transactionObj: UserTransaction = {
        userId: createUserTransactionInput.userId,
        transanctionType: createUserTransactionInput.transanctionType,
        amount: remBalance,
        walletId: walletCheck._id,
        previousBalance: walletCheck.userBalance,
        afterBalance:
          createUserTransactionInput.transanctionType == 'Debit'
            ? totalBalance - remBalance
            : totalBalance + createUserTransactionInput.amount,
        transanctionRelatedType:
          createUserTransactionInput.transanctionRelatedType,
        fixtureId: createUserTransactionInput.fixtureId,
        contestId: createUserTransactionInput.contestId,
        transanctionTime: new Date(),
        transactionStatus: 'Success',
        bonusUsed: bal,
        referId: createUserTransactionInput.referId
          ? createUserTransactionInput.referId
          : '',
        fixtureName: createUserTransactionInput.fixtureName
          ? createUserTransactionInput.fixtureName
          : '',
        contestName: createUserTransactionInput.contestName
          ? createUserTransactionInput.contestName
          : '',
      };

      if (transactionObj.afterBalance < 0) return commonErrors('balance');
      await this.UserTransactiontModel.create(transactionObj);
      await this.userWalletService.updateWallet(
        walletCheck,
        transactionObj.amount,
        transactionObj.transanctionType == 'Credit',
        transactionObj.transanctionRelatedType,
        bal,
      );
      return successResponse('transaction', {
        amount: transactionObj.afterBalance,
      });
    }
  }

  async getUserTransactions(userId: string) {
    const userTransactions = await this.UserTransactiontModel.find({ userId });
    return successResponse('found', userTransactions);
  }

  async getTransactions(userId: any) {
    let array: any = {};
    for (const key in userId) {
      if (key == 'ref_from') {
        const userTransactions = await this.UserTransactiontModel.find({
          userId: userId.ref_from, //user
          transanctionRelatedType: 'Referral Bonus From',
          transactionStatus: 'Success',
        }).select(['userId', 'amount']);
        const amount = userTransactions.map((e) => e.amount);
        const sum = amount.reduce(
          (accumulator, currentValue) => accumulator + currentValue,
          0,
        );
        const user = await this.UserModel.findOne({ _id: userId.ref_from });
        array['userName'] = user.userName;
        array['amount'] = sum;
      } else {
        let arr: any = [];
        const userTransaction: any = await this.UserTransactiontModel.find({
          //userId: { $in: userId.ref_to },
          // transanctionRelatedType: 'Referral Bonus To',
          referId: { $in: userId.ref_to },
        })
          .select(['userId', 'amount', 'referId'])
          .lean();

        for (const id in userTransaction) {
          let newarray: any = {};
          const user = await this.UserModel.findOne({
            _id: userTransaction[id].referId,
          });
          const userName = user.userName;
          newarray['userName'] = userName;
          newarray['amount'] = userTransaction[id].amount;
          arr.push(newarray);
        }
        array['referrals'] = arr;
      }
    }
    return array;
  }

  async filterUserTransactions(
    userId: string,
    filterInput: filterTransactionInput,
  ) {
    const queryObj: any = { userId };

    if (filterInput.transactionStatus.length > 0)
      queryObj.transactionStatus = { $in: filterInput.transactionStatus };

    if (filterInput.transanctionType) {
      if (filterInput.transanctionType == 'Winnings')
        queryObj['$or'] = [
          { transanctionRelatedType: 'Winnings' },
          { transanctionRelatedType: 'EntryFee' },
          { transanctionRelatedType: 'Refund' },
        ];
      else if (filterInput.transanctionType == 'Bonus')
        queryObj['$or'] = [
          { transanctionRelatedType: 'Signup Bonus' },
          { transanctionRelatedType: 'Cash Bonus' },
          {
            transanctionRelatedType: 'Referral Bonus From',
            transactionStatus: { $ne: 'Pending' },
          },
          {
            transanctionRelatedType: 'Referral Bonus To',
            amount: { $ne: 0 },
            transactionStatus: { $ne: 'Pending' },
          },
          { transanctionRelatedType: 'Admin' },
        ];
      else queryObj.transanctionRelatedType = filterInput.transanctionType;
    }

    const userTransactions = await this.UserTransactiontModel.find(queryObj)
      .sort('-transanctionTime')
      .skip((filterInput.page - 1) * 20)
      .limit(20);

    return successResponse('found', {
      data: userTransactions,
      page: filterInput.page,
    });
  }

  async withdrawbalance(
    user: any,
    amount: number,
    userIp: string,
    paymentType: number,
  ) {
    try {
      const walletCheck = await this.userWalletService.getUserWallet(user._id);
      if (!walletCheck) return commonErrors('notFound');
      if (!user.kycStatus) return commonErrors('kyc');
      if (!user.panStatus) return commonErrors('pan');

      if (amount > walletCheck.totalWinnings) return commonErrors('balance');

      const transactionObj: UserTransaction = {
        userId: user._id,
        transanctionType: 'Debit',
        amount: amount,
        walletId: walletCheck._id,
        previousBalance: walletCheck.userBalance,
        afterBalance: walletCheck.userBalance - amount,
        transanctionRelatedType: 'Withdrawal',
        transanctionTime: new Date(),
        transactionStatus: 'Pending',
      };
      const transaction = await this.UserTransactiontModel.create(
        transactionObj,
      );

      walletCheck.totalWinnings = walletCheck.totalWinnings - amount;
      walletCheck.userBalance = walletCheck.userBalance - amount;
      await walletCheck.save();
      return successResponse('withdraw');
    } catch (err) {
      console.log(err);
      return commonErrors('withdraw');
    }
  }

  async addMoney(user: any, addmoneyInput: addMoneyInput) {
    try {
      Cashfree.XClientId = '706614fe550e843c6f4399cee7416607';
      Cashfree.XClientSecret =
        'cfsk_ma_prod_5946ec40e47bc04e3d7a40305c40c538_225f9248';
      Cashfree.XEnvironment = Cashfree.Environment.PRODUCTION;

      const walletCheck = await this.userWalletService.getUserWallet(user._id);
      const user_details = await this.UserModel.findOne({
        _id: user._id,
      });

      let request = {
        order_amount: addmoneyInput.amount,
        order_currency: 'INR',
        customer_details: {
          customer_id: `customer_${new Date().getTime()}`,
          customer_name: user_details.userName,
          customer_email: user_details.email || '',
          customer_phone: user_details.phone,
        },
        order_meta: {
          return_url:
            'https://test.cashfree.com/pgappsdemos/return.php?order_id=order_123',
        },
        order_note: 'Payment gateway',
      };
      let orders = {
        order_id: '',
        session_id: '',
      };
      await Cashfree.PGCreateOrder(CASH_FREE.cashfree_api_version, request)
        .then((response) => {
          console.log('now');
          let data = response.data;
          orders.order_id = data?.order_id;
          orders.session_id = data?.payment_session_id;
          console.log(data);
        })
        .catch((err) => console.log(err));

      // Cashfree.PGOrderFetchPayments(CASH_FREE.cashfree_api_version, orders).then((response) => {
      //   console.log('Order fetched successfully:', response);
      // }).catch((error) => {
      //   console.error('Erorr:', error.response);
      // });

      const transactionObj: UserTransaction = {
        userId: user._id,
        walletId: walletCheck._id.toString(),
        amount: addmoneyInput.amount,
        transanctionTime: new Date(),
        transanctionType: 'Credit',
        transanctionRelatedType: 'Credit',
        transactionStatus: 'Success',
        previousBalance: walletCheck.userBalance,
        afterBalance: walletCheck.userBalance + addmoneyInput.amount,
      };

      const userTransaction = new this.UserTransactiontModel(transactionObj);
      walletCheck.userBalance += addmoneyInput.amount;
      walletCheck.unutilisedBalance += addmoneyInput.amount;

      await walletCheck.save();
      await userTransaction.save();
      return successResponse('add', {
        order_id: orders.order_id,
        session_id: orders.session_id,
        transactionId: userTransaction._id.toString(),
        kycVerified: user.kycStatus,
      });
    } catch (err) {
      return commonErrors('addcash');
    }
  }

  async webhook(data: string) {
    return data;
  }

  // async checkout(transactionId : string) {
  //   try {
  //     let findTransaction = await this.UserTransactiontModel.findOne(
  //       {orderId:transactionId}
  //     );
  //     if(!findTransaction||findTransaction.transactionStatus === "Success") return commonErrors('transactionStatus');
  //     let walletCheck = await this.userWalletService.getUserWallet(
  //       findTransaction.userId
  //     );
  //     Cashfree.XClientId = 'TEST10217085736283d97459f969a1fd58071201';
  //     Cashfree.XClientSecret = 'cfsk_ma_test_36bd4db5db0f9365fe08a423397792d5_45c5c942';
  //     Cashfree.XEnvironment = Cashfree.Environment.SANDBOX;
  //  const getorder = await  Cashfree.PGOrderFetchPayments(CASH_FREE.cashfree_api_version, transactionId)
  //  if (getorder.data[0].payment_status === "SUCCESS") {
  //   findTransaction.transactionStatus = 'Success'
  //   let userTransaction = new this.UserTransactiontModel(findTransaction);
  //   walletCheck.userBalance += findTransaction.amount;
  //   walletCheck.unutilisedBalance += findTransaction.amount;

  //   await walletCheck.save();
  //   await userTransaction.save();

  //  }else{
  //   findTransaction.transactionStatus = 'Failed'
  //   let userTransaction = new this.UserTransactiontModel(findTransaction);
  //   await userTransaction.save();

  //  }

  //   } catch (error) {
  //     console.log(error);
  //   }
  // }

  async checkout(transactionId: string) {
    try {
      console.log(transactionId);

      // Fetch the transaction details from your database
      let findTransaction = await this.UserTransactiontModel.findOne({
        orderId: transactionId,
      });

      // Check if the transaction exists or if it has already been processed
      if (!findTransaction || findTransaction.transactionStatus === 'Success') {
        return commonErrors('transactionStatus');
      }

      // Fetch the user’s wallet
      let walletCheck = await this.userWalletService.getUserWallet(
        findTransaction.userId,
      );

      // Set up Cashfree credentials
      const clientId = 'TEST10217085736283d97459f969a1fd58071201';
      const clientSecret =
        'cfsk_ma_test_36bd4db5db0f9365fe08a423397792d5_45c5c942';
      const apiVersion = '2023-08-01'; // Cashfree API version
      const linkId = transactionId; // Assuming transactionId is the payment link ID

      // Make a GET request to fetch payment link details
      const getPaymentLinkDetails = await axios.get(
        `https://sandbox.cashfree.com/pg/links/${transactionId}`,
        {
          headers: {
            'x-api-version': apiVersion,
            'x-client-id': clientId,
            'x-client-secret': clientSecret,
            accept: 'application/json',
          },
        },
      );

      // Check the response from the Cashfree API
      const paymentData = getPaymentLinkDetails.data;
      console.log(paymentData);

      if (paymentData && paymentData.link_status === 'PAID') {
        // Update transaction status to 'Success'
        findTransaction.transactionStatus = 'Success';

        // Update user's wallet balance
        walletCheck.userBalance += findTransaction.amount;
        walletCheck.unutilisedBalance += findTransaction.amount;

        // Save updated wallet and transaction records
        await walletCheck.save();
        await findTransaction.save();
      } else {
        // Handle failed payment, update the transaction status to 'Failed'
        findTransaction.transactionStatus = 'Failed';
        await findTransaction.save();
      }
    } catch (error) {
      console.error(error);
    }
  }

  async gigadatQueueTransactions(transactionId: string, paymentMethod: number) {
    try {
      const input = {
        transactionId: transactionId,
        paymentMethod: paymentMethod,
      };
      await this.gigadatQueue.push(input);
    } catch (err) {
      console.log(err);
      return commonErrors('gigadatQueue');
    }
  }

  // async checkout(  transactionId : string) {
  //   try {

  //   } catch (error) {

  //   }
  // }

  async updateBonus(userId: any) {
    try {
      var bonustyp = await this.BonusMasterModel.findOne({
        bonusType: 'referal',
        isactive: true,
      });

      for (const key in userId) {
        if (key == 'refFrom' && bonustyp.refFrom > 0) {
          await this.enterTransaction({
            userId: userId['refFrom'],
            transanctionType: 'Credit',
            amount: bonustyp.refFrom,
            transanctionRelatedType: 'Referral Bonus From',
            transactionStatus: 'Success',
            referId: userId['userId'],
          });
        } else if (key == 'refTo' /* && bonustyp.refTo > 0 */) {
          await this.enterTransaction({
            userId: userId['refTo'],
            transanctionType: 'Credit',
            amount: bonustyp.refTo,
            transanctionRelatedType: 'Referral Bonus To',
            transactionStatus: 'Success',
          });
        }
      }
      return true;
    } catch (error) {
      return false;
    }
  }

  async bonusConfirmation(user: any, team: number, entryfee: number) {
    try {
      const EntryFee = entryfee * team;
      const walletCheck = await this.userWalletService.getUserWallet(user._id);
      const bonus = +((5 / 100) * EntryFee).toFixed(2);
      let newbonus: number = 0;
      if (walletCheck.totalBonus > 0) {
        if (walletCheck.totalBonus < bonus) {
          newbonus = walletCheck.totalBonus;
        } else {
          newbonus = bonus;
        }
      }
      const remBalance = EntryFee - newbonus;
      const data: any = {};
      data.entryfeeAfterBonus = remBalance;
      data.bonus = newbonus;
      data.entryfee = EntryFee;
      return successResponse('bonus', data);
    } catch (error) {}
  }

  async notification() {
    const notificationObj = {
      notification: {
        title: 'payment added',
        body: `100₹ has been credited to your wallet `,
      },
      token:
        'ev2crVyWSfmuVHlwI0qzdr:APA91bEdwadsCnjBAL4TwXpLcy_vibWAUVmNjTzHMzNanRDGGYbiL2tu5Ru4iiRmyzhLndQYL-d_k5VW2pQWRNTcHYjMaxeChq6WVTzyOQ49ucS8DJXV5vX8jCqeaC7v_uSTr59wxP43',
    };
    await this.notificationService.sendNotification(notificationObj);
    return successResponse('getWallet');
  }

  async joinGame(gameInput: GameTransactionInput, userId: string) {
    try {
      const { amount, gameId, gameName } = gameInput;
      const userWallet = await this.userWalletService.getUserWallet(userId);
      if (userWallet.userBalance < amount) return commonErrors('balance');

      const transactionObj: UserTransaction = {
        userId,
        previousBalance: userWallet.userBalance,
        afterBalance: userWallet.userBalance - amount,
        amount,
        transactionStatus: 'Success',
        transanctionRelatedType: 'GameFee',
        transanctionTime: new Date(),
        transanctionType: 'Debit',
        walletId: userWallet._id,
        contestId: gameId,
        contestName: gameName,
      };
      userWallet.userBalance = userWallet.userBalance - amount;
      userWallet.unutilisedBalance = userWallet.unutilisedBalance - amount;
      if (userWallet.unutilisedBalance < 0) {
        userWallet.totalWinnings =
          userWallet.totalWinnings + userWallet.unutilisedBalance;
        userWallet.unutilisedBalance = 0;
      }
      await userWallet.save();
      await this.UserTransactiontModel.create(transactionObj);

      return successResponse('transaction');
    } catch (err) {
      return commonErrors('game');
    }
  }

  async winGame(gameInput: GameTransactionInput, userId: string) {
    try {
      const { amount, gameId, gameName } = gameInput;
      const userWallet = await this.userWalletService.getUserWallet(userId);

      const transactionObj: UserTransaction = {
        userId,
        previousBalance: userWallet.userBalance,
        afterBalance: userWallet.userBalance + amount,
        amount,
        transactionStatus: 'Success',
        transanctionRelatedType: 'GameFee',
        transanctionTime: new Date(),
        transanctionType: 'Debit',
        walletId: userWallet._id,
        contestId: gameId,
        contestName: gameName,
      };
      userWallet.userBalance = userWallet.userBalance + amount;
      userWallet.totalWinnings = userWallet.totalWinnings + amount;

      await userWallet.save();
      await this.UserTransactiontModel.create(transactionObj);

      return successResponse('transaction');
    } catch (err) {
      return commonErrors('win');
    }
  }
}
