import { Injectable } from '@nestjs/common';
// import { GIGADAT } from 'config/envirnment';

import { Cashfree } from 'cashfree-pg';
import { CASH_FREE } from 'config/envirnment';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import {
  UserTransaction,
  UserTransactionDocument,
} from '../entities/user-transaction.entity';
import { UserWalletService } from 'src/user-wallet/user-wallet.service';
import { gidadatDocument } from '../entities/gidadat-reciver';
import { successResponse } from 'src/commonResponse/success';
import { commonErrors } from 'src/commonResponse/errors';
import { addMoneyInput } from '../dto/create-user-transaction.input';
import { userDocument } from '../entities/user.entity';
import axios from 'axios';

const GIDADAT_STATUS = {
  SUCCESS: ['STATUS_SUCCESS'],
  FAILURE: [
    'STATUS_FAILED',
    'STATUS_ABORTED',
    'STATUS_ABORTED1',
    'STATUS_EXPIRED',
    'STATUS_REJECTED',
  ],
  INPROGRESS: [
    'STATUS_INITED',
    'STATUS_AWAITING_CONFIRMATION',
    'STATUS_PENDING',
  ],
  REFUND: ['STATUS_REFUNDED'],
};

@Injectable()
export class GigadatService {
  constructor(
    @InjectModel('UserTransaction')
    private UserTransactiontModel: Model<UserTransactionDocument>,
    @InjectModel('gidadat')
    private gidadatModel: Model<gidadatDocument>,
    private userWalletService: UserWalletService,
    @InjectModel('User')
    private UserModel: Model<userDocument>,
  ) {}

  // async addMoney(user: any, addmoneyInput: addMoneyInput) {
  //   try {
  //     Cashfree.XClientId = 'TEST10217085736283d97459f969a1fd58071201';
  //     Cashfree.XClientSecret =
  //       'cfsk_ma_test_36bd4db5db0f9365fe08a423397792d5_45c5c942';
  //     Cashfree.XEnvironment = Cashfree.Environment.SANDBOX;

  //     const walletCheck = await this.userWalletService.getUserWallet(user._id);
  //     const user_details = await this.UserModel.findOne({
  //       _id: user._id,
  //     });

  //     let request = {
  //       order_amount: addmoneyInput.amount,
  //       order_currency: 'INR',
  //       customer_details: {
  //         customer_id: `customer_${new Date().getTime()}`,
  //         customer_name: user_details.userName,
  //         customer_email: user_details.email || '',
  //         customer_phone: user_details.phone,
  //       },
  //       order_meta: {
  //         // return_url: "https://test.cashfree.com/pgappsdemos/return.php?order_id=order_123"
  //         return_url: 'http://api.krazyy22.in/updatepayment',
  //         // payment_methods:
  //         //   "cc,dc,ccc,ppc,nb,upi,app,cardlessemi,dcemi,ccemi,banktransfer",
  //       },
  //       order_note: 'Payment gateway',
  //     };

  //     let orders = {
  //       order_id: '',
  //       session_id: '',
  //       redirect_url: '',
  //     };

  //     await Cashfree.PGCreateOrder(CASH_FREE.cashfree_api_version, request)
  //       .then((response) => {
  //         let data = response.data;
  //         console.log(data?.order_id);

  //         orders.order_id = data?.order_id;
  //         orders.session_id = data?.payment_session_id;
  //       })
  //       .catch((err) => console.log('asd', err));

  //     const transactionObj: UserTransaction = {
  //       userId: user._id,
  //       walletId: walletCheck._id.toString(),
  //       amount: addmoneyInput.amount,
  //       transanctionTime: new Date(),
  //       transanctionType: 'Credit',
  //       transanctionRelatedType: 'Credit',
  //       transactionStatus: 'Pending',
  //       previousBalance: walletCheck.userBalance,
  //       afterBalance: walletCheck.userBalance + addmoneyInput.amount,
  //       orderId: orders?.order_id,
  //     };

  //     const userTransaction = new this.UserTransactiontModel(transactionObj);

  //     await userTransaction.save();
  //     return successResponse('add', {
  //       order_id: orders.order_id,
  //       session_id: orders.session_id,
  //       redirect_url: orders.redirect_url,
  //       transactionId: orders.redirect_url,
  //       kycVerified: user.kycStatus,
  //     });
  //   } catch (err) {
  //     return commonErrors('addcash');
  //   }
  // }

  async addMoney(user: any, addmoneyInput: addMoneyInput) {
    try {
      // Set Cashfree credentials and environment
      const headers = {
        'x-client-id': 'TEST10217085736283d97459f969a1fd58071201',
        'x-client-secret':
          'cfsk_ma_test_36bd4db5db0f9365fe08a423397792d5_45c5c942',
        'x-api-version': '2023-08-01',
      };

      // Retrieve wallet and user details
      const walletCheck = await this.userWalletService.getUserWallet(user._id);
      const user_details = await this.UserModel.findOne({ _id: user._id });

      let request = {
        order_amount: addmoneyInput.amount,
        order_currency: 'INR',
        customer_details: {
          customer_id: `customer_${new Date().getTime()}`,
          customer_name: user_details.userName,
          customer_email: user_details.email || '',
          customer_phone: user_details.phone,
        },
        order_meta: {
          // return_url: "https://test.cashfree.com/pgappsdemos/return.php?order_id=order_123"
          return_url: 'http://api.krazyy22.in/updatepayment',
          // payment_methods:
          //   "cc,dc,ccc,ppc,nb,upi,app,cardlessemi,dcemi,ccemi,banktransfer",
        },
        order_note: 'Payment gateway',
      };

      Cashfree.XClientId = 'TEST10217085736283d97459f969a1fd58071201';
      Cashfree.XClientSecret =
        'cfsk_ma_test_36bd4db5db0f9365fe08a423397792d5_45c5c942';
      Cashfree.XEnvironment = Cashfree.Environment.SANDBOX;

      let orders = {
        order_id: '',
        session_id: '',
        redirect_url: '',
      };

      await Cashfree.PGCreateOrder(CASH_FREE.cashfree_api_version, request)
        .then((response) => {
          let data = response.data;
          console.log(data?.order_id);

          orders.order_id = data?.order_id;
          orders.session_id = data?.payment_session_id;
        })
        .catch((err) => console.log('asd', err));
      const paymentLinkRequest = {
        link_id: `link_${new Date().getTime()}`,
        link_amount: addmoneyInput.amount,
        link_currency: 'INR',
        link_purpose: 'Adding money to wallet',
        customer_details: {
          customer_name: user_details.userName,
          customer_email: user_details.email || '',
          customer_phone: user_details.phone,
        },
        link_meta: {
          return_url: '',
          notify_url: 'http://api.krazyy22.in/updatepayment',
        },
        link_expiry_time: new Date(
          new Date().setDate(new Date().getDate() + 30),
        ).toISOString(),
        link_notify: {
          send_sms: true,
          send_email: true,
        },
      };
      // Make the request to Cashfree's API to create a payment link
      const paymentLinkResponse = await axios.post(
        'https://sandbox.cashfree.com/pg/links', // Use production URL for live environment
        paymentLinkRequest,
        { headers },
      );

      const paymentData = paymentLinkResponse.data;
      const paymentObject = {
        link_url: paymentData.link_url,
        link_id: paymentData.link_id,
        session_id: `session_${new Date().getTime()}`,
      };

      const transactionObj: UserTransaction = {
        userId: user._id,
        walletId: walletCheck._id.toString(),
        amount: addmoneyInput.amount,
        transanctionTime: new Date(),
        transanctionType: 'Credit',
        transanctionRelatedType: 'Credit',
        transactionStatus: 'Pending',
        previousBalance: walletCheck.userBalance,
        afterBalance: walletCheck.userBalance + addmoneyInput.amount,
        orderId: paymentObject.link_id,
      };

      const userTransaction = new this.UserTransactiontModel(transactionObj);
      await userTransaction.save();

      return successResponse('add', {
        order_id: paymentObject.link_id,
        session_id: paymentObject.session_id,
        redirect_url: paymentObject.link_url,
        transactionId: orders.order_id,
        notify_url: paymentObject.link_url,
      });
    } catch (error) {
      console.error('Error creating payment link:', error.message);
      throw new Error('Failed to create payment link');
    }
  }

  async reciver(body: any) {
    // console.log('adf', body.data.type);
    try {
      if (!body?.data?.order?.order_tags?.link_id) throw new Error();
      await this.gidadatModel.create({ body, createdat: new Date() });
      return {
        status: true,
        transactionId: body?.data?.order?.order_tags?.link_id,
      };
    } catch (err) {
      console.log(err);
      return { status: false };
    }
  }

  // async createWithdrawal(userObj: any) {
  //   try {
  //     const transactionURL = `${GIGADAT.BASE_URL}payment-token/${GIGADAT.campaignId}`;

  //     const reqBody = {
  //       userId: userObj.userId,
  //       transactionId: userObj.transactionId,
  //       name: userObj.name,
  //       email: userObj.email,
  //       mobile: userObj.mobile,
  //       userIp: userObj.userIp,
  //       amount: userObj.amount,
  //       site: 'https://americandream11.us/',
  //       currency: 'CAD',
  //       language: 'en',
  //       type: 'ETO', //'CPI'
  //       sandbox: false,
  //       hosted: 'partial',
  //       // fi: 123,
  //       // transit: 12345,
  //       // acct: 123456789012,
  //     };

  //     const auth =
  //       'Basic ' +
  //       Buffer.from(GIGADAT.accessToken + ':' + GIGADAT.securityToken).toString(
  //         'base64',
  //       );

  //     const transactionRequest = await fetch(transactionURL, {
  //       headers: {
  //         Accept: 'application/json',
  //         'Content-Type': 'application/json',
  //         Authorization: auth,
  //       },
  //       method: 'POST',
  //       body: JSON.stringify(reqBody),
  //     });

  //     return { status: true, data: await transactionRequest.json() };
  //   } catch (err) {
  //     return { status: false };
  //   }
  // }
}
