import { Controller, Get, HttpCode, Post, Req } from '@nestjs/common';
import { UserTransactionService } from './user-transaction.service';
import { GigadatService } from './payment-gateway/gigadat.service';
import { Request } from 'express';

@Controller('payment')
export class PaymentController {
  constructor(
    private readonly userTransactionService: UserTransactionService,
    private readonly gigadatService: GigadatService,
  ) {}

  @Post('cashfree')
  @HttpCode(200)
  async gidadatReciver(@Req() req: Request) {
    //  console.log("first", req.body)
    const endterGidatTransaction = await this.gigadatService.reciver(req.body);
    if (!endterGidatTransaction)
      return { status: false, message: 'Unable to update transaction' };
    await this.userTransactionService.gigadatQueueTransactions(
      endterGidatTransaction?.transactionId,
      1,
    );
    // await this.userTransactionService.checkout(
    //   endterGidatTransaction?.transactionId

    // );

    return { status: true, message: 'Transaction updated' };
  }
}
