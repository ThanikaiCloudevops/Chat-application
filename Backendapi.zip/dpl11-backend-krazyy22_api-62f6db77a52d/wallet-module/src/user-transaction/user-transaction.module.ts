import { Module } from '@nestjs/common';
import { UserTransactionService } from './user-transaction.service';
import { UserTransactionResolver } from './user-transaction.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import {
  UserTransaction,
  UserTransactionSchema,
} from './entities/user-transaction.entity';
import { UserWalletService } from 'src/user-wallet/user-wallet.service';
import {
  UserWallet,
  UserWalletSchema,
} from 'src/user-wallet/entities/user-wallet.entity';
import {
  BonusMaster,
  BonusMasterSchema,
} from 'src/user-transaction/entities/bonus-master.entity';
import { User, UserSchema } from 'src/user-transaction/entities/user.entity';
import { trpcServices } from 'src/trpc/client/trpc';
import { ScheduleModule } from '@nestjs/schedule';
import { NotificationService } from './notification.service';
import { Msg91SmsService } from './send-sms/sms.service';
import {
  Notification,
  NotificationSchema,
} from 'src/user-transaction/entities/notifications.entity';
import {
  UserBank,
  UserBankSchema,
} from 'src/bank-verify/entities/user-bank.entity';
import { BankVerifyService } from 'src/bank-verify/bank-verify.service';
import { GigadatService } from './payment-gateway/gigadat.service';
import { gidadat, gidadatSchema } from './entities/gidadat-reciver';
import { PaymentController } from './payment.controller';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: UserTransaction.name, schema: UserTransactionSchema },
      { name: User.name, schema: UserSchema },
      { name: UserWallet.name, schema: UserWalletSchema },
      { name: BonusMaster.name, schema: BonusMasterSchema },
      { name: gidadat.name, schema: gidadatSchema },
      { name: Notification.name, schema: NotificationSchema },
      { name: UserBank.name, schema: UserBankSchema },
    ]),
    ScheduleModule.forRoot(),
  ],
  providers: [
    UserTransactionResolver,
    UserTransactionService,
    UserWalletService,
    trpcServices,
    NotificationService,
    GigadatService,
    Msg91SmsService,
    BankVerifyService,
  ],
  controllers: [PaymentController],
})
export class UserTransactionModule {}
