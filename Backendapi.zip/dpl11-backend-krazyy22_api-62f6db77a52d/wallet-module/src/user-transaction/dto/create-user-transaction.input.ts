import { InputType, Int, Field } from '@nestjs/graphql';
import { IsIn } from 'class-validator';

@InputType()
export class CreateUserTransactionInput {
  @Field()
  userId: string;

  @Field()
  @IsIn(['Credit', 'Debit', 'Others'])
  transanctionType: string;

  @Field()
  amount: number;

  @Field()
  @IsIn([
    'Winnings',
    'Referral',
    'System',
    'Withdrawal',
    'EntryFee',
    'Admin',
    'Bonus',
    'Credit',
  ])
  transanctionRelatedType: string;

  @Field()
  fixtureId?: string;

  @Field()
  contestId?: string;

  @Field()
  fixtureName?: string;

  @Field()
  transactionStatus?: string;

  @Field()
  referId?: string;

  @Field()
  contestName?: string;
}

@InputType()
export class addMoneyInput {
  @Field()
  amount: number;
  @Field()
  userIp: string;
}
