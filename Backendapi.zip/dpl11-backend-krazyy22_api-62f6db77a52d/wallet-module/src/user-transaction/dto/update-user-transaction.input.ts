import { CreateUserTransactionInput } from './create-user-transaction.input';
import { InputType, Field, Int, PartialType } from '@nestjs/graphql';

@InputType()
export class UpdateUserTransactionInput extends PartialType(CreateUserTransactionInput) {
  @Field(() => Int)
  id: number;
}
