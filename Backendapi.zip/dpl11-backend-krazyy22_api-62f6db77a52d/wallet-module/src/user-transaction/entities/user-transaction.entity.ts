import { ObjectType, Field, Int, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { IsIn } from 'class-validator';
import { UserWallet_defaultFields } from 'src/commonResponse/response.entity';

export type UserTransactionDocument = UserTransaction & Document;
@ObjectType()
@Schema()
export class UserTransaction {
  @Field()
  @Prop()
  userId: string;

  /* @Field()
  @Prop()
  transanctionId: string; */

  @Field()
  @Prop()
  @IsIn(['Credit', 'Debit', 'Others'])
  transanctionType: string;

  @Field({ defaultValue: 0 })
  @Prop()
  bonusUsed?: number;

  @Field()
  @Prop()
  amount: number;

  @Field()
  @Prop()
  transanctionTime: Date;

  @Field()
  @Prop()
  walletId: string;

  @Field({nullable:true})
  @Prop()
  orderId?: string;


  @Field()
  @Prop()
  previousBalance: number;

  @Field()
  @Prop()
  afterBalance: number;

  @Field()
  @Prop()
  @IsIn([
    'Winnings',
    'Referral',
    'System',
    'Withdrawal',
    'EntryFee',
    'Admin',
    'Bonus',
    'Credit',
    'GameFee',
    'GameWin',
  ])
  transanctionRelatedType: string;

  @Field({ defaultValue: 'Success', nullable: true })
  @Prop({ default: 'Success' })
  @IsIn(['Success', 'Pending', 'Failed', 'Refund'])
  transactionStatus: string;

  @Field({ nullable: true })
  @Prop()
  fixtureId?: string;

  @Field({ defaultValue: '' })
  @Prop()
  fixtureName?: string;

  @Field({ nullable: true })
  @Prop()
  contestId?: string;

  @Field({ defaultValue: '' })
  @Prop()
  contestName?: string;

  @Field({ nullable: true })
  @Prop()
  referId?: string;
}

@ObjectType()
export class getUserTransaction extends PartialType(UserWallet_defaultFields) {
  @Field(() => [UserTransaction], { nullable: true })
  data: UserTransaction;
}

export const UserTransactionSchema =
  SchemaFactory.createForClass(UserTransaction);
