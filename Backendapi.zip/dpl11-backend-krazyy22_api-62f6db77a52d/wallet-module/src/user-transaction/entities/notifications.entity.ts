import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type notificationDocument = Notification & Document;


@Schema()
export class Notification {
 
  @Prop()
  pn_title: string;
 
  @Prop()
  pn_message: string;
  
  @Prop()
  pn_image?: string;
  @Prop()
  fixture_id?: number;
  @Prop({ default: true})
  pn_receivers: string;
  
  @Prop()
  pn_sendType?: string;
 
  @Prop({ default: new Date() })
  pn_sendTime: Date;
 
  @Prop()
  pn_status: number;
  
  @Prop({ default: true })
  pn_read?: string;
 
  @Prop({ default: false })
  status: boolean;
  
  @Prop()
  createdBy?: string;
 
  @Prop({ default: new Date() })
  createdat: Date;
  
  @Prop()
  updatedat?: Date;
  
  @Prop()
  deletedat?: Date; 
}

export const NotificationSchema = SchemaFactory.createForClass(Notification);
