import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type gidadatDocument = gidadat & Document;

@Schema()
export class gidadat {
  @Prop({ type: Object })
  body: object;

  @Prop()
  createdat: Date;
}

export const gidadatSchema = SchemaFactory.createForClass(gidadat);
