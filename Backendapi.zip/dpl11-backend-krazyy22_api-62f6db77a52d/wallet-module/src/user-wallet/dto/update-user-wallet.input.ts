import { CreateUserWalletInput } from './create-user-wallet.input';
import { InputType, Field, Int, PartialType } from '@nestjs/graphql';

@InputType()
export class UpdateUserWalletInput extends PartialType(CreateUserWalletInput) {
  @Field(() => Int)
  id: number;
}
