import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { UserWallet_defaultFields } from 'src/commonResponse/response.entity';

export type UserWalletDocument = UserWallet & Document;

@ObjectType()
@Schema()
export class UserWallet {
  @Field()
  @Prop()
  userId: string;

  @Field()
  @Prop()
  userBalance: number;

  @Field()
  @Prop()
  totalWinnings: number;

  @Field()
  @Prop()
  totalBonus: number;

  @Field()
  @Prop()
  unutilisedBalance: number;
}

@ObjectType()
export class getUserWallet extends PartialType(UserWallet_defaultFields) {
  @Field(() => UserWallet, { nullable: true })
  data: UserWallet;
}

export const UserWalletSchema = SchemaFactory.createForClass(UserWallet);
