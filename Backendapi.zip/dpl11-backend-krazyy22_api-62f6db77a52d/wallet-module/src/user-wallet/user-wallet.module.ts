import { Module } from '@nestjs/common';
import { UserWalletService } from './user-wallet.service';
import { UserWalletResolver } from './user-wallet.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import { UserWallet, UserWalletSchema } from './entities/user-wallet.entity';
import {
  BonusMaster,
  BonusMasterSchema,
} from 'src/user-transaction/entities/bonus-master.entity';
import {
  UserTransaction,
  UserTransactionSchema,
} from 'src/user-transaction/entities/user-transaction.entity';
import {
  UserBank,
  UserBankSchema,
} from 'src/bank-verify/entities/user-bank.entity';
import { BankVerifyService } from 'src/bank-verify/bank-verify.service';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: UserWallet.name, schema: UserWalletSchema },
      { name: BonusMaster.name, schema: BonusMasterSchema },
      { name: UserTransaction.name, schema: UserTransactionSchema },
      { name: UserBank.name, schema: UserBankSchema },
    ]),
  ],
  providers: [UserWalletResolver, UserWalletService, BankVerifyService],
})
export class UserWalletModule {}
