import { Injectable } from '@nestjs/common';
import { CreateUserWalletInput } from './dto/create-user-wallet.input';
import { UpdateUserWalletInput } from './dto/update-user-wallet.input';
import { commonErrors } from 'src/commonResponse/errors';
import { successResponse } from 'src/commonResponse/success';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { UserWallet, UserWalletDocument } from './entities/user-wallet.entity';
import { UserTransactionService } from 'src/user-transaction/user-transaction.service';
import {
  BonusMaster,
  BonusMasterDocument,
} from 'src/user-transaction/entities/bonus-master.entity';
import {
  UserTransaction,
  UserTransactionDocument,
} from 'src/user-transaction/entities/user-transaction.entity';
import { BankVerifyService } from 'src/bank-verify/bank-verify.service';
@Injectable()
export class UserWalletService {
  constructor(
    // private userTransactionService: UserTransactionService,
    @InjectModel('UserTransaction')
    private UserTransactiontModel: Model<UserTransactionDocument>,
    @InjectModel('UserWallet')
    private UserWalletModel: Model<UserWalletDocument>,
    @InjectModel('BonusMaster')
    private BonusMasterModel: Model<BonusMasterDocument>,
    private readonly bankVerifyService: BankVerifyService,
  ) {}

  async getUserWallet(_id: string) {
    return await this.UserWalletModel.findOne({ userId: _id });
  }

  async getUserWalletOrder(_id: string) {
    return await this.UserWalletModel.findOne({ orderId: _id });
  }

  async findOne(id: string) {
    try {
      let data = await this.getUserWallet(id);
      data = data.toObject();
      const bonustyp = await this.BonusMasterModel.findOne({
        bonusType: 'bonusReductionPersentage',
        isactive: true,
      }).lean();
      const bankData = await this.bankVerifyService.getBankAccoounts(id);

      if (bankData.status) data['bankAccounts'] = bankData.data;
      data['bonusReductionPersentage'] = bonustyp['bonusReductionPersentage'];

      return successResponse('getWallet', data);
    } catch (error) {
      return commonErrors('getWallet');
    }
  }

  async createWallet(userId: string) {
    try {
      const checkDupliate = await this.getUserWallet(userId);
      if (checkDupliate) return commonErrors('walletExist');

      var bonustyp = await this.BonusMasterModel.findOne({
        bonusType: 'signup',
        isactive: true,
      });
      let amount = 0;
      bonustyp.refFrom > 0 ? (amount = bonustyp.refFrom / 2) : 0;

      const walletCheck = await this.UserWalletModel.create({
        userId,
        userBalance: amount,
        totalWinnings: 0,
        totalBonus: bonustyp.refFrom ? amount : 0,
        unutilisedBalance: amount,
      });
      if (bonustyp.refFrom > 0) {
        let transRelated = '';
        let previous = 0;
        let balAmnt = 0;
        for (let i = 0; i < 2; i++) {
          if (i == 0) {
            transRelated = 'Signup Bonus';
            balAmnt = 0;
          } else {
            transRelated = 'Cash Bonus';
            balAmnt = amount;
          }
          const transaction = await this.UserTransactiontModel.create({
            userId: userId,
            transanctionType: 'Credit',
            amount: amount,
            walletId: walletCheck._id,
            previousBalance: previous,
            afterBalance: previous + balAmnt,
            transanctionRelatedType: transRelated,
            transanctionTime: new Date(),
            transactionStatus: 'Success',
          });
        }
      }
      return successResponse('createWallet');
    } catch (err) {
      return { status: false };
    }
  }

  async updateWallet(
    userWallet: UserWalletDocument,
    amount: number,
    updateType: boolean, //true is credit and false is debit
    transanctionRelatedType: string,
    bonusamount: number,
  ) {
    if (updateType)
      transanctionRelatedType == 'Winnings'
        ? (userWallet.totalWinnings += amount)
        : transanctionRelatedType == 'Bonus'
        ? (userWallet.totalBonus += amount)
        : transanctionRelatedType == 'Credit'
        ? (userWallet.unutilisedBalance -= amount)
        : null;
    else {
      let winnings;
      let unutilisedbal;
      if (userWallet['unutilisedBalance'] > amount) {
        unutilisedbal = userWallet['unutilisedBalance'] - amount;
        winnings = userWallet['totalWinnings'];
      }
      if (userWallet['unutilisedBalance'] <= amount) {
        const remaining = amount - userWallet['unutilisedBalance'];
        unutilisedbal = 0;
        if (userWallet['totalWinnings'] >= +remaining.toFixed(2)) {
          winnings = userWallet['totalWinnings'] - +remaining.toFixed(2);
          console.log(winnings);
        } else {
          winnings = userWallet['totalWinnings'];
        }
      }
      userWallet['unutilisedBalance'] = +unutilisedbal.toFixed(2);
      userWallet['totalWinnings'] = +winnings.toFixed(2);
      userWallet['totalBonus'] = +(
        Number(userWallet.totalBonus) - Number(bonusamount)
      ).toFixed(2);
      userWallet['userBalance'] =
        userWallet.unutilisedBalance + userWallet.totalWinnings;
      return await userWallet.save();
    }

    userWallet.totalBonus < 0 ? (userWallet.totalBonus = 0) : null;
    userWallet.unutilisedBalance < 0
      ? (userWallet.unutilisedBalance = 0)
      : null;
    userWallet.totalWinnings < 0 ? (userWallet.totalWinnings = 0) : null;
    userWallet.userBalance = +(
      Number(userWallet.unutilisedBalance) + Number(userWallet.totalWinnings)
    ).toFixed(2);
    return await userWallet.save();
  }

  async addMoney(userId: string, amount: number) {
    try {
      const userWallet = await this.UserWalletModel.findOne({ userId });
      if (!userWallet) throw new Error();
      userWallet.unutilisedBalance = userWallet.unutilisedBalance + amount;
      userWallet.userBalance = userWallet.userBalance + amount;
      await userWallet.save();
      return { status: true };
    } catch (err) {
      return { status: false };
    }
  }

  async refundMoney(userId: string, amount: number) {
    try {
      const userWallet = await this.UserWalletModel.findOne({ userId });
      if (!userWallet) throw new Error();
      userWallet.totalWinnings = userWallet.totalWinnings + amount;
      userWallet.userBalance = userWallet.userBalance + amount;
      await userWallet.save();
      return { status: true };
    } catch (err) {
      return { status: false };
    }
  }
}
