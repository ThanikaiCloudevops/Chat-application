const successMsg = {
  getWallet: 'Wallet Retrived Successfully',
  transaction: 'Transaction updated successfully',
  found: 'Transaction found',
  createWallet: 'Wallet creation success',
  add: 'Money added successfully',
  bonus: 'bonus check',
  qrcode: 'Payment code found',
  withdraw: 'Withdrawal requested',
  currency: 'Amount converted',
  kyc: 'KYC verification incomplete',
  bank: 'Bank account verification success',
  data: 'Data found',
};
export function successResponse(msg: string, data: any = null) {
  return { status: true, success: { message: successMsg[msg] }, data };
}
