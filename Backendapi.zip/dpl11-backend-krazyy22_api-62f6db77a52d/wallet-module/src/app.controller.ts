import { Controller, Get, Post, HttpCode, Req } from '@nestjs/common';
import { AppService } from './app.service';
import { Request } from '@nestjs/common';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @Get('/hook')
  hook(): string {
    return this.appService.hook();
  }

  // @Post('cashfree')
  // @HttpCode(200)
  // async gidadatReciver(@Req() req: Request) {
  //   console.log('gidadatReciver', req.body)
  //   // const endterGidatTransaction = await this.gigadatService.reciver(req.body);
  //   // if (!endterGidatTransaction?.status)
  //   //   return { status: false, message: 'Unable to update transaction' };

  //   // await this.userTransactionService.checkout(
  //   //   endterGidatTransaction?.transactionId
      
  //   // );

  //   return { status: true, message: 'Transaction updated' };
  // }
}
