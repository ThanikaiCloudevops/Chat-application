import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { TrpcRouter } from './trpc/server/trpc.router';
import { MODULE } from 'config/envirnment';
import { ValidationPipe } from '@nestjs/common';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors({ allowedHeaders: '*', origin: '*' });
  const trpc = app.get(TrpcRouter);
  trpc.applyMiddleware(app);
  app.useGlobalPipes(new ValidationPipe());
  await app.listen(MODULE.PORT, () =>
    console.log(` ${MODULE.NAME} listening http://localhost:${MODULE.PORT}`),
  );
}
bootstrap();
