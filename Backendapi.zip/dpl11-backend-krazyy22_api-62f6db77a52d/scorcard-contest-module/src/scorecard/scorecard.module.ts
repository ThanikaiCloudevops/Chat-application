import { Module } from '@nestjs/common';
import { CacheModule } from '@nestjs/cache-manager';
import { ScorecardService } from './scorecard.service';
import { ScorecardResolver } from './scorecard.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import { scorecards, ScorecardSchema } from './entities/scorecard.entity';
import { commentries, CommentrySchema } from './entities/commentary.entity';
import {
  playerPerformance,
  playerPerformanceSchema,
} from './entities/playerPerformance.entity';
import { trpcServices } from 'src/trpc/client/trpc';
import {
  FootballCommentary,
  FootballCommentarySchema,
} from './entities/football-commentry.entity';
import {
  FootballPlayerPerformance,
  FootballPlayerPerformanceSchema,
} from './entities/football-playerperformance.entity';
import {
  FootballScorecard,
  FootballScorecardSchema,
} from './entities/football-scorecard.entity';
import {
  KabaddiScorecard,
  KabaddiScorecardSchema,
} from './entities/kabaddi-scorecard.entity';
import {
  KabaddiPlayerPerformance,
  KabaddiPlayerPerformanceSchema,
} from './entities/kabaddi-playerperformance.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: playerPerformance.name, schema: playerPerformanceSchema },
      { name: scorecards.name, schema: ScorecardSchema },
      { name: commentries.name, schema: CommentrySchema },
      {
        name: FootballPlayerPerformance.name,
        schema: FootballPlayerPerformanceSchema,
      },
      {
        name: FootballScorecard.name,
        schema: FootballScorecardSchema,
      },
      { name: FootballCommentary.name, schema: FootballCommentarySchema },
      { name: KabaddiScorecard.name, schema: KabaddiScorecardSchema },
      {
        name: KabaddiPlayerPerformance.name,
        schema: KabaddiPlayerPerformanceSchema,
      },
    ]),
    CacheModule.register(),
  ],
  providers: [ScorecardResolver, ScorecardService, trpcServices],
})
export class ScorecardModule {}
