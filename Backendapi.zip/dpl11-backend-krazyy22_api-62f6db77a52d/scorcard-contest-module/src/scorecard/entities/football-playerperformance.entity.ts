import { Field, ObjectType, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { score_defaultFields } from 'src/commonResponse/response.entity';
import { FootballTeamDetails } from './scorecard.entity';
import { nullable } from 'zod';

export type FootballPlayerPointsDocument = FootballPlayerPerformance & Document;

@ObjectType()
export class FootballPlayerPoints {
  @Field({ nullable: true })
  @Prop()
  playerAPIId: number;
  @Field()
  @Prop()
  playerName: string;
  @Field()
  @Prop()
  playerRole: string;
  @Field()
  @Prop()
  playerTeamType: string;
  @Field()
  @Prop()
  goalStrikerPoints: number;
  @Field()
  @Prop()
  goalMidfielderPoints: number;
  @Field()
  @Prop()
  goalDefKeepPoints: number;
  @Field()
  @Prop()
  assistPoints: number;
  @Field()
  @Prop()
  chanceCreatedPoints: number;
  @Field()
  @Prop()
  shotOnTargetPoints: number;
  @Field()
  @Prop()
  fivePassPoints: number;
  @Field()
  @Prop()
  tacketPoints: number;
  @Field()
  @Prop()
  interceptionPoints: number;
  @Field()
  @Prop()
  goalSavePoints: number;
  @Field()
  @Prop()
  penaltySavePoints: number;
  @Field()
  @Prop()
  cleanSheetPoints: number;
  @Field()
  @Prop()
  in11Points: number;
  @Field()
  @Prop()
  subPoints: number;
  @Field()
  @Prop()
  yellowCardPoints: number;
  @Field()
  @Prop()
  redCardPoints: number;
  @Field()
  @Prop()
  ownGoalPoints: number;
  @Field()
  @Prop()
  goalsConcededPoints: number;
  @Field()
  @Prop()
  penaltyMissedPoints: number;
  @Field()
  @Prop()
  playerPoints: number;
}

@ObjectType()
export class FootballPlayerStats {
  @Field({ nullable: true })
  @Prop()
  playerAPIId: number;
  @Field()
  @Prop()
  playerName: string;
  @Field()
  @Prop()
  playerRole: string;
  @Field()
  @Prop()
  playerTeamType: string;
  @Field()
  @Prop()
  goalStrikerMade: number;
  @Field()
  @Prop()
  goalMidfielderMade: number;
  @Field()
  @Prop()
  goalDefKeepMade: number;
  @Field()
  @Prop()
  assistMade: number;
  @Field()
  @Prop()
  chanceCreatedMade: number;
  @Field()
  @Prop()
  shotOnTargetMade: number;
  @Field()
  @Prop()
  fivePassMade: number;
  @Field()
  @Prop()
  tacketMade: number;
  @Field()
  @Prop()
  interceptionMade: number;
  @Field()
  @Prop()
  goalSaveMade: number;
  @Field()
  @Prop()
  penaltySaveMade: number;
  @Field()
  @Prop()
  cleanSheetMade: number;
  @Field()
  @Prop()
  yellowCardMade: number;
  @Field()
  @Prop()
  redCardMade: number;
  @Field()
  @Prop()
  ownGoalMade: number;
  @Field()
  @Prop()
  goalsConcededMade: number;
  @Field()
  @Prop()
  penaltyMissedMade: number;
}

@ObjectType()
@Schema()
export class FootballPlayerPerformance {
  @Field({ nullable: true })
  @Prop({ type: Number })
  fixtureAPIId: number;

  @Field({ nullable: true })
  @Prop({ type: String })
  fixtureStatus: string;

  @Field(() => [FootballPlayerPoints])
  @Prop()
  playerPoints: FootballPlayerPoints[];

  @Field(() => FootballPlayerStats)
  @Prop()
  playerStats: FootballPlayerStats[];
}

@ObjectType()
class FootballPlayerPerformanceStatsData extends FootballPlayerPoints {
  @Field({ nullable: true })
  goalStrikerMade: number;
  @Field()
  goalMidfielderMade: number;
  @Field()
  goalDefKeepMade: number;
  @Field()
  assistMade: number;
  @Field()
  chanceCreatedMade: number;
  @Field()
  shotOnTargetMade: number;
  @Field()
  fivePassMade: number;
  @Field()
  tacketMade: number;
  @Field()
  interceptionMade: number;
  @Field()
  goalSaveMade: number;
  @Field()
  penaltySaveMade: number;
  @Field()
  cleanSheetMade: number;
  @Field()
  yellowCardMade: number;
  @Field()
  redCardMade: number;
  @Field()
  ownGoalMade: number;
  @Field()
  goalsConcededMade: number;
  @Field()
  penaltyMissedMade: number;
  @Field({ nullable: true })
  selectedbyCount: number;
  @Field({ nullable: true })
  selectedbyCountVC: number;
  @Field({ nullable: true })
  selectedbyCountCAP: number;
  @Field({ nullable: true })
  teamAPIId: number;
}

@ObjectType()
class FootballPlayerPointsDatas {
  @Field({ defaultValue: 0 })
  totalPoints: number;
  @Field({ defaultValue: 0 })
  otherPoints: number;
  @Field({ defaultValue: '' })
  playerName: string;
}

@ObjectType()
export class FootballTotalData {
  @Field({ nullable: true })
  fixtureAPIId: number;

  @Field({ nullable: true })
  teams: FootballTeamDetails;

  @Field({ nullable: true })
  playerPoints: FootballPlayerPointsDatas;
}

@ObjectType()
export class FootballData {
  @Field(() => [FootballTotalData])
  data: [FootballTotalData];

  @Field({ defaultValue: 0 })
  playerTotalPoints: number;

  @Field({ defaultValue: 0 })
  playerPointAverage: number;
}

@ObjectType()
export class FinalFootballPlayerPerformanceStats extends PartialType(
  score_defaultFields,
) {
  @Field(() => FootballData)
  data: FootballData;
}

@ObjectType()
export class FootballPlayerPerformanceStats extends PartialType(
  score_defaultFields,
) {
  @Field(() => [FootballPlayerPerformanceStatsData], {
    nullable: 'itemsAndList',
  })
  data: FootballPlayerPerformanceStatsData;
}

export const FootballPlayerPerformanceSchema = SchemaFactory.createForClass(
  FootballPlayerPerformance,
);
