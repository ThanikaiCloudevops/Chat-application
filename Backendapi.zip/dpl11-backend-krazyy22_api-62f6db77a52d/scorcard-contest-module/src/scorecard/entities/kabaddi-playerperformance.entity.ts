import { Field, ObjectType, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { score_defaultFields } from 'src/commonResponse/response.entity';
import { KabaddiScorecardTeams } from './kabaddi-scorecard.entity';
export type KabaddiPlayerPerformanceDocument = KabaddiPlayerPerformance &
  Document;

@ObjectType()
export class KabaddiPlayerStats {
  @Field()
  playerAPIId: number;

  @Field()
  playerName: string;

  @Field()
  side: string;

  @Field()
  greencardcount: number;

  @Field()
  yellowcardcount: number;

  @Field()
  redcardcount: number;

  @Field()
  totalpoint: number;

  @Field()
  raidtotalpoint: number;

  @Field()
  raidtouchpoint: number;

  @Field()
  raidbonuspoint: number;

  @Field()
  tackletotalpoint: number;

  @Field()
  tacklecapturepoint: number;

  @Field()
  tacklecapturebonuspoint: number;

  @Field()
  tackletotal: number;

  @Field()
  tacklesuccessful: number;

  @Field()
  tackleunsuccessful: number;

  @Field()
  supertackles: number;

  @Field()
  raidtotal: number;

  @Field()
  raidsuccessful: number;

  @Field()
  raidunsuccessful: number;

  @Field()
  raidempty: number;

  @Field()
  superraid: number;

  @Field()
  superten: number;

  @Field()
  highfive: number;
}

@ObjectType()
export class KabaddiPlayerPoints {
  @Field()
  playerAPIId: number;

  @Field()
  playerName: string;

  @Field()
  playerRole: string;

  @Field()
  fantasyCredit: number;

  @Field()
  playerPoints: number;

  @Field()
  in11Points: number;

  @Field()
  subPoints: number;

  @Field()
  raidtouchPoints: number;

  @Field()
  raidbonusPoints: number;

  @Field()
  superraidPoints: number;

  @Field()
  supertenPoints: number;

  @Field()
  tacklesucceessfulPoints: number;

  @Field()
  supertacklePoints: number;

  @Field()
  tackleunsucceessfulPoints: number;

  @Field()
  highfivePoints: number;

  @Field()
  greencardPoints: number;

  @Field()
  yellowcardPoints: number;

  @Field()
  redcardPoints: number;

  @Field()
  pushingalloutPoints: number;

  @Field()
  gettingalloutPoints: number;
}

@ObjectType()
export class PlayerPoints {
  @Field()
  playerName: string;
  @Field({ defaultValue: 0 })
  totalPoints: number;
}

@ObjectType()
class kabaddiPlayerPerformanceStatsData extends KabaddiPlayerPoints {
  @Field()
  playerAPIId: number;

  @Field()
  playerName: string;

  @Field()
  side: string;

  @Field()
  greencardcount: number;

  @Field()
  yellowcardcount: number;

  @Field()
  redcardcount: number;

  @Field()
  totalpoint: number;

  @Field()
  raidtotalpoint: number;

  @Field()
  raidtouchpoint: number;

  @Field()
  raidbonuspoint: number;

  @Field()
  tackletotalpoint: number;

  @Field()
  tacklecapturepoint: number;

  @Field()
  tacklecapturebonuspoint: number;

  @Field()
  tackletotal: number;

  @Field()
  tacklesuccessful: number;

  @Field()
  tackleunsuccessful: number;

  @Field()
  supertackles: number;

  @Field()
  raidtotal: number;

  @Field()
  raidsuccessful: number;

  @Field()
  raidunsuccessful: number;

  @Field()
  raidempty: number;

  @Field()
  superraid: number;

  @Field()
  superten: number;

  @Field()
  highfive: number;
  @Field({ nullable: true, defaultValue: 0 })
  selectedbyCount: number;
  @Field({ nullable: true, defaultValue: 0 })
  selectedbyCountVC: number;
  @Field({ nullable: true, defaultValue: 0 })
  selectedbyCountCAP: number;
  @Field({ nullable: true, defaultValue: 0 })
  teamAPIId: number;
}

@Schema()
@ObjectType()
export class KabaddiPlayerPerformance {
  @Field()
  @Prop({ type: Number })
  fixtureAPIId: number;

  @Field()
  @Prop({ type: String })
  fixtureStatus: string;

  @Field(() => [KabaddiPlayerPoints], { nullable: true })
  @Prop()
  playerPoints: KabaddiPlayerPoints[];

  @Field(() => [KabaddiPlayerStats], { nullable: true })
  @Prop()
  playerStats: KabaddiPlayerStats[];
}

@ObjectType()
export class KabaddiTotalData {
  @Field({ nullable: true })
  fixtureAPIId: number;

  @Field({ nullable: true })
  teams: KabaddiScorecardTeams;

  @Field({ nullable: true })
  playerPoints: PlayerPoints;
}

@ObjectType()
export class KabaddiData {
  @Field(() => [KabaddiTotalData])
  data: [KabaddiTotalData];

  @Field({ defaultValue: 0 })
  playerTotalPoints: number;

  @Field({ defaultValue: 0 })
  playerPointAverage: number;
}

@ObjectType()
export class FinalKabaddiPlayerPerformanceStats extends PartialType(
  score_defaultFields,
) {
  @Field(() => KabaddiData)
  data: KabaddiData;
}

@ObjectType()
export class KabaddiPlayerPerformanceStats extends PartialType(
  score_defaultFields,
) {
  @Field(() => [kabaddiPlayerPerformanceStatsData], {
    nullable: 'itemsAndList',
  })
  data: kabaddiPlayerPerformanceStatsData[];
}

export const KabaddiPlayerPerformanceSchema = SchemaFactory.createForClass(
  KabaddiPlayerPerformance,
);
