import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { score_defaultFields } from 'src/commonResponse/response.entity';

export type FootballCommentaryDocument = FootballCommentary & Document;

@ObjectType()
export class FootballEvents {
  @Field()
  playerAPIId: number;

  @Field()
  playerName: string;

  @Field()
  type: string;

  @Field({ nullable: true, defaultValue: 0 })
  time: number;

  @Field()
  card: string;

  @Field()
  name: string;

  @Field()
  team: string;

  @Field()
  injuryTime: number;

  @Field()
  playerAPIIdIn: number;

  @Field()
  playerAPIIdOut: number;

  @Field()
  inPlayerName: string;

  @Field()
  outPlayerName: string;

  @Field()
  status: number;

  @Field()
  statusStr: string;
}

@ObjectType()
export class FootballCommentaries {
  @Field()
  id: number;

  @Field()
  time: number;

  @Field()
  sentence: string;

  @Field()
  injuryTime: number;
}

@ObjectType()
@Schema()
export class FootballCommentary {
  @Field()
  @Prop()
  fixtureAPIId: number;

  @Field(() => [FootballEvents])
  @Prop()
  events: FootballEvents[];

  @Field(() => [FootballCommentaries])
  @Prop()
  commentary: FootballCommentaries[];
}

@ObjectType()
export class footballcommentary_data extends PartialType(score_defaultFields) {
  @Field(() => FootballCommentary, { nullable: true })
  data: FootballCommentary;
}

export const FootballCommentarySchema =
  SchemaFactory.createForClass(FootballCommentary);
