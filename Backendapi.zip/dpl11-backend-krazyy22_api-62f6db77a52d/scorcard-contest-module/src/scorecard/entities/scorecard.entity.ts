import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import graphqlTypeJson from 'graphql-type-json';
import { Document } from 'mongoose';
import { score_defaultFields } from 'src/commonResponse/response.entity';

export type scorecardDocument = scorecards & Document;

@ObjectType()
export class Toss {
  @Field()
  wonTeamId: number;
  @Field()
  result: string;
  @Field()
  text: string;
}

@ObjectType()
class _Team {
  @Field()
  name: string;
  @Field()
  shortName: string;
  @Field()
  teamAPIId: number;
  @Field()
  logo: string;
  @Field()
  scores_full: string;
  @Field()
  scores: string;
  @Field()
  overs: string;
}

@ObjectType()
export class TeamDetails {
  @Field(() => _Team)
  teamA: _Team;
  @Field(() => _Team)
  teamB: _Team;
}

@ObjectType()
class FootballTeam {
  @Field()
  name: string;
  @Field()
  shortName: string;
  @Field()
  teamAPIId: number;
  @Field()
  logo: string;
}

@ObjectType()
export class FootballTeamDetails {
  @Field(() => FootballTeam)
  teamA: FootballTeam;
  @Field(() => FootballTeam)
  teamB: FootballTeam;
}

@ObjectType()
class OutType {
  @Field({ nullable: true })
  type: string;
  @Field({ nullable: true })
  duckOut: boolean;
  @Field({ nullable: true })
  bowledBy: string;
  @Field({ nullable: true })
  caughtBy: string;
  @Field({ nullable: true })
  stumpedBy: string;
  @Field({ nullable: true })
  runout: string;
  @Field({ nullable: true })
  FOW: string;
  @Field({ nullable: true })
  outComment: string;
}

@ObjectType()
export class BatTeam {
  @Field({ nullable: true })
  playerName: string;
  @Field({ nullable: true })
  playerAPIId: number;
  @Field({ nullable: true })
  player_type: string;
  @Field({ nullable: true })
  ballsFaced: number;
  @Field({ nullable: true })
  battingPosition: string;
  @Field({ nullable: true })
  runsScored: number;
  @Field({ nullable: true })
  foursHit: number;
  @Field({ nullable: true })
  sixesHit: number;
  @Field({ nullable: true })
  strikeRate: number;
  @Field({ nullable: true })
  outStatus: boolean;
  @Field(() => OutType, { nullable: true })
  outType?: OutType;
}

@ObjectType()
export class BowlTeam {
  @Field()
  playerName: string;
  @Field()
  playerAPIId: number;
  @Field()
  player_type: string;
  @Field()
  bowlingPosition: string;
  @Field()
  oversBowled: number;
  @Field()
  runsGiven: number;
  @Field()
  maidensBowled: number;
  @Field()
  noBallsBowled: number;
  @Field()
  widesBowled: number;
  @Field()
  wicketsTaken: number;
  @Field()
  bowledMade: number;
  @Field()
  lbwMade: number;
  @Field()
  economy: number;
  @Field()
  bowlingStrikerate: number;
}

@ObjectType()
class fieldTeam {
  @Field()
  fielder_id: string;
  @Field()
  fielder_name: string;
  @Field()
  catches: number;
  @Field()
  runout_thrower: number;
  @Field()
  runout_catcher: number;
  @Field()
  runout_direct_hit: number;
  @Field()
  stumping: number;
  @Field()
  is_substitute: string;
}
@ObjectType()
class Bat {
  @Field()
  teamAPIId: number;
  @Field(() => [BatTeam])
  team: BatTeam[];
}

@ObjectType()
class Bowl {
  @Field()
  teamAPIId: number;
  @Field(() => [BowlTeam])
  team: BowlTeam[];
}

@ObjectType()
class field {
  @Field()
  teamAPIId: number;
  @Field(() => [fieldTeam])
  team: fieldTeam[];
}
@ObjectType()
class extras {
  @Field()
  byes: number;
  @Field()
  legbyes: number;
  @Field()
  wides: number;
  @Field()
  noballs: number;
  @Field()
  penalty: number;
  @Field()
  total: number;
}
@ObjectType()
class equations {
  @Field()
  totalRuns: number;
  @Field()
  totalWickets: number;
  @Field()
  overs: string;
  @Field()
  bowlers_used: number;
  @Field()
  runrate: string;
}

@ObjectType()
class dnbTeam {
  @Field()
  playerName: string;
  @Field()
  playerId: number;
}

@ObjectType()
class DNB {
  @Field()
  teamAPIId: number;
  @Field(() => [dnbTeam])
  team: dnbTeam[];
}

@ObjectType()
class Inning {
  @Field()
  inningsNumber: number;
  @Field(() => extras)
  extras: extras;
  @Field(() => equations)
  equations: equations;
  @Field(() => Bat)
  bat: Bat;
  @Field(() => Bowl)
  bowl: Bowl;
  @Field(() => field)
  fielders: field;
  @Field(() => DNB)
  didNotBat: DNB;
}

@Schema()
@ObjectType()
export class scorecards {
  @Field()
  @Prop()
  fixtureAPIId: number;
  @Field({ nullable: true, defaultValue: 0 })
  @Prop()
  seriesAPIId?: number;
  @Field()
  @Prop()
  fixtureType: string;
  @Field()
  @Prop()
  maxInningsCount: number;
  @Field()
  @Prop({ type: String })
  fixtureStatusNote: string;
  @Field()
  @Prop()
  currentInnings?: number;
  @Field()
  @Prop()
  fixtureStatus: string;
  @Field(() => TeamDetails)
  @Prop()
  teams: TeamDetails;
  @Field(() => [Inning])
  @Prop()
  innings?: Inning[];
  @Field(() => Toss)
  @Prop()
  toss?: Toss;
  @Field(() => graphqlTypeJson)
  @Prop({ type: Object })
  playerPerformance?: any;
}

@ObjectType()
export class scoreCardData extends PartialType(score_defaultFields) {
  @Field(() => scorecards, { nullable: true })
  data: scorecards;
}
export const ScorecardSchema = SchemaFactory.createForClass(scorecards);
