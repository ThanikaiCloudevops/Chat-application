import { ObjectType, Field } from '@nestjs/graphql';

@ObjectType()
export class score_message {
  @Field({ nullable: true })
  message: string;
  @Field({ nullable: true, defaultValue: '' })
  location: string;
}

// @ObjectType()
// class score_dataFields {
//   @Field({ nullable: true })
//   token: string;
//   @Field({ nullable: true })
//   user_id: string;
//   @Field({ nullable: true })
//   email: string;
//   @Field({ nullable: false })
//   profileStatus: boolean;
// }

@ObjectType()
export class score_defaultFields {
  @Field()
  status: boolean;

  @Field({ nullable: true })
  error: score_message;

  @Field({ nullable: true })
  success: score_message;
}
// @ObjectType()
// export class JsonResponse extends PartialType(score_defaultFields) {
//   @Field({ nullable: true })
//   data?: score_dataFields;
// }
