import { GraphQLError } from 'graphql';

const errorMsg = {
  getallcontets: 'No Contests Found',
  invalidTeam: 'Not a valid team',
  duplicate: 'Team already exist',
  retrived: 'No Data Found',
  scorecard: 'Unable to fetch scorecard',
};
export function commonErrors(errorType: string, data: any = null) {
  return { status: false, error: { message: errorMsg[errorType] }, data };
}
export function handleException(error) {
  throw new GraphQLError(error, {
    extensions: {
      code: 'FORBIDDEN',
    },
  });
}
