export const MODULE = { NAME: 'Score Card Module', PORT: 4000 };
export const DB = {
  URL: 'mongodb+srv://sciflare:HEO6yUFoS7tmk3w0@krayzz22.vh8chph.mongodb.net/krayzz22',
};

export const TRPC = {
  //dev
  USERAUTH: 'http://3.7.135.45:5000/trpc/userauth',
  CRICKETGAME: 'http://3.7.135.45:5001/trpc/game',
  // Local
  // USERAUTH: 'http://localhost:5000/trpc/userauth',
  // CRICKETGAME: 'http://localhost:5001/trpc/game',
};
