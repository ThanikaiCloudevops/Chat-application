import { GraphQLError } from 'graphql';

const errorMsg = {
  getallcontets: 'No Contests Found',
  joincontest: 'Contest not found for the fixture',
  teamcreation: 'Team creation error',
  contestfull: 'Max amount of teams reached',
  maxim: 'spots / entry fee crossed maximum count ',
};

export function commonErrors(errorType: string, data: any = null) {
  return { status: false, error: { message: errorMsg[errorType] }, data };
}
export function handleException(error) {
  throw new GraphQLError(error, {
    extensions: {
      code: 'FORBIDDEN',
    },
  });
}
