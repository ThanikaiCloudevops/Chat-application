import { ObjectType, Field } from '@nestjs/graphql';

@ObjectType()
export class master_message {
  @Field({ nullable: true, defaultValue: '' })
  message: string;
  @Field({ nullable: true, defaultValue: '' })
  location: string;
}

@ObjectType()
export class master_defaultFields {
  @Field()
  status: boolean;

  @Field({ nullable: true })
  error: master_message;

  @Field({ nullable: true })
  success: master_message;
}

// an optional type //data?: Prettify<dataFields>;
export type Prettify<T> = {
  [K in keyof T]: T[K];
} & object;
