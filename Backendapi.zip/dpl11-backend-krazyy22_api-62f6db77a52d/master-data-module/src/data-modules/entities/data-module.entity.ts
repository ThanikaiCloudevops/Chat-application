import { ObjectType, Field, PartialType } from '@nestjs/graphql';
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { master_defaultFields } from 'src/commonResponse/response.entity';

export type contestMasterDocument = ContestFilter & Document;

@ObjectType()
class filterDatas {
  @Field()
  key: string;
  @Field(() => [String])
  value: [string];
}

@ObjectType()
@Schema()
export class ContestFilter {
  @Field(() => [filterDatas])
  @Prop()
  EntryFee: filterDatas[];
  @Field(() => [filterDatas])
  @Prop()
  SpotsCount: filterDatas[];
  @Field(() => [filterDatas])
  @Prop()
  PrizePool: filterDatas[];
  @Field(() => [filterDatas])
  @Prop()
  ContestTypes: filterDatas[];
}

@ObjectType()
export class DataModule extends PartialType(master_defaultFields) {
  @Field()
  data: ContestFilter;
}

export const MasterSchema = SchemaFactory.createForClass(ContestFilter);
