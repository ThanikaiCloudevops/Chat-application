import { Resolver, Query, Args } from '@nestjs/graphql';
import { DataModulesService } from './data-modules.service';
import { DataModule } from './entities/data-module.entity';
import { winnerList } from './entities/private-contest.entity';

@Resolver(() => DataModule)
export class DataModulesResolver {
  constructor(private readonly dataModulesService: DataModulesService) {}

  @Query(() => DataModule, { name: 'contestFilterMaster' })
  findOne() {
    return this.dataModulesService.filterContestData();
  }

  @Query(() => winnerList, { name: 'privateContestWinningData' })
  winnerList(
    @Args('spots') spots: number,
    @Args('entryFee') entryFee: number,
    @Args('entryType') entryType: number,
  ) {
    return this.dataModulesService.winnerListData(spots, entryFee, entryType);
  }
}
