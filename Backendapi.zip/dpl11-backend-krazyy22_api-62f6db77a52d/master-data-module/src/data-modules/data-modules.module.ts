import { Module } from '@nestjs/common';
import { DataModulesService } from './data-modules.service';
import { DataModulesResolver } from './data-modules.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import { ContestFilter, MasterSchema } from './entities/data-module.entity';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: ContestFilter.name, schema: MasterSchema },
    ]),
  ],
  providers: [DataModulesResolver, DataModulesService],
})
export class DataModulesModule {}
