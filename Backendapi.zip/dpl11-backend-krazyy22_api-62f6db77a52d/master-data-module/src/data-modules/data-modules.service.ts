import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { successResponse } from 'src/commonResponse/success';
import { contestMasterDocument } from './entities/data-module.entity';
import { PRIVATE_CONTEST } from 'config/envirnment';
import { commonErrors } from 'src/commonResponse/errors';

@Injectable()
export class DataModulesService {
  constructor(
    @InjectModel('ContestFilter')
    private contestMaster: Model<contestMasterDocument>,
  ) {}
  async filterContestData() {
    const data = await this.contestMaster.findOne();
    return successResponse('contestmaster', data);
  }

  async winnerListData(spots: number, entryFee: number, entryType: number) {
    const { MAX_ENTRY_FEE, MAX_SPOTS, SHARE_PERCENTAGE, NUMBER_OF_WINNERS } =
      PRIVATE_CONTEST;
    const spot_split = spots / 2;
    if (spots > MAX_SPOTS || entryFee > MAX_ENTRY_FEE)
      return commonErrors('maxim');

    const maxAmount = entryFee * spots;
    const sharedAmount = (maxAmount / 100) * 30;

    const winnerList_arr = Object.keys(NUMBER_OF_WINNERS)
      .filter((ite) => +ite <= spot_split)
      .reverse();

    const winnerList = winnerList_arr.map((value) => {
      return {
        key: `_${value}`,
        value,
        winnerTable: NUMBER_OF_WINNERS[value].map(
          (value: { RANK: any; PERCENTAGE: any }) => {
            const rankSplit = value.RANK.split('-');

            return {
              rank: value.RANK,
              percentage: value.PERCENTAGE,
              winningPrize: +(
                ((maxAmount - sharedAmount) / 100) *
                value.PERCENTAGE
              ).toFixed(2),
            };
          },
        ),
      };
    });

    // const winnerTable = winnerList_arr.reduce((obj, ite) => {
    //   obj[`_${ite}`] =
    //   return obj;
    // }, {});
    const winners = {
      winnerCount: 0,
      firstPrize: 0,
    };
    const payload = {
      maxPrizePool: maxAmount - sharedAmount,
      winnerList,
      winners,
    };

    return successResponse('', payload);
  }
}
