import { InputType, Int, Field } from '@nestjs/graphql';

@InputType()
export class CreateDataModuleInput {
  @Field(() => Int, { description: 'Example field (placeholder)' })
  exampleField: number;
}
