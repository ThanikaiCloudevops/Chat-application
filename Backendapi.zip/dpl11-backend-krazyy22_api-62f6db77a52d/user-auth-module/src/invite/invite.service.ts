import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { successResponse } from 'src/commonResponse/success';
import { mailSender } from 'src/helpers/ses.mail.helper';
import { TEMPLATE } from 'src/template/mailTemplates';
import { pointDocument } from 'src/user/entities/point.entity';

@Injectable()
export class InviteService {
  constructor(
    private mailService: mailSender,
    @InjectModel('Point')
    private pointsModel: Model<pointDocument>,
  ) {}

  async sendAppLink(email: string) {
    try {
      await this.mailService.sendEmail(
        [
          email,
          // 'karthik.j@sciflare.com',
          // 'davidwyatt309@gmail.com',
        ],
        'Krayzz22 installation',
        TEMPLATE.INVITE(email.split('@')[0]),
      );
      return successResponse('app');
    } catch (err) {}
  }

  async getPoints() {
    try {
      const data = await this.pointsModel.find();
      return { status: true, message: 'Data found', data: data };
    } catch (err) {
      console.log(err);
      return { status: true, message: 'Data found', data: [] };
    }
  }
}
