import { Injectable } from '@nestjs/common';
import { CreateUserMetaInput } from './dto/create-user-meta.input';
import { successResponse } from 'src/commonResponse/success';
import { UserMetaDocument } from './entities/user-meta.entity';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

@Injectable()
export class UserMetaService {
  constructor(
    @InjectModel('UserMeta') private UserMetaModel: Model<UserMetaDocument>,
  ) {}
  async create(createUserMetaInput: CreateUserMetaInput, userId: string) {
    const { metaType, metadata } = createUserMetaInput;
    await this.UserMetaModel.create({
      userId,
      metadata,
      metaType,
      createdAt: new Date(),
    });

    return successResponse('meta');
  }
}
