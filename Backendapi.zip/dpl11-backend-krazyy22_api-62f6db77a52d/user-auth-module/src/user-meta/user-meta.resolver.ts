import { Resolver, Mutation, Args, Context } from '@nestjs/graphql';
import { UserMetaService } from './user-meta.service';
import { UserMeta } from './entities/user-meta.entity';
import { CreateUserMetaInput } from './dto/create-user-meta.input';
import { JsonResponse } from 'src/commonResponse/response.entity';
import { UseGuards } from '@nestjs/common';
import { AuthGuard } from 'src/auth/auth.guard';

@Resolver()
@UseGuards(AuthGuard)
export class UserMetaResolver {
  constructor(private readonly userMetaService: UserMetaService) {}

  @Mutation(() => JsonResponse)
  createUserMeta(
    @Context('user') user: any,
    @Args('createUserMetaInput') createUserMetaInput: CreateUserMetaInput,
  ) {
    return this.userMetaService.create(createUserMetaInput, user._id);
  }
}
