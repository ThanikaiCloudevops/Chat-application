import { Injectable } from '@nestjs/common';
import { sign, verify, decode } from 'jsonwebtoken';

const secert = '123ABCcba!@#';
const Exp = '7d';
const otpExp = 60 * 5;

@Injectable()
export class AuthService {
  generateJWT(userInput: any, otp: any = null) {
    userInput = userInput?.toJSON() || this.otpGeneration();
    if (otp) userInput.credential = otp;

    return sign(userInput, secert, {
      algorithm: 'HS256',
      expiresIn: otp ? otpExp : Exp,
    });
  }

  otpGeneration() {
    const OTP = Math.floor(100000 + Math.random() * 900000);
    // const OTP = 123456;
    return { OTP };
  }

  verifyToken(token: string): any {
    return verify(token, secert);
  }

  decodeToken(token: string) {
    return decode(token);
  }
}
