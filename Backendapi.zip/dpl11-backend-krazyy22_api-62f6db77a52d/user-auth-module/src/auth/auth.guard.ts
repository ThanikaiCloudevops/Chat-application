import {
  CanActivate,
  ExecutionContext,
  HttpException,
  HttpStatus,
  Injectable,
} from '@nestjs/common';
import { GqlExecutionContext } from '@nestjs/graphql';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private auth: AuthService) {}

  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    const ctx = GqlExecutionContext.create(context).getContext();
    try {
      const token = ctx.req.headers?.authorization.split(' ')[1];
      const verify = this.auth.verifyToken(token);
      ctx.user = verify;
      return true;
    } catch (error) {
      throw new HttpException('UnAuthendicated', HttpStatus.UNAUTHORIZED);
    }
  }
}
