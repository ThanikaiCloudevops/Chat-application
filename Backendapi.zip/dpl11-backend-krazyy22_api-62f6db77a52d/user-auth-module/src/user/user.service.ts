import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { hash, compare } from 'bcrypt';
import { Model } from 'mongoose';
import { AuthService } from 'src/auth/auth.service';
import { commonErrors, handleException } from 'src/commonResponse/errors';
import { successResponse } from 'src/commonResponse/success';
import { randomBytes } from 'crypto';
import { AWS } from '../../config/envirnment';

import {
  checkEmail,
  loginViaEmail,
  loginViaMobile,
  registerViaEmail,
  verifyEmail,
  verify_OTP,
  ForgotPassword,
  ForgotPasswordVerify,
} from './dto/login-user.input';
import { userDocument } from './entities/user.entity';
import { trpcServices } from 'src/trpc/client/trpc';
import { socialLoginHelper } from './helper/social.helper';
import { mailSender } from 'src/helpers/ses.mail.helper';
import { TEMPLATE } from 'src/template/mailTemplates';
import { Msg91OtpService } from 'src/otp/otp.service';
import { InviteService } from 'src/invite/invite.service';

@Injectable()
export class UserService {
  constructor(
    private msg91service: Msg91OtpService,
    private authService: AuthService,
    private trpcService: trpcServices,
    private mailService: mailSender,

    @InjectModel('User') private userModel: Model<userDocument>,
    private socialLoginService: socialLoginHelper,
    private inviteService: InviteService,
  ) {}

  async isPhoneExist({ phone }: checkEmail) {
    let user: userDocument;

    if (phone) user = await this.userModel.findOne({ phone });
    if (user && !user?.isactive) return commonErrors('block');
    if (phone && user) {
      try {
        await this.loginWithMobile({ phone });
      } catch (error) {
        console.log(error);
      }
      return successResponse('AlreadyExist', { registered: true });
    }

    if (phone) var res: any = await this.regsiterWithMobile({ phone });
    return successResponse('proceed', {
      registered: false,
      token: res?.data?.token,
    });
  }

  async loginWithMobile(loginInput: loginViaMobile) {
    const phone = loginInput.phone;
    if (isNaN(+phone)) return commonErrors('NotaNumber');
    try {
      //Login via phone
      const user = await this.userModel.findOne({
        phone,
        isactive: true,
      });
      if (!user) return commonErrors('invalidUser');
      //User login
      //otp twilio
      // user.OTP = this.authService.generateJWT(null, phone);
      // const otp = this.authService.decodeToken(user.OTP);
      //  const OTP = String(otp['OTP']);
      const response = await this.msg91service.sendOTP(phone, 'login');
      await user.save();
      return successResponse('otpgeneration');
    } catch (error) {
      return handleException(error);
    }
  }

  async loginWithEmail(loginInput: loginViaEmail) {
    try {
      //Login via email
      if (loginInput.email) {
        const User = await this.userModel.findOne({
          email: loginInput.email.toLowerCase(),
        });
        if (!User) return commonErrors('IncorrectEmail');
        if (!User.isactive) return commonErrors('block');

        if (await compare(loginInput.password, User.password || '')) {
          const payload = this.#generatePayload(User);
          User.deviceType = loginInput.deviceType;
          User.deviceToken = loginInput.deviceToken;
          await User.save();
          return successResponse('loggedin', payload);
        }
        return commonErrors('IncorrectPassword');
      }
      return commonErrors('IncorrectPassword');
    } catch (error) {
      console.log(error);
      return commonErrors('IncorrectPassword');
    }
  }

  async regsiterWithMobile(loginInput: loginViaMobile) {
    const phone = loginInput.phone;
    if (isNaN(+phone)) return commonErrors('NotaNumber');
    try {
      const user = await this.userModel.findOne({
        phone,
      });

      if (user) return commonErrors('phoneExist');

      // const otpToken = this.authService.generateJWT(null, loginInput.phone);

      await this.msg91service.sendOTP(phone, 'signup').catch((error) => {
        console.error('Unhandled promise rejection:', error);
      });
      /* 
      await this.userModel.create({
        phone: loginInput.phone,
        OTP: otpToken,
      });
       */
      return successResponse('otpgeneration' /*{ token: otpToken }*/);
    } catch (error) {
      console.log(error.message);
      return handleException(error);
    }
  }

  async OTPverify(verifyOTP: verify_OTP) {
    try {
      const { phone, otp, isNew, token, deviceToken, deviceType } = verifyOTP;
      if (isNaN(+phone)) return commonErrors('NotaNumber');
      let user: any;
      if (isNew) {
        user = new this.userModel({ phone: phone });
      } else user = await this.userModel.findOne({ phone, isactive: true });

      if (!user) return commonErrors('IncorrectPhone');

      const isValidOtp = await this.msg91service.verifyOTP(phone, otp);
      if (isValidOtp['type'] === 'success') {
        const payload = this.#generatePayload(user);
        // user.authToken = payload.token;
        user.deviceType = deviceType;
        user.deviceToken = deviceToken;
        const newUser = isNew ? 'registered' : 'loggedin';
        if (isNew) {
          const length = 6; // Adjust the length as needed
          const randomString = this.generateRandomString(length);
          user.referral = randomString;
          console.log(isNew, 'isnew');
          console.log(user, 'user');
          await this.trpcService.walletCreation('walletcreation', user._id);
          await this.trpcService.userProfile('createUserProfile', user).catch(err => console.log(err));
          // Register bonus TODO
        }

        await user.save();
        return successResponse(newUser, payload);
      } else {
        console.log(isValidOtp['message'], 'here4');
        // TODO: Implement logic for failed OTP verification
        return commonErrors('InvalidOTP', isValidOtp['message']);
      }
    } catch (error) {
      console.log('here5');
      return commonErrors('InvalidOTP');
    }
  }
  // async testing(user: any) {
  //   try {
  //     await this.trpcService.userProfile('createUserProfile', user);
  //   } catch (error) {
  //     console.log(error);
  //   }
  // }

  async regsiterWithEmail(registerInput: registerViaEmail) {
    try {
      const { email } = registerInput;
      const user = await this.userModel.findOne({
        email: email.toLowerCase(),
        isactive: true,
      });

      if (user) return commonErrors('EmailAlreadyExist');

      const otpToken = this.authService.generateJWT(null, email.toLowerCase());

      return successResponse('otpsent', { token: otpToken });
    } catch (error) {
      return handleException(error);
    }
  }

  async linkEmail(userId: string, email: string) {
    try {
      const user = await this.userModel.findById(userId);
      if (!user.isactive) return commonErrors('block');

      if (user.email && user.password)
        return successResponse('AlreadyExist', { emailSet: true });

      const checkDuplicate = await this.userModel.findOne({
        email: email.toLowerCase(),
      });

      if (
        checkDuplicate &&
        checkDuplicate._id.toString() != user._id.toString()
      )
        return commonErrors('emailExist');

      const otpToken = this.authService.generateJWT(null, email.toLowerCase());
      const otpRetrieve = this.authService.decodeToken(otpToken);
      const temp = TEMPLATE.OTP(otpRetrieve['OTP']);
      await this.mailService.sendEmail([email.toLowerCase()], 'otp', temp);
      user.OTP = otpToken;

      await user.save();
      return successResponse('otpsent', { emailSet: false });
    } catch (err) {
      return commonErrors('emailerror');
    }
  }

  async emailVerify(userId: string, otp: number) {
    try {
      const user = await this.userModel.findById(userId);
      if (!user.isactive) return commonErrors('block');
      if (user.email) return commonErrors('emailExist');

      const { credential, OTP } = this.authService.verifyToken(user.OTP);

      // if (otp != OTP) throw new Error();

      user.email = credential;
      await user.save();
      return successResponse('email');
    } catch (err) {
      return commonErrors('InvalidOTP');
    }
  }

  async verifyEmail(verifyEmail: verifyEmail) {
    try {
      const { otp, email, token, deviceToken, deviceType } = verifyEmail;
      const { credential, OTP } = this.authService.verifyToken(token);
      if (credential != email.toLowerCase())
        return commonErrors('IncorrectEmail');

      let checkUser = await this.userModel.findOne({
        email: email.toLowerCase(),
      });
      if (!checkUser.isactive) return commonErrors('block');
      if (checkUser && checkUser.password) return commonErrors('emailExist');

      if (otp != OTP) return commonErrors('InvalidOTP');

      if (!checkUser)
        checkUser = new this.userModel({ email: email.toLowerCase() });
      checkUser.deviceType = deviceType;
      checkUser.deviceToken = deviceToken;
      await checkUser.save();

      return successResponse('email');
    } catch (err) {
      return commonErrors('OTPExp');
    }
  }

  async setUserPassword(
    deviceToken: string,
    password: string,
    referral: string,
    userName: string,
  ) {
    try {
      const user = await this.userModel.findOne({ deviceToken });
      if (!user.isactive) return commonErrors('block');
      if (user.password) return commonErrors('emailExist');

      user.password = await hash(password, 10);
      const length = 6; // Adjust the length as needed
      // const randomString = this.generateRandomString(length);
      // user.referral = randomString;
      if (referral) {
        const referralDetails = await this.userModel.findOne({ referral });
        if (referralDetails) {
          user.ref_from = referralDetails._id;
          user.is_ref = referral;
        } else {
          return commonErrors('invalidReferral');
        }
      }
      user.userName = userName;
      user.profileStatus = true;
      await user.save();
      await this.trpcService.walletCreation('walletcreation', user._id);
      // Register bonus TODO
      return successResponse('registered', this.#generatePayload(user));
    } catch (err) {
      commonErrors('password');
    }
  }

  async referralAdd(userId: string, referral: string, userName: string) {
    try {
      const userref = await this.userModel.findById(userId);

      if (userref) {
        const usernameCheck = await this.userModel
          .find({ userName: { $regex: `^${userName}$`, $options: 'i' } })
          .lean();
        if (usernameCheck.length == 0) {
          userref.userName = userName;
          userref.profileStatus = true;
        } else {
          return commonErrors('username');
        }
        if (referral) {
          const referralDetails = await this.userModel.findOne({ referral });
          if (!referralDetails) {
            return commonErrors('invalidReferral');
          }
          const newref = String(referralDetails._id);
          userref.ref_from = referralDetails._id;
          userref.is_ref = referral;
          const bonusIds = {};
          bonusIds['refFrom'] = newref;
          bonusIds['refTo'] = userId;
          // await this.trpcService.walletUpdation('walletupdation', bonusIds); referral amount added after cash deposit
        }
        userref.save();
        return successResponse('user profile updated', userref);
      }
    } catch (err) {
      return commonErrors('retrieved');
    }
  }

  // social login
  async socialLogin(token: string, type: number) {
    let payload: any;

    switch (type) {
      case 1:
        payload = await this.socialLoginService.googleLogin(token);
        break;
      case 2:
        payload = await this.socialLoginService.facebookLogin(token);
        break;
      case 3:
        payload = await this.socialLoginService.appleLogin(token);
        break;
      default:
        payload = {};
    }

    if (!payload?.email) return commonErrors('IncorrectEmail');

    const userExists = await this.userModel.findOne({
      email: payload.email,
    });
    if (userExists && !userExists.isactive) return commonErrors('block');
    if (!userExists) {
      return commonErrors('IncorrectEmail');
    } else {
      const payload = this.#generatePayload(userExists);
      return successResponse('loggedin', payload);
    }
  }

  async updatePassword(userId: string, password: string) {
    const user = await this.userModel.findById(userId);
    if (!user.isactive) return commonErrors('block');
    await this.userModel.findByIdAndUpdate(userId, {
      password: await hash(password, 10),
    });
    return successResponse('password');
  }

  async updatePhoneEmail(userId: string, phone?: string, email?: string) {
    const user = await this.userModel.findById(userId);
    if (!user.isactive) return commonErrors('block');

    if (!phone && !email) return commonErrors('NotaNumber', {});
    if (phone && (await this.userModel.findOne({ phone })))
      return commonErrors('phoneExist', {});
    if (email && (await this.userModel.findOne({ email: email.toLowerCase() })))
      return commonErrors('EmailAlreadyExist', {});

    const token = this.authService.generateJWT(
      null,
      phone ? phone : email.toLowerCase(),
    );
    await this.userModel.findByIdAndUpdate(userId, { updateToken: token });

    return successResponse('otpsent', {});
  }

  async verifyUpdate(userId: string, phone: boolean, otp: string) {
    const user = await this.userModel.findById(userId);
    if (!user.isactive) return commonErrors('block');

    const { OTP, credential } = this.authService.verifyToken(user.updateToken);
    if (OTP != otp) return commonErrors('InvalidOTP', {});
    if (phone) user.phone = credential;
    else user.email = credential;
    await user.save();
    user.updateToken = '';
    const payload = this.#generatePayload(user);
    return successResponse('update', payload);
  }

  async updateUserProfile(updateStatus: any) {
    await this.userModel.findByIdAndUpdate(updateStatus.userId, updateStatus);
    return { status: true };
  }

  async getUserbyPhone(phone: any) {
    return await this.userModel.findOne({ phone });
  }

  async findOne(id: string) {
    const user = await this.userModel.findById(id);
    return successResponse('retrieved', user);
  }

  #generatePayload(payload: any) {
    const token = this.authService.generateJWT(payload);
    return {
      token,
      user_id: payload?._id,
      email: payload?.email,
      profileStatus: payload?.profileStatus,
    };
  }

  generateRandomString(length: number): string {
    const randomBytesBuffer = randomBytes(Math.ceil(length / 2));
    return randomBytesBuffer.toString('hex').slice(0, length);
  }

  async verifyMiddleware(token: string): Promise<any> {
    try {
      const tokenDecrypt = await this.authService.verifyToken(token);
      const user = await this.userModel.findById(tokenDecrypt._id);
      if (!user.isactive) throw new Error('User restricted');
      user.lastLoginTime = new Date();
      await user.save();
      return user;
    } catch (err) {
      throw new Error(err.message);
    }
  }

  async authTokenVerify(token: string) {
    try {
      const verifyToken = await this.verifyMiddleware(token);
      return successResponse('auth', verifyToken);
    } catch (err) {
      console.log(err);
      return commonErrors('auth');
    }
  }

  async setFCM(_id: string, deviceType: string, deviceToken: string) {
    try {
      const user = await this.userModel.findById(_id);
      if (!user.isactive) return commonErrors('block');

      user.deviceType = deviceType;
      user.deviceToken = deviceToken;
      await user.save();
      return successResponse('fcm');
    } catch (err) {
      return commonErrors('fcm');
    }
  }

  async Logout(_id: string) {
    try {
      const user = await this.userModel.findById(_id);
      user.deviceToken = '';
      user.deviceType = '';
      await user.save();
      return successResponse('logout');
    } catch (err) {
      return commonErrors('logout');
    }
  }

  async sendAppLink(email: string) {
    await this.inviteService.sendAppLink(email);
    return successResponse('app');
  }

  async points() {
    const points = await this.inviteService.getPoints();
    return successResponse('found', points.data);
  }

  async testMail() {
    await this.mailService.readMail();
    return 'Hello there';
  }

  async forgotPassword({ email }: ForgotPassword) {
    try {
      let user: userDocument;
      if (email)
        user = await this.userModel.findOne({ email: email.toLowerCase() });

      if (!user.isactive) return commonErrors('block');
      if (email && user) {
        const otpToken = this.authService.generateJWT(
          null,
          email.toLowerCase(),
        );
        const otpRetrieve = this.authService.decodeToken(otpToken);
        const user = await this.userModel.findOne({
          email: email.toLowerCase(),
        });
        const temp = TEMPLATE.OTP(otpRetrieve['OTP']);
        await this.mailService.sendEmail([email.toLowerCase()], 'otp', temp);
        return successResponse('ForgotPassword', { token: otpToken });
      } else {
        return commonErrors('proceed');
      }
    } catch (error) {
      return commonErrors('forgotEmail');
    }
  }

  async forgotPasswordVerify(ForgotPasswordVerify: ForgotPasswordVerify) {
    const { otp, token } = ForgotPasswordVerify;
    try {
      const otpRetrieve = this.authService.decodeToken(token);
      const email = otpRetrieve['credential'];
      // email && otp Replace
      if (email && otp) {
        //otp == otpRetrieve['OTP'] replace
        if (otp == otpRetrieve['OTP']) {
          return successResponse('otpVerify');
        } else {
          return commonErrors('InvalidOTP');
        }
      }
    } catch (error) {
      return commonErrors('InvalidOTP');
    }
  }

  async passwordSet(token: string, password: string) {
    try {
      const Token = this.authService.decodeToken(token);
      const newPassword = await hash(password, 10);

      const userCheck = await this.userModel.findOne({
        email: Token['credential'],
      });
      if (!userCheck.isactive) return commonErrors('block');
      const user = await this.userModel.findOneAndUpdate(
        { email: Token['credential'] },
        { password: newPassword },
      );
      return successResponse('password');
    } catch (error) {
      return commonErrors('password');
    }
  }

  async referralList(user: any) {
    try {
      const refList = await this.userModel.find({ ref_from: user._id });

      const reflistIds: any = { ref_to: refList.map((e) => e._id.toString()) };
      reflistIds.ref_from = user._id;

      const userwallet = await this.trpcService.transactions(
        'gettransactions',
        reflistIds,
      );
      const userId = await this.userModel.findOne({ _id: user._id });
      userwallet['referralCode'] = userId.referral;
      return successResponse('referral', userwallet);
    } catch (error) {
      return commonErrors('retrieved');
    }
  }

  async helpEmail(user: any, email: string, description: string) {
    try {
      const emailcheck = email.includes('@');
      if (!emailcheck) return commonErrors('InvalidEmail');
      if (!description) return commonErrors('required');
      const username = user.userName;
      const temp = TEMPLATE.HELPEMAIL(
        email.toLowerCase(),
        username,
        description,
      );
      await this.mailService.sendEmail([`${AWS.SES.MAIL}`], 'Help Email', temp);
      return successResponse('ForgotPassword');
    } catch (error) {
      return commonErrors(error);
    }
  }

  async metaDataDump(user, userData) {
    try {
      return { status: true, message: 'success' };
    } catch (err) {
      return { status: false, message: 'error' };
    }
  }

  async usernameUniqueCheck(user, userName) {
    try {
      const usercheck = await this.userModel
        .find({ userName: { $regex: `^${userName}$`, $options: 'i' } })
        .lean();
      if (usercheck.length == 0) return successResponse('userName');
      return commonErrors('username');
    } catch (error) {
      return commonErrors('username');
    }
  }
}
