import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UserResolver } from './user.resolver';
import { User, UserSchema } from './entities/user.entity';
import { MongooseModule } from '@nestjs/mongoose';
import { AuthService } from 'src/auth/auth.service';
import { trpcServices } from 'src/trpc/client/trpc';
import { socialLoginHelper } from './helper/social.helper';
import { mailSender } from 'src/helpers/ses.mail.helper';
import { Msg91OtpService } from 'src/otp/otp.service';
import { InviteService } from 'src/invite/invite.service';
import { Point, PointsSchema } from './entities/point.entity';
@Module({
  imports: [
    MongooseModule.forFeature([{ name: User.name, schema: UserSchema }]),
    MongooseModule.forFeature([{ name: Point.name, schema: PointsSchema }]),
  ],
  providers: [
    UserResolver,
    UserService,
    AuthService,
    trpcServices,
    socialLoginHelper,
    mailSender,
    Msg91OtpService,
    InviteService,
  ],
  exports: [Msg91OtpService],
})
export class UserModule {}
