import { InputType, Int, Field } from '@nestjs/graphql';
import { IsDate, IsEmail, IsIn, Length, Matches } from 'class-validator';

@InputType()
export class CreateUserInput {
  @Field()
  @Length(15, 25)
  firstName: string;

  @Field()
  @Length(15, 25)
  lastName?: string;

  @Field()
  @IsEmail()
  email: string;

  @Field()
  @IsDate()
  DOB: string;

  @Field()
  @IsIn(['Male', 'Female'])
  gender: string;

  @Field()
  country: string;

  @Field(() => Int)
  zipcode: number;

  @Field()
  phone: string;

  @Field({ nullable: true })
  @Matches(/((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/)
  password?: string;
}
