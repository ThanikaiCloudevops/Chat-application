import { IsEmail, IsOptional, Length } from 'class-validator';
import { CreateUserInput } from './create-user.input';
import { Field, InputType, PartialType } from '@nestjs/graphql';

@InputType()
export class UpdateUserInput extends PartialType(CreateUserInput) {}

@InputType()
export class updatePhoneEmail {
  @Field({ nullable: true })
  @Length(8, 12)
  @IsOptional()
  phone?: string;

  @Field({ nullable: true })
  @IsEmail()
  @IsOptional()
  email?: string;
}
