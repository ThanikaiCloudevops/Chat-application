export const MODULE = { NAME: 'User Auth Module', PORT: 5000 };
export const DB = {
  URL: 'mongodb+srv://sciflare:HEO6yUFoS7tmk3w0@krayzz22.vh8chph.mongodb.net/krayzz22',
};

export const MSG91APIKEY = {
  MSG91_AUTH_KEY: '422152A0TdQQ7tei665097e0P1',
  MSG91_TEMPLATE_ID_SIGNUP: '6687cb3cd6fc05346d602e52',
  MSG91_TEMPLATE_ID_LOGIN: '6688e3e6d6fc0514ff11b723',
};
export const TRPC = {
  TRANSACTION: 'http://3.7.135.45:5005/trpc/wallet',
  // TRANSACTION: 'http://localhost:5005/trpc/wallet',
  USERMODULE: 'http://3.7.135.45:5004/trpc/userprofile',
  // USERMODULE: 'http://localhost:5004/trpc/userprofile',
};

export const GOOGLE = {
  CLIENT_ID: '',
  CLIENT_SECRET: '',
};

export const FACEBOOK = {
  APP_ID: '',
  APP_SECRET: '',
  verifyURL: 'https://graph.facebook.com/me?fields=id,name,email&access_token',
};

export const APPLE = {
  clientId: 'com.kassket.krazyy22',
};

export const AWS = {
  AWS_ACCESSKEY: 'AKIAZBYTQMX76XLZIZ4',
  AWS_SECRET: '32FVl01fD32s16ESi6VHu/heGXiONHt01baHLd3',
  S3_REGION: 'ap-south-1',
  S3_BUCKET: 'a11',
  SES: {
    SES_REGION: 'us-east-1',
    AWS_ACCESSKEY: 'AKIA4CDUU23WTKEEDWFS',
    AWS_SECRET: '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',
    MAIL: 'support@krazyy22.in',
    IAM_USER_NAME: 'Sciflare_SES_AD11',
    SMTP_USER_NAME: 'AKIAZTUNCOOLT2676MB',
    SMTP_PASSWORD: 'BEjsyB/OYLJPnStRX88JTa2WQdBpXlVlHWjysy+c1x2',
  },
};
